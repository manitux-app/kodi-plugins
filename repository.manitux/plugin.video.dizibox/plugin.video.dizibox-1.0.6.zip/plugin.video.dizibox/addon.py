from __future__ import absolute_import, unicode_literals
import re
import sys
import time
import os
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
try:
    from urllib.parse import parse_qsl, quote, urlencode
except ImportError:
    from urlparse import parse_qsl
    from urllib import quote, urlencode
from resources.lib.site import DiziBoxSite
MANITUXUI_LIB = os.path.join(xbmcaddon.Addon(id=bytes.fromhex('7363726970742e6d6f64756c652e6d616e697475787569').decode('utf-8')).getAddonInfo(bytes.fromhex('70617468').decode('utf-8')), bytes.fromhex('6c6962').decode('utf-8'))
if MANITUXUI_LIB not in sys.path:
    sys.path.insert(0, MANITUXUI_LIB)
from manituxui import ManituxUI, open_browser
ADDON_ID = bytes.fromhex('706c7567696e2e766964656f2e64697a69626f78').decode('utf-8')
SKIP_GUI_UNTIL = ADDON_ID + bytes.fromhex('2e736b69705f6775695f756e74696c').decode('utf-8')
ADDON = xbmcaddon.Addon(id=ADDON_ID)
HANDLE = int(sys.argv[1])
BASE_URL = ADDON.getSetting(bytes.fromhex('626173655f75726c').decode('utf-8')) or bytes.fromhex('68747470733a2f2f7777772e64697a69626f782e6c697665').decode('utf-8')
UA = ADDON.getSetting(bytes.fromhex('757365725f6167656e74').decode('utf-8')) or bytes.fromhex('4d6f7a696c6c612f352e3020285831313b204c696e7578207838365f363429204170706c655765624b69742f3533372e333620284b48544d4c2c206c696b65204765636b6f29204368726f6d652f3132342e30205361666172692f3533372e3336').decode('utf-8')
RRRRRRRRRRRRRRRR = DiziBoxSite(BASE_URL, UA)

class DiziBoxUI(ManituxUI):
    title = bytes.fromhex('44697a69424f58').decode('utf-8')

    def __init__(self):
        self._last_has_next = False

    def categories(self):
        categories = [{bytes.fromhex('7469746c65').decode('utf-8'): bytes.fromhex('417261').decode('utf-8'), bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('736561726368').decode('utf-8')}]
        for title, url in RRRRRRRRRRRRRRRR.categories():
            categories.append({bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url})
        return categories

    def videos(self, category, page=1):
        if category.get(bytes.fromhex('616374696f6e').decode('utf-8')) == bytes.fromhex('736561726368').decode('utf-8'):
            query = xbmcgui.Dialog().input(bytes.fromhex('44697a69424f5820417261').decode('utf-8'))
            if not query:
                self._last_has_next = False
                return []
            vvvvvvvvv, AAAaAAA = RRRRRRRRRRRRRRRR.search(query)
            self._last_has_next = AAAaAAA
            return [self._art_item(item) for item in vvvvvvvvv]
        vvvvvvvvv, AAAaAAA = RRRRRRRRRRRRRRRR.get_page_items(category[bytes.fromhex('75726c').decode('utf-8')], page)
        self._last_has_next = AAAaAAA
        return [self._art_item(item) for item in vvvvvvvvv]

    def _art_item(self, item):
        G33633612964454 = dict(item)
        image = G33633612964454.get(bytes.fromhex('696d616765').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
        referer = G33633612964454.get(bytes.fromhex('75726c').decode('utf-8')) or BASE_URL + bytes.fromhex('2f').decode('utf-8')
        G33633612964454[bytes.fromhex('696d616765').decode('utf-8')] = art_url(image, referer)
        return G33633612964454

    def has_next_page(self, category, page=1, videos=None):
        return bool(self._last_has_next)

    def detail(self, video):
        IlIllIllIII = video[bytes.fromhex('75726c').decode('utf-8')]
        b75026132298198 = RRRRRRRRRRRRRRRR.detail(IlIllIllIII)
        image = art_url(b75026132298198.get(bytes.fromhex('696d616765').decode('utf-8')) or video.get(bytes.fromhex('696d616765').decode('utf-8'), bytes.fromhex('').decode('utf-8')), IlIllIllIII)
        plot = b75026132298198.get(bytes.fromhex('706c6f74').decode('utf-8')) or video.get(bytes.fromhex('706c6f74').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
        sources = []
        for source in b75026132298198.get(bytes.fromhex('736f7572636573').decode('utf-8'), []):
            sources.append({bytes.fromhex('6c6162656c').decode('utf-8'): source.get(bytes.fromhex('6c6162656c').decode('utf-8')) or bytes.fromhex('4f796e6174').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('72656665726572').decode('utf-8'): source.get(bytes.fromhex('72656665726572').decode('utf-8')) or IlIllIllIII, bytes.fromhex('69735f747261696c6572').decode('utf-8'): source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8'), False)})
        sources = sort_sources(sources)
        S48116929993145 = []
        for episode in b75026132298198.get(bytes.fromhex('657069736f646573').decode('utf-8'), []):
            S48116929993145.append({bytes.fromhex('7469746c65').decode('utf-8'): episode.get(bytes.fromhex('7469746c65').decode('utf-8')) or b75026132298198.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('42c3b66cc3bc6d').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): episode.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('696d616765').decode('utf-8'): art_url(episode.get(bytes.fromhex('696d616765').decode('utf-8')) or image, episode.get(bytes.fromhex('75726c').decode('utf-8')) or IlIllIllIII), bytes.fromhex('706c6f74').decode('utf-8'): plot})
        for R15 in b75026132298198.get(bytes.fromhex('736561736f6e5f6c696e6b73').decode('utf-8'), []):
            S48116929993145.append({bytes.fromhex('7469746c65').decode('utf-8'): R15.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('53657a6f6e').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): R15.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('696d616765').decode('utf-8'): image, bytes.fromhex('706c6f74').decode('utf-8'): plot})
        return {bytes.fromhex('7469746c65').decode('utf-8'): b75026132298198.get(bytes.fromhex('7469746c65').decode('utf-8')) or video.get(bytes.fromhex('7469746c65').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('75726c').decode('utf-8'): IlIllIllIII, bytes.fromhex('696d616765').decode('utf-8'): image, bytes.fromhex('6261636b64726f70').decode('utf-8'): art_url(b75026132298198.get(bytes.fromhex('6261636b64726f70').decode('utf-8')) or b75026132298198.get(bytes.fromhex('66616e617274').decode('utf-8')) or image, IlIllIllIII), bytes.fromhex('706c6f74').decode('utf-8'): plot, bytes.fromhex('79656172').decode('utf-8'): b75026132298198.get(bytes.fromhex('79656172').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('636f756e747279').decode('utf-8'): b75026132298198.get(bytes.fromhex('636f756e747279').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('6475726174696f6e').decode('utf-8'): b75026132298198.get(bytes.fromhex('6475726174696f6e').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('726174696e67').decode('utf-8'): b75026132298198.get(bytes.fromhex('726174696e67').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('74616773').decode('utf-8'): b75026132298198.get(bytes.fromhex('74616773').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('6163746f7273').decode('utf-8'): b75026132298198.get(bytes.fromhex('6163746f7273').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('657069736f646573').decode('utf-8'): S48116929993145, bytes.fromhex('736f7572636573').decode('utf-8'): sources}

    def episode_detail(self, episode, video=None):
        return self.detail(episode)

    def play(self, source, video=None):
        if source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8')):
            play_youtube_gui(source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
        else:
            if play_source_gui(source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), source.get(bytes.fromhex('72656665726572').decode('utf-8')), source.get(bytes.fromhex('6c6162656c').decode('utf-8'), bytes.fromhex('').decode('utf-8'))):
                return
            for qGdabMSmtPFwvuQVaEFMtoyCLwhnbpdDjorXupOllJFbYaTnqJZkMkCHiTwybjjwmaruMPfmFoJrSvz6 in (video or {}).get(bytes.fromhex('736f7572636573').decode('utf-8'), []):
                if qGdabMSmtPFwvuQVaEFMtoyCLwhnbpdDjorXupOllJFbYaTnqJZkMkCHiTwybjjwmaruMPfmFoJrSvz6 is source or qGdabMSmtPFwvuQVaEFMtoyCLwhnbpdDjorXupOllJFbYaTnqJZkMkCHiTwybjjwmaruMPfmFoJrSvz6.get(bytes.fromhex('69735f747261696c6572').decode('utf-8')):
                    continue
                if qGdabMSmtPFwvuQVaEFMtoyCLwhnbpdDjorXupOllJFbYaTnqJZkMkCHiTwybjjwmaruMPfmFoJrSvz6.get(bytes.fromhex('75726c').decode('utf-8')) == source.get(bytes.fromhex('75726c').decode('utf-8')):
                    continue
                if play_source_gui(qGdabMSmtPFwvuQVaEFMtoyCLwhnbpdDjorXupOllJFbYaTnqJZkMkCHiTwybjjwmaruMPfmFoJrSvz6.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), qGdabMSmtPFwvuQVaEFMtoyCLwhnbpdDjorXupOllJFbYaTnqJZkMkCHiTwybjjwmaruMPfmFoJrSvz6.get(bytes.fromhex('72656665726572').decode('utf-8')), qGdabMSmtPFwvuQVaEFMtoyCLwhnbpdDjorXupOllJFbYaTnqJZkMkCHiTwybjjwmaruMPfmFoJrSvz6.get(bytes.fromhex('6c6162656c').decode('utf-8'), bytes.fromhex('').decode('utf-8'))):
                    return

def build_url(query):
    return sys.argv[0] + bytes.fromhex('3f').decode('utf-8') + urlencode(query)

def art_url(url, referer=None):
    if not url or bytes.fromhex('7c').decode('utf-8') in url or (not url.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8')))):
        return url
    I2 = [bytes.fromhex('557365722d4167656e743d').decode('utf-8') + quote(UA)]
    I2.append(bytes.fromhex('526566657265723d').decode('utf-8') + quote(referer or BASE_URL + bytes.fromhex('2f').decode('utf-8')))
    I2.append(bytes.fromhex('4163636570743d').decode('utf-8') + quote(bytes.fromhex('696d6167652f617669662c696d6167652f776562702c696d6167652f61706e672c696d6167652f2a2c2a2f2a3b713d302e38').decode('utf-8')))
    I2.append(bytes.fromhex('436f6f6b69653d').decode('utf-8') + quote(bytes.fromhex('697354727573746564557365723d747275653b20646278753d7b307d').decode('utf-8').format(int(time.time() * 1000))))
    return url + bytes.fromhex('7c').decode('utf-8') + bytes.fromhex('26').decode('utf-8').join(I2)

def set_art(li, image, referer=None):
    image = art_url(image, referer)
    li.setArt({bytes.fromhex('7468756d62').decode('utf-8'): image, bytes.fromhex('69636f6e').decode('utf-8'): image, bytes.fromhex('706f73746572').decode('utf-8'): image, bytes.fromhex('66616e617274').decode('utf-8'): image})

def add_directory(title, action, url=bytes.fromhex('').decode('utf-8'), image=bytes.fromhex('').decode('utf-8'), plot=bytes.fromhex('').decode('utf-8')):
    li = xbmcgui.ListItem(label=title)
    set_art(li, image, url or BASE_URL + bytes.fromhex('2f').decode('utf-8'))
    li.setInfo(bytes.fromhex('766964656f').decode('utf-8'), {bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('706c6f74').decode('utf-8'): plot})
    xbmcplugin.addDirectoryItem(HANDLE, build_url({bytes.fromhex('616374696f6e').decode('utf-8'): action, bytes.fromhex('75726c').decode('utf-8'): url}), li, True)

def add_video(title, action, url, image=bytes.fromhex('').decode('utf-8'), plot=bytes.fromhex('').decode('utf-8'), extra=None):
    query = {bytes.fromhex('616374696f6e').decode('utf-8'): action, bytes.fromhex('75726c').decode('utf-8'): url}
    if extra:
        query.update(extra)
    li = xbmcgui.ListItem(label=title)
    set_art(li, image, extra.get(bytes.fromhex('72656665726572').decode('utf-8')) if extra else BASE_URL + bytes.fromhex('2f').decode('utf-8'))
    li.setInfo(bytes.fromhex('766964656f').decode('utf-8'), {bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('706c6f74').decode('utf-8'): plot})
    li.setProperty(bytes.fromhex('4973506c617961626c65').decode('utf-8'), bytes.fromhex('74727565').decode('utf-8'))
    xbmcplugin.addDirectoryItem(HANDLE, build_url(query), li, False)

def source_priority(source):
    j742653634585018 = ((source or {}).get(bytes.fromhex('6c6162656c').decode('utf-8'), bytes.fromhex('').decode('utf-8')) + bytes.fromhex('20').decode('utf-8') + (source or {}).get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8'))).lower()
    if (source or {}).get(bytes.fromhex('69735f747261696c6572').decode('utf-8')):
        return 100
    if bytes.fromhex('6f646e6f6b').decode('utf-8') in j742653634585018 or bytes.fromhex('6f6b2e7275').decode('utf-8') in j742653634585018 or bytes.fromhex('6f646e6f6b6c6173736e696b69').decode('utf-8') in j742653634585018:
        return 0
    if bytes.fromhex('6d6f6c79').decode('utf-8') in j742653634585018 or bytes.fromhex('7669646d6f6c79').decode('utf-8') in j742653634585018 or bytes.fromhex('766964656f62696e').decode('utf-8') in j742653634585018:
        return 1
    if bytes.fromhex('646278').decode('utf-8') in j742653634585018 or bytes.fromhex('6b696e67').decode('utf-8') in j742653634585018 or bytes.fromhex('6861796469').decode('utf-8') in j742653634585018:
        return 3
    return 2

def sort_sources(sources):
    return sorted(sources or [], key=source_priority)

def main_menu():
    add_directory(bytes.fromhex('417261').decode('utf-8'), bytes.fromhex('736561726368').decode('utf-8'))
    for title, url in RRRRRRRRRRRRRRRR.categories():
        add_directory(title, bytes.fromhex('6c697374').decode('utf-8'), url)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('747673686f7773').decode('utf-8'))

def list_page(url, page_number=1):
    vvvvvvvvv, AAAaAAA = RRRRRRRRRRRRRRRR.get_page_items(url, page_number)
    for item in vvvvvvvvv:
        add_directory(item[bytes.fromhex('7469746c65').decode('utf-8')], bytes.fromhex('64657461696c').decode('utf-8'), item[bytes.fromhex('75726c').decode('utf-8')], item[bytes.fromhex('696d616765').decode('utf-8')], item[bytes.fromhex('706c6f74').decode('utf-8')])
    if AAAaAAA:
        xbmcplugin.addDirectoryItem(HANDLE, build_url({bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('6c697374').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('70616765').decode('utf-8'): str(int(page_number) + 1)}), xbmcgui.ListItem(label=bytes.fromhex('536f6e72616b69205361796661').decode('utf-8')), True)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('747673686f7773').decode('utf-8'))

def search():
    query = xbmcgui.Dialog().input(bytes.fromhex('44697a69424f5820417261').decode('utf-8'))
    if query:
        vvvvvvvvv, a54966506825611 = RRRRRRRRRRRRRRRR.search(query)
        for item in vvvvvvvvv:
            add_directory(item[bytes.fromhex('7469746c65').decode('utf-8')], bytes.fromhex('64657461696c').decode('utf-8'), item[bytes.fromhex('75726c').decode('utf-8')], item[bytes.fromhex('696d616765').decode('utf-8')], item.get(bytes.fromhex('706c6f74').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
        xbmcplugin.setContent(HANDLE, bytes.fromhex('747673686f7773').decode('utf-8'))

def detail(url):
    b75026132298198 = RRRRRRRRRRRRRRRR.detail(url)
    sources = sort_sources(b75026132298198.get(bytes.fromhex('736f7572636573').decode('utf-8'), []))
    S48116929993145 = b75026132298198.get(bytes.fromhex('657069736f646573').decode('utf-8'), [])
    lllIlIIlIIlIl = [source for source in sources if not source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8'))]
    for source in sources if not S48116929993145 else [source for source in sources if source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8'))]:
        add_video(source[bytes.fromhex('6c6162656c').decode('utf-8')], bytes.fromhex('706c61795f796f7574756265').decode('utf-8') if source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8')) else bytes.fromhex('706c61795f736f75726365').decode('utf-8'), source[bytes.fromhex('75726c').decode('utf-8')], b75026132298198.get(bytes.fromhex('696d616765').decode('utf-8'), bytes.fromhex('').decode('utf-8')), b75026132298198.get(bytes.fromhex('706c6f74').decode('utf-8'), bytes.fromhex('').decode('utf-8')), {bytes.fromhex('72656665726572').decode('utf-8'): source.get(bytes.fromhex('72656665726572').decode('utf-8')) or url, bytes.fromhex('6c6162656c').decode('utf-8'): source[bytes.fromhex('6c6162656c').decode('utf-8')]})
    if not lllIlIIlIIlIl:
        if S48116929993145:
            for episode in S48116929993145:
                title = episode.get(bytes.fromhex('7469746c65').decode('utf-8')) or b75026132298198.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('42c3b66cc3bc6d').decode('utf-8')
                image = episode.get(bytes.fromhex('696d616765').decode('utf-8')) or b75026132298198.get(bytes.fromhex('696d616765').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
                add_directory(title, bytes.fromhex('64657461696c').decode('utf-8'), episode[bytes.fromhex('75726c').decode('utf-8')], image, b75026132298198.get(bytes.fromhex('706c6f74').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
        else:
            for R15 in b75026132298198.get(bytes.fromhex('736561736f6e5f6c696e6b73').decode('utf-8'), []):
                title = R15.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('53657a6f6e').decode('utf-8')
                add_directory(title, bytes.fromhex('64657461696c').decode('utf-8'), R15[bytes.fromhex('75726c').decode('utf-8')], b75026132298198.get(bytes.fromhex('696d616765').decode('utf-8'), bytes.fromhex('').decode('utf-8')), b75026132298198.get(bytes.fromhex('706c6f74').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
    if not sources and (not b75026132298198.get(bytes.fromhex('657069736f646573').decode('utf-8'))) and (not b75026132298198.get(bytes.fromhex('736561736f6e5f6c696e6b73').decode('utf-8'))):
        xbmcgui.Dialog().notification(bytes.fromhex('44697a69424f58').decode('utf-8'), bytes.fromhex('4b61796e616b20766579612062c3b66cc3bc6d2062756c756e616d6164c4b1').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('747673686f7773').decode('utf-8'))

def youtube_plugin_url(url):
    video_id = bytes.fromhex('').decode('utf-8')
    for T320513568159712 in (bytes.fromhex('283f3a796f75747562655c2e636f6d2f656d6265642f7c796f75747562655c2e636f6d2f77617463685c3f763d7c796f7574755c2e62652f29285b412d5a612d7a302d395f2d5d7b362c7d29').decode('utf-8'), bytes.fromhex('5b3f265d763d285b412d5a612d7a302d395f2d5d7b362c7d29').decode('utf-8')):
        mpZspDEOAEUOSFLIVDFIbiemoVuWxKmtwJzRvhzPBFAhmTCyWnCbOZuodBQwZkwiiAxerIOrXEIPqci10 = re.search(T320513568159712, url or bytes.fromhex('').decode('utf-8'), re.I)
        if mpZspDEOAEUOSFLIVDFIbiemoVuWxKmtwJzRvhzPBFAhmTCyWnCbOZuodBQwZkwiiAxerIOrXEIPqci10:
            video_id = mpZspDEOAEUOSFLIVDFIbiemoVuWxKmtwJzRvhzPBFAhmTCyWnCbOZuodBQwZkwiiAxerIOrXEIPqci10.group(1)
            break
    return bytes.fromhex('706c7567696e3a2f2f706c7567696e2e766964656f2e796f75747562652f706c61792f3f766964656f5f69643d').decode('utf-8') + video_id if video_id else bytes.fromhex('').decode('utf-8')

def play_youtube(url):
    llIIIlllIllllI = youtube_plugin_url(url)
    if not llIIIlllIllllI:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    try:
        xbmcaddon.Addon(id=bytes.fromhex('706c7567696e2e766964656f2e796f7574756265').decode('utf-8'))
    except Exception:
        xbmcgui.Dialog().notification(bytes.fromhex('596f7554756265').decode('utf-8'), bytes.fromhex('706c7567696e2e766964656f2e796f757475626520676572656b6c69').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=llIIIlllIllllI))

def play_youtube_gui(url):
    llIIIlllIllllI = youtube_plugin_url(url)
    if not llIIIlllIllllI:
        return False
    try:
        xbmcaddon.Addon(id=bytes.fromhex('706c7567696e2e766964656f2e796f7574756265').decode('utf-8'))
    except Exception:
        xbmcgui.Dialog().notification(bytes.fromhex('596f7554756265').decode('utf-8'), bytes.fromhex('706c7567696e2e766964656f2e796f757475626520676572656b6c69').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
        return False
    xbmc.Player().play(llIIIlllIllllI)
    return True

def play_source(url, referer=None, label=bytes.fromhex('').decode('utf-8')):
    stream, subtitles = RRRRRRRRRRRRRRRR.resolve_source(url, referer, label)
    if not stream:
        xbmcgui.Dialog().notification(bytes.fromhex('44697a69424f58').decode('utf-8'), bytes.fromhex('4b61796e616b20c3a7c3b67ac3bc6c656d656469').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    li = xbmcgui.ListItem(path=stream)
    if is_hls_stream(stream):
        li.setMimeType(bytes.fromhex('6170706c69636174696f6e2f766e642e6170706c652e6d70656775726c').decode('utf-8'))
        li.setContentLookup(False)
        if has_addon(bytes.fromhex('696e70757473747265616d2e6164617074697665').decode('utf-8')):
            li.setProperty(bytes.fromhex('696e70757473747265616d').decode('utf-8'), bytes.fromhex('696e70757473747265616d2e6164617074697665').decode('utf-8'))
            li.setProperty(bytes.fromhex('696e70757473747265616d6164646f6e').decode('utf-8'), bytes.fromhex('696e70757473747265616d2e6164617074697665').decode('utf-8'))
            li.setProperty(bytes.fromhex('696e70757473747265616d2e61646170746976652e6d616e69666573745f74797065').decode('utf-8'), bytes.fromhex('686c73').decode('utf-8'))
            li.setProperty(bytes.fromhex('696e70757473747265616d2e61646170746976652e73747265616d5f68656164657273').decode('utf-8'), stream_headers(stream))
            li.setProperty(bytes.fromhex('696e70757473747265616d2e61646170746976652e6d616e69666573745f68656164657273').decode('utf-8'), stream_headers(stream))
    if subtitles:
        li.setSubtitles(subtitles)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)

def play_source_gui(url, referer=None, label=bytes.fromhex('').decode('utf-8')):
    stream, subtitles = RRRRRRRRRRRRRRRR.resolve_source(url, referer, label)
    return play_stream_gui(stream, subtitles)

def play_stream_gui(stream, subtitles=None):
    if not stream:
        xbmcgui.Dialog().notification(bytes.fromhex('44697a69424f58').decode('utf-8'), bytes.fromhex('4b61796e616b20c3a7c3b67ac3bc6c656d656469').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
        return False
    li = xbmcgui.ListItem(path=stream)
    if is_hls_stream(stream):
        li.setMimeType(bytes.fromhex('6170706c69636174696f6e2f766e642e6170706c652e6d70656775726c').decode('utf-8'))
        li.setContentLookup(False)
        if has_addon(bytes.fromhex('696e70757473747265616d2e6164617074697665').decode('utf-8')):
            li.setProperty(bytes.fromhex('696e70757473747265616d').decode('utf-8'), bytes.fromhex('696e70757473747265616d2e6164617074697665').decode('utf-8'))
            li.setProperty(bytes.fromhex('696e70757473747265616d6164646f6e').decode('utf-8'), bytes.fromhex('696e70757473747265616d2e6164617074697665').decode('utf-8'))
            li.setProperty(bytes.fromhex('696e70757473747265616d2e61646170746976652e6d616e69666573745f74797065').decode('utf-8'), bytes.fromhex('686c73').decode('utf-8'))
            li.setProperty(bytes.fromhex('696e70757473747265616d2e61646170746976652e73747265616d5f68656164657273').decode('utf-8'), stream_headers(stream))
            li.setProperty(bytes.fromhex('696e70757473747265616d2e61646170746976652e6d616e69666573745f68656164657273').decode('utf-8'), stream_headers(stream))
    if subtitles:
        li.setSubtitles(subtitles)
    xbmc.Player().play(stream, li)
    return True

def is_hls_stream(url):
    GGG = (url or bytes.fromhex('').decode('utf-8')).split(bytes.fromhex('7c').decode('utf-8'), 1)[0]
    return bool(re.search(bytes.fromhex('283f3a5c2e6d3375387c6d61737465725c2e7478747c2f656d6265642f736865696c612f7c2f712f5c642b29283f3a5b3f235d2e2a293f24').decode('utf-8'), GGG, re.I))

def stream_headers(url):
    if bytes.fromhex('7c').decode('utf-8') not in (url or bytes.fromhex('').decode('utf-8')):
        return bytes.fromhex('').decode('utf-8')
    return url.split(bytes.fromhex('7c').decode('utf-8'), 1)[1]

def has_addon(addon_id):
    return bool(xbmc.getCondVisibility(bytes.fromhex('53797374656d2e4861734164646f6e287b307d29').decode('utf-8').format(addon_id)))

def run():
    params = dict(parse_qsl(sys.argv[2][1:]))
    action = params.get(bytes.fromhex('616374696f6e').decode('utf-8'))
    url = params.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
    page_number = int(params.get(bytes.fromhex('70616765').decode('utf-8'), bytes.fromhex('31').decode('utf-8')))
    if not action:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
        l19 = xbmcgui.Window(10000)
        try:
            w17 = float(l19.getProperty(SKIP_GUI_UNTIL) or bytes.fromhex('30').decode('utf-8'))
        except ValueError:
            w17 = 0
        if time.time() < w17:
            return
        l19.clearProperty(SKIP_GUI_UNTIL)
        xbmc.executebuiltin(bytes.fromhex('52756e506c7567696e287b307d29').decode('utf-8').format(build_url({bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('677569').decode('utf-8')})))
        return
    elif action == bytes.fromhex('677569').decode('utf-8'):
        open_browser(DiziBoxUI())
        xbmcgui.Window(10000).setProperty(SKIP_GUI_UNTIL, str(time.time() + 4))
        xbmc.executebuiltin(bytes.fromhex('416374697661746557696e646f7728486f6d6529').decode('utf-8'))
        return
    elif action == bytes.fromhex('636c6173736963').decode('utf-8'):
        main_menu()
    elif action == bytes.fromhex('6c697374').decode('utf-8'):
        list_page(url, page_number)
    elif action == bytes.fromhex('736561726368').decode('utf-8'):
        search()
    elif action == bytes.fromhex('64657461696c').decode('utf-8'):
        detail(url)
    elif action == bytes.fromhex('706c61795f736f75726365').decode('utf-8'):
        play_source(url, params.get(bytes.fromhex('72656665726572').decode('utf-8')), params.get(bytes.fromhex('6c6162656c').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
    elif action == bytes.fromhex('706c61795f796f7574756265').decode('utf-8'):
        play_youtube(url)
    xbmcplugin.endOfDirectory(HANDLE)
if __name__ == bytes.fromhex('5f5f6d61696e5f5f').decode('utf-8'):
    run()
