from __future__ import absolute_import, unicode_literals
import base64
import hashlib
import json
import re
import string
import manituxhttp
try:
    from Crypto.Cipher import AES
except Exception:
    AES = None
try:
    from urllib.parse import quote, unquote, urljoin, urlparse, urlunparse
except ImportError:
    from urllib import quote, unquote
    from urlparse import urljoin, urlparse, urlunparse
from . import parsers

class DiziBoxExtractor(object):
    MOLY_DOMAINS = (bytes.fromhex('6d6f6c7973747265616d').decode('utf-8'), bytes.fromhex('736865696c612e73747265616d').decode('utf-8'), bytes.fromhex('706f70636f726e76616b7469').decode('utf-8'), bytes.fromhex('727566696967757461').decode('utf-8'))

    def __init__(self, user_agent, base_url):
        self.user_agent = user_agent
        self.base_url = base_url.rstrip(bytes.fromhex('2f').decode('utf-8'))
        self.session = manituxhttp.Session()

    def resolve(self, url, referer=None, label=bytes.fromhex('').decode('utf-8')):
        if not url:
            return (None, [])
        url = self.normalize_url(url)
        referer = referer or self.base_url + bytes.fromhex('2f').decode('utf-8')
        if bytes.fromhex('2f656d6265642f736865696c612f').decode('utf-8') in url:
            return self.resolve_moly(url, referer, label)
        if self.is_media_url(url):
            return (url + self.kodi_headers(referer), [])
        HpoQaeXCzplJgrclBZwcIWVgVgxLPdwBclEZchTIleKbPCGbUfWBZEjreoXlRPPSPqRpzMVfmojbmkj19 = self.decode_iframe(url, referer)
        if HpoQaeXCzplJgrclBZwcIWVgVgxLPdwBclEZchTIleKbPCGbUfWBZEjreoXlRPPSPqRpzMVfmojbmkj19 and HpoQaeXCzplJgrclBZwcIWVgVgxLPdwBclEZchTIleKbPCGbUfWBZEjreoXlRPPSPqRpzMVfmojbmkj19 != url:
            return self.resolve(HpoQaeXCzplJgrclBZwcIWVgVgxLPdwBclEZchTIleKbPCGbUfWBZEjreoXlRPPSPqRpzMVfmojbmkj19, url, label)
        X226106769836718 = urlparse(url).netloc.lower()
        if self.is_site_player(url):
            return self.resolve_site_player(url, referer, label)
        if bytes.fromhex('7669646d6f6c79').decode('utf-8') in X226106769836718 or bytes.fromhex('766964656f62696e').decode('utf-8') in X226106769836718:
            return self.resolve_vidmoly(url, referer)
        if bytes.fromhex('6f6b2e7275').decode('utf-8') in X226106769836718 or bytes.fromhex('6f646e6f6b6c6173736e696b69').decode('utf-8') in X226106769836718:
            return self.resolve_okru(url)
        if any((e627595020592413 in X226106769836718 for e627595020592413 in self.MOLY_DOMAINS)):
            return self.resolve_moly(url, referer, label)
        page = self.fetch(url, referer)
        HpoQaeXCzplJgrclBZwcIWVgVgxLPdwBclEZchTIleKbPCGbUfWBZEjreoXlRPPSPqRpzMVfmojbmkj19 = parsers.parse_iframe(page, url)
        if HpoQaeXCzplJgrclBZwcIWVgVgxLPdwBclEZchTIleKbPCGbUfWBZEjreoXlRPPSPqRpzMVfmojbmkj19 and HpoQaeXCzplJgrclBZwcIWVgVgxLPdwBclEZchTIleKbPCGbUfWBZEjreoXlRPPSPqRpzMVfmojbmkj19 != url:
            return self.resolve(HpoQaeXCzplJgrclBZwcIWVgVgxLPdwBclEZchTIleKbPCGbUfWBZEjreoXlRPPSPqRpzMVfmojbmkj19, url, label)
        source, y714982853883441 = self.extract_jw(page, url, label or bytes.fromhex('44697a69426f78').decode('utf-8'))
        if source:
            return (source + self.kodi_headers(url), y714982853883441)
        return (url + self.kodi_headers(referer), [])

    def decode_iframe(self, url, referer=None):
        if bytes.fromhex('2f706c617965722f68617964692e706870').decode('utf-8') in url and bytes.fromhex('3f763d').decode('utf-8') in url:
            value = url.split(bytes.fromhex('3f763d').decode('utf-8'), 1)[1].split(bytes.fromhex('26').decode('utf-8'), 1)[0]
            return self._b64(unquote(value))
        if bytes.fromhex('2f706c617965722f6d6f6c792f6d6f6c792e706870').decode('utf-8') in url:
            w35 = url.replace(bytes.fromhex('6d6f6c792e7068703f683d').decode('utf-8'), bytes.fromhex('6d6f6c792e7068703f776d6f64653d6f706171756526683d').decode('utf-8'))
            page = self.fetch(w35, referer)
            bsVrmRzkYHPDJpshucARAEIrgRPeOzDfzjyvCjduyTIJYTYinAOGuQYVKkSrIRJHZAMwHbjIwZWgtPF16 = self._first(bytes.fromhex('756e6573636170655c285b225c275d282e2a3f295b225c275d5c29').decode('utf-8'), page, re.S)
            if bsVrmRzkYHPDJpshucARAEIrgRPeOzDfzjyvCjduyTIJYTYinAOGuQYVKkSrIRJHZAMwHbjIwZWgtPF16:
                WWWWWWWWWW = unquote(bsVrmRzkYHPDJpshucARAEIrgRPeOzDfzjyvCjduyTIJYTYinAOGuQYVKkSrIRJHZAMwHbjIwZWgtPF16)
                HpoQaeXCzplJgrclBZwcIWVgVgxLPdwBclEZchTIleKbPCGbUfWBZEjreoXlRPPSPqRpzMVfmojbmkj19 = parsers.parse_iframe(WWWWWWWWWW, w35)
                if HpoQaeXCzplJgrclBZwcIWVgVgxLPdwBclEZchTIleKbPCGbUfWBZEjreoXlRPPSPqRpzMVfmojbmkj19:
                    return HpoQaeXCzplJgrclBZwcIWVgVgxLPdwBclEZchTIleKbPCGbUfWBZEjreoXlRPPSPqRpzMVfmojbmkj19
                WWWWWWWWWW = self._b64(WWWWWWWWWW)
                HpoQaeXCzplJgrclBZwcIWVgVgxLPdwBclEZchTIleKbPCGbUfWBZEjreoXlRPPSPqRpzMVfmojbmkj19 = parsers.parse_iframe(WWWWWWWWWW, w35)
                if HpoQaeXCzplJgrclBZwcIWVgVgxLPdwBclEZchTIleKbPCGbUfWBZEjreoXlRPPSPqRpzMVfmojbmkj19:
                    return HpoQaeXCzplJgrclBZwcIWVgVgxLPdwBclEZchTIleKbPCGbUfWBZEjreoXlRPPSPqRpzMVfmojbmkj19
            HpoQaeXCzplJgrclBZwcIWVgVgxLPdwBclEZchTIleKbPCGbUfWBZEjreoXlRPPSPqRpzMVfmojbmkj19 = parsers.parse_iframe(page, w35)
            if HpoQaeXCzplJgrclBZwcIWVgVgxLPdwBclEZchTIleKbPCGbUfWBZEjreoXlRPPSPqRpzMVfmojbmkj19:
                return HpoQaeXCzplJgrclBZwcIWVgVgxLPdwBclEZchTIleKbPCGbUfWBZEjreoXlRPPSPqRpzMVfmojbmkj19
        if bytes.fromhex('2f706c617965722f6b696e672f6b696e672e706870').decode('utf-8') in url:
            w35 = url.replace(bytes.fromhex('6b696e672e7068703f763d').decode('utf-8'), bytes.fromhex('6b696e672e7068703f776d6f64653d6f706171756526763d').decode('utf-8'))
            return self.extract_player_target(w35, referer)
        return url

    def resolve_site_player(self, url, referer=None, label=bytes.fromhex('').decode('utf-8')):
        AAAaAAAAaaaAAaaaaaaAaaaAaAaAAaAAAAaaaaaaAaa = self.extract_player_target(url, referer)
        if AAAaAAAAaaaAAaaaaaaAaaaAaAaAAaAAAAaaaaaaAaa and AAAaAAAAaaaAAaaaaaaAaaaAaAaAAaAAAAaaaaaaAaa != url:
            return self.resolve(AAAaAAAAaaaAAaaaaaaAaaaAaAaAAaAAAAaaaaaaAaa, url, label)
        try:
            page = self.fetch(url, referer)
        except (manituxhttp.HTTPError, manituxhttp.RequestError):
            return (None, [])
        source, y714982853883441 = self.extract_jw(page, url, label or bytes.fromhex('44697a69426f78').decode('utf-8'))
        if not source:
            OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO = self.unpack_first_eval(page)
            source = self.media_url(OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO) or self.media_url(page)
        return (source + self.kodi_headers(url) if source else None, y714982853883441)

    def extract_player_target(self, url, referer=None):
        page = self.fetch(url, referer)
        WWWWWWWWWW = self.decode_embedded_html(page)
        AAAaAAAAaaaAAaaaaaaAaaaAaAaAAaAAAAaaaaaaAaa = parsers.parse_iframe(WWWWWWWWWW or page, url)
        if AAAaAAAAaaaAAaaaaaaAaaaAaAaAAaAAAAaaaaaaAaa:
            return AAAaAAAAaaaAAaaaaaaAaaaAaAaAAaAAAAaaaaaaAaa
        source = self.media_url(WWWWWWWWWW) or self.media_url(page)
        if source:
            return source
        OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO = self.unpack_first_eval(page)
        AAAaAAAAaaaAAaaaaaaAaaaAaAaAAaAAAAaaaaaaAaa = parsers.parse_iframe(OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO, url)
        if AAAaAAAAaaaAAaaaaaaAaaaAaAaAAaAAAAaaaaaaAaa:
            return AAAaAAAAaaaAAaaaaaaAaaaAaAaAAaAAAAaaaaaaAaa
        return self.media_url(OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO) or bytes.fromhex('').decode('utf-8')

    def resolve_moly(self, url, referer=None, label=bytes.fromhex('').decode('utf-8')):
        page = self.fetch(url, referer or self.base_url + bytes.fromhex('2f').decode('utf-8'))
        YfMMDtNslBKXRUgvififEtENulUOZfDZiUXPqSRGapNddlLFtTdMQmaRTNIZzFiooBNNuKxsAGenaEG11 = self.decrypt_cryptojs_page(page)
        if YfMMDtNslBKXRUgvififEtENulUOZfDZiUXPqSRGapNddlLFtTdMQmaRTNIZzFiooBNNuKxsAGenaEG11:
            page = YfMMDtNslBKXRUgvififEtENulUOZfDZiUXPqSRGapNddlLFtTdMQmaRTNIZzFiooBNNuKxsAGenaEG11
        source, y714982853883441 = self.extract_jw(page, url, label or bytes.fromhex('4d6f6c7973747265616d').decode('utf-8'))
        if not source:
            source = self._first(bytes.fromhex('68747470733f3a2f2f5b5e5c7322273c3e5d2b3f283f3a5c2e6d3375387c5c2e6d70347c6d61737465725c2e747874295b5e5c7322273c3e5d2a').decode('utf-8'), page)
        if source:
            source = self.resolve_hls_variant(source, url) or source
        return (source + self.kodi_headers(url) if source else None, y714982853883441)

    def resolve_vidmoly(self, url, referer=None):
        candidates = self.vidmoly_candidates(url)
        page = bytes.fromhex('').decode('utf-8')
        page_url = url
        for RRRRRR in candidates:
            try:
                page = self.fetch(RRRRRR, referer or bytes.fromhex('68747470733a2f2f7669646d6f6c792e746f2f').decode('utf-8'))
            except (manituxhttp.HTTPError, manituxhttp.RequestError):
                continue
            page_url = RRRRRR
            if self.has_playable(page):
                break
        if not page:
            return (None, [])
        if self.needs_number_challenge(page):
            S40392032426497 = self.submit_number_challenge(page_url, page, referer)
            if S40392032426497:
                page = S40392032426497
        source, y714982853883441 = self.extract_jw(page, page_url, bytes.fromhex('5669644d6f6c79').decode('utf-8'))
        if not source:
            OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO = self.unpack_first_eval(page)
            source = self.media_url(OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO) or self.media_url(page)
        if source and self.is_hls_url(source):
            source = self.resolve_hls_variant(source, page_url) or source
        return (source + self.kodi_headers(page_url) if source else None, y714982853883441)

    def resolve_okru(self, url):
        video_id = self._first(bytes.fromhex('283f3a766964656f656d6265642f7c2f766964656f2f7c6d69643d29285c642b29').decode('utf-8'), url)
        if not video_id:
            return (url + self.kodi_headers(bytes.fromhex('68747470733a2f2f6f6b2e72752f').decode('utf-8')), [])
        d761022644319939 = self.session.post(bytes.fromhex('68747470733a2f2f7777772e6f6b2e72752f646b').decode('utf-8'), data={bytes.fromhex('636d64').decode('utf-8'): bytes.fromhex('766964656f506c617965724d65746164617461').decode('utf-8'), bytes.fromhex('6d6964').decode('utf-8'): video_id}, headers=self.headers(bytes.fromhex('68747470733a2f2f6f6b2e72752f').decode('utf-8')), timeout=25)
        d761022644319939.raise_for_status()
        source = self._first(bytes.fromhex('283f3a756c7472617c717561647c66756c6c7c68647c73647c6c6f777c6c6f7765737429222c2275726c223a22282e2a3f2922').decode('utf-8'), d761022644319939.text)
        return (source.replace(bytes.fromhex('5c7530303236').decode('utf-8'), bytes.fromhex('26').decode('utf-8')) + self.kodi_headers(bytes.fromhex('68747470733a2f2f6f6b2e72752f').decode('utf-8')) if source else None, [])

    def extract_jw(self, page, page_url, source_name):
        sources = self._extract_sources(page, page_url, source_name)
        y714982853883441 = self._extract_subtitles(page, page_url)
        if sources:
            return (sources[0], y714982853883441)
        source = self._first(bytes.fromhex('5b3a3d5d5c732a5b22275d285b5e22275c735d2b283f3a5c2e6d3375387c5c2e6d70347c6d61737465725c2e7478747c2f656d6265642f736865696c612f295b5e22275c735d2a29').decode('utf-8'), page, re.S)
        return (parsers.fix_url(source.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')), page_url) if source else None, y714982853883441)

    def fetch(self, url, referer=None):
        d761022644319939 = self.session.get(self.normalize_url(url), headers=self.headers(referer), timeout=25, allow_redirects=True)
        d761022644319939.raise_for_status()
        return d761022644319939.text

    def headers(self, referer=None):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): self.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('746578742f68746d6c2c6170706c69636174696f6e2f7868746d6c2b786d6c2c6170706c69636174696f6e2f786d6c3b713d302e392c2a2f2a3b713d302e38').decode('utf-8'), bytes.fromhex('4163636570742d4c616e6775616765').decode('utf-8'): bytes.fromhex('74722d54522c74723b713d302e392c656e2d55533b713d302e382c656e3b713d302e37').decode('utf-8'), bytes.fromhex('5365632d46657463682d44657374').decode('utf-8'): bytes.fromhex('696672616d65').decode('utf-8')}
        if referer:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        return headers

    def kodi_headers(self, referer=None):
        v3 = [bytes.fromhex('557365722d4167656e743d').decode('utf-8') + quote(self.user_agent)]
        if referer:
            v3.append(bytes.fromhex('526566657265723d').decode('utf-8') + quote(referer))
        v3.append(bytes.fromhex('4163636570743d').decode('utf-8') + quote(bytes.fromhex('2a2f2a').decode('utf-8')))
        return bytes.fromhex('7c').decode('utf-8') + bytes.fromhex('26').decode('utf-8').join(v3)

    def normalize_url(self, url):
        url = (url or bytes.fromhex('').decode('utf-8')).strip()
        if url.startswith(bytes.fromhex('2f2f').decode('utf-8')):
            url = bytes.fromhex('68747470733a').decode('utf-8') + url
        elif url.startswith(bytes.fromhex('2f').decode('utf-8')):
            url = urljoin(self.base_url + bytes.fromhex('2f').decode('utf-8'), url)
        elif url.startswith(bytes.fromhex('7777772e').decode('utf-8')):
            url = bytes.fromhex('68747470733a2f2f').decode('utf-8') + url
        elif not url.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8'))):
            url = urljoin(self.base_url + bytes.fromhex('2f').decode('utf-8'), url)
        n32 = urlparse(url)
        return urlunparse(n32._replace(scheme=bytes.fromhex('6874747073').decode('utf-8')))

    def vidmoly_candidates(self, url):
        candidates = []
        self._add_candidate(candidates, re.sub(bytes.fromhex('2f772f285b612d7a302d395d2b292f2a24').decode('utf-8'), bytes.fromhex('2f656d6265642d5c312e68746d6c').decode('utf-8'), url, flags=re.I))
        self._add_candidate(candidates, url)
        AaaaAaaAAaaAaAAAaaaaaAaAaAAaaa = re.sub(bytes.fromhex('68747470733f3a2f2f7669646d6f6c795c2e5b612d7a5d2b').decode('utf-8'), bytes.fromhex('68747470733a2f2f7669646d6f6c792e62697a').decode('utf-8'), url, flags=re.I)
        self._add_candidate(candidates, re.sub(bytes.fromhex('2f772f285b612d7a302d395d2b292f2a24').decode('utf-8'), bytes.fromhex('2f656d6265642d5c312e68746d6c').decode('utf-8'), AaaaAaaAAaaAaAAAaaaaaAaAaAAaaa, flags=re.I))
        self._add_candidate(candidates, AaaaAaaAAaaAaAAAaaaaaAaAaAAaaa)
        self._add_candidate(candidates, re.sub(bytes.fromhex('2f656d6265642d285b612d7a302d395d2b295c2e68746d6c').decode('utf-8'), bytes.fromhex('2f772f5c31').decode('utf-8'), AaaaAaaAAaaAaAAAaaaaaAaAaAAaaa, flags=re.I))
        return candidates

    def submit_number_challenge(self, page_url, page, referer=None):
        OO = self._first(bytes.fromhex('283f3a506c656173652073656c6563747c53656c656374206e756d626572295c732b285c642b29').decode('utf-8'), page)
        if not OO:
            OO = self._first(bytes.fromhex('3c283f3a6469767c7370616e295b5e3e5d2b636c6173733d5b275c225d5b5e275c225d2a7668696e745b5e275c225d2a5b275c225d5b5e3e5d2a3e2e2a3f3c625b5e3e5d2a3e285c642b293c2f623e').decode('utf-8'), page, re.S)
        aAaaa = {bytes.fromhex('6f70').decode('utf-8'): self._input_value(page, bytes.fromhex('6f70').decode('utf-8')), bytes.fromhex('66696c655f636f6465').decode('utf-8'): self._input_value(page, bytes.fromhex('66696c655f636f6465').decode('utf-8')), bytes.fromhex('616e73776572').decode('utf-8'): OO}
        for name in (bytes.fromhex('7473').decode('utf-8'), bytes.fromhex('6e6f6e6365').decode('utf-8'), bytes.fromhex('63746f6b').decode('utf-8')):
            value = self._input_value(page, name)
            if value:
                aAaaa[name] = value
        if not aAaaa[bytes.fromhex('6f70').decode('utf-8')] or not aAaaa[bytes.fromhex('66696c655f636f6465').decode('utf-8')] or (not aAaaa[bytes.fromhex('616e73776572').decode('utf-8')]):
            return bytes.fromhex('').decode('utf-8')
        d761022644319939 = self.session.post(page_url, data=aAaaa, headers=self.headers(referer or page_url), timeout=25)
        d761022644319939.raise_for_status()
        return d761022644319939.text

    def _extract_sources(self, page, page_url, source_name):
        aAAaAaaaAAAAAAAAaAaaaaAAaAAAaaAAAaaAAaAA = []
        for aAAa in re.findall(bytes.fromhex('5b22275d3f736f75726365735b22275d3f5c732a3a5c732a285c5b2e2a3f5c5d29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            for i258649039968222 in self._parse_js_list(aAAa):
                if not isinstance(i258649039968222, dict):
                    continue
                t17 = i258649039968222.get(bytes.fromhex('66696c65').decode('utf-8')) or i258649039968222.get(bytes.fromhex('737263').decode('utf-8'))
                if not t17:
                    continue
                label = i258649039968222.get(bytes.fromhex('6c6162656c').decode('utf-8'))
                aAAaAaaaAAAAAAAAaAaaaaAAaAAAaaAAAaaAAaAA.append(parsers.fix_url(t17.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')), page_url))
        if not aAAaAaaaAAAAAAAAaAaaaaAAaAAAaaAAAaaAAaAA:
            for LtdgRjPzrduiTXfRNYBbLhansPUjRBheSkPcTTaeIersssyHlxJCTuMlULaTUlNjNFPtDWlEINPeMKH29 in re.finditer(bytes.fromhex('68747470733f3a2f2f5b5e5c7322273c3e5d2b3f283f3a5c2e6d3375387c5c2e6d70347c6d61737465725c2e7478747c2f656d6265642f736865696c612f295b5e5c7322273c3e5d2a').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.I):
                aAAaAaaaAAAAAAAAaAaaaaAAaAAAaaAAAaaAAaAA.append(LtdgRjPzrduiTXfRNYBbLhansPUjRBheSkPcTTaeIersssyHlxJCTuMlULaTUlNjNFPtDWlEINPeMKH29.group(0).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')))
        return list(dict.fromkeys(aAAaAaaaAAAAAAAAaAaaaaAAaAAAaaAAAaaAAaAA))

    def _extract_subtitles(self, page, page_url):
        y714982853883441 = []
        for aAAa in re.findall(bytes.fromhex('5b22275d3f747261636b735b22275d3f5c732a3a5c732a285c5b2e2a3f5c5d29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            for i258649039968222 in self._parse_js_list(aAAa):
                if not isinstance(i258649039968222, dict):
                    continue
                t17 = i258649039968222.get(bytes.fromhex('66696c65').decode('utf-8'))
                IIIIIIIIllIllllIllIIlIIIIl = i258649039968222.get(bytes.fromhex('6b696e64').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
                if t17 and (bytes.fromhex('63617074696f6e').decode('utf-8') in IIIIIIIIllIllllIllIIlIIIIl.lower() or bytes.fromhex('7375627469746c65').decode('utf-8') in IIIIIIIIllIllllIllIIlIIIIl.lower()):
                    y714982853883441.append(parsers.fix_url(t17.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')), page_url))
        for LtdgRjPzrduiTXfRNYBbLhansPUjRBheSkPcTTaeIersssyHlxJCTuMlULaTUlNjNFPtDWlEINPeMKH29 in re.finditer(bytes.fromhex('61646453727446696c655c285b22275d283f503c75726c3e5b5e22275d2b5c2e737274295b22275d').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.I):
            y714982853883441.append(parsers.fix_url(LtdgRjPzrduiTXfRNYBbLhansPUjRBheSkPcTTaeIersssyHlxJCTuMlULaTUlNjNFPtDWlEINPeMKH29.group(bytes.fromhex('75726c').decode('utf-8')), page_url))
        return list(dict.fromkeys(y714982853883441))

    def _parse_js_list(self, value):
        AaaaAaaAAaaAaAAAaaaaaAaAaAAaaa = (value or bytes.fromhex('').decode('utf-8')).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')).replace(bytes.fromhex('27').decode('utf-8'), bytes.fromhex('22').decode('utf-8'))
        AaaaAaaAAaaAaAAAaaaaaAaAaAAaaa = re.sub(bytes.fromhex('283f3c215c22295c622866696c657c7372637c6c6162656c7c747970657c6b696e64295c625c732a3a').decode('utf-8'), bytes.fromhex('225c31223a').decode('utf-8'), AaaaAaaAAaaAaAAAaaaaaAaAaAAaaa, flags=re.I)
        AaaaAaaAAaaAaAAAaaaaaAaAaAAaaa = re.sub(bytes.fromhex('2c5c732a285b5c5d7d5d29').decode('utf-8'), bytes.fromhex('5c31').decode('utf-8'), AaaaAaaAAaaAaAAAaaaaaAaAaAAaaa)
        try:
            data = json.loads(AaaaAaaAAaaAaAAAaaaaaAaAaAAaaa)
        except ValueError:
            return []
        return data if isinstance(data, list) else []

    def unpack_first_eval(self, page):
        LtdgRjPzrduiTXfRNYBbLhansPUjRBheSkPcTTaeIersssyHlxJCTuMlULaTUlNjNFPtDWlEINPeMKH29 = re.search(bytes.fromhex('6576616c5c2866756e6374696f6e5c28702c612c632c6b2c652c283f3a727c64295c292e2a3f5c7d5c285c732a27283f503c7061796c6f61643e283f3a5c5c277c5b5e275d292a29275c732a2c5c732a283f503c626173653e5c642b295c732a2c5c732a283f503c636f756e743e5c642b295c732a2c5c732a27283f503c73796d626f6c733e283f3a5c5c277c5b5e275d292a29275c2e73706c69745c28275c7c275c29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S)
        if not LtdgRjPzrduiTXfRNYBbLhansPUjRBheSkPcTTaeIersssyHlxJCTuMlULaTUlNjNFPtDWlEINPeMKH29:
            return bytes.fromhex('').decode('utf-8')
        ZvHSkOSxCbbuFBfvFplHwzbEnfZngzxYRquGjciHiFSiNZSUFOlnasnDTsfMzYaYdJtfHUToUCJuLyS33 = LtdgRjPzrduiTXfRNYBbLhansPUjRBheSkPcTTaeIersssyHlxJCTuMlULaTUlNjNFPtDWlEINPeMKH29.group(bytes.fromhex('7061796c6f6164').decode('utf-8')).replace(bytes.fromhex('5c27').decode('utf-8'), bytes.fromhex('27').decode('utf-8')).replace(bytes.fromhex('5c5c').decode('utf-8'), bytes.fromhex('5c').decode('utf-8'))
        base = int(LtdgRjPzrduiTXfRNYBbLhansPUjRBheSkPcTTaeIersssyHlxJCTuMlULaTUlNjNFPtDWlEINPeMKH29.group(bytes.fromhex('62617365').decode('utf-8')))
        symbols = LtdgRjPzrduiTXfRNYBbLhansPUjRBheSkPcTTaeIersssyHlxJCTuMlULaTUlNjNFPtDWlEINPeMKH29.group(bytes.fromhex('73796d626f6c73').decode('utf-8')).replace(bytes.fromhex('5c27').decode('utf-8'), bytes.fromhex('27').decode('utf-8')).replace(bytes.fromhex('5c5c').decode('utf-8'), bytes.fromhex('5c').decode('utf-8')).split(bytes.fromhex('7c').decode('utf-8'))
        return re.sub(bytes.fromhex('5c625c772b5c62').decode('utf-8'), lambda dddddddddddddddddddddddddddd: self._packed_symbol(dddddddddddddddddddddddddddd.group(0), base, symbols), ZvHSkOSxCbbuFBfvFplHwzbEnfZngzxYRquGjciHiFSiNZSUFOlnasnDTsfMzYaYdJtfHUToUCJuLyS33)

    def media_url(self, text):
        LtdgRjPzrduiTXfRNYBbLhansPUjRBheSkPcTTaeIersssyHlxJCTuMlULaTUlNjNFPtDWlEINPeMKH29 = re.search(bytes.fromhex('68747470733f3a2f2f5b5e5c7322273c3e5d2b3f283f3a5c2e283f3a6d3375387c6d7034297c6d61737465725c2e7478747c2f656d6265642f736865696c612f5b5e22275c733c3e5d2b29283f3a5c3f5b5e5c7322273c3e5d2a293f').decode('utf-8'), text or bytes.fromhex('').decode('utf-8'), re.I)
        return LtdgRjPzrduiTXfRNYBbLhansPUjRBheSkPcTTaeIersssyHlxJCTuMlULaTUlNjNFPtDWlEINPeMKH29.group(0).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')) if LtdgRjPzrduiTXfRNYBbLhansPUjRBheSkPcTTaeIersssyHlxJCTuMlULaTUlNjNFPtDWlEINPeMKH29 else bytes.fromhex('').decode('utf-8')

    def resolve_hls_variant(self, url, referer=None):
        try:
            KlSDifZehXjdFUCzfsFUNFcXwYTXpAoLyjRgZpDpLCZgTTBDlwKdjQTRWQURMtkZmOjcMWrNyEvmPLN36 = self.fetch(url, referer)
        except (manituxhttp.HTTPError, manituxhttp.RequestError):
            return bytes.fromhex('').decode('utf-8')
        if bytes.fromhex('234558544d3355').decode('utf-8') not in KlSDifZehXjdFUCzfsFUNFcXwYTXpAoLyjRgZpDpLCZgTTBDlwKdjQTRWQURMtkZmOjcMWrNyEvmPLN36 or bytes.fromhex('234558542d582d53545245414d2d494e46').decode('utf-8') not in KlSDifZehXjdFUCzfsFUNFcXwYTXpAoLyjRgZpDpLCZgTTBDlwKdjQTRWQURMtkZmOjcMWrNyEvmPLN36:
            return bytes.fromhex('').decode('utf-8')
        lIllllIIlIIIllllIlIIIIlIlIIlIIlllllIIIllllIII = []
        IIIlllIlIIIIlIllllIlIlIIlIlllIlllI = 0
        for R27 in KlSDifZehXjdFUCzfsFUNFcXwYTXpAoLyjRgZpDpLCZgTTBDlwKdjQTRWQURMtkZmOjcMWrNyEvmPLN36.splitlines():
            R27 = R27.strip()
            if not R27:
                continue
            if R27.startswith(bytes.fromhex('234558542d582d53545245414d2d494e46').decode('utf-8')):
                LtdgRjPzrduiTXfRNYBbLhansPUjRBheSkPcTTaeIersssyHlxJCTuMlULaTUlNjNFPtDWlEINPeMKH29 = re.search(bytes.fromhex('42414e4457494454483d285c642b29').decode('utf-8'), R27, re.I)
                IIIlllIlIIIIlIllllIlIlIIlIlllIlllI = int(LtdgRjPzrduiTXfRNYBbLhansPUjRBheSkPcTTaeIersssyHlxJCTuMlULaTUlNjNFPtDWlEINPeMKH29.group(1)) if LtdgRjPzrduiTXfRNYBbLhansPUjRBheSkPcTTaeIersssyHlxJCTuMlULaTUlNjNFPtDWlEINPeMKH29 else 0
                continue
            if R27.startswith(bytes.fromhex('23').decode('utf-8')):
                continue
            lIllllIIlIIIllllIlIIIIlIlIIlIIlllllIIIllllIII.append((IIIlllIlIIIIlIllllIlIlIIlIlllIlllI, parsers.fix_url(R27, url)))
            IIIlllIlIIIIlIllllIlIlIIlIlllIlllI = 0
        if not lIllllIIlIIIllllIlIIIIlIlIIlIIlllllIIIllllIII:
            return bytes.fromhex('').decode('utf-8')
        lIllllIIlIIIllllIlIIIIlIlIIlIIlllllIIIllllIII.sort(key=lambda i258649039968222: i258649039968222[0], reverse=True)
        return lIllllIIlIIIllllIlIIIIlIlIIlIIlllllIIIllllIII[0][1]

    def decode_embedded_html(self, page):
        y41873909690459 = []
        YfMMDtNslBKXRUgvififEtENulUOZfDZiUXPqSRGapNddlLFtTdMQmaRTNIZzFiooBNNuKxsAGenaEG11 = self.decrypt_cryptojs_page(page)
        if YfMMDtNslBKXRUgvififEtENulUOZfDZiUXPqSRGapNddlLFtTdMQmaRTNIZzFiooBNNuKxsAGenaEG11:
            y41873909690459.append(YfMMDtNslBKXRUgvififEtENulUOZfDZiUXPqSRGapNddlLFtTdMQmaRTNIZzFiooBNNuKxsAGenaEG11)
        for bsVrmRzkYHPDJpshucARAEIrgRPeOzDfzjyvCjduyTIJYTYinAOGuQYVKkSrIRJHZAMwHbjIwZWgtPF16 in re.findall(bytes.fromhex('756e6573636170655c285b225c275d282e2a3f295b225c275d5c29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            y41873909690459.append(unquote(bsVrmRzkYHPDJpshucARAEIrgRPeOzDfzjyvCjduyTIJYTYinAOGuQYVKkSrIRJHZAMwHbjIwZWgtPF16))
        for A14 in re.findall(bytes.fromhex('61746f625c285b225c275d285b412d5a612d7a302d392b2f3d5f2d5d2b295b225c275d5c29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.I):
            y41873909690459.append(self._b64(A14))
        for A14 in re.findall(bytes.fromhex('5b225c275d285b412d5a612d7a302d392b2f3d5f2d5d7b34302c7d295b225c275d').decode('utf-8'), page or bytes.fromhex('').decode('utf-8')):
            WWWWWWWWWW = self._b64(A14)
            if bytes.fromhex('3c696672616d65').decode('utf-8') in WWWWWWWWWW or bytes.fromhex('2e6d337538').decode('utf-8') in WWWWWWWWWW or bytes.fromhex('2e6d7034').decode('utf-8') in WWWWWWWWWW:
                y41873909690459.append(WWWWWWWWWW)
        return bytes.fromhex('0a').decode('utf-8').join((IIIIllIIIlIlIllIIlIllIllIlIIIllIIIIlIlIlllIlII for IIIIllIIIlIlIllIIlIllIllIlIIIllIIIIlIlIlllIlII in y41873909690459 if IIIIllIIIlIlIllIIlIllIllIlIIIllIIIIlIlIlllIlII))

    def decrypt_cryptojs_page(self, page):
        if AES is None:
            return bytes.fromhex('').decode('utf-8')
        LtdgRjPzrduiTXfRNYBbLhansPUjRBheSkPcTTaeIersssyHlxJCTuMlULaTUlNjNFPtDWlEINPeMKH29 = re.search(bytes.fromhex('43727970746f4a535c2e4145535c2e646563727970745c285b22275d283f503c646174613e5b5e22275d2b295b22275d5c732a2c5c732a5b22275d283f503c706173733e5b5e22275d2b295b22275d5c29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I)
        if not LtdgRjPzrduiTXfRNYBbLhansPUjRBheSkPcTTaeIersssyHlxJCTuMlULaTUlNjNFPtDWlEINPeMKH29:
            return bytes.fromhex('').decode('utf-8')
        try:
            pppppppppppppppppppppppppppppppppppppp = base64.b64decode(LtdgRjPzrduiTXfRNYBbLhansPUjRBheSkPcTTaeIersssyHlxJCTuMlULaTUlNjNFPtDWlEINPeMKH29.group(bytes.fromhex('64617461').decode('utf-8')))
            password = LtdgRjPzrduiTXfRNYBbLhansPUjRBheSkPcTTaeIersssyHlxJCTuMlULaTUlNjNFPtDWlEINPeMKH29.group(bytes.fromhex('70617373').decode('utf-8')).encode(bytes.fromhex('7574662d38').decode('utf-8'))
            if pppppppppppppppppppppppppppppppppppppp.startswith(b'Salted__'):
                salt = pppppppppppppppppppppppppppppppppppppp[8:16]
                IlIIIIllIIIIIll = pppppppppppppppppppppppppppppppppppppp[16:]
                i25 = self.evp_bytes_to_key(password, salt, 48)
                vvvvvvvvvvvvvvvvvvvvvvvv = i25[:32]
                IIlIIlIIIIIIlIIIIlIIIll = i25[32:48]
            else:
                IlIIIIllIIIIIll = pppppppppppppppppppppppppppppppppppppp
                i25 = self.evp_bytes_to_key(password, b'', 48)
                vvvvvvvvvvvvvvvvvvvvvvvv = i25[:32]
                IIlIIlIIIIIIlIIIIlIIIll = i25[32:48]
            YfMMDtNslBKXRUgvififEtENulUOZfDZiUXPqSRGapNddlLFtTdMQmaRTNIZzFiooBNNuKxsAGenaEG11 = AES.new(vvvvvvvvvvvvvvvvvvvvvvvv, AES.MODE_CBC, IIlIIlIIIIIIlIIIIlIIIll).decrypt(IlIIIIllIIIIIll)
            p31 = YfMMDtNslBKXRUgvififEtENulUOZfDZiUXPqSRGapNddlLFtTdMQmaRTNIZzFiooBNNuKxsAGenaEG11[-1]
            if 0 < p31 <= 16:
                YfMMDtNslBKXRUgvififEtENulUOZfDZiUXPqSRGapNddlLFtTdMQmaRTNIZzFiooBNNuKxsAGenaEG11 = YfMMDtNslBKXRUgvififEtENulUOZfDZiUXPqSRGapNddlLFtTdMQmaRTNIZzFiooBNNuKxsAGenaEG11[:-p31]
            return YfMMDtNslBKXRUgvififEtENulUOZfDZiUXPqSRGapNddlLFtTdMQmaRTNIZzFiooBNNuKxsAGenaEG11.decode(bytes.fromhex('7574662d38').decode('utf-8'), bytes.fromhex('7265706c616365').decode('utf-8'))
        except Exception:
            return bytes.fromhex('').decode('utf-8')

    @staticmethod
    def evp_bytes_to_key(password, salt, key_len):
        data = b''
        i37 = b''
        while len(data) < key_len:
            i37 = hashlib.md5(i37 + password + salt).digest()
            data += i37
        return data[:key_len]

    def is_site_player(self, url):
        n32 = urlparse(url or bytes.fromhex('').decode('utf-8'))
        return n32.netloc.lower() == urlparse(self.base_url).netloc.lower() and bytes.fromhex('2f706c617965722f').decode('utf-8') in n32.path

    @staticmethod
    def is_media_url(url):
        return bool(re.search(bytes.fromhex('283f3a5c2e6d3375387c5c2e6d70347c6d61737465725c2e7478747c2f656d6265642f736865696c612f5b5e3f235d2a29283f3a5b3f235d2e2a293f24').decode('utf-8'), url or bytes.fromhex('').decode('utf-8'), re.I))

    @staticmethod
    def is_hls_url(url):
        return bool(re.search(bytes.fromhex('283f3a5c2e6d3375387c6d61737465725c2e74787429283f3a5b3f235d2e2a293f24').decode('utf-8'), url or bytes.fromhex('').decode('utf-8'), re.I))

    @staticmethod
    def has_playable(page):
        text = page or bytes.fromhex('').decode('utf-8')
        return bytes.fromhex('736f75726365733a').decode('utf-8') in text or bytes.fromhex('2e6d337538').decode('utf-8') in text or bytes.fromhex('2e6d7034').decode('utf-8') in text or (bytes.fromhex('6a77706c61796572').decode('utf-8') in text)

    @staticmethod
    def needs_number_challenge(page):
        text = page or bytes.fromhex('').decode('utf-8')
        return bytes.fromhex('53656c656374206e756d626572').decode('utf-8') in text or bytes.fromhex('73656c65637420746865206e756d626572').decode('utf-8') in text

    @staticmethod
    def _packed_symbol(value, base, symbols):
        M29036762686251 = string.digits + string.ascii_lowercase + string.ascii_uppercase
        RiyBXNvHMQIdrDLmYDpjOdiPrwbSYaJFGwwsmnFlGNDAjIjpGKDHKezNMCODxjiOLITFXtXVLurFfnc20 = 0
        for VqXfmhTwdWCPhwLTFpskUELMqfyfVaLUlumRdpRhgZLeHWlmemRJfiEnaGNVQgsMBTUvvACoDFmibfU8 in value:
            lIIlIlIlIIll = M29036762686251.find(VqXfmhTwdWCPhwLTFpskUELMqfyfVaLUlumRdpRhgZLeHWlmemRJfiEnaGNVQgsMBTUvvACoDFmibfU8)
            if lIIlIlIlIIll < 0 or lIIlIlIlIIll >= base:
                return value
            RiyBXNvHMQIdrDLmYDpjOdiPrwbSYaJFGwwsmnFlGNDAjIjpGKDHKezNMCODxjiOLITFXtXVLurFfnc20 = RiyBXNvHMQIdrDLmYDpjOdiPrwbSYaJFGwwsmnFlGNDAjIjpGKDHKezNMCODxjiOLITFXtXVLurFfnc20 * base + lIIlIlIlIIll
        return symbols[RiyBXNvHMQIdrDLmYDpjOdiPrwbSYaJFGwwsmnFlGNDAjIjpGKDHKezNMCODxjiOLITFXtXVLurFfnc20] if 0 <= RiyBXNvHMQIdrDLmYDpjOdiPrwbSYaJFGwwsmnFlGNDAjIjpGKDHKezNMCODxjiOLITFXtXVLurFfnc20 < len(symbols) and symbols[RiyBXNvHMQIdrDLmYDpjOdiPrwbSYaJFGwwsmnFlGNDAjIjpGKDHKezNMCODxjiOLITFXtXVLurFfnc20] else value

    @staticmethod
    def _input_value(page, name):
        for duWmFTsuGSXLcuIYuglCqvUxMsyJLPKFjeWjVdcJOSUJQCQnGjZLsdxLkIoeJrBbQqUOUGExJOgoNMT42 in re.findall(bytes.fromhex('3c696e7075745c625b5e3e5d2a3e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            k973139578900621 = DiziBoxExtractor._first(bytes.fromhex('6e616d653d5b22275d285b5e22275d2b295b22275d').decode('utf-8'), duWmFTsuGSXLcuIYuglCqvUxMsyJLPKFjeWjVdcJOSUJQCQnGjZLsdxLkIoeJrBbQqUOUGExJOgoNMT42)
            if k973139578900621 == name:
                return DiziBoxExtractor._first(bytes.fromhex('76616c75653d5b22275d285b5e22275d2a295b22275d').decode('utf-8'), duWmFTsuGSXLcuIYuglCqvUxMsyJLPKFjeWjVdcJOSUJQCQnGjZLsdxLkIoeJrBbQqUOUGExJOgoNMT42, re.S)
        return bytes.fromhex('').decode('utf-8')

    @staticmethod
    def _add_candidate(candidates, url):
        if url and url not in candidates:
            candidates.append(url)

    @staticmethod
    def _b64(value):
        try:
            pppppppppppppppppppppppppppppppppppppp = value.encode(bytes.fromhex('7574662d38').decode('utf-8'))
            pppppppppppppppppppppppppppppppppppppp += b'=' * ((4 - len(pppppppppppppppppppppppppppppppppppppp) % 4) % 4)
            return base64.b64decode(pppppppppppppppppppppppppppppppppppppp).decode(bytes.fromhex('7574662d38').decode('utf-8'), bytes.fromhex('7265706c616365').decode('utf-8'))
        except Exception:
            return bytes.fromhex('').decode('utf-8')

    @staticmethod
    def _first(pattern, text, flags=0):
        LtdgRjPzrduiTXfRNYBbLhansPUjRBheSkPcTTaeIersssyHlxJCTuMlULaTUlNjNFPtDWlEINPeMKH29 = re.search(pattern, text or bytes.fromhex('').decode('utf-8'), flags | re.I)
        return LtdgRjPzrduiTXfRNYBbLhansPUjRBheSkPcTTaeIersssyHlxJCTuMlULaTUlNjNFPtDWlEINPeMKH29.group(1) if LtdgRjPzrduiTXfRNYBbLhansPUjRBheSkPcTTaeIersssyHlxJCTuMlULaTUlNjNFPtDWlEINPeMKH29 else bytes.fromhex('').decode('utf-8')
