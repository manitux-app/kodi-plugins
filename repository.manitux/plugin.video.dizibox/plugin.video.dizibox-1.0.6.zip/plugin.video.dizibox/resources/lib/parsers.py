from __future__ import absolute_import, unicode_literals
import html
import re
import manituxhttp
try:
    from urllib.parse import quote_plus, urlencode, urljoin, urlparse, parse_qsl, urlunparse
except ImportError:
    from urllib import quote_plus, urlencode
    from urlparse import urljoin, urlparse, parse_qsl, urlunparse
GENRE_NAMES = [bytes.fromhex('41696c65').decode('utf-8'), bytes.fromhex('416b7369796f6e').decode('utf-8'), bytes.fromhex('416e696d6173796f6e').decode('utf-8'), bytes.fromhex('4176756b6174').decode('utf-8'), bytes.fromhex('42656c676573656c').decode('utf-8'), bytes.fromhex('42696c696d6b75726775').decode('utf-8'), bytes.fromhex('4269796f6772616669').decode('utf-8'), bytes.fromhex('43617375736c756b').decode('utf-8'), bytes.fromhex('4472616d').decode('utf-8'), bytes.fromhex('4472616d61').decode('utf-8'), bytes.fromhex('46616e74617374696b').decode('utf-8'), bytes.fromhex('476572696c696d').decode('utf-8'), bytes.fromhex('47697a656d').decode('utf-8'), bytes.fromhex('4b6f6d656469').decode('utf-8'), bytes.fromhex('4b6f726b75').decode('utf-8'), bytes.fromhex('4d6163657261').decode('utf-8'), bytes.fromhex('4d61686b656d65').decode('utf-8'), bytes.fromhex('4dc3bc7a696b').decode('utf-8'), bytes.fromhex('4dc3bc7a696b616c').decode('utf-8'), bytes.fromhex('506f6c6973697965').decode('utf-8'), bytes.fromhex('506f6c6974696b61').decode('utf-8'), bytes.fromhex('5265616c697479205456').decode('utf-8'), bytes.fromhex('526f6d616e74696b').decode('utf-8'), bytes.fromhex('53617661c59f').decode('utf-8'), bytes.fromhex('53706f72').decode('utf-8'), bytes.fromhex('5375c3a7').decode('utf-8'), bytes.fromhex('54616c6b2d53686f77').decode('utf-8'), bytes.fromhex('5461726968').decode('utf-8'), bytes.fromhex('5765737465726e').decode('utf-8'), bytes.fromhex('596172c4b1c59f6d61').decode('utf-8')]
GENRE_SLUGS = {bytes.fromhex('41696c65').decode('utf-8'): bytes.fromhex('61696c65').decode('utf-8'), bytes.fromhex('416b7369796f6e').decode('utf-8'): bytes.fromhex('616b7369796f6e').decode('utf-8'), bytes.fromhex('416e696d6173796f6e').decode('utf-8'): bytes.fromhex('616e696d6173796f6e').decode('utf-8'), bytes.fromhex('4176756b6174').decode('utf-8'): bytes.fromhex('6176756b6174').decode('utf-8'), bytes.fromhex('42656c676573656c').decode('utf-8'): bytes.fromhex('62656c676573656c').decode('utf-8'), bytes.fromhex('42696c696d6b75726775').decode('utf-8'): bytes.fromhex('62696c696d6b75726775').decode('utf-8'), bytes.fromhex('4269796f6772616669').decode('utf-8'): bytes.fromhex('6269796f6772616669').decode('utf-8'), bytes.fromhex('43617375736c756b').decode('utf-8'): bytes.fromhex('63617375736c756b').decode('utf-8'), bytes.fromhex('4472616d').decode('utf-8'): bytes.fromhex('6472616d').decode('utf-8'), bytes.fromhex('4472616d61').decode('utf-8'): bytes.fromhex('6472616d61').decode('utf-8'), bytes.fromhex('46616e74617374696b').decode('utf-8'): bytes.fromhex('66616e74617374696b').decode('utf-8'), bytes.fromhex('476572696c696d').decode('utf-8'): bytes.fromhex('676572696c696d').decode('utf-8'), bytes.fromhex('47697a656d').decode('utf-8'): bytes.fromhex('67697a656d').decode('utf-8'), bytes.fromhex('4b6f6d656469').decode('utf-8'): bytes.fromhex('6b6f6d656469').decode('utf-8'), bytes.fromhex('4b6f726b75').decode('utf-8'): bytes.fromhex('6b6f726b75').decode('utf-8'), bytes.fromhex('4d6163657261').decode('utf-8'): bytes.fromhex('6d6163657261').decode('utf-8'), bytes.fromhex('4d61686b656d65').decode('utf-8'): bytes.fromhex('6d61686b656d65').decode('utf-8'), bytes.fromhex('4dc3bc7a696b').decode('utf-8'): bytes.fromhex('6d757a696b').decode('utf-8'), bytes.fromhex('4dc3bc7a696b616c').decode('utf-8'): bytes.fromhex('6d757a696b616c').decode('utf-8'), bytes.fromhex('506f6c6973697965').decode('utf-8'): bytes.fromhex('706f6c6973697965').decode('utf-8'), bytes.fromhex('506f6c6974696b61').decode('utf-8'): bytes.fromhex('706f6c6974696b61').decode('utf-8'), bytes.fromhex('5265616c697479205456').decode('utf-8'): bytes.fromhex('7265616c6974792d7476').decode('utf-8'), bytes.fromhex('526f6d616e74696b').decode('utf-8'): bytes.fromhex('726f6d616e74696b').decode('utf-8'), bytes.fromhex('53617661c59f').decode('utf-8'): bytes.fromhex('7361766173').decode('utf-8'), bytes.fromhex('53706f72').decode('utf-8'): bytes.fromhex('73706f72').decode('utf-8'), bytes.fromhex('5375c3a7').decode('utf-8'): bytes.fromhex('737563').decode('utf-8'), bytes.fromhex('54616c6b2d53686f77').decode('utf-8'): bytes.fromhex('74616c6b2d73686f77').decode('utf-8'), bytes.fromhex('5461726968').decode('utf-8'): bytes.fromhex('7461726968').decode('utf-8'), bytes.fromhex('5765737465726e').decode('utf-8'): bytes.fromhex('7765737465726e').decode('utf-8'), bytes.fromhex('596172c4b1c59f6d61').decode('utf-8'): bytes.fromhex('79617269736d61').decode('utf-8')}

def parse_genres(page, base_url, archive_url):
    eeeeeeeeeeeeeeeeeeeeeeeeee = _parse_genres_with_soup(page, base_url, archive_url)
    if eeeeeeeeeeeeeeeeeeeeeeeeee:
        return eeeeeeeeeeeeeeeeeeeeeeeeee
    return _parse_genres_with_regex(page, base_url, archive_url)

def fallback_genres(base_url):
    archive_url = base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f64697a692d6172736976692f').decode('utf-8')
    eeeeeeeeeeeeeeeeeeeeeeeeee = [(bytes.fromhex('5965726c69').decode('utf-8'), _country_filter_url(archive_url, bytes.fromhex('7475726b697965').decode('utf-8')))]
    eeeeeeeeeeeeeeeeeeeeeeeeee.extend(((name, _genre_filter_url(archive_url, name)) for name in GENRE_NAMES))
    return eeeeeeeeeeeeeeeeeeeeeeeeee

def page_url(category_url, page_number):
    page_number = int(page_number)
    if bytes.fromhex('5341594641').decode('utf-8') in category_url:
        return category_url.replace(bytes.fromhex('5341594641').decode('utf-8'), str(page_number))
    if page_number <= 1:
        return category_url
    if bytes.fromhex('5b706167654e756d6265725d').decode('utf-8') in category_url:
        return category_url.replace(bytes.fromhex('5b706167654e756d6265725d').decode('utf-8'), str(page_number))
    WuSNMmiRXapSYMmuFSqMhFHLdYdIdOYbPOTvKpdFxfdYztzcvAyCoTeVqysqVGMHimJxRIhPqgOdwCR35 = urlparse(category_url)
    query = dict(parse_qsl(WuSNMmiRXapSYMmuFSqMhFHLdYdIdOYbPOTvKpdFxfdYztzcvAyCoTeVqysqVGMHimJxRIhPqgOdwCR35.query))
    query[bytes.fromhex('7361796661').decode('utf-8')] = str(page_number)
    query[bytes.fromhex('70616765').decode('utf-8')] = str(page_number)
    return urlunparse(WuSNMmiRXapSYMmuFSqMhFHLdYdIdOYbPOTvKpdFxfdYztzcvAyCoTeVqysqVGMHimJxRIhPqgOdwCR35._replace(query=urlencode(query)))

def parse_page_items(page, base_url):
    soup = _soup(page)
    if soup is not None:
        eeeeeeeeeeeeeeeeeeeeeeeeee = _parse_page_items_with_soup(soup, base_url)
        if eeeeeeeeeeeeeeeeeeeeeeeeee:
            return eeeeeeeeeeeeeeeeeeeeeeeeee
    return _parse_page_items_with_regex(page, base_url)

def has_next_page(page, page_number):
    e882588091444732 = int(page_number) + 1
    if re.search(bytes.fromhex('3e5c732a7b307d5c732a3c').decode('utf-8').format(e882588091444732), page or bytes.fromhex('').decode('utf-8')):
        return True
    return bool(re.search(bytes.fromhex('3e5c732a283f3a536f6e72616b697c536f6e7ce286927c26726172723b29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.I))

def parse_detail(page, url, base_url):
    soup = _soup(page)
    title = bytes.fromhex('').decode('utf-8')
    p38 = bytes.fromhex('').decode('utf-8')
    p360175364299837 = bytes.fromhex('').decode('utf-8')
    V100506330125054 = bytes.fromhex('').decode('utf-8')
    ktFBYtYbsmXfvLTnDfAoKymgPQTlFAVpNTahRIEOKyhLBpLfbhcCHJbDACkqycnYNMWZrtzuAtfwBRU40 = bytes.fromhex('').decode('utf-8')
    m193472703861748 = []
    iOItAYasMrSPwxoYOFBzhLpiqSWAKCWttOzHnNGPUSsnjWvnNtleDZGbtVTHJmUMvRTZMhKfQRQufhU2 = []
    if soup is not None:
        e19 = soup.select_one(bytes.fromhex('6469762e74762d6f766572766965772068312061').decode('utf-8')) or soup.find(bytes.fromhex('6831').decode('utf-8'))
        title = _clean(e19.get_text(bytes.fromhex('20').decode('utf-8'))) if e19 else bytes.fromhex('').decode('utf-8')
        lIlIIlllllIllIlIIlIlll = soup.select_one(bytes.fromhex('6469762e74762d6f766572766965772066696775726520696d67').decode('utf-8')) or soup.select_one(bytes.fromhex('696d675b6974656d70726f703d27696d616765275d').decode('utf-8')) or soup.select_one(bytes.fromhex('6d6574615b70726f70657274793d276f673a696d616765275d').decode('utf-8')) or soup.find(bytes.fromhex('696d67').decode('utf-8'), attrs={bytes.fromhex('737263').decode('utf-8'): True})
        p38 = _image_url_from_node(lIlIIlllllIllIlIIlIlll, base_url)
        AJjguUHLQWuBbxZyEnkHMrhZppkAbWVLkCFUsdHruUrJJqHtvjWZzcVHRCaGhToJVinNmsuCUrZMETG12 = soup.select_one(bytes.fromhex('6469762e74762d73746f72792070').decode('utf-8')) or soup.find(attrs={bytes.fromhex('6974656d70726f70').decode('utf-8'): bytes.fromhex('6465736372697074696f6e').decode('utf-8')}) or soup.find(bytes.fromhex('70').decode('utf-8'))
        p360175364299837 = _clean(AJjguUHLQWuBbxZyEnkHMrhZppkAbWVLkCFUsdHruUrJJqHtvjWZzcVHRCaGhToJVinNmsuCUrZMETG12.get_text(bytes.fromhex('20').decode('utf-8'))) if AJjguUHLQWuBbxZyEnkHMrhZppkAbWVLkCFUsdHruUrJJqHtvjWZzcVHRCaGhToJVinNmsuCUrZMETG12 else bytes.fromhex('').decode('utf-8')
        A55 = soup.select_one(bytes.fromhex('615b687265662a3d272f79696c2f275d').decode('utf-8'))
        V100506330125054 = _clean(A55.get_text(bytes.fromhex('20').decode('utf-8'))) if A55 else bytes.fromhex('').decode('utf-8')
        aAaAAaAAAaAaaAaAAaaaAAaaaAaAAAAaaAAAAaAaA = soup.select_one(bytes.fromhex('7370616e2e6c6162656c2d696d64622062').decode('utf-8'))
        ktFBYtYbsmXfvLTnDfAoKymgPQTlFAVpNTahRIEOKyhLBpLfbhcCHJbDACkqycnYNMWZrtzuAtfwBRU40 = _clean(aAaAAaAAAaAaaAaAAaaaAAaaaAaAAAAaaAAAAaAaA.get_text(bytes.fromhex('20').decode('utf-8'))) if aAaAAaAAAaAaaAaAAaaaAAaaaAaAAAAaaAAAAaAaA else bytes.fromhex('').decode('utf-8')
        m193472703861748 = [_clean(IlllllIlIIIIlIlIIlIlIIllIlIlIllllllllIlIlllIlIIllIIlI.get_text(bytes.fromhex('20').decode('utf-8'))) for IlllllIlIIIIlIlIIlIlIIllIlIlIllllllllIlIlllIlIIllIIlI in soup.select(bytes.fromhex('615b687265662a3d272f7475722f275d').decode('utf-8')) if _clean(IlllllIlIIIIlIlIIlIlIIllIlIlIllllllllIlIlllIlIIllIIlI.get_text(bytes.fromhex('20').decode('utf-8')))]
        iOItAYasMrSPwxoYOFBzhLpiqSWAKCWttOzHnNGPUSsnjWvnNtleDZGbtVTHJmUMvRTZMhKfQRQufhU2 = [_clean(IlllllIlIIIIlIlIIlIlIIllIlIlIllllllllIlIlllIlIIllIIlI.get_text(bytes.fromhex('20').decode('utf-8'))) for IlllllIlIIIIlIlIIlIlIIllIlIlIllllllllIlIlllIlIIllIIlI in soup.select(bytes.fromhex('615b687265662a3d272f6f79756e63752f275d').decode('utf-8')) if _clean(IlllllIlIIIIlIlIIlIlIIllIlIlIllllllllIlIlllIlIIllIIlI.get_text(bytes.fromhex('20').decode('utf-8')))]
    if not title:
        title = _clean(_first(bytes.fromhex('3c68315b5e3e5d2a3e282e2a3f293c2f68313e').decode('utf-8'), page, re.S))
    if not p38:
        p38 = _poster_from_html(page, base_url)
    if not p360175364299837:
        p360175364299837 = _clean(_first(bytes.fromhex('3c705b5e3e5d2a6974656d70726f703d5b275c225d6465736372697074696f6e5b275c225d5b5e3e5d2a3e282e2a3f293c2f703e').decode('utf-8'), page, re.S))
    if not V100506330125054:
        V100506330125054 = _first(bytes.fromhex('5c622831395c647b327d7c32305c647b327d295c62').decode('utf-8'), page)
    V100506330125054 = _first(bytes.fromhex('5c622831395c647b327d7c32305c647b327d295c62').decode('utf-8'), V100506330125054) or V100506330125054
    return {bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('696d616765').decode('utf-8'): p38, bytes.fromhex('6261636b64726f70').decode('utf-8'): p38, bytes.fromhex('706c6f74').decode('utf-8'): p360175364299837, bytes.fromhex('79656172').decode('utf-8'): V100506330125054, bytes.fromhex('726174696e67').decode('utf-8'): ktFBYtYbsmXfvLTnDfAoKymgPQTlFAVpNTahRIEOKyhLBpLfbhcCHJbDACkqycnYNMWZrtzuAtfwBRU40, bytes.fromhex('74616773').decode('utf-8'): m193472703861748, bytes.fromhex('6163746f7273').decode('utf-8'): iOItAYasMrSPwxoYOFBzhLpiqSWAKCWttOzHnNGPUSsnjWvnNtleDZGbtVTHJmUMvRTZMhKfQRQufhU2, bytes.fromhex('736561736f6e5f6c696e6b73').decode('utf-8'): parse_season_links(page, base_url), bytes.fromhex('657069736f646573').decode('utf-8'): parse_episodes(page, base_url), bytes.fromhex('736f7572636573').decode('utf-8'): parse_video_sources(page, url, base_url)}

def parse_season_links(page, base_url):
    soup = _soup(page)
    T265621001724228 = []
    a44 = set()
    if soup is not None:
        X33 = soup.select(bytes.fromhex('64697623736561736f6e732d6c69737420615b687265665d').decode('utf-8'))
        for node in X33:
            url = fix_url(node.get(bytes.fromhex('68726566').decode('utf-8')), base_url)
            if not url or url in a44:
                continue
            a44.add(url)
            title = _clean(node.get_text(bytes.fromhex('20').decode('utf-8'))) or bytes.fromhex('53657a6f6e').decode('utf-8')
            T265621001724228.append({bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url})
        if T265621001724228:
            return T265621001724228
    AaaaAA = _first(bytes.fromhex('3c6469765c625b5e3e5d2a69643d5b275c225d736561736f6e732d6c6973745b275c225d5b5e3e5d2a3e282e2a3f293c2f6469763e').decode('utf-8'), page, re.S)
    for link in re.findall(bytes.fromhex('3c615c625b5e3e5d2a687265663d5b275c225d5b5e275c225d2b5b275c225d5b5e3e5d2a3e2e2a3f3c2f613e').decode('utf-8'), AaaaAA or bytes.fromhex('').decode('utf-8'), re.S | re.I):
        url = fix_url(_attr(link, bytes.fromhex('68726566').decode('utf-8')), base_url)
        if not url or url in a44:
            continue
        a44.add(url)
        title = _clean(link) or bytes.fromhex('53657a6f6e').decode('utf-8')
        T265621001724228.append({bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url})
    return T265621001724228

def parse_episodes(page, base_url):
    soup = _soup(page)
    if soup is not None:
        SSSSSSSSSSSSSSSS = []
        a44 = set()
        for lIIl in soup.select(bytes.fromhex('61727469636c652e677269642d626f78').decode('utf-8')):
            link = _episode_link_from_node(lIIl)
            if link is None:
                continue
            title = _episode_title_from_node(link)
            url = fix_url(link.get(bytes.fromhex('68726566').decode('utf-8')), base_url)
            if not _is_episode_link(title, url) or url in a44:
                continue
            a44.add(url)
            aaaAaAaAaAAaAaAAaaaaaaA = lIIl.find(bytes.fromhex('696d67').decode('utf-8'))
            lIlIIlllllIllIlIIlIlll = fix_url(aaaAaAaAaAAaAaAAaaaaaaA.get(bytes.fromhex('646174612d737263').decode('utf-8')) or aaaAaAaAaAAaAaAAaaaaaaA.get(bytes.fromhex('737263').decode('utf-8')) if aaaAaAaAaAAaAaAAaaaaaaA else bytes.fromhex('').decode('utf-8'), base_url)
            if _is_generic_title(title):
                title = _title_from_episode_url(url) or title
            AAaAaAaaaAaAAAAaaAAaaAAaAaAaaaaaaaaaaaAAAaA, LslwTPApusTNrCXKLvoiyzgSIZqyhFLrpOAULxjIZQUwxLxLzwVjLuqrKiDWxtwdhptHhSsKbaamEsX15 = parse_episode_numbers(title + bytes.fromhex('20').decode('utf-8') + url)
            SSSSSSSSSSSSSSSS.append({bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('696d616765').decode('utf-8'): lIlIIlllllIllIlIIlIlll, bytes.fromhex('736561736f6e').decode('utf-8'): AAaAaAaaaAaAAAAaaAAaaAAaAaAaaaaaaaaaaaAAAaA, bytes.fromhex('657069736f6465').decode('utf-8'): LslwTPApusTNrCXKLvoiyzgSIZqyhFLrpOAULxjIZQUwxLxLzwVjLuqrKiDWxtwdhptHhSsKbaamEsX15})
        if SSSSSSSSSSSSSSSS:
            return SSSSSSSSSSSSSSSS
    SSSSSSSSSSSSSSSS = []
    a44 = set()
    for AaaaAA in re.findall(bytes.fromhex('3c61727469636c655c625b5e3e5d2a636c6173733d5b275c225d5b5e275c225d2a5c62677269642d626f785c625b5e275c225d2a5b275c225d5b5e3e5d2a3e2e2a3f3c2f61727469636c653e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
        T265621001724228 = re.findall(bytes.fromhex('3c615c625b5e3e5d2a687265663d5b275c225d5b5e275c225d2b5b275c225d5b5e3e5d2a3e2e2a3f3c2f613e').decode('utf-8'), AaaaAA, re.S | re.I)
        link = bytes.fromhex('').decode('utf-8')
        for lllllll in T265621001724228:
            lIIIIlllI = fix_url(_attr(lllllll, bytes.fromhex('68726566').decode('utf-8')), base_url)
            aAAaaAAa = _clean(lllllll) or _attr(lllllll, bytes.fromhex('7469746c65').decode('utf-8'))
            if _is_episode_link(aAAaaAAa, lIIIIlllI):
                link = lllllll
                break
        l20 = _attr(link, bytes.fromhex('68726566').decode('utf-8'))
        title = _clean(link) or _attr(link, bytes.fromhex('7469746c65').decode('utf-8'))
        url = fix_url(l20, base_url)
        if not _is_episode_link(title, url) or url in a44:
            continue
        a44.add(url)
        if _is_generic_title(title):
            title = _title_from_episode_url(url) or title
        AAaAaAaaaAaAAAAaaAAaaAAaAaAaaaaaaaaaaaAAAaA, LslwTPApusTNrCXKLvoiyzgSIZqyhFLrpOAULxjIZQUwxLxLzwVjLuqrKiDWxtwdhptHhSsKbaamEsX15 = parse_episode_numbers(title + bytes.fromhex('20').decode('utf-8') + url)
        SSSSSSSSSSSSSSSS.append({bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('696d616765').decode('utf-8'): bytes.fromhex('').decode('utf-8'), bytes.fromhex('736561736f6e').decode('utf-8'): AAaAaAaaaAaAAAAaaAAaaAAaAaAaaaaaaaaaaaAAAaA, bytes.fromhex('657069736f6465').decode('utf-8'): LslwTPApusTNrCXKLvoiyzgSIZqyhFLrpOAULxjIZQUwxLxLzwVjLuqrKiDWxtwdhptHhSsKbaamEsX15})
    return SSSSSSSSSSSSSSSS

def parse_episode_numbers(value):
    value = value or bytes.fromhex('').decode('utf-8')
    cccccccccccccccccccccccccccccccccccc = (bytes.fromhex('285c642b295c2e3f5c732a73657a6f6e2e2a3f285c642b295c2e3f5c732a625b6fc3b65d6c5b75c3bc5d6d').decode('utf-8'), bytes.fromhex('285c642b292d73657a6f6e2d285c642b292d626f6c756d').decode('utf-8'), bytes.fromhex('285c642b2978285c642b29').decode('utf-8'))
    for pattern in cccccccccccccccccccccccccccccccccccc:
        match = re.search(pattern, value, re.I)
        if match:
            return (int(match.group(1)), int(match.group(2)))
    return (0, 0)

def _episode_link_from_node(node):
    O39 = node.select_one(bytes.fromhex('6469762e706f73742d7469746c6520615b687265665d2c20683220615b687265665d2c20683320615b687265665d').decode('utf-8'))
    if O39 is not None and _is_episode_link(_episode_title_from_node(O39), O39.get(bytes.fromhex('68726566').decode('utf-8'))):
        return O39
    for link in node.find_all(bytes.fromhex('61').decode('utf-8'), href=True):
        if _is_episode_link(_episode_title_from_node(link), link.get(bytes.fromhex('68726566').decode('utf-8'))):
            return link
    return None

def _episode_title_from_node(node):
    if node is None:
        return bytes.fromhex('').decode('utf-8')
    title = _clean(node.get_text(bytes.fromhex('20').decode('utf-8')) or node.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8'))
    if not title:
        lIlIIlllllIllIlIIlIlll = node.find(bytes.fromhex('696d67').decode('utf-8'))
        title = _clean((lIlIIlllllIllIlIIlIlll.get(bytes.fromhex('616c74').decode('utf-8')) if lIlIIlllllIllIlIIlIlll else bytes.fromhex('').decode('utf-8')) or node.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8'))
    return title

def _is_episode_link(title, url):
    value = (title or bytes.fromhex('').decode('utf-8')) + bytes.fromhex('20').decode('utf-8') + (url or bytes.fromhex('').decode('utf-8'))
    if re.search(bytes.fromhex('283f3a706c617965727c667261676d616e7c747261696c65727c796f75747562657c6f6b5c2e72757c7669646d6f6c797c6a6176617363726970743a7c2329').decode('utf-8'), value, re.I):
        return False
    return bool(re.search(bytes.fromhex('283f3a5c642b5c2e3f5c732a73657a6f6e7c5c642b2d73657a6f6e7c5c642b785c642b292e2a3f283f3a5c642b5c2e3f5c732a625b6fc3b65d6c5b75c3bc5d6d7c5c642b2d626f6c756d297c626f6c756d2d697a6c65').decode('utf-8'), value, re.I))

def _is_generic_title(title):
    return _clean(title).lower() in (bytes.fromhex('64697a69626f78').decode('utf-8'), bytes.fromhex('64697a6920626f78').decode('utf-8'), bytes.fromhex('697a6c65').decode('utf-8'), bytes.fromhex('7761746368').decode('utf-8'), bytes.fromhex('').decode('utf-8'))

def _title_from_episode_url(url):
    path = urlparse(url or bytes.fromhex('').decode('utf-8')).path.strip(bytes.fromhex('2f').decode('utf-8'))
    tAPxjEodaAwLpUhXShbOJBRZEJYWKHCoqrYbVyvvCRWSzFsGJBLxRFTUWVxoKosEGSQiAuJlBOmhUgL46 = path.split(bytes.fromhex('2f').decode('utf-8'))[-1]
    if not tAPxjEodaAwLpUhXShbOJBRZEJYWKHCoqrYbVyvvCRWSzFsGJBLxRFTUWVxoKosEGSQiAuJlBOmhUgL46:
        return bytes.fromhex('').decode('utf-8')
    text = re.sub(bytes.fromhex('2d697a6c6524').decode('utf-8'), bytes.fromhex('').decode('utf-8'), tAPxjEodaAwLpUhXShbOJBRZEJYWKHCoqrYbVyvvCRWSzFsGJBLxRFTUWVxoKosEGSQiAuJlBOmhUgL46, flags=re.I)
    text = text.replace(bytes.fromhex('2d').decode('utf-8'), bytes.fromhex('20').decode('utf-8'))
    text = re.sub(bytes.fromhex('5c62285c642b295c732b73657a6f6e5c732b285c642b295c732b626f6c756d5c62').decode('utf-8'), bytes.fromhex('5c312e2053657a6f6e205c322e2042c3b66cc3bc6d').decode('utf-8'), text, flags=re.I)
    return _clean(text.title())

def parse_video_sources(page, page_url, base_url):
    soup = _soup(page)
    sources = []
    a44 = set()

    def add(label, url, referer=None, is_trailer=False):
        fffffffffffffffff = fix_url(url, base_url)
        if not fffffffffffffffff or fffffffffffffffff in a44:
            return
        label = _clean(label)
        aaaAAAaAAaAAAaaaaaAaAaAaaAAaAaaAAaAAAAaaaaAAAAAAAa = bool(is_trailer) or _is_youtube_url(fffffffffffffffff) or _looks_like_trailer(label, fffffffffffffffff)
        if aaaAAAaAAaAAAaaaaaAaAaAaaAAaAaaAAaAAAAaaaaAAAAAAAa and (not label or label.lower() == bytes.fromhex('64697a69626f78').decode('utf-8')):
            label = bytes.fromhex('467261676d616e').decode('utf-8')
        elif not aaaAAAaAAaAAAaaaaaAaAaAaaAAaAaaAAaAAAAaaaaAAAAAAAa and label.lower() == bytes.fromhex('64697a69626f78').decode('utf-8'):
            aAAAAaaAAAaAaaAAAaAAAaAa = _source_label(fffffffffffffffff)
            if aAAAAaaAAAaAaaAAAaAAAaAa != bytes.fromhex('44697a69426f78').decode('utf-8'):
                label = aAAAAaaAAAaAaaAAAaAAAaAa
        a44.add(fffffffffffffffff)
        sources.append({bytes.fromhex('6c6162656c').decode('utf-8'): _display_source_label(label or _source_label(fffffffffffffffff), fffffffffffffffff), bytes.fromhex('75726c').decode('utf-8'): fffffffffffffffff, bytes.fromhex('72656665726572').decode('utf-8'): referer or page_url, bytes.fromhex('69735f747261696c6572').decode('utf-8'): aaaAAAaAAaAAAaaaaaAaAaAaaAAaAaaAAaAAAAaaaaAAAAAAAa})
    if soup is not None:
        for node in soup.select(bytes.fromhex('64697623747261696c65722d626f7820696672616d655b7372635d2c2064697623747261696c65722d626f7820696672616d655b646174612d7372635d2c20615b687265662a3d27796f7574756265275d2c20615b687265662a3d27796f7574752e6265275d2c20615b687265662a3d27667261676d616e275d2c20696672616d655b7372632a3d27796f7574756265275d2c20696672616d655b646174612d7372632a3d27796f7574756265275d2c20615b646174612d766964656f5f75726c5d').decode('utf-8')):
            l20 = _source_url_from_node(node, base_url)
            label = _clean(node.get_text(bytes.fromhex('20').decode('utf-8')) or node.get(bytes.fromhex('7469746c65').decode('utf-8')) or node.get(bytes.fromhex('646174612d7469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8'))
            if _looks_like_trailer(label, l20):
                add(label or _source_label(l20), l20, page_url, True)
        b281512182087649 = [llIIIllIlIIllIIlIlIlIlIllIllllIlIl for llIIIllIlIIllIIlIlIlIlIllIllllIlIl in soup.select(bytes.fromhex('6469762e766964656f2d746f6f6c626172206f7074696f6e5b76616c75655d2c206469762e766964656f2d746f6f6c626172206f7074696f6e5b687265665d').decode('utf-8')) if _clean(llIIIllIlIIllIIlIlIlIlIllIllllIlIl.get(bytes.fromhex('76616c7565').decode('utf-8')) or llIIIllIlIIllIIlIlIlIlIllIllllIlIl.get(bytes.fromhex('68726566').decode('utf-8')))]
        for llIIIllIlIIllIIlIlIlIlIllIllllIlIl in b281512182087649:
            url = _source_url_from_node(llIIIllIlIIllIIlIlIlIlIllIllllIlIl, base_url)
            label = _clean(llIIIllIlIIllIIlIlIlIlIllIllllIlIl.get_text(bytes.fromhex('20').decode('utf-8')) or llIIIllIlIIllIIlIlIlIlIllIllllIlIl.get(bytes.fromhex('6c6162656c').decode('utf-8')) or llIIIllIlIIllIIlIlIlIlIllIllllIlIl.get(bytes.fromhex('646174612d7469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')) or _source_label(url)
            add(label, url, page_url)
        if not b281512182087649:
            AAAAAAAAAAAAAAAAAAAAA = soup.select_one(bytes.fromhex('64697623766964656f2d6172656120696672616d655b7372635d2c2064697623766964656f2d6172656120696672616d655b646174612d7372635d').decode('utf-8')) or soup.select_one(bytes.fromhex('696672616d655b7372632a3d272f706c617965722f275d2c20696672616d655b646174612d7372632a3d272f706c617965722f275d').decode('utf-8'))
            if AAAAAAAAAAAAAAAAAAAAA is not None:
                Y580980220551445 = soup.select_one(bytes.fromhex('6469762e766964656f2d746f6f6c626172206f7074696f6e5b73656c65637465645d').decode('utf-8'))
                label = _clean(Y580980220551445.get_text(bytes.fromhex('20').decode('utf-8'))) if Y580980220551445 else _source_label(AAAAAAAAAAAAAAAAAAAAA.get(bytes.fromhex('646174612d737263').decode('utf-8')) or AAAAAAAAAAAAAAAAAAAAA.get(bytes.fromhex('737263').decode('utf-8')))
                add(label, AAAAAAAAAAAAAAAAAAAAA.get(bytes.fromhex('646174612d737263').decode('utf-8')) or AAAAAAAAAAAAAAAAAAAAA.get(bytes.fromhex('737263').decode('utf-8')), page_url)
    if not any((not source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8')) for source in sources)):
        for tag in re.findall(bytes.fromhex('3c6f7074696f6e5c625b5e3e5d2a283f3a76616c75657c68726566293d5b275c225d5b5e275c225d2b5b275c225d5b5e3e5d2a3e2e2a3f3c2f6f7074696f6e3e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            url = _source_url_from_tag(tag, base_url)
            if not _looks_like_video_url(url) and (not _is_same_site_url(url, base_url)):
                continue
            add(_clean(tag) or _source_label(url), url, page_url)
    if not any((not source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8')) for source in sources)):
        for AAAAAAAAAAAAAAAAAAAAA in re.findall(bytes.fromhex('3c696672616d655c625b5e3e5d2b283f3a646174612d7372637c737263293d5b275c225d285b5e275c225d2b295b275c225d').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            if _is_youtube_url(AAAAAAAAAAAAAAAAAAAAA):
                continue
            add(_source_label(AAAAAAAAAAAAAAAAAAAAA), AAAAAAAAAAAAAAAAAAAAA, page_url)
    if not any((source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8')) for source in sources)):
        aaAaAAAaAaAAAAAAaaAaaAaAAaAaaAAAAaaaAAAAAaAAaaAAAaa = _first(bytes.fromhex('3c6469765c625b5e3e5d2a69643d5b275c225d747261696c65722d626f785b275c225d5b5e3e5d2a3e282e2a3f293c2f6469763e').decode('utf-8'), page, re.S)
        for AAAAAAAAAAAAAAAAAAAAA in re.findall(bytes.fromhex('3c696672616d655c625b5e3e5d2b283f3a646174612d7372637c737263293d5b275c225d285b5e275c225d2b295b275c225d').decode('utf-8'), aaAaAAAaAaAAAAAAaaAaaAaAAaAaaAAAAaaaAAAAAaAAaaAAAaa or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            add(bytes.fromhex('467261676d616e').decode('utf-8'), AAAAAAAAAAAAAAAAAAAAA, page_url, True)
    return sources

def parse_iframe(page, base_url):
    soup = _soup(page)
    if soup is not None:
        AAAAAAAAAAAAAAAAAAAAA = soup.select_one(bytes.fromhex('64697623766964656f2d6172656120696672616d655b7372635d2c2064697623766964656f2d6172656120696672616d655b646174612d7372635d').decode('utf-8')) or soup.select_one(bytes.fromhex('64697623506c6179657220696672616d655b7372635d2c2064697623506c6179657220696672616d655b646174612d7372635d').decode('utf-8')) or soup.find(bytes.fromhex('696672616d65').decode('utf-8'), src=True) or soup.find(bytes.fromhex('696672616d65').decode('utf-8'), attrs={bytes.fromhex('646174612d737263').decode('utf-8'): True})
        if AAAAAAAAAAAAAAAAAAAAA is not None:
            return fix_url(AAAAAAAAAAAAAAAAAAAAA.get(bytes.fromhex('646174612d737263').decode('utf-8')) or AAAAAAAAAAAAAAAAAAAAA.get(bytes.fromhex('737263').decode('utf-8')), base_url)
    return fix_url(_first(bytes.fromhex('3c696672616d655c625b5e3e5d2b283f3a646174612d7372637c737263293d5b275c225d285b5e275c225d2b295b275c225d').decode('utf-8'), page, re.S), base_url)

def _is_youtube_url(url):
    return bool(re.search(bytes.fromhex('283f3a796f75747562655c2e636f6d7c796f7574755c2e626529').decode('utf-8'), url or bytes.fromhex('').decode('utf-8'), re.I))

def _looks_like_trailer(label, url):
    text = (label or bytes.fromhex('').decode('utf-8')) + bytes.fromhex('20').decode('utf-8') + (url or bytes.fromhex('').decode('utf-8'))
    return bool(re.search(bytes.fromhex('283f3a667261676d616e7c747261696c65727c796f75747562655c2e636f6d7c796f7574755c2e626529').decode('utf-8'), text, re.I))

def _looks_like_video_url(url):
    return bool(re.search(bytes.fromhex('283f3a2f706c617965722f7c6f6b5c2e72757c6f646e6f6b6c6173736e696b697c7669646d6f6c797c766964656f62696e7c6d6f6c7973747265616d7c736865696c615c2e73747265616d7c706f70636f726e76616b74697c7275666969677574617c796f75747562655c2e636f6d7c796f7574755c2e62657c5c2e6d3375387c5c2e6d703429').decode('utf-8'), url or bytes.fromhex('').decode('utf-8'), re.I))

def _is_same_site_url(url, base_url):
    if not url:
        return False
    return urlparse(fix_url(url, base_url)).netloc.lower() == urlparse(base_url).netloc.lower()

def _source_label(url):
    text = (url or bytes.fromhex('').decode('utf-8')).lower()
    if _is_youtube_url(text) or bytes.fromhex('667261676d616e').decode('utf-8') in text:
        return bytes.fromhex('467261676d616e').decode('utf-8')
    w27 = ((bytes.fromhex('64627870726f').decode('utf-8'), bytes.fromhex('44425850726f').decode('utf-8')), (bytes.fromhex('2f706c617965722f64656278').decode('utf-8'), bytes.fromhex('44425850726f').decode('utf-8')), (bytes.fromhex('64656278').decode('utf-8'), bytes.fromhex('44425850726f').decode('utf-8')), (bytes.fromhex('6f6b2e7275').decode('utf-8'), bytes.fromhex('4f646e6f6b').decode('utf-8')), (bytes.fromhex('6f646e6f6b6c6173736e696b69').decode('utf-8'), bytes.fromhex('4f646e6f6b').decode('utf-8')), (bytes.fromhex('6f646e6f6b').decode('utf-8'), bytes.fromhex('4f646e6f6b').decode('utf-8')), (bytes.fromhex('7669646d6f6c79').decode('utf-8'), bytes.fromhex('5669644d6f6c79').decode('utf-8')), (bytes.fromhex('766964656f62696e').decode('utf-8'), bytes.fromhex('5669644d6f6c79').decode('utf-8')), (bytes.fromhex('6d6f6c79').decode('utf-8'), bytes.fromhex('4d6f6c792b').decode('utf-8')), (bytes.fromhex('6b696e67').decode('utf-8'), bytes.fromhex('4b696e67').decode('utf-8')), (bytes.fromhex('6861796469').decode('utf-8'), bytes.fromhex('4861796469').decode('utf-8')))
    for kLhhRSGqubcPESNvXAumGWwiccSecMdcwZLpZBXhIvjlvWxbrIbipiEbAxMZqUHlptGRFqgsYyoCYcv31, label in w27:
        if kLhhRSGqubcPESNvXAumGWwiccSecMdcwZLpZBXhIvjlvWxbrIbipiEbAxMZqUHlptGRFqgsYyoCYcv31 in text:
            return label
    return bytes.fromhex('44697a69426f78').decode('utf-8')

def _display_source_label(label, url):
    m763058996984842 = _clean(label)
    KKKKKKKKKKKKKKKKKKKKKKKKKKKKK = m763058996984842.lower()
    kPbBiMiDzlviNCAjKnFIokpqflZUIXwFafEoIqtLItROLfkMreYnOoTTKNkUzIjkTdvOOnybWeQdoXK3 = {bytes.fromhex('646278').decode('utf-8'): bytes.fromhex('44425850726f').decode('utf-8'), bytes.fromhex('64627870726f').decode('utf-8'): bytes.fromhex('44425850726f').decode('utf-8'), bytes.fromhex('6462782070726f').decode('utf-8'): bytes.fromhex('44425850726f').decode('utf-8'), bytes.fromhex('64656278').decode('utf-8'): bytes.fromhex('44425850726f').decode('utf-8'), bytes.fromhex('6d6f6c79').decode('utf-8'): bytes.fromhex('4d6f6c792b').decode('utf-8'), bytes.fromhex('6d6f6c792b').decode('utf-8'): bytes.fromhex('4d6f6c792b').decode('utf-8'), bytes.fromhex('6d6f6c7973747265616d').decode('utf-8'): bytes.fromhex('4d6f6c792b').decode('utf-8'), bytes.fromhex('6f646e6f6b').decode('utf-8'): bytes.fromhex('4f646e6f6b').decode('utf-8'), bytes.fromhex('6f646e6f6b6c6173736e696b69').decode('utf-8'): bytes.fromhex('4f646e6f6b').decode('utf-8'), bytes.fromhex('6f6b').decode('utf-8'): bytes.fromhex('4f646e6f6b').decode('utf-8'), bytes.fromhex('6f6b2e7275').decode('utf-8'): bytes.fromhex('4f646e6f6b').decode('utf-8')}
    if KKKKKKKKKKKKKKKKKKKKKKKKKKKKK in kPbBiMiDzlviNCAjKnFIokpqflZUIXwFafEoIqtLItROLfkMreYnOoTTKNkUzIjkTdvOOnybWeQdoXK3:
        return kPbBiMiDzlviNCAjKnFIokpqflZUIXwFafEoIqtLItROLfkMreYnOoTTKNkUzIjkTdvOOnybWeQdoXK3[KKKKKKKKKKKKKKKKKKKKKKKKKKKKK]
    if KKKKKKKKKKKKKKKKKKKKKKKKKKKKK in (bytes.fromhex('').decode('utf-8'), bytes.fromhex('64697a69626f78').decode('utf-8'), bytes.fromhex('64697a6920626f78').decode('utf-8'), bytes.fromhex('616c7465726e61746966').decode('utf-8')):
        return _source_label(url)
    return m763058996984842

def _source_url_from_node(node, base_url):
    if node is None:
        return bytes.fromhex('').decode('utf-8')
    CEKMzxAWfWMfthVKDEHFfWwDocsadcsXHyDYnYAwXeaJDhVIkawthcUjdPUycurxvspqrMbgUKAgbym5 = (bytes.fromhex('646174612d766964656f5f75726c').decode('utf-8'), bytes.fromhex('646174612d766964656f2d75726c').decode('utf-8'), bytes.fromhex('646174612d737263').decode('utf-8'), bytes.fromhex('646174612d696672616d65').decode('utf-8'), bytes.fromhex('646174612d75726c').decode('utf-8'), bytes.fromhex('646174612d68726566').decode('utf-8'), bytes.fromhex('68726566').decode('utf-8'), bytes.fromhex('737263').decode('utf-8'), bytes.fromhex('76616c7565').decode('utf-8'))
    for name in CEKMzxAWfWMfthVKDEHFfWwDocsadcsXHyDYnYAwXeaJDhVIkawthcUjdPUycurxvspqrMbgUKAgbym5:
        value = node.get(name)
        if value and value != bytes.fromhex('23').decode('utf-8'):
            if _looks_like_video_url(value) or value.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'), bytes.fromhex('2f2f').decode('utf-8'))):
                return value
    token = node.get(bytes.fromhex('646174612d766964656f').decode('utf-8')) or node.get(bytes.fromhex('646174612d68617368').decode('utf-8')) or node.get(bytes.fromhex('646174612d6964').decode('utf-8')) or node.get(bytes.fromhex('76616c7565').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
    player = _clean(node.get(bytes.fromhex('646174612d74797065').decode('utf-8')) or node.get(bytes.fromhex('646174612d706c61796572').decode('utf-8')) or node.get(bytes.fromhex('646174612d7469746c65').decode('utf-8')) or node.get(bytes.fromhex('6c6162656c').decode('utf-8')) or node.get_text(bytes.fromhex('20').decode('utf-8')) or bytes.fromhex('').decode('utf-8')).lower()
    return _build_player_url(token, player, base_url)

def _source_url_from_tag(tag, base_url):
    for name in (bytes.fromhex('646174612d766964656f5f75726c').decode('utf-8'), bytes.fromhex('646174612d766964656f2d75726c').decode('utf-8'), bytes.fromhex('646174612d737263').decode('utf-8'), bytes.fromhex('646174612d696672616d65').decode('utf-8'), bytes.fromhex('646174612d75726c').decode('utf-8'), bytes.fromhex('646174612d68726566').decode('utf-8'), bytes.fromhex('68726566').decode('utf-8'), bytes.fromhex('737263').decode('utf-8'), bytes.fromhex('76616c7565').decode('utf-8')):
        value = _attr(tag, name)
        if value and value != bytes.fromhex('23').decode('utf-8'):
            if _looks_like_video_url(value) or value.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'), bytes.fromhex('2f2f').decode('utf-8'))):
                return value
    token = _attr(tag, bytes.fromhex('646174612d766964656f').decode('utf-8')) or _attr(tag, bytes.fromhex('646174612d68617368').decode('utf-8')) or _attr(tag, bytes.fromhex('646174612d6964').decode('utf-8')) or _attr(tag, bytes.fromhex('76616c7565').decode('utf-8'))
    player = _clean(_attr(tag, bytes.fromhex('646174612d74797065').decode('utf-8')) or _attr(tag, bytes.fromhex('646174612d706c61796572').decode('utf-8')) or _attr(tag, bytes.fromhex('646174612d7469746c65').decode('utf-8')) or _attr(tag, bytes.fromhex('6c6162656c').decode('utf-8')) or tag).lower()
    return _build_player_url(token, player, base_url)

def _build_player_url(token, player, base_url):
    token = html.unescape((token or bytes.fromhex('').decode('utf-8')).strip())
    if not token or token == bytes.fromhex('23').decode('utf-8'):
        return bytes.fromhex('').decode('utf-8')
    if _looks_like_video_url(token) or token.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'), bytes.fromhex('2f2f').decode('utf-8'))):
        return token
    if bytes.fromhex('6f6b').decode('utf-8') in player or bytes.fromhex('6f646e6f6b6c6173736e696b69').decode('utf-8') in player:
        return bytes.fromhex('68747470733a2f2f6f6b2e72752f766964656f656d6265642f').decode('utf-8') + token if token.isdigit() else bytes.fromhex('').decode('utf-8')
    if bytes.fromhex('7669646d6f6c79').decode('utf-8') in player or bytes.fromhex('766964656f62696e').decode('utf-8') in player:
        if token.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8'), bytes.fromhex('2f2f').decode('utf-8'))):
            return token
        if re.match(bytes.fromhex('5e5b612d7a302d395f2d5d2b24').decode('utf-8'), token, re.I):
            return bytes.fromhex('68747470733a2f2f7669646d6f6c792e746f2f656d6265642d').decode('utf-8') + token + bytes.fromhex('2e68746d6c').decode('utf-8')
        return bytes.fromhex('').decode('utf-8')
    if bytes.fromhex('646278').decode('utf-8') in player or bytes.fromhex('64656278').decode('utf-8') in player:
        return base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f706c617965722f646562782e7068703f763d').decode('utf-8') + token
    if bytes.fromhex('6d6f6c79').decode('utf-8') in player:
        return base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f706c617965722f6d6f6c792f6d6f6c792e7068703f683d').decode('utf-8') + token
    if bytes.fromhex('6861796469').decode('utf-8') in player:
        return base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f706c617965722f68617964692e7068703f763d').decode('utf-8') + token
    if bytes.fromhex('6b696e67').decode('utf-8') in player:
        return base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f706c617965722f6b696e672f6b696e672e7068703f763d').decode('utf-8') + token
    return bytes.fromhex('').decode('utf-8')

def fix_url(url, base_url):
    if not url:
        return bytes.fromhex('').decode('utf-8')
    return urljoin(base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8'), html.unescape(url).strip())

def _image_url_from_node(node, base_url):
    if node is None:
        return bytes.fromhex('').decode('utf-8')
    if getattr(node, bytes.fromhex('6e616d65').decode('utf-8'), bytes.fromhex('').decode('utf-8')) == bytes.fromhex('6d657461').decode('utf-8'):
        value = node.get(bytes.fromhex('636f6e74656e74').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
    else:
        value = node.get(bytes.fromhex('646174612d737263').decode('utf-8')) or node.get(bytes.fromhex('646174612d6c617a792d737263').decode('utf-8')) or node.get(bytes.fromhex('646174612d6f726967696e616c').decode('utf-8')) or node.get(bytes.fromhex('646174612d737263736574').decode('utf-8')) or node.get(bytes.fromhex('737263736574').decode('utf-8')) or node.get(bytes.fromhex('737263').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
    value = (value or bytes.fromhex('').decode('utf-8')).split(bytes.fromhex('2c').decode('utf-8'))[0].strip().split(bytes.fromhex('20').decode('utf-8'))[0]
    if not value or value.lower().startswith(bytes.fromhex('646174613a696d616765').decode('utf-8')):
        return bytes.fromhex('').decode('utf-8')
    return fix_url(value, base_url)

def _poster_from_html(page, base_url):
    cccccccccccccccccccccccccccccccccccc = (bytes.fromhex('3c6d6574615c625b5e3e5d2a283f3a70726f70657274797c6e616d65293d5b275c225d6f673a696d6167655b275c225d5b5e3e5d2a3e').decode('utf-8'), bytes.fromhex('3c696d675c625b5e3e5d2a636c6173733d5b275c225d5b5e275c225d2a283f3a706f737465727c7468756d627c696d6167657c636f766572295b5e275c225d2a5b275c225d5b5e3e5d2a3e').decode('utf-8'), bytes.fromhex('3c696d675c625b5e3e5d2a3e').decode('utf-8'))
    for pattern in cccccccccccccccccccccccccccccccccccc:
        tag = _first(pattern, page, re.S)
        if not tag:
            continue
        value = _attr(tag, bytes.fromhex('636f6e74656e74').decode('utf-8')) or _attr(tag, bytes.fromhex('646174612d737263').decode('utf-8')) or _attr(tag, bytes.fromhex('646174612d6c617a792d737263').decode('utf-8')) or _attr(tag, bytes.fromhex('646174612d6f726967696e616c').decode('utf-8')) or _attr(tag, bytes.fromhex('646174612d737263736574').decode('utf-8')) or _attr(tag, bytes.fromhex('737263736574').decode('utf-8')) or _attr(tag, bytes.fromhex('737263').decode('utf-8'))
        value = (value or bytes.fromhex('').decode('utf-8')).split(bytes.fromhex('2c').decode('utf-8'))[0].strip().split(bytes.fromhex('20').decode('utf-8'))[0]
        if value and (not value.lower().startswith(bytes.fromhex('646174613a696d616765').decode('utf-8'))):
            return fix_url(value, base_url)
    return bytes.fromhex('').decode('utf-8')

def _parse_genres_with_soup(page, base_url, archive_url):
    soup = _soup(page)
    if soup is None:
        return []
    AAAAaaAAAAAaaAaAAA = _find_heading_region(soup, bytes.fromhex('54c3bc72').decode('utf-8'), stop_texts=(bytes.fromhex('c39c6c6b65').decode('utf-8'), bytes.fromhex('596170c4b16d2059c4b16cc4b1').decode('utf-8'), bytes.fromhex('494d4462').decode('utf-8'), bytes.fromhex('46c4b04c5452454c454d45').decode('utf-8')))
    IlFpnTvXiMXUGavZhGwWqHQfOkGGKAkwUrMuaDuHjWzdCiezEzwWXPuvbYMenwkGebyzfQJkqrvYOiT10 = AAAAaaAAAAAaaAaAAA.find_all([bytes.fromhex('61').decode('utf-8'), bytes.fromhex('6c6162656c').decode('utf-8'), bytes.fromhex('696e707574').decode('utf-8'), bytes.fromhex('6f7074696f6e').decode('utf-8')]) if AAAAaaAAAAAaaAaAAA is not None else []
    eeeeeeeeeeeeeeeeeeeeeeeeee = []
    a44 = set()
    for node in IlFpnTvXiMXUGavZhGwWqHQfOkGGKAkwUrMuaDuHjWzdCiezEzwWXPuvbYMenwkGebyzfQJkqrvYOiT10:
        text = _clean(node.get_text(bytes.fromhex('20').decode('utf-8')))
        value = bytes.fromhex('').decode('utf-8')
        l20 = bytes.fromhex('').decode('utf-8')
        if getattr(node, bytes.fromhex('6e616d65').decode('utf-8'), bytes.fromhex('').decode('utf-8')) == bytes.fromhex('696e707574').decode('utf-8'):
            text = _clean(node.get(bytes.fromhex('76616c7565').decode('utf-8')) or node.get(bytes.fromhex('646174612d7469746c65').decode('utf-8')) or node.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8'))
            value = node.get(bytes.fromhex('76616c7565').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
            name = node.get(bytes.fromhex('6e616d65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        else:
            p884345884327325 = node.find(bytes.fromhex('696e707574').decode('utf-8')) if hasattr(node, bytes.fromhex('66696e64').decode('utf-8')) else None
            if p884345884327325 is not None:
                text = text or _clean(p884345884327325.get(bytes.fromhex('76616c7565').decode('utf-8')) or bytes.fromhex('').decode('utf-8'))
                value = p884345884327325.get(bytes.fromhex('76616c7565').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
                name = p884345884327325.get(bytes.fromhex('6e616d65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
            else:
                name = node.get(bytes.fromhex('6e616d65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        if getattr(node, bytes.fromhex('6e616d65').decode('utf-8'), bytes.fromhex('').decode('utf-8')) == bytes.fromhex('61').decode('utf-8'):
            l20 = node.get(bytes.fromhex('68726566').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        if text not in GENRE_NAMES and text.title() not in GENRE_NAMES:
            continue
        title = _canonical_genre_name(text)
        if title in a44:
            continue
        a44.add(title)
        if l20:
            url = fix_url(l20, base_url)
        elif value and name:
            url = _genre_filter_url(archive_url, title, param=name, value=value)
        else:
            url = _genre_filter_url(archive_url, title)
        eeeeeeeeeeeeeeeeeeeeeeeeee.append((title, url))
    return eeeeeeeeeeeeeeeeeeeeeeeeee

def _parse_genres_with_regex(page, base_url, archive_url):
    AaaaAA = _first(bytes.fromhex('54c3bc725c732a282e2a3f29283f3ac39c6c6b657c596170c4b16d2059c4b16cc4b17c494d44627c46c4b04c5452454c454d4529').decode('utf-8'), _html_text_with_links(page), re.S | re.I)
    eeeeeeeeeeeeeeeeeeeeeeeeee = []
    a44 = set()
    for name in GENRE_NAMES:
        if re.search(bytes.fromhex('283f3a5e7c5c6e295c732a7b307d5c732a283f3a5c6e7c2429').decode('utf-8').format(re.escape(name)), AaaaAA or bytes.fromhex('').decode('utf-8'), re.I):
            if name not in a44:
                a44.add(name)
                eeeeeeeeeeeeeeeeeeeeeeeeee.append((name, _genre_filter_url(archive_url, name)))
    return eeeeeeeeeeeeeeeeeeeeeeeeee

def _parse_page_items_with_soup(soup, base_url):
    N179188471013014 = _parse_detailed_articles(soup, base_url)
    if N179188471013014:
        return N179188471013014
    eeeeeeeeeeeeeeeeeeeeeeeeee = []
    a44 = set()
    for link in soup.find_all(bytes.fromhex('61').decode('utf-8'), href=True):
        l20 = link.get(bytes.fromhex('68726566').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        if bytes.fromhex('2f64697a696c65722f').decode('utf-8') not in l20:
            continue
        title = _clean(link.get_text(bytes.fromhex('20').decode('utf-8')) or link.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8'))
        if not title:
            aaaAaAaAaAAaAaAAaaaaaaA = link.find(bytes.fromhex('696d67').decode('utf-8'))
            title = _clean((aaaAaAaAaAAaAaAAaaaaaaA.get(bytes.fromhex('616c74').decode('utf-8')) if aaaAaAaAaAAaAaAAaaaaaaA else bytes.fromhex('').decode('utf-8')) or bytes.fromhex('').decode('utf-8'))
        title = _clean_title(title)
        if not title:
            continue
        url = fix_url(l20, base_url)
        if url in a44:
            continue
        a44.add(url)
        aaaAaAaAaAAaAaAAaaaaaaA = link.find(bytes.fromhex('696d67').decode('utf-8')) or _near_image(link)
        lIlIIlllllIllIlIIlIlll = fix_url(aaaAaAaAaAAaAaAAaaaaaaA.get(bytes.fromhex('646174612d737263').decode('utf-8')) or aaaAaAaAaAAaAaAAaaaaaaA.get(bytes.fromhex('737263').decode('utf-8')) if aaaAaAaAaAAaAaAAaaaaaaA else bytes.fromhex('').decode('utf-8'), base_url)
        p360175364299837 = _near_plot(link)
        eeeeeeeeeeeeeeeeeeeeeeeeee.append({bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('696d616765').decode('utf-8'): lIlIIlllllIllIlIIlIlll, bytes.fromhex('706c6f74').decode('utf-8'): p360175364299837})
    return eeeeeeeeeeeeeeeeeeeeeeeeee

def _parse_page_items_with_regex(page, base_url):
    eeeeeeeeeeeeeeeeeeeeeeeeee = []
    a44 = set()
    for AaaaAA in re.findall(bytes.fromhex('3c61727469636c655c625b5e3e5d2a636c6173733d5b275c225d5b5e275c225d2a5c6264657461696c65642d61727469636c655c625b5e275c225d2a5b275c225d5b5e3e5d2a3e2e2a3f3c2f61727469636c653e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
        link = _first(bytes.fromhex('3c68335b5e3e5d2a3e2e2a3f3c615c625b5e3e5d2a687265663d5b275c225d5b5e275c225d2b5b275c225d5b5e3e5d2a3e2e2a3f3c2f613e').decode('utf-8'), AaaaAA, re.S)
        l20 = _attr(link, bytes.fromhex('68726566').decode('utf-8'))
        title = _clean_title(_clean(link))
        if not title or not l20:
            continue
        url = fix_url(l20, base_url)
        if url in a44:
            continue
        a44.add(url)
        lIlIIlllllIllIlIIlIlll = fix_url(_attr(_first(bytes.fromhex('3c696d675c625b5e3e5d2a3e').decode('utf-8'), AaaaAA, re.S), bytes.fromhex('646174612d737263').decode('utf-8')) or _attr(_first(bytes.fromhex('3c696d675c625b5e3e5d2a3e').decode('utf-8'), AaaaAA, re.S), bytes.fromhex('737263').decode('utf-8')), base_url)
        p360175364299837 = _clean(re.sub(bytes.fromhex('2e2a3f3c2f68333e').decode('utf-8'), bytes.fromhex('').decode('utf-8'), AaaaAA, flags=re.S | re.I))
        eeeeeeeeeeeeeeeeeeeeeeeeee.append({bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('696d616765').decode('utf-8'): lIlIIlllllIllIlIIlIlll, bytes.fromhex('706c6f74').decode('utf-8'): p360175364299837})
    if eeeeeeeeeeeeeeeeeeeeeeeeee:
        return eeeeeeeeeeeeeeeeeeeeeeeeee
    eeeeeeeeeeeeeeeeeeeeeeeeee = []
    a44 = set()
    for match in re.finditer(bytes.fromhex('3c615c625b5e3e5d2a687265663d5b275c225d285b5e275c225d2a2f64697a696c65722f5b5e275c225d2b295b275c225d5b5e3e5d2a3e282e2a3f293c2f613e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
        url = fix_url(match.group(1), base_url)
        title = _clean_title(_clean(match.group(2)) or _attr(match.group(0), bytes.fromhex('7469746c65').decode('utf-8')))
        if not title or url in a44:
            continue
        a44.add(url)
        eeeeeeeeeeeeeeeeeeeeeeeeee.append({bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('696d616765').decode('utf-8'): bytes.fromhex('').decode('utf-8'), bytes.fromhex('706c6f74').decode('utf-8'): bytes.fromhex('').decode('utf-8')})
    return eeeeeeeeeeeeeeeeeeeeeeeeee

def _genre_filter_url(archive_url, title, param=bytes.fromhex('747572').decode('utf-8'), value=None):
    tAPxjEodaAwLpUhXShbOJBRZEJYWKHCoqrYbVyvvCRWSzFsGJBLxRFTUWVxoKosEGSQiAuJlBOmhUgL46 = value or GENRE_SLUGS.get(title) or _slug(title)
    if param.startswith(bytes.fromhex('747572').decode('utf-8')):
        return archive_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f706167652f53415946412f3f7475725b305d3d7b307d2679696c26696d6462').decode('utf-8').format(quote_plus(tAPxjEodaAwLpUhXShbOJBRZEJYWKHCoqrYbVyvvCRWSzFsGJBLxRFTUWVxoKosEGSQiAuJlBOmhUgL46))
    return archive_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f706167652f53415946412f3f7b307d3d7b317d2679696c26696d6462').decode('utf-8').format(param, quote_plus(tAPxjEodaAwLpUhXShbOJBRZEJYWKHCoqrYbVyvvCRWSzFsGJBLxRFTUWVxoKosEGSQiAuJlBOmhUgL46))

def _country_filter_url(archive_url, value):
    return archive_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f706167652f53415946412f3f756c6b655b5d3d7b307d2679696c3d26696d6462').decode('utf-8').format(quote_plus(value))

def _parse_detailed_articles(soup, base_url):
    eeeeeeeeeeeeeeeeeeeeeeeeee = []
    a44 = set()
    for lIIl in soup.select(bytes.fromhex('61727469636c652e64657461696c65642d61727469636c65').decode('utf-8')):
        link = lIIl.select_one(bytes.fromhex('683320615b687265665d').decode('utf-8')) or lIIl.find(bytes.fromhex('61').decode('utf-8'), href=True)
        if link is None:
            continue
        title = _clean_title(link.get_text(bytes.fromhex('20').decode('utf-8')) or link.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8'))
        l20 = link.get(bytes.fromhex('68726566').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        if not title or not l20:
            continue
        url = fix_url(l20, base_url)
        if url in a44:
            continue
        a44.add(url)
        aaaAaAaAaAAaAaAAaaaaaaA = lIIl.find(bytes.fromhex('696d67').decode('utf-8'))
        lIlIIlllllIllIlIIlIlll = fix_url(aaaAaAaAaAAaAaAAaaaaaaA.get(bytes.fromhex('646174612d737263').decode('utf-8')) or aaaAaAaAaAAaAaAAaaaaaaA.get(bytes.fromhex('737263').decode('utf-8')) if aaaAaAaAaAAaAaAAaaaaaaA else bytes.fromhex('').decode('utf-8'), base_url)
        AaaaAaAAAAAAA = lIIl.select_one(bytes.fromhex('70').decode('utf-8'))
        p360175364299837 = _clean(AaaaAaAAAAAAA.get_text(bytes.fromhex('20').decode('utf-8'))) if AaaaAaAAAAAAA else bytes.fromhex('').decode('utf-8')
        eeeeeeeeeeeeeeeeeeeeeeeeee.append({bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('696d616765').decode('utf-8'): lIlIIlllllIllIlIIlIlll, bytes.fromhex('706c6f74').decode('utf-8'): p360175364299837})
    return eeeeeeeeeeeeeeeeeeeeeeeeee

def _slug(value):
    AaaaaaaaAaaAaAaAAaAAaaAAaAaaaaAaaAAaAaaaAaAaaaa = {bytes.fromhex('c4b1').decode('utf-8'): bytes.fromhex('69').decode('utf-8'), bytes.fromhex('c4b0').decode('utf-8'): bytes.fromhex('69').decode('utf-8'), bytes.fromhex('c49f').decode('utf-8'): bytes.fromhex('67').decode('utf-8'), bytes.fromhex('c49e').decode('utf-8'): bytes.fromhex('67').decode('utf-8'), bytes.fromhex('c3bc').decode('utf-8'): bytes.fromhex('75').decode('utf-8'), bytes.fromhex('c39c').decode('utf-8'): bytes.fromhex('75').decode('utf-8'), bytes.fromhex('c59f').decode('utf-8'): bytes.fromhex('73').decode('utf-8'), bytes.fromhex('c59e').decode('utf-8'): bytes.fromhex('73').decode('utf-8'), bytes.fromhex('c3b6').decode('utf-8'): bytes.fromhex('6f').decode('utf-8'), bytes.fromhex('c396').decode('utf-8'): bytes.fromhex('6f').decode('utf-8'), bytes.fromhex('c3a7').decode('utf-8'): bytes.fromhex('63').decode('utf-8'), bytes.fromhex('c387').decode('utf-8'): bytes.fromhex('63').decode('utf-8')}
    text = bytes.fromhex('').decode('utf-8').join((AaaaaaaaAaaAaAaAAaAAaaAAaAaaaaAaaAAaAaaaAaAaaaa.get(W984521728831311, W984521728831311) for W984521728831311 in value.lower()))
    return re.sub(bytes.fromhex('5b5e612d7a302d395d2b').decode('utf-8'), bytes.fromhex('2d').decode('utf-8'), text).strip(bytes.fromhex('2d').decode('utf-8'))

def _soup(page):
    if manituxhttp.BeautifulSoup is None:
        return None
    return manituxhttp.BeautifulSoup(page or bytes.fromhex('').decode('utf-8'), bytes.fromhex('68746d6c2e706172736572').decode('utf-8'))

def _find_heading_region(soup, text, stop_texts=()):
    aAaAaAAAaAAAaAaAaAAAAAaAaAAaaa = soup.find(string=lambda value: _clean(value) == text)
    if aAaAaAAAaAAAaAaAaAAAAAaAaAAaaa is None:
        return None
    Z52 = aAaAaAAAaAAAaAaAaAAAAAaAaAAaaa.parent
    while Z52 is not None and Z52.name not in (bytes.fromhex('626f6479').decode('utf-8'), bytes.fromhex('666f726d').decode('utf-8'), bytes.fromhex('6173696465').decode('utf-8'), bytes.fromhex('73656374696f6e').decode('utf-8'), bytes.fromhex('646976').decode('utf-8')):
        Z52 = Z52.parent
    if Z52 is None:
        return None
    return Z52

def _canonical_genre_name(text):
    for name in GENRE_NAMES:
        if name.lower() == text.lower():
            return name
    return text

def _near_image(link):
    parent = link.parent
    for A61241278415881 in range(4):
        if parent is None:
            return None
        aaaAaAaAaAAaAaAAaaaaaaA = parent.find(bytes.fromhex('696d67').decode('utf-8')) if hasattr(parent, bytes.fromhex('66696e64').decode('utf-8')) else None
        if aaaAaAaAaAAaAaAAaaaaaaA is not None:
            return aaaAaAaAaAAaAaAAaaaaaaA
        parent = parent.parent
    return None

def _near_plot(link):
    parent = link.parent
    for A61241278415881 in range(4):
        if parent is None:
            return bytes.fromhex('').decode('utf-8')
        text = _clean(parent.get_text(bytes.fromhex('20').decode('utf-8'))) if hasattr(parent, bytes.fromhex('6765745f74657874').decode('utf-8')) else bytes.fromhex('').decode('utf-8')
        if len(text) > 80:
            return text
        parent = parent.parent
    return bytes.fromhex('').decode('utf-8')

def _html_text_with_links(page):
    soup = _soup(page)
    if soup is not None:
        return soup.get_text(bytes.fromhex('0a').decode('utf-8'))
    return _clean(page).replace(bytes.fromhex('202a20').decode('utf-8'), bytes.fromhex('0a').decode('utf-8'))

def _attr(tag, name):
    if not tag:
        return bytes.fromhex('').decode('utf-8')
    match = re.search(bytes.fromhex('5c627b307d3d5b225c275d285b5e225c275d2b295b225c275d').decode('utf-8').format(re.escape(name)), tag, re.I)
    return html.unescape(match.group(1)) if match else bytes.fromhex('').decode('utf-8')

def _first(pattern, text, flags=0):
    match = re.search(pattern, text or bytes.fromhex('').decode('utf-8'), flags | re.I)
    if not match:
        return bytes.fromhex('').decode('utf-8')
    return match.group(1) if match.lastindex else match.group(0)

def _clean_title(value):
    value = _clean(value)
    value = re.sub(bytes.fromhex('5c732b697a6c655c732a24').decode('utf-8'), bytes.fromhex('').decode('utf-8'), value, flags=re.I).strip()
    return value

def _clean(text):
    text = re.sub(bytes.fromhex('3c7363726970742e2a3f3c2f7363726970743e').decode('utf-8'), bytes.fromhex('20').decode('utf-8'), text or bytes.fromhex('').decode('utf-8'), flags=re.S | re.I)
    text = re.sub(bytes.fromhex('3c7374796c652e2a3f3c2f7374796c653e').decode('utf-8'), bytes.fromhex('20').decode('utf-8'), text, flags=re.S | re.I)
    text = re.sub(bytes.fromhex('3c5b5e3e5d2b3e').decode('utf-8'), bytes.fromhex('20').decode('utf-8'), text)
    text = html.unescape(text)
    return re.sub(bytes.fromhex('5c732b').decode('utf-8'), bytes.fromhex('20').decode('utf-8'), text).strip()
