from __future__ import absolute_import, unicode_literals
import time
import re
import manituxhttp
try:
    from urllib.parse import quote_plus, urlparse
except ImportError:
    from urllib import quote_plus
    from urlparse import urlparse
from .extractor import DiziBoxExtractor
from . import parsers

class DiziBoxSite(object):
    ARCHIVE_PATH = bytes.fromhex('2f64697a692d6172736976692f').decode('utf-8')

    def __init__(self, base_url, user_agent):
        self.base_url = base_url.rstrip(bytes.fromhex('2f').decode('utf-8'))
        self.user_agent = user_agent
        self.session = manituxhttp.Session()
        self.extractor = DiziBoxExtractor(user_agent, self.base_url)

    def headers(self, referer=None):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): self.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('746578742f68746d6c2c6170706c69636174696f6e2f7868746d6c2b786d6c2c6170706c69636174696f6e2f786d6c3b713d302e392c2a2f2a3b713d302e38').decode('utf-8'), bytes.fromhex('4163636570742d4c616e6775616765').decode('utf-8'): bytes.fromhex('74722d54522c74723b713d302e392c656e2d55533b713d302e382c656e3b713d302e37').decode('utf-8'), bytes.fromhex('436f6f6b6965').decode('utf-8'): bytes.fromhex('697354727573746564557365723d747275653b20646278753d7b307d').decode('utf-8').format(int(time.time() * 1000)), bytes.fromhex('557067726164652d496e7365637572652d5265717565737473').decode('utf-8'): bytes.fromhex('31').decode('utf-8')}
        if referer:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        return headers

    def get(self, url, referer=None):
        uLyxDlXjmgHvEvYUXrJvOXpPfyJfifYSyAKAUnHFXTubZLmxaylAmOIDFFETRdCPIuFcDyXTqeoFgLn8 = self.session.get(self.absolute(url), headers=self.headers(referer), timeout=25, allow_redirects=True)
        uLyxDlXjmgHvEvYUXrJvOXpPfyJfifYSyAKAUnHFXTubZLmxaylAmOIDFFETRdCPIuFcDyXTqeoFgLn8.raise_for_status()
        return uLyxDlXjmgHvEvYUXrJvOXpPfyJfifYSyAKAUnHFXTubZLmxaylAmOIDFFETRdCPIuFcDyXTqeoFgLn8.text

    def categories(self):
        return parsers.fallback_genres(self.base_url)

    def get_page_items(self, category_url, page_number=1):
        url = parsers.page_url(category_url, page_number)
        page = self.get(url, referer=self.base_url + self.ARCHIVE_PATH)
        return (parsers.parse_page_items(page, self.base_url), parsers.has_next_page(page, page_number))

    def search(self, query):
        page = self.get(self.base_url + bytes.fromhex('2f3f733d').decode('utf-8') + quote_plus(query), referer=self.base_url + bytes.fromhex('2f').decode('utf-8'))
        return (parsers.parse_page_items(page, self.base_url), parsers.has_next_page(page, 1))

    def detail(self, url):
        page = self.get(url)
        FSpfzLTLzudHEXFknmAHXhWhkmxUUHYWzultlVtXijtqABHtdgbHhOxxYnvRDOMLTTHvHCFIefGRxfI6 = parsers.parse_detail(page, url, self.base_url)
        FSpfzLTLzudHEXFknmAHXhWhkmxUUHYWzultlVtXijtqABHtdgbHhOxxYnvRDOMLTTHvHCFIefGRxfI6[bytes.fromhex('657069736f646573').decode('utf-8')] = self.sort_episodes(FSpfzLTLzudHEXFknmAHXhWhkmxUUHYWzultlVtXijtqABHtdgbHhOxxYnvRDOMLTTHvHCFIefGRxfI6.get(bytes.fromhex('657069736f646573').decode('utf-8')) or [])
        if not self.is_episode_url(url):
            FSpfzLTLzudHEXFknmAHXhWhkmxUUHYWzultlVtXijtqABHtdgbHhOxxYnvRDOMLTTHvHCFIefGRxfI6[bytes.fromhex('736f7572636573').decode('utf-8')] = [source for source in FSpfzLTLzudHEXFknmAHXhWhkmxUUHYWzultlVtXijtqABHtdgbHhOxxYnvRDOMLTTHvHCFIefGRxfI6.get(bytes.fromhex('736f7572636573').decode('utf-8'), []) if source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8'))]
        return FSpfzLTLzudHEXFknmAHXhWhkmxUUHYWzultlVtXijtqABHtdgbHhOxxYnvRDOMLTTHvHCFIefGRxfI6

    def parse_detail(self, page, url):
        return parsers.parse_detail(page, url, self.base_url)

    def load_episodes(self, season_links, referer=None):
        episodes = []
        yoqRrzhAfQGFOadFrOcZZDTUJVfephwAfkviPKEtQMowtdFzuHijBarsbmzOzMajsiOWdAnbIuRpuNX11 = set()
        for aAaAAAAaa in season_links:
            f10 = aAaAAAAaa.get(bytes.fromhex('75726c').decode('utf-8'))
            if not f10:
                continue
            try:
                page = self.get(f10, referer=referer or self.base_url)
            except Exception:
                continue
            for II in parsers.parse_episodes(page, self.base_url):
                o47195246467473 = II.get(bytes.fromhex('75726c').decode('utf-8'))
                if not o47195246467473 or o47195246467473 in yoqRrzhAfQGFOadFrOcZZDTUJVfephwAfkviPKEtQMowtdFzuHijBarsbmzOzMajsiOWdAnbIuRpuNX11:
                    continue
                yoqRrzhAfQGFOadFrOcZZDTUJVfephwAfkviPKEtQMowtdFzuHijBarsbmzOzMajsiOWdAnbIuRpuNX11.add(o47195246467473)
                episodes.append(II)
        return episodes

    def fetch_iframe(self, url, referer=None):
        page = self.get(url, referer=referer)
        fffff = parsers.parse_iframe(page, self.base_url)
        if fffff:
            return fffff
        detail = parsers.parse_detail(page, url, self.base_url)
        sources = [source for source in detail.get(bytes.fromhex('736f7572636573').decode('utf-8'), []) if not source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8'))]
        return sources[0][bytes.fromhex('75726c').decode('utf-8')] if sources else bytes.fromhex('').decode('utf-8')

    def resolve_source(self, url, referer=None, label=bytes.fromhex('').decode('utf-8')):
        zzzzzzzzzzzz = self.absolute(url)
        if self.is_site_page(zzzzzzzzzzzz):
            fffff = self.fetch_iframe(zzzzzzzzzzzz, referer=referer)
            if fffff:
                return self.extractor.resolve(fffff, zzzzzzzzzzzz, label)
        return self.extractor.resolve(zzzzzzzzzzzz, referer, label)

    def absolute(self, url):
        return parsers.fix_url(url, self.base_url)

    def is_site_page(self, url):
        llII = urlparse(url or bytes.fromhex('').decode('utf-8')).netloc.lower()
        V1 = urlparse(self.base_url).netloc.lower()
        return llII == V1 and bytes.fromhex('2f706c617965722f').decode('utf-8') not in (url or bytes.fromhex('').decode('utf-8'))

    @staticmethod
    def is_episode_url(url):
        return bool(re.search(bytes.fromhex('283f3a5c642b2d73657a6f6e2d5c642b2d626f6c756d7c5c642b785c642b7c626f6c756d283f3a2d7c242929').decode('utf-8'), url or bytes.fromhex('').decode('utf-8'), re.I))

    @staticmethod
    def sort_episodes(episodes):
        return sorted(episodes or [], key=lambda j7: (j7.get(bytes.fromhex('736561736f6e').decode('utf-8')) or 0, j7.get(bytes.fromhex('657069736f6465').decode('utf-8')) or 0, j7.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')))
