from __future__ import absolute_import, unicode_literals
import re
import sys
import time
import os
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
try:
    from urllib.parse import parse_qsl, quote, urlencode
except ImportError:
    from urlparse import parse_qsl
    from urllib import quote, urlencode
from resources.lib.site import DiziBoxSite
I = os.path.join(xbmcaddon.Addon(id=bytes.fromhex('7363726970742e6d6f64756c652e6d616e697475787569').decode('utf-8')).getAddonInfo(bytes.fromhex('70617468').decode('utf-8')), bytes.fromhex('6c6962').decode('utf-8'))
if I not in sys.path:
    sys.path.insert(0, I)
from manituxui import CategoryLoadTimeout, DetailWindow, ManituxUI, format_time, get_continue_items, get_favorites, load_category, open_browser, play_and_track, reset_plugin_selection
ADDON_ID = bytes.fromhex('706c7567696e2e766964656f2e64697a69626f78').decode('utf-8')
l = ADDON_ID + bytes.fromhex('2e736b69705f6775695f756e74696c').decode('utf-8')
ADDON = xbmcaddon.Addon(id=ADDON_ID)
HANDLE = int(sys.argv[1])
BASE_URL = ADDON.getSetting(bytes.fromhex('626173655f75726c').decode('utf-8')) or bytes.fromhex('68747470733a2f2f7777772e64697a69626f782e6c697665').decode('utf-8')
UA = ADDON.getSetting(bytes.fromhex('757365725f6167656e74').decode('utf-8')) or bytes.fromhex('4d6f7a696c6c612f352e3020285831313b204c696e7578207838365f363429204170706c655765624b69742f3533372e333620284b48544d4c2c206c696b65204765636b6f29204368726f6d652f3132342e30205361666172692f3533372e3336').decode('utf-8')
site = DiziBoxSite(BASE_URL, UA)

class DiziBoxUI(ManituxUI):
    title = bytes.fromhex('44697a69424f58').decode('utf-8')
    favorite_owner = ADDON_ID

    def __init__(IIIlI):
        IIIlI._last_has_next = False

    def categories(IIIlI):
        categories = [{bytes.fromhex('7469746c65').decode('utf-8'): bytes.fromhex('417261').decode('utf-8'), bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('736561726368').decode('utf-8')}]
        for title, url in site.categories():
            categories.append({bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url})
        return categories

    def videos(IIIlI, category, page=1):
        if category.get(bytes.fromhex('616374696f6e').decode('utf-8')) == bytes.fromhex('736561726368').decode('utf-8'):
            query = xbmcgui.Dialog().input(bytes.fromhex('44697a69424f5820417261').decode('utf-8'))
            if not query:
                IIIlI._last_has_next = False
                return []
            IlII, IIIl = site.search(query)
            IIIlI._last_has_next = IIIl
            return [IIIlI._art_item(item) for item in IlII]
        IlII, IIIl = site.get_page_items(category[bytes.fromhex('75726c').decode('utf-8')], page)
        IIIlI._last_has_next = IIIl
        return [IIIlI._art_item(item) for item in IlII]

    def _art_item(IIIlI, item):
        lII = dict(item)
        image = lII.get(bytes.fromhex('696d616765').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
        referer = lII.get(bytes.fromhex('75726c').decode('utf-8')) or BASE_URL + bytes.fromhex('2f').decode('utf-8')
        lII[bytes.fromhex('696d616765').decode('utf-8')] = art_url(image, referer)
        return lII

    def has_next_page(IIIlI, category, page=1, videos=None):
        return bool(IIIlI._last_has_next)

    def detail(IIIlI, video):
        page_url = video[bytes.fromhex('75726c').decode('utf-8')]
        IIlI = site.detail(page_url)
        image = art_url(IIlI.get(bytes.fromhex('696d616765').decode('utf-8')) or video.get(bytes.fromhex('696d616765').decode('utf-8'), bytes.fromhex('').decode('utf-8')), page_url)
        plot = IIlI.get(bytes.fromhex('706c6f74').decode('utf-8')) or video.get(bytes.fromhex('706c6f74').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
        sources = []
        for source in IIlI.get(bytes.fromhex('736f7572636573').decode('utf-8'), []):
            sources.append({bytes.fromhex('6c6162656c').decode('utf-8'): source.get(bytes.fromhex('6c6162656c').decode('utf-8')) or bytes.fromhex('4f796e6174').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('72656665726572').decode('utf-8'): source.get(bytes.fromhex('72656665726572').decode('utf-8')) or page_url, bytes.fromhex('69735f747261696c6572').decode('utf-8'): source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8'), False)})
        sources = sort_sources(sources)
        episodes = []
        for episode in IIlI.get(bytes.fromhex('657069736f646573').decode('utf-8'), []):
            episodes.append({bytes.fromhex('7469746c65').decode('utf-8'): episode.get(bytes.fromhex('7469746c65').decode('utf-8')) or IIlI.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('42c3b66cc3bc6d').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): episode.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('696d616765').decode('utf-8'): art_url(episode.get(bytes.fromhex('696d616765').decode('utf-8')) or image, episode.get(bytes.fromhex('75726c').decode('utf-8')) or page_url), bytes.fromhex('706c6f74').decode('utf-8'): plot})
        for IIIIl in IIlI.get(bytes.fromhex('736561736f6e5f6c696e6b73').decode('utf-8'), []):
            episodes.append({bytes.fromhex('7469746c65').decode('utf-8'): IIIIl.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('53657a6f6e').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): IIIIl.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('696d616765').decode('utf-8'): image, bytes.fromhex('706c6f74').decode('utf-8'): plot})
        return {bytes.fromhex('7469746c65').decode('utf-8'): IIlI.get(bytes.fromhex('7469746c65').decode('utf-8')) or video.get(bytes.fromhex('7469746c65').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('75726c').decode('utf-8'): page_url, bytes.fromhex('696d616765').decode('utf-8'): image, bytes.fromhex('6261636b64726f70').decode('utf-8'): art_url(IIlI.get(bytes.fromhex('6261636b64726f70').decode('utf-8')) or IIlI.get(bytes.fromhex('66616e617274').decode('utf-8')) or image, page_url), bytes.fromhex('706c6f74').decode('utf-8'): plot, bytes.fromhex('79656172').decode('utf-8'): IIlI.get(bytes.fromhex('79656172').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('636f756e747279').decode('utf-8'): IIlI.get(bytes.fromhex('636f756e747279').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('6475726174696f6e').decode('utf-8'): IIlI.get(bytes.fromhex('6475726174696f6e').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('726174696e67').decode('utf-8'): IIlI.get(bytes.fromhex('726174696e67').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('74616773').decode('utf-8'): IIlI.get(bytes.fromhex('74616773').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('6163746f7273').decode('utf-8'): IIlI.get(bytes.fromhex('6163746f7273').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('657069736f646573').decode('utf-8'): episodes, bytes.fromhex('736f7572636573').decode('utf-8'): sources}

    def episode_detail(IIIlI, episode, video=None):
        return IIIlI.detail(episode)

    def play(IIIlI, source, video=None):
        if source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8')):
            play_youtube_gui(source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
        else:
            if play_source_gui(source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), source.get(bytes.fromhex('72656665726572').decode('utf-8')), source.get(bytes.fromhex('6c6162656c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), video, source):
                return
            for IIII in (video or {}).get(bytes.fromhex('736f7572636573').decode('utf-8'), []):
                if IIII is source or IIII.get(bytes.fromhex('69735f747261696c6572').decode('utf-8')):
                    continue
                if IIII.get(bytes.fromhex('75726c').decode('utf-8')) == source.get(bytes.fromhex('75726c').decode('utf-8')):
                    continue
                if play_source_gui(IIII.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), IIII.get(bytes.fromhex('72656665726572').decode('utf-8')), IIII.get(bytes.fromhex('6c6162656c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), video, IIII):
                    return

    def resume(IIIlI, source, video, llll):
        play_source_gui(source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), source.get(bytes.fromhex('72656665726572').decode('utf-8')), source.get(bytes.fromhex('6c6162656c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), video, source, llll)

def build_url(query):
    return sys.argv[0] + bytes.fromhex('3f').decode('utf-8') + urlencode(query)

def art_url(url, referer=None):
    if not url or bytes.fromhex('7c').decode('utf-8') in url or (not url.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8')))):
        return url
    lI = [bytes.fromhex('557365722d4167656e743d').decode('utf-8') + quote(UA)]
    lI.append(bytes.fromhex('526566657265723d').decode('utf-8') + quote(referer or BASE_URL + bytes.fromhex('2f').decode('utf-8')))
    lI.append(bytes.fromhex('4163636570743d').decode('utf-8') + quote(bytes.fromhex('696d6167652f617669662c696d6167652f776562702c696d6167652f61706e672c696d6167652f2a2c2a2f2a3b713d302e38').decode('utf-8')))
    lI.append(bytes.fromhex('436f6f6b69653d').decode('utf-8') + quote(bytes.fromhex('697354727573746564557365723d747275653b20646278753d7b307d').decode('utf-8').format(int(time.time() * 1000))))
    return url + bytes.fromhex('7c').decode('utf-8') + bytes.fromhex('26').decode('utf-8').join(lI)

def set_art(IlIl, image, referer=None):
    image = art_url(image, referer)
    IlIl.setArt({bytes.fromhex('7468756d62').decode('utf-8'): image, bytes.fromhex('69636f6e').decode('utf-8'): image, bytes.fromhex('706f73746572').decode('utf-8'): image, bytes.fromhex('66616e617274').decode('utf-8'): image})

def add_directory(title, action, url=bytes.fromhex('').decode('utf-8'), image=bytes.fromhex('').decode('utf-8'), plot=bytes.fromhex('').decode('utf-8')):
    IlIl = xbmcgui.ListItem(label=title)
    set_art(IlIl, image, url or BASE_URL + bytes.fromhex('2f').decode('utf-8'))
    IlIl.setInfo(bytes.fromhex('766964656f').decode('utf-8'), {bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('706c6f74').decode('utf-8'): plot})
    xbmcplugin.addDirectoryItem(HANDLE, build_url({bytes.fromhex('616374696f6e').decode('utf-8'): action, bytes.fromhex('75726c').decode('utf-8'): url}), IlIl, True)

def add_video(title, action, url, image=bytes.fromhex('').decode('utf-8'), plot=bytes.fromhex('').decode('utf-8'), lll=None):
    query = {bytes.fromhex('616374696f6e').decode('utf-8'): action, bytes.fromhex('75726c').decode('utf-8'): url}
    if lll:
        query.update(lll)
    IlIl = xbmcgui.ListItem(label=title)
    set_art(IlIl, image, lll.get(bytes.fromhex('72656665726572').decode('utf-8')) if lll else BASE_URL + bytes.fromhex('2f').decode('utf-8'))
    IlIl.setInfo(bytes.fromhex('766964656f').decode('utf-8'), {bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('706c6f74').decode('utf-8'): plot})
    IlIl.setProperty(bytes.fromhex('4973506c617961626c65').decode('utf-8'), bytes.fromhex('74727565').decode('utf-8'))
    xbmcplugin.addDirectoryItem(HANDLE, build_url(query), IlIl, False)

def source_priority(source):
    IIllI = ((source or {}).get(bytes.fromhex('6c6162656c').decode('utf-8'), bytes.fromhex('').decode('utf-8')) + bytes.fromhex('20').decode('utf-8') + (source or {}).get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8'))).lower()
    if (source or {}).get(bytes.fromhex('69735f747261696c6572').decode('utf-8')):
        return 100
    if bytes.fromhex('6f646e6f6b').decode('utf-8') in IIllI or bytes.fromhex('6f6b2e7275').decode('utf-8') in IIllI or bytes.fromhex('6f646e6f6b6c6173736e696b69').decode('utf-8') in IIllI:
        return 0
    if bytes.fromhex('6d6f6c79').decode('utf-8') in IIllI or bytes.fromhex('7669646d6f6c79').decode('utf-8') in IIllI or bytes.fromhex('766964656f62696e').decode('utf-8') in IIllI:
        return 1
    if bytes.fromhex('646278').decode('utf-8') in IIllI or bytes.fromhex('6b696e67').decode('utf-8') in IIllI or bytes.fromhex('6861796469').decode('utf-8') in IIllI:
        return 3
    return 2

def sort_sources(sources):
    return sorted(sources or [], key=source_priority)

def main_menu():
    add_directory(bytes.fromhex('417261').decode('utf-8'), bytes.fromhex('736561726368').decode('utf-8'))
    for title, url in site.categories():
        add_directory(title, bytes.fromhex('6c697374').decode('utf-8'), url)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('747673686f7773').decode('utf-8'))

def manitux_skin_categories():
    for category in DiziBoxUI().categories():
        if category.get(bytes.fromhex('616374696f6e').decode('utf-8')) == bytes.fromhex('736561726368').decode('utf-8') or not category.get(bytes.fromhex('75726c').decode('utf-8')):
            continue
        IlIl = xbmcgui.ListItem(label=category.get(bytes.fromhex('7469746c65').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
        IlIl.setArt({bytes.fromhex('69636f6e').decode('utf-8'): ADDON.getAddonInfo(bytes.fromhex('69636f6e').decode('utf-8')), bytes.fromhex('7468756d62').decode('utf-8'): ADDON.getAddonInfo(bytes.fromhex('69636f6e').decode('utf-8'))})
        path = build_url({bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('6d616e697475785f736b696e5f6974656d73').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): category[bytes.fromhex('75726c').decode('utf-8')], bytes.fromhex('70616765').decode('utf-8'): bytes.fromhex('31').decode('utf-8')})
        xbmcplugin.addDirectoryItem(HANDLE, path, IlIl, True)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('766964656f73').decode('utf-8'))

def manitux_skin_items(url, page_number=1):
    page_number = max(1, int(page_number))
    adapter = DiziBoxUI()
    try:
        IlII = load_category(lambda: adapter.videos({bytes.fromhex('75726c').decode('utf-8'): url}, page_number))
    except CategoryLoadTimeout:
        reset_plugin_selection()
        IlII = []
    if page_number > 1:
        add_manitux_page_card(url, 1, bytes.fromhex('c4b06c6b205361796661').decode('utf-8'))
    if page_number > 2:
        add_manitux_page_card(url, page_number - 1, bytes.fromhex('c3966e63656b69205361796661').decode('utf-8'))
    lIIl = (1 if page_number > 1 else 0) + (1 if page_number > 2 else 0)
    for IIll, item in enumerate(IlII, lIIl):
        add_manitux_detail_card(item, IIll)
    if adapter.has_next_page({bytes.fromhex('75726c').decode('utf-8'): url}, page_number, IlII):
        add_manitux_page_card(url, page_number + 1, bytes.fromhex('536f6e72616b69205361796661').decode('utf-8'))
    xbmcplugin.setContent(HANDLE, bytes.fromhex('747673686f7773').decode('utf-8'))

def manitux_skin_search(query):
    IlII, II = site.search(query) if query else ([], False)
    adapter = DiziBoxUI()
    for IIll, item in enumerate(IlII):
        add_manitux_detail_card(adapter._art_item(item), IIll)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('747673686f7773').decode('utf-8'))

def manitux_skin_favorites():
    for IIll, item in enumerate(get_favorites()):
        add_manitux_detail_card(item, IIll)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('747673686f7773').decode('utf-8'))

def manitux_skin_continue():
    for IIll, item in enumerate(get_continue_items()):
        III = dict(item)
        Ill = item.get(bytes.fromhex('636f6e74657874').decode('utf-8')) or {}
        III[bytes.fromhex('79656172').decode('utf-8')] = item.get(bytes.fromhex('79656172').decode('utf-8')) or Ill.get(bytes.fromhex('79656172').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
        III[bytes.fromhex('726174696e67').decode('utf-8')] = item.get(bytes.fromhex('726174696e67').decode('utf-8')) or Ill.get(bytes.fromhex('726174696e67').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
        III[bytes.fromhex('7469746c65').decode('utf-8')] = bytes.fromhex('7b7d2020e280a220207b7d').decode('utf-8').format(item.get(bytes.fromhex('7469746c65').decode('utf-8'), bytes.fromhex('566964656f').decode('utf-8')), format_time(item.get(bytes.fromhex('706f736974696f6e').decode('utf-8'))))
        add_manitux_detail_card(III, IIll)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('747673686f7773').decode('utf-8'))

def add_manitux_detail_card(item, IIll):
    title = item.get(bytes.fromhex('7469746c65').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
    image = item.get(bytes.fromhex('696d616765').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
    plot = item.get(bytes.fromhex('706c6f74').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
    IlIl = xbmcgui.ListItem(label=title)
    IlIl.setArt({bytes.fromhex('7468756d62').decode('utf-8'): image, bytes.fromhex('69636f6e').decode('utf-8'): image, bytes.fromhex('706f73746572').decode('utf-8'): image, bytes.fromhex('66616e617274').decode('utf-8'): image})
    IlIl.setInfo(bytes.fromhex('766964656f').decode('utf-8'), {bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('706c6f74').decode('utf-8'): plot})
    IlIl.setProperty(bytes.fromhex('79656172').decode('utf-8'), str(item.get(bytes.fromhex('79656172').decode('utf-8')) or bytes.fromhex('').decode('utf-8')))
    IlIl.setProperty(bytes.fromhex('726174696e67').decode('utf-8'), str(item.get(bytes.fromhex('726174696e67').decode('utf-8')) or bytes.fromhex('').decode('utf-8')))
    IlIl.setProperty(bytes.fromhex('4973506c617961626c65').decode('utf-8'), bytes.fromhex('74727565').decode('utf-8'))
    query = {bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('6d616e697475785f736b696e5f64657461696c').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): item.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('696d616765').decode('utf-8'): image, bytes.fromhex('706c6f74').decode('utf-8'): plot, bytes.fromhex('6974656d5f696e646578').decode('utf-8'): str(IIll)}
    lIII = item.get(bytes.fromhex('6f776e6572').decode('utf-8')) or ADDON_ID
    path = bytes.fromhex('706c7567696e3a2f2f7b307d2f3f7b317d').decode('utf-8').format(lIII, urlencode(query))
    xbmcplugin.addDirectoryItem(HANDLE, path, IlIl, False)

def add_manitux_page_card(url, page_number, ll):
    IlIl = xbmcgui.ListItem(label=str(page_number))
    IlIl.setProperty(bytes.fromhex('6d616e697475785f706167655f63617264').decode('utf-8'), bytes.fromhex('74727565').decode('utf-8'))
    IlIl.setProperty(bytes.fromhex('6d616e697475785f706167655f63617074696f6e').decode('utf-8'), ll)
    IlIl.setProperty(bytes.fromhex('4973506c617961626c65').decode('utf-8'), bytes.fromhex('74727565').decode('utf-8'))
    path = build_url({bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('6d616e697475785f736b696e5f70616765').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('70616765').decode('utf-8'): str(page_number)})
    xbmcplugin.addDirectoryItem(HANDLE, path, IlIl, False)

def set_skin_string(Illl, IIlll):
    IIlll = (IIlll or bytes.fromhex('').decode('utf-8')).replace(bytes.fromhex('5c').decode('utf-8'), bytes.fromhex('5c5c').decode('utf-8')).replace(bytes.fromhex('2c').decode('utf-8'), bytes.fromhex('5c2c').decode('utf-8')).replace(bytes.fromhex('29').decode('utf-8'), bytes.fromhex('5c29').decode('utf-8'))
    xbmc.executebuiltin(bytes.fromhex('536b696e2e536574537472696e67287b307d2c7b317d29').decode('utf-8').format(Illl, IIlll))

def manitux_skin_page(url, page_number):
    page_number = max(1, int(page_number))
    IIl = build_url({bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('6d616e697475785f736b696e5f6974656d73').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('70616765').decode('utf-8'): str(page_number)})
    set_skin_string(bytes.fromhex('4d616e697475782e4c6f6164696e67').decode('utf-8'), bytes.fromhex('74727565').decode('utf-8'))
    set_skin_string(bytes.fromhex('4d616e697475782e43757272656e74506c7567696e43617465676f727950617468').decode('utf-8'), IIl)
    set_skin_string(bytes.fromhex('4d616e697475782e43757272656e74506c7567696e43617465676f727950616765').decode('utf-8'), str(page_number))
    set_skin_string(bytes.fromhex('4d616e697475782e43757272656e74506c7567696e50726576696f757350616765').decode('utf-8'), str(max(1, page_number - 1)))
    set_skin_string(bytes.fromhex('4d616e697475782e43757272656e74506c7567696e4e65787450616765').decode('utf-8'), str(page_number + 1))
    xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
    xbmc.executebuiltin(bytes.fromhex('436f6e7461696e65722e52656672657368').decode('utf-8'))
    xbmc.sleep(150)
    xbmc.executebuiltin(bytes.fromhex('536574466f637573283330302c3029').decode('utf-8'))

def manitux_skin_detail(url, title, image, plot, IIll=0):
    xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
    llI = DetailWindow(bytes.fromhex('6d616e6974757875695f64657461696c2e786d6c').decode('utf-8'), xbmcaddon.Addon(id=bytes.fromhex('7363726970742e6d6f64756c652e6d616e697475787569').decode('utf-8')).getAddonInfo(bytes.fromhex('70617468').decode('utf-8')), bytes.fromhex('44656661756c74').decode('utf-8'), bytes.fromhex('3130383069').decode('utf-8'), adapter=DiziBoxUI(), video={bytes.fromhex('6661766f726974655f6f776e6572').decode('utf-8'): ADDON_ID, bytes.fromhex('7469746c65').decode('utf-8'): title or bytes.fromhex('').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): url or bytes.fromhex('').decode('utf-8'), bytes.fromhex('696d616765').decode('utf-8'): image or bytes.fromhex('').decode('utf-8'), bytes.fromhex('6261636b64726f70').decode('utf-8'): image or bytes.fromhex('').decode('utf-8'), bytes.fromhex('706c6f74').decode('utf-8'): plot or bytes.fromhex('').decode('utf-8')})
    llI.doModal()
    del llI
    lIl = xbmc.getInfoLabel(bytes.fromhex('536b696e2e537472696e67284d616e697475782e43757272656e74506c7567696e43617465676f72795061746829').decode('utf-8'))
    if bytes.fromhex('616374696f6e3d6d616e697475785f736b696e5f6661766f7269746573').decode('utf-8') in lIl or bytes.fromhex('616374696f6e3d6d616e697475785f736b696e5f636f6e74696e7565').decode('utf-8') in lIl:
        xbmc.executebuiltin(bytes.fromhex('436f6e7461696e65722e52656672657368').decode('utf-8'))
    xbmc.sleep(100)
    xbmc.executebuiltin(bytes.fromhex('536574466f637573283330302c7b307d2c6162736f6c75746529').decode('utf-8').format(max(0, int(IIll))))

def list_page(url, page_number=1):
    IlII, IIIl = site.get_page_items(url, page_number)
    for item in IlII:
        add_directory(item[bytes.fromhex('7469746c65').decode('utf-8')], bytes.fromhex('64657461696c').decode('utf-8'), item[bytes.fromhex('75726c').decode('utf-8')], item[bytes.fromhex('696d616765').decode('utf-8')], item[bytes.fromhex('706c6f74').decode('utf-8')])
    if IIIl:
        xbmcplugin.addDirectoryItem(HANDLE, build_url({bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('6c697374').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('70616765').decode('utf-8'): str(int(page_number) + 1)}), xbmcgui.ListItem(label=bytes.fromhex('536f6e72616b69205361796661').decode('utf-8')), True)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('747673686f7773').decode('utf-8'))

def search():
    query = xbmcgui.Dialog().input(bytes.fromhex('44697a69424f5820417261').decode('utf-8'))
    if query:
        IlII, II = site.search(query)
        for item in IlII:
            add_directory(item[bytes.fromhex('7469746c65').decode('utf-8')], bytes.fromhex('64657461696c').decode('utf-8'), item[bytes.fromhex('75726c').decode('utf-8')], item[bytes.fromhex('696d616765').decode('utf-8')], item.get(bytes.fromhex('706c6f74').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
        xbmcplugin.setContent(HANDLE, bytes.fromhex('747673686f7773').decode('utf-8'))

def detail(url):
    IIlI = site.detail(url)
    sources = sort_sources(IIlI.get(bytes.fromhex('736f7572636573').decode('utf-8'), []))
    episodes = IIlI.get(bytes.fromhex('657069736f646573').decode('utf-8'), [])
    llII = [source for source in sources if not source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8'))]
    for source in sources if not episodes else [source for source in sources if source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8'))]:
        add_video(source[bytes.fromhex('6c6162656c').decode('utf-8')], bytes.fromhex('706c61795f796f7574756265').decode('utf-8') if source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8')) else bytes.fromhex('706c61795f736f75726365').decode('utf-8'), source[bytes.fromhex('75726c').decode('utf-8')], IIlI.get(bytes.fromhex('696d616765').decode('utf-8'), bytes.fromhex('').decode('utf-8')), IIlI.get(bytes.fromhex('706c6f74').decode('utf-8'), bytes.fromhex('').decode('utf-8')), {bytes.fromhex('72656665726572').decode('utf-8'): source.get(bytes.fromhex('72656665726572').decode('utf-8')) or url, bytes.fromhex('6c6162656c').decode('utf-8'): source[bytes.fromhex('6c6162656c').decode('utf-8')]})
    if not llII:
        if episodes:
            for episode in episodes:
                title = episode.get(bytes.fromhex('7469746c65').decode('utf-8')) or IIlI.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('42c3b66cc3bc6d').decode('utf-8')
                image = episode.get(bytes.fromhex('696d616765').decode('utf-8')) or IIlI.get(bytes.fromhex('696d616765').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
                add_directory(title, bytes.fromhex('64657461696c').decode('utf-8'), episode[bytes.fromhex('75726c').decode('utf-8')], image, IIlI.get(bytes.fromhex('706c6f74').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
        else:
            for IIIIl in IIlI.get(bytes.fromhex('736561736f6e5f6c696e6b73').decode('utf-8'), []):
                title = IIIIl.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('53657a6f6e').decode('utf-8')
                add_directory(title, bytes.fromhex('64657461696c').decode('utf-8'), IIIIl[bytes.fromhex('75726c').decode('utf-8')], IIlI.get(bytes.fromhex('696d616765').decode('utf-8'), bytes.fromhex('').decode('utf-8')), IIlI.get(bytes.fromhex('706c6f74').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
    if not sources and (not IIlI.get(bytes.fromhex('657069736f646573').decode('utf-8'))) and (not IIlI.get(bytes.fromhex('736561736f6e5f6c696e6b73').decode('utf-8'))):
        xbmcgui.Dialog().notification(bytes.fromhex('44697a69424f58').decode('utf-8'), bytes.fromhex('4b61796e616b20766579612062c3b66cc3bc6d2062756c756e616d6164c4b1').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('747673686f7773').decode('utf-8'))

def youtube_plugin_url(url):
    IlIII = bytes.fromhex('').decode('utf-8')
    for lIll in (bytes.fromhex('283f3a796f75747562655c2e636f6d2f656d6265642f7c796f75747562655c2e636f6d2f77617463685c3f763d7c796f7574755c2e62652f29285b412d5a612d7a302d395f2d5d7b362c7d29').decode('utf-8'), bytes.fromhex('5b3f265d763d285b412d5a612d7a302d395f2d5d7b362c7d29').decode('utf-8')):
        IllI = re.search(lIll, url or bytes.fromhex('').decode('utf-8'), re.I)
        if IllI:
            IlIII = IllI.group(1)
            break
    return bytes.fromhex('706c7567696e3a2f2f706c7567696e2e766964656f2e796f75747562652f706c61792f3f766964656f5f69643d').decode('utf-8') + IlIII if IlIII else bytes.fromhex('').decode('utf-8')

def play_youtube(url):
    lllI = youtube_plugin_url(url)
    if not lllI:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    try:
        xbmcaddon.Addon(id=bytes.fromhex('706c7567696e2e766964656f2e796f7574756265').decode('utf-8'))
    except Exception:
        xbmcgui.Dialog().notification(bytes.fromhex('596f7554756265').decode('utf-8'), bytes.fromhex('706c7567696e2e766964656f2e796f757475626520676572656b6c69').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=lllI))

def play_youtube_gui(url):
    lllI = youtube_plugin_url(url)
    if not lllI:
        return False
    try:
        xbmcaddon.Addon(id=bytes.fromhex('706c7567696e2e766964656f2e796f7574756265').decode('utf-8'))
    except Exception:
        xbmcgui.Dialog().notification(bytes.fromhex('596f7554756265').decode('utf-8'), bytes.fromhex('706c7567696e2e766964656f2e796f757475626520676572656b6c69').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
        return False
    xbmc.Player().play(lllI)
    return True

def play_source(url, referer=None, label=bytes.fromhex('').decode('utf-8')):
    IIlII, IIlIl = site.resolve_source(url, referer, label)
    if not IIlII:
        xbmcgui.Dialog().notification(bytes.fromhex('44697a69424f58').decode('utf-8'), bytes.fromhex('4b61796e616b20c3a7c3b67ac3bc6c656d656469').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    IlIl = xbmcgui.ListItem(path=IIlII)
    if is_hls_stream(IIlII):
        IlIl.setMimeType(bytes.fromhex('6170706c69636174696f6e2f766e642e6170706c652e6d70656775726c').decode('utf-8'))
        IlIl.setContentLookup(False)
        if has_addon(bytes.fromhex('696e70757473747265616d2e6164617074697665').decode('utf-8')):
            IlIl.setProperty(bytes.fromhex('696e70757473747265616d').decode('utf-8'), bytes.fromhex('696e70757473747265616d2e6164617074697665').decode('utf-8'))
            IlIl.setProperty(bytes.fromhex('696e70757473747265616d6164646f6e').decode('utf-8'), bytes.fromhex('696e70757473747265616d2e6164617074697665').decode('utf-8'))
            IlIl.setProperty(bytes.fromhex('696e70757473747265616d2e61646170746976652e6d616e69666573745f74797065').decode('utf-8'), bytes.fromhex('686c73').decode('utf-8'))
            IlIl.setProperty(bytes.fromhex('696e70757473747265616d2e61646170746976652e73747265616d5f68656164657273').decode('utf-8'), stream_headers(IIlII))
            IlIl.setProperty(bytes.fromhex('696e70757473747265616d2e61646170746976652e6d616e69666573745f68656164657273').decode('utf-8'), stream_headers(IIlII))
    if IIlIl:
        IlIl.setSubtitles(IIlIl)
    xbmcplugin.setResolvedUrl(HANDLE, True, IlIl)

def play_source_gui(url, referer=None, label=bytes.fromhex('').decode('utf-8'), llIl=None, source=None, IIIII=0):
    IIlII, IIlIl = site.resolve_source(url, referer, label)
    return play_stream_gui(IIlII, IIlIl, llIl, source, IIIII)

def play_stream_gui(IIlII, IIlIl=None, llIl=None, source=None, IIIII=0):
    if not IIlII:
        xbmcgui.Dialog().notification(bytes.fromhex('44697a69424f58').decode('utf-8'), bytes.fromhex('4b61796e616b20c3a7c3b67ac3bc6c656d656469').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
        return False
    IlIl = xbmcgui.ListItem(path=IIlII)
    if is_hls_stream(IIlII):
        IlIl.setMimeType(bytes.fromhex('6170706c69636174696f6e2f766e642e6170706c652e6d70656775726c').decode('utf-8'))
        IlIl.setContentLookup(False)
        if has_addon(bytes.fromhex('696e70757473747265616d2e6164617074697665').decode('utf-8')):
            IlIl.setProperty(bytes.fromhex('696e70757473747265616d').decode('utf-8'), bytes.fromhex('696e70757473747265616d2e6164617074697665').decode('utf-8'))
            IlIl.setProperty(bytes.fromhex('696e70757473747265616d6164646f6e').decode('utf-8'), bytes.fromhex('696e70757473747265616d2e6164617074697665').decode('utf-8'))
            IlIl.setProperty(bytes.fromhex('696e70757473747265616d2e61646170746976652e6d616e69666573745f74797065').decode('utf-8'), bytes.fromhex('686c73').decode('utf-8'))
            IlIl.setProperty(bytes.fromhex('696e70757473747265616d2e61646170746976652e73747265616d5f68656164657273').decode('utf-8'), stream_headers(IIlII))
            IlIl.setProperty(bytes.fromhex('696e70757473747265616d2e61646170746976652e6d616e69666573745f68656164657273').decode('utf-8'), stream_headers(IIlII))
    if IIlIl:
        IlIl.setSubtitles(IIlIl)
    if llIl:
        play_and_track(IIlII, IlIl, ADDON_ID, llIl, source or {}, IIIII)
    else:
        xbmc.Player().play(IIlII, IlIl)
    return True

def is_hls_stream(url):
    IlI = (url or bytes.fromhex('').decode('utf-8')).split(bytes.fromhex('7c').decode('utf-8'), 1)[0]
    return bool(re.search(bytes.fromhex('283f3a5c2e6d3375387c6d61737465725c2e7478747c2f656d6265642f736865696c612f7c2f712f5c642b29283f3a5b3f235d2e2a293f24').decode('utf-8'), IlI, re.I))

def stream_headers(url):
    if bytes.fromhex('7c').decode('utf-8') not in (url or bytes.fromhex('').decode('utf-8')):
        return bytes.fromhex('').decode('utf-8')
    return url.split(bytes.fromhex('7c').decode('utf-8'), 1)[1]

def has_addon(Il):
    return bool(xbmc.getCondVisibility(bytes.fromhex('53797374656d2e4861734164646f6e287b307d29').decode('utf-8').format(Il)))

def run():
    lIlI = dict(parse_qsl(sys.argv[2][1:]))
    action = lIlI.get(bytes.fromhex('616374696f6e').decode('utf-8'))
    url = lIlI.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
    page_number = int(lIlI.get(bytes.fromhex('70616765').decode('utf-8'), bytes.fromhex('31').decode('utf-8')))
    if not action:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
        IlIIl = xbmcgui.Window(10000)
        try:
            IIIll = float(IlIIl.getProperty(l) or bytes.fromhex('30').decode('utf-8'))
        except ValueError:
            IIIll = 0
        if time.time() < IIIll:
            return
        IlIIl.clearProperty(l)
        xbmc.executebuiltin(bytes.fromhex('52756e506c7567696e287b307d29').decode('utf-8').format(build_url({bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('677569').decode('utf-8')})))
        return
    elif action == bytes.fromhex('677569').decode('utf-8'):
        open_browser(DiziBoxUI())
        xbmcgui.Window(10000).setProperty(l, str(time.time() + 4))
        xbmc.executebuiltin(bytes.fromhex('416374697661746557696e646f7728486f6d6529').decode('utf-8'))
        return
    elif action == bytes.fromhex('636c6173736963').decode('utf-8'):
        main_menu()
    elif action == bytes.fromhex('6d616e697475785f736b696e5f63617465676f72696573').decode('utf-8'):
        manitux_skin_categories()
    elif action == bytes.fromhex('6d616e697475785f736b696e5f6974656d73').decode('utf-8'):
        manitux_skin_items(url, page_number)
    elif action == bytes.fromhex('6d616e697475785f736b696e5f736561726368').decode('utf-8'):
        manitux_skin_search(lIlI.get(bytes.fromhex('7175657279').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
    elif action == bytes.fromhex('6d616e697475785f736b696e5f6661766f7269746573').decode('utf-8'):
        manitux_skin_favorites()
    elif action == bytes.fromhex('6d616e697475785f736b696e5f636f6e74696e7565').decode('utf-8'):
        manitux_skin_continue()
    elif action == bytes.fromhex('6d616e697475785f736b696e5f70616765').decode('utf-8'):
        manitux_skin_page(url, page_number)
        return
    elif action == bytes.fromhex('6d616e697475785f736b696e5f64657461696c').decode('utf-8'):
        manitux_skin_detail(url, lIlI.get(bytes.fromhex('7469746c65').decode('utf-8'), bytes.fromhex('').decode('utf-8')), lIlI.get(bytes.fromhex('696d616765').decode('utf-8'), bytes.fromhex('').decode('utf-8')), lIlI.get(bytes.fromhex('706c6f74').decode('utf-8'), bytes.fromhex('').decode('utf-8')), lIlI.get(bytes.fromhex('6974656d5f696e646578').decode('utf-8'), bytes.fromhex('30').decode('utf-8')))
        return
    elif action == bytes.fromhex('6c697374').decode('utf-8'):
        list_page(url, page_number)
    elif action == bytes.fromhex('736561726368').decode('utf-8'):
        search()
    elif action == bytes.fromhex('64657461696c').decode('utf-8'):
        detail(url)
    elif action == bytes.fromhex('706c61795f736f75726365').decode('utf-8'):
        play_source(url, lIlI.get(bytes.fromhex('72656665726572').decode('utf-8')), lIlI.get(bytes.fromhex('6c6162656c').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
    elif action == bytes.fromhex('706c61795f796f7574756265').decode('utf-8'):
        play_youtube(url)
    xbmcplugin.endOfDirectory(HANDLE)
if __name__ == bytes.fromhex('5f5f6d61696e5f5f').decode('utf-8'):
    run()
