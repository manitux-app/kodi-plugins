from __future__ import absolute_import, unicode_literals
import base64
import hashlib
import json
import re
import string
import manituxhttp
try:
    from Crypto.Cipher import AES
except Exception:
    AES = None
try:
    from urllib.parse import quote, unquote, urljoin, urlparse, urlunparse
except ImportError:
    from urllib import quote, unquote
    from urlparse import urljoin, urlparse, urlunparse
from . import parsers

class DiziBoxExtractor(object):
    MOLY_DOMAINS = (bytes.fromhex('6d6f6c7973747265616d').decode('utf-8'), bytes.fromhex('736865696c612e73747265616d').decode('utf-8'), bytes.fromhex('706f70636f726e76616b7469').decode('utf-8'), bytes.fromhex('727566696967757461').decode('utf-8'))

    def __init__(Illll, user_agent, base_url):
        Illll.user_agent = user_agent
        Illll.base_url = base_url.rstrip(bytes.fromhex('2f').decode('utf-8'))
        Illll.session = manituxhttp.Session()

    def resolve(Illll, url, referer=None, label=bytes.fromhex('').decode('utf-8')):
        if not url:
            return (None, [])
        url = Illll.normalize_url(url)
        referer = referer or Illll.base_url + bytes.fromhex('2f').decode('utf-8')
        if bytes.fromhex('2f656d6265642f736865696c612f').decode('utf-8') in url:
            return Illll.resolve_moly(url, referer, label)
        if Illll.is_media_url(url):
            return (url + Illll.kodi_headers(referer), [])
        IllI = Illll.decode_iframe(url, referer)
        if IllI and IllI != url:
            return Illll.resolve(IllI, url, label)
        IlIl = urlparse(url).netloc.lower()
        if Illll.is_site_player(url):
            return Illll.resolve_site_player(url, referer, label)
        if bytes.fromhex('7669646d6f6c79').decode('utf-8') in IlIl or bytes.fromhex('766964656f62696e').decode('utf-8') in IlIl:
            return Illll.resolve_vidmoly(url, referer)
        if bytes.fromhex('6f6b2e7275').decode('utf-8') in IlIl or bytes.fromhex('6f646e6f6b6c6173736e696b69').decode('utf-8') in IlIl:
            return Illll.resolve_okru(url)
        if any((IIII in IlIl for IIII in Illll.MOLY_DOMAINS)):
            return Illll.resolve_moly(url, referer, label)
        page = Illll.fetch(url, referer)
        IllI = parsers.parse_iframe(page, url)
        if IllI and IllI != url:
            return Illll.resolve(IllI, url, label)
        source, lIIIl = Illll.extract_jw(page, url, label or bytes.fromhex('44697a69426f78').decode('utf-8'))
        if source:
            return (source + Illll.kodi_headers(url), lIIIl)
        return (url + Illll.kodi_headers(referer), [])

    def decode_iframe(Illll, url, referer=None):
        if bytes.fromhex('2f706c617965722f68617964692e706870').decode('utf-8') in url and bytes.fromhex('3f763d').decode('utf-8') in url:
            lIllI = url.split(bytes.fromhex('3f763d').decode('utf-8'), 1)[1].split(bytes.fromhex('26').decode('utf-8'), 1)[0]
            return Illll._b64(unquote(lIllI))
        if bytes.fromhex('2f706c617965722f6d6f6c792f6d6f6c792e706870').decode('utf-8') in url:
            IlIII = url.replace(bytes.fromhex('6d6f6c792e7068703f683d').decode('utf-8'), bytes.fromhex('6d6f6c792e7068703f776d6f64653d6f706171756526683d').decode('utf-8'))
            page = Illll.fetch(IlIII, referer)
            IIll = Illll._first(bytes.fromhex('756e6573636170655c285b225c275d282e2a3f295b225c275d5c29').decode('utf-8'), page, re.S)
            if IIll:
                lIl = unquote(IIll)
                IllI = parsers.parse_iframe(lIl, IlIII)
                if IllI:
                    return IllI
                lIl = Illll._b64(lIl)
                IllI = parsers.parse_iframe(lIl, IlIII)
                if IllI:
                    return IllI
            IllI = parsers.parse_iframe(page, IlIII)
            if IllI:
                return IllI
        if bytes.fromhex('2f706c617965722f6b696e672f6b696e672e706870').decode('utf-8') in url:
            IlIII = url.replace(bytes.fromhex('6b696e672e7068703f763d').decode('utf-8'), bytes.fromhex('6b696e672e7068703f776d6f64653d6f706171756526763d').decode('utf-8'))
            return Illll.extract_player_target(IlIII, referer)
        return url

    def resolve_site_player(Illll, url, referer=None, label=bytes.fromhex('').decode('utf-8')):
        lIlII = Illll.extract_player_target(url, referer)
        if lIlII and lIlII != url:
            return Illll.resolve(lIlII, url, label)
        try:
            page = Illll.fetch(url, referer)
        except (manituxhttp.HTTPError, manituxhttp.RequestError):
            return (None, [])
        source, lIIIl = Illll.extract_jw(page, url, label or bytes.fromhex('44697a69426f78').decode('utf-8'))
        if not source:
            lIlIl = Illll.unpack_first_eval(page)
            source = Illll.media_url(lIlIl) or Illll.media_url(page)
        return (source + Illll.kodi_headers(url) if source else None, lIIIl)

    def extract_player_target(Illll, url, referer=None):
        page = Illll.fetch(url, referer)
        lIl = Illll.decode_embedded_html(page)
        lIlII = parsers.parse_iframe(lIl or page, url)
        if lIlII:
            return lIlII
        source = Illll.media_url(lIl) or Illll.media_url(page)
        if source:
            return source
        lIlIl = Illll.unpack_first_eval(page)
        lIlII = parsers.parse_iframe(lIlIl, url)
        if lIlII:
            return lIlII
        return Illll.media_url(lIlIl) or bytes.fromhex('').decode('utf-8')

    def resolve_moly(Illll, url, referer=None, label=bytes.fromhex('').decode('utf-8')):
        page = Illll.fetch(url, referer or Illll.base_url + bytes.fromhex('2f').decode('utf-8'))
        llI = Illll.decrypt_cryptojs_page(page)
        if llI:
            page = llI
        source, lIIIl = Illll.extract_jw(page, url, label or bytes.fromhex('4d6f6c7973747265616d').decode('utf-8'))
        if not source:
            source = Illll._first(bytes.fromhex('68747470733f3a2f2f5b5e5c7322273c3e5d2b3f283f3a5c2e6d3375387c5c2e6d70347c6d61737465725c2e747874295b5e5c7322273c3e5d2a').decode('utf-8'), page)
        if source:
            source = Illll.resolve_hls_variant(source, url) or source
        return (source + Illll.kodi_headers(url) if source else None, lIIIl)

    def resolve_vidmoly(Illll, url, referer=None):
        IIl = Illll.vidmoly_candidates(url)
        page = bytes.fromhex('').decode('utf-8')
        page_url = url
        for III in IIl:
            try:
                page = Illll.fetch(III, referer or bytes.fromhex('68747470733a2f2f7669646d6f6c792e746f2f').decode('utf-8'))
            except (manituxhttp.HTTPError, manituxhttp.RequestError):
                continue
            page_url = III
            if Illll.has_playable(page):
                break
        if not page:
            return (None, [])
        if Illll.needs_number_challenge(page):
            IlI = Illll.submit_number_challenge(page_url, page, referer)
            if IlI:
                page = IlI
        source, lIIIl = Illll.extract_jw(page, page_url, bytes.fromhex('5669644d6f6c79').decode('utf-8'))
        if not source:
            lIlIl = Illll.unpack_first_eval(page)
            source = Illll.media_url(lIlIl) or Illll.media_url(page)
        if source and Illll.is_hls_url(source):
            source = Illll.resolve_hls_variant(source, page_url) or source
        return (source + Illll.kodi_headers(page_url) if source else None, lIIIl)

    def resolve_okru(Illll, url):
        llIII = Illll._first(bytes.fromhex('283f3a766964656f656d6265642f7c2f766964656f2f7c6d69643d29285c642b29').decode('utf-8'), url)
        if not llIII:
            return (url + Illll.kodi_headers(bytes.fromhex('68747470733a2f2f6f6b2e72752f').decode('utf-8')), [])
        IllII = Illll.session.post(bytes.fromhex('68747470733a2f2f7777772e6f6b2e72752f646b').decode('utf-8'), data={bytes.fromhex('636d64').decode('utf-8'): bytes.fromhex('766964656f506c617965724d65746164617461').decode('utf-8'), bytes.fromhex('6d6964').decode('utf-8'): llIII}, headers=Illll.headers(bytes.fromhex('68747470733a2f2f6f6b2e72752f').decode('utf-8')), timeout=25)
        IllII.raise_for_status()
        source = Illll._first(bytes.fromhex('283f3a756c7472617c717561647c66756c6c7c68647c73647c6c6f777c6c6f7765737429222c2275726c223a22282e2a3f2922').decode('utf-8'), IllII.text)
        return (source.replace(bytes.fromhex('5c7530303236').decode('utf-8'), bytes.fromhex('26').decode('utf-8')) + Illll.kodi_headers(bytes.fromhex('68747470733a2f2f6f6b2e72752f').decode('utf-8')) if source else None, [])

    def extract_jw(Illll, page, page_url, lIIII):
        sources = Illll._extract_sources(page, page_url, lIIII)
        lIIIl = Illll._extract_subtitles(page, page_url)
        if sources:
            return (sources[0], lIIIl)
        source = Illll._first(bytes.fromhex('5b3a3d5d5c732a5b22275d285b5e22275c735d2b283f3a5c2e6d3375387c5c2e6d70347c6d61737465725c2e7478747c2f656d6265642f736865696c612f295b5e22275c735d2a29').decode('utf-8'), page, re.S)
        return (parsers.fix_url(source.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')), page_url) if source else None, lIIIl)

    def fetch(Illll, url, referer=None):
        IllII = Illll.session.get(Illll.normalize_url(url), headers=Illll.headers(referer), timeout=25, allow_redirects=True)
        IllII.raise_for_status()
        return IllII.text

    def headers(Illll, referer=None):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): Illll.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('746578742f68746d6c2c6170706c69636174696f6e2f7868746d6c2b786d6c2c6170706c69636174696f6e2f786d6c3b713d302e392c2a2f2a3b713d302e38').decode('utf-8'), bytes.fromhex('4163636570742d4c616e6775616765').decode('utf-8'): bytes.fromhex('74722d54522c74723b713d302e392c656e2d55533b713d302e382c656e3b713d302e37').decode('utf-8'), bytes.fromhex('5365632d46657463682d44657374').decode('utf-8'): bytes.fromhex('696672616d65').decode('utf-8')}
        if referer:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        return headers

    def kodi_headers(Illll, referer=None):
        Il = [bytes.fromhex('557365722d4167656e743d').decode('utf-8') + quote(Illll.user_agent)]
        if referer:
            Il.append(bytes.fromhex('526566657265723d').decode('utf-8') + quote(referer))
        Il.append(bytes.fromhex('4163636570743d').decode('utf-8') + quote(bytes.fromhex('2a2f2a').decode('utf-8')))
        return bytes.fromhex('7c').decode('utf-8') + bytes.fromhex('26').decode('utf-8').join(Il)

    def normalize_url(Illll, url):
        url = (url or bytes.fromhex('').decode('utf-8')).strip()
        if url.startswith(bytes.fromhex('2f2f').decode('utf-8')):
            url = bytes.fromhex('68747470733a').decode('utf-8') + url
        elif url.startswith(bytes.fromhex('2f').decode('utf-8')):
            url = urljoin(Illll.base_url + bytes.fromhex('2f').decode('utf-8'), url)
        elif url.startswith(bytes.fromhex('7777772e').decode('utf-8')):
            url = bytes.fromhex('68747470733a2f2f').decode('utf-8') + url
        elif not url.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8'))):
            url = urljoin(Illll.base_url + bytes.fromhex('2f').decode('utf-8'), url)
        IIIll = urlparse(url)
        return urlunparse(IIIll._replace(scheme=bytes.fromhex('6874747073').decode('utf-8')))

    def vidmoly_candidates(Illll, url):
        IIl = []
        Illll._add_candidate(IIl, re.sub(bytes.fromhex('2f772f285b612d7a302d395d2b292f2a24').decode('utf-8'), bytes.fromhex('2f656d6265642d5c312e68746d6c').decode('utf-8'), url, flags=re.I))
        Illll._add_candidate(IIl, url)
        IIIIl = re.sub(bytes.fromhex('68747470733f3a2f2f7669646d6f6c795c2e5b612d7a5d2b').decode('utf-8'), bytes.fromhex('68747470733a2f2f7669646d6f6c792e62697a').decode('utf-8'), url, flags=re.I)
        Illll._add_candidate(IIl, re.sub(bytes.fromhex('2f772f285b612d7a302d395d2b292f2a24').decode('utf-8'), bytes.fromhex('2f656d6265642d5c312e68746d6c').decode('utf-8'), IIIIl, flags=re.I))
        Illll._add_candidate(IIl, IIIIl)
        Illll._add_candidate(IIl, re.sub(bytes.fromhex('2f656d6265642d285b612d7a302d395d2b295c2e68746d6c').decode('utf-8'), bytes.fromhex('2f772f5c31').decode('utf-8'), IIIIl, flags=re.I))
        return IIl

    def submit_number_challenge(Illll, page_url, page, referer=None):
        l = Illll._first(bytes.fromhex('283f3a506c656173652073656c6563747c53656c656374206e756d626572295c732b285c642b29').decode('utf-8'), page)
        if not l:
            l = Illll._first(bytes.fromhex('3c283f3a6469767c7370616e295b5e3e5d2b636c6173733d5b275c225d5b5e275c225d2a7668696e745b5e275c225d2a5b275c225d5b5e3e5d2a3e2e2a3f3c625b5e3e5d2a3e285c642b293c2f623e').decode('utf-8'), page, re.S)
        ll = {bytes.fromhex('6f70').decode('utf-8'): Illll._input_value(page, bytes.fromhex('6f70').decode('utf-8')), bytes.fromhex('66696c655f636f6465').decode('utf-8'): Illll._input_value(page, bytes.fromhex('66696c655f636f6465').decode('utf-8')), bytes.fromhex('616e73776572').decode('utf-8'): l}
        for IIIII in (bytes.fromhex('7473').decode('utf-8'), bytes.fromhex('6e6f6e6365').decode('utf-8'), bytes.fromhex('63746f6b').decode('utf-8')):
            lIllI = Illll._input_value(page, IIIII)
            if lIllI:
                ll[IIIII] = lIllI
        if not ll[bytes.fromhex('6f70').decode('utf-8')] or not ll[bytes.fromhex('66696c655f636f6465').decode('utf-8')] or (not ll[bytes.fromhex('616e73776572').decode('utf-8')]):
            return bytes.fromhex('').decode('utf-8')
        IllII = Illll.session.post(page_url, data=ll, headers=Illll.headers(referer or page_url), timeout=25)
        IllII.raise_for_status()
        return IllII.text

    def _extract_sources(Illll, page, page_url, lIIII):
        IllIl = []
        for lI in re.findall(bytes.fromhex('5b22275d3f736f75726365735b22275d3f5c732a3a5c732a285c5b2e2a3f5c5d29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            for item in Illll._parse_js_list(lI):
                if not isinstance(item, dict):
                    continue
                IlII = item.get(bytes.fromhex('66696c65').decode('utf-8')) or item.get(bytes.fromhex('737263').decode('utf-8'))
                if not IlII:
                    continue
                label = item.get(bytes.fromhex('6c6162656c').decode('utf-8'))
                IllIl.append(parsers.fix_url(IlII.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')), page_url))
        if not IllIl:
            for llll in re.finditer(bytes.fromhex('68747470733f3a2f2f5b5e5c7322273c3e5d2b3f283f3a5c2e6d3375387c5c2e6d70347c6d61737465725c2e7478747c2f656d6265642f736865696c612f295b5e5c7322273c3e5d2a').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.I):
                IllIl.append(llll.group(0).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')))
        return list(dict.fromkeys(IllIl))

    def _extract_subtitles(Illll, page, page_url):
        lIIIl = []
        for lI in re.findall(bytes.fromhex('5b22275d3f747261636b735b22275d3f5c732a3a5c732a285c5b2e2a3f5c5d29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            for item in Illll._parse_js_list(lI):
                if not isinstance(item, dict):
                    continue
                IlII = item.get(bytes.fromhex('66696c65').decode('utf-8'))
                llII = item.get(bytes.fromhex('6b696e64').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
                if IlII and (bytes.fromhex('63617074696f6e').decode('utf-8') in llII.lower() or bytes.fromhex('7375627469746c65').decode('utf-8') in llII.lower()):
                    lIIIl.append(parsers.fix_url(IlII.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')), page_url))
        for llll in re.finditer(bytes.fromhex('61646453727446696c655c285b22275d283f503c75726c3e5b5e22275d2b5c2e737274295b22275d').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.I):
            lIIIl.append(parsers.fix_url(llll.group(bytes.fromhex('75726c').decode('utf-8')), page_url))
        return list(dict.fromkeys(lIIIl))

    def _parse_js_list(Illll, lIllI):
        IIIIl = (lIllI or bytes.fromhex('').decode('utf-8')).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')).replace(bytes.fromhex('27').decode('utf-8'), bytes.fromhex('22').decode('utf-8'))
        IIIIl = re.sub(bytes.fromhex('283f3c215c22295c622866696c657c7372637c6c6162656c7c747970657c6b696e64295c625c732a3a').decode('utf-8'), bytes.fromhex('225c31223a').decode('utf-8'), IIIIl, flags=re.I)
        IIIIl = re.sub(bytes.fromhex('2c5c732a285b5c5d7d5d29').decode('utf-8'), bytes.fromhex('5c31').decode('utf-8'), IIIIl)
        try:
            data = json.loads(IIIIl)
        except ValueError:
            return []
        return data if isinstance(data, list) else []

    def unpack_first_eval(Illll, page):
        llll = re.search(bytes.fromhex('6576616c5c2866756e6374696f6e5c28702c612c632c6b2c652c283f3a727c64295c292e2a3f5c7d5c285c732a27283f503c7061796c6f61643e283f3a5c5c277c5b5e275d292a29275c732a2c5c732a283f503c626173653e5c642b295c732a2c5c732a283f503c636f756e743e5c642b295c732a2c5c732a27283f503c73796d626f6c733e283f3a5c5c277c5b5e275d292a29275c2e73706c69745c28275c7c275c29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S)
        if not llll:
            return bytes.fromhex('').decode('utf-8')
        IIllI = llll.group(bytes.fromhex('7061796c6f6164').decode('utf-8')).replace(bytes.fromhex('5c27').decode('utf-8'), bytes.fromhex('27').decode('utf-8')).replace(bytes.fromhex('5c5c').decode('utf-8'), bytes.fromhex('5c').decode('utf-8'))
        II = int(llll.group(bytes.fromhex('62617365').decode('utf-8')))
        lIIlI = llll.group(bytes.fromhex('73796d626f6c73').decode('utf-8')).replace(bytes.fromhex('5c27').decode('utf-8'), bytes.fromhex('27').decode('utf-8')).replace(bytes.fromhex('5c5c').decode('utf-8'), bytes.fromhex('5c').decode('utf-8')).split(bytes.fromhex('7c').decode('utf-8'))
        return re.sub(bytes.fromhex('5c625c772b5c62').decode('utf-8'), lambda lllI: Illll._packed_symbol(lllI.group(0), II, lIIlI), IIllI)

    def media_url(Illll, text):
        llll = re.search(bytes.fromhex('68747470733f3a2f2f5b5e5c7322273c3e5d2b3f283f3a5c2e283f3a6d3375387c6d7034297c6d61737465725c2e7478747c2f656d6265642f736865696c612f5b5e22275c733c3e5d2b29283f3a5c3f5b5e5c7322273c3e5d2a293f').decode('utf-8'), text or bytes.fromhex('').decode('utf-8'), re.I)
        return llll.group(0).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')) if llll else bytes.fromhex('').decode('utf-8')

    def resolve_hls_variant(Illll, url, referer=None):
        try:
            IlIIl = Illll.fetch(url, referer)
        except (manituxhttp.HTTPError, manituxhttp.RequestError):
            return bytes.fromhex('').decode('utf-8')
        if bytes.fromhex('234558544d3355').decode('utf-8') not in IlIIl or bytes.fromhex('234558542d582d53545245414d2d494e46').decode('utf-8') not in IlIIl:
            return bytes.fromhex('').decode('utf-8')
        lIlll = []
        IIlll = 0
        for llIl in IlIIl.splitlines():
            llIl = llIl.strip()
            if not llIl:
                continue
            if llIl.startswith(bytes.fromhex('234558542d582d53545245414d2d494e46').decode('utf-8')):
                llll = re.search(bytes.fromhex('42414e4457494454483d285c642b29').decode('utf-8'), llIl, re.I)
                IIlll = int(llll.group(1)) if llll else 0
                continue
            if llIl.startswith(bytes.fromhex('23').decode('utf-8')):
                continue
            lIlll.append((IIlll, parsers.fix_url(llIl, url)))
            IIlll = 0
        if not lIlll:
            return bytes.fromhex('').decode('utf-8')
        lIlll.sort(key=lambda item: item[0], reverse=True)
        return lIlll[0][1]

    def decode_embedded_html(Illll, page):
        lII = []
        llI = Illll.decrypt_cryptojs_page(page)
        if llI:
            lII.append(llI)
        for IIll in re.findall(bytes.fromhex('756e6573636170655c285b225c275d282e2a3f295b225c275d5c29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            lII.append(unquote(IIll))
        for IIIl in re.findall(bytes.fromhex('61746f625c285b225c275d285b412d5a612d7a302d392b2f3d5f2d5d2b295b225c275d5c29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.I):
            lII.append(Illll._b64(IIIl))
        for IIIl in re.findall(bytes.fromhex('5b225c275d285b412d5a612d7a302d392b2f3d5f2d5d7b34302c7d295b225c275d').decode('utf-8'), page or bytes.fromhex('').decode('utf-8')):
            lIl = Illll._b64(IIIl)
            if bytes.fromhex('3c696672616d65').decode('utf-8') in lIl or bytes.fromhex('2e6d337538').decode('utf-8') in lIl or bytes.fromhex('2e6d7034').decode('utf-8') in lIl:
                lII.append(lIl)
        return bytes.fromhex('0a').decode('utf-8').join((llIIl for llIIl in lII if llIIl))

    def decrypt_cryptojs_page(Illll, page):
        if AES is None:
            return bytes.fromhex('').decode('utf-8')
        llll = re.search(bytes.fromhex('43727970746f4a535c2e4145535c2e646563727970745c285b22275d283f503c646174613e5b5e22275d2b295b22275d5c732a2c5c732a5b22275d283f503c706173733e5b5e22275d2b295b22275d5c29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I)
        if not llll:
            return bytes.fromhex('').decode('utf-8')
        try:
            IlIll = base64.b64decode(llll.group(bytes.fromhex('64617461').decode('utf-8')))
            IIlII = llll.group(bytes.fromhex('70617373').decode('utf-8')).encode(bytes.fromhex('7574662d38').decode('utf-8'))
            if IlIll.startswith(b'Salted__'):
                IlllI = IlIll[8:16]
                IIlI = IlIll[16:]
                lIlI = Illll.evp_bytes_to_key(IIlII, IlllI, 48)
                key = lIlI[:32]
                lIIl = lIlI[32:48]
            else:
                IIlI = IlIll
                lIlI = Illll.evp_bytes_to_key(IIlII, b'', 48)
                key = lIlI[:32]
                lIIl = lIlI[32:48]
            llI = AES.new(key, AES.MODE_CBC, lIIl).decrypt(IIlI)
            IIIlI = llI[-1]
            if 0 < IIIlI <= 16:
                llI = llI[:-IIIlI]
            return llI.decode(bytes.fromhex('7574662d38').decode('utf-8'), bytes.fromhex('7265706c616365').decode('utf-8'))
        except Exception:
            return bytes.fromhex('').decode('utf-8')

    @staticmethod
    def evp_bytes_to_key(IIlII, IlllI, lIll):
        data = b''
        IlIlI = b''
        while len(data) < lIll:
            IlIlI = hashlib.md5(IlIlI + IIlII + IlllI).digest()
            data += IlIlI
        return data[:lIll]

    def is_site_player(Illll, url):
        IIIll = urlparse(url or bytes.fromhex('').decode('utf-8'))
        return IIIll.netloc.lower() == urlparse(Illll.base_url).netloc.lower() and bytes.fromhex('2f706c617965722f').decode('utf-8') in IIIll.path

    @staticmethod
    def is_media_url(url):
        return bool(re.search(bytes.fromhex('283f3a5c2e6d3375387c5c2e6d70347c6d61737465725c2e7478747c2f656d6265642f736865696c612f5b5e3f235d2a29283f3a5b3f235d2e2a293f24').decode('utf-8'), url or bytes.fromhex('').decode('utf-8'), re.I))

    @staticmethod
    def is_hls_url(url):
        return bool(re.search(bytes.fromhex('283f3a5c2e6d3375387c6d61737465725c2e74787429283f3a5b3f235d2e2a293f24').decode('utf-8'), url or bytes.fromhex('').decode('utf-8'), re.I))

    @staticmethod
    def has_playable(page):
        text = page or bytes.fromhex('').decode('utf-8')
        return bytes.fromhex('736f75726365733a').decode('utf-8') in text or bytes.fromhex('2e6d337538').decode('utf-8') in text or bytes.fromhex('2e6d7034').decode('utf-8') in text or (bytes.fromhex('6a77706c61796572').decode('utf-8') in text)

    @staticmethod
    def needs_number_challenge(page):
        text = page or bytes.fromhex('').decode('utf-8')
        return bytes.fromhex('53656c656374206e756d626572').decode('utf-8') in text or bytes.fromhex('73656c65637420746865206e756d626572').decode('utf-8') in text

    @staticmethod
    def _packed_symbol(lIllI, II, lIIlI):
        I = string.digits + string.ascii_lowercase + string.ascii_uppercase
        Illl = 0
        for Ill in lIllI:
            lll = I.find(Ill)
            if lll < 0 or lll >= II:
                return lIllI
            Illl = Illl * II + lll
        return lIIlI[Illl] if 0 <= Illl < len(lIIlI) and lIIlI[Illl] else lIllI

    @staticmethod
    def _input_value(page, IIIII):
        for lIIll in re.findall(bytes.fromhex('3c696e7075745c625b5e3e5d2a3e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            lIII = DiziBoxExtractor._first(bytes.fromhex('6e616d653d5b22275d285b5e22275d2b295b22275d').decode('utf-8'), lIIll)
            if lIII == IIIII:
                return DiziBoxExtractor._first(bytes.fromhex('76616c75653d5b22275d285b5e22275d2a295b22275d').decode('utf-8'), lIIll, re.S)
        return bytes.fromhex('').decode('utf-8')

    @staticmethod
    def _add_candidate(IIl, url):
        if url and url not in IIl:
            IIl.append(url)

    @staticmethod
    def _b64(lIllI):
        try:
            IlIll = lIllI.encode(bytes.fromhex('7574662d38').decode('utf-8'))
            IlIll += b'=' * ((4 - len(IlIll) % 4) % 4)
            return base64.b64decode(IlIll).decode(bytes.fromhex('7574662d38').decode('utf-8'), bytes.fromhex('7265706c616365').decode('utf-8'))
        except Exception:
            return bytes.fromhex('').decode('utf-8')

    @staticmethod
    def _first(IIlIl, text, flags=0):
        llll = re.search(IIlIl, text or bytes.fromhex('').decode('utf-8'), flags | re.I)
        return llll.group(1) if llll else bytes.fromhex('').decode('utf-8')
