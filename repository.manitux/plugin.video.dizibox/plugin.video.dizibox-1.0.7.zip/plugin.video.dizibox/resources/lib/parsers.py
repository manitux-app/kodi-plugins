from __future__ import absolute_import, unicode_literals
import html
import re
import manituxhttp
try:
    from urllib.parse import quote_plus, urlencode, urljoin, urlparse, parse_qsl, urlunparse
except ImportError:
    from urllib import quote_plus, urlencode
    from urlparse import urljoin, urlparse, parse_qsl, urlunparse
I = [bytes.fromhex('41696c65').decode('utf-8'), bytes.fromhex('416b7369796f6e').decode('utf-8'), bytes.fromhex('416e696d6173796f6e').decode('utf-8'), bytes.fromhex('4176756b6174').decode('utf-8'), bytes.fromhex('42656c676573656c').decode('utf-8'), bytes.fromhex('42696c696d6b75726775').decode('utf-8'), bytes.fromhex('4269796f6772616669').decode('utf-8'), bytes.fromhex('43617375736c756b').decode('utf-8'), bytes.fromhex('4472616d').decode('utf-8'), bytes.fromhex('4472616d61').decode('utf-8'), bytes.fromhex('46616e74617374696b').decode('utf-8'), bytes.fromhex('476572696c696d').decode('utf-8'), bytes.fromhex('47697a656d').decode('utf-8'), bytes.fromhex('4b6f6d656469').decode('utf-8'), bytes.fromhex('4b6f726b75').decode('utf-8'), bytes.fromhex('4d6163657261').decode('utf-8'), bytes.fromhex('4d61686b656d65').decode('utf-8'), bytes.fromhex('4dc3bc7a696b').decode('utf-8'), bytes.fromhex('4dc3bc7a696b616c').decode('utf-8'), bytes.fromhex('506f6c6973697965').decode('utf-8'), bytes.fromhex('506f6c6974696b61').decode('utf-8'), bytes.fromhex('5265616c697479205456').decode('utf-8'), bytes.fromhex('526f6d616e74696b').decode('utf-8'), bytes.fromhex('53617661c59f').decode('utf-8'), bytes.fromhex('53706f72').decode('utf-8'), bytes.fromhex('5375c3a7').decode('utf-8'), bytes.fromhex('54616c6b2d53686f77').decode('utf-8'), bytes.fromhex('5461726968').decode('utf-8'), bytes.fromhex('5765737465726e').decode('utf-8'), bytes.fromhex('596172c4b1c59f6d61').decode('utf-8')]
l = {bytes.fromhex('41696c65').decode('utf-8'): bytes.fromhex('61696c65').decode('utf-8'), bytes.fromhex('416b7369796f6e').decode('utf-8'): bytes.fromhex('616b7369796f6e').decode('utf-8'), bytes.fromhex('416e696d6173796f6e').decode('utf-8'): bytes.fromhex('616e696d6173796f6e').decode('utf-8'), bytes.fromhex('4176756b6174').decode('utf-8'): bytes.fromhex('6176756b6174').decode('utf-8'), bytes.fromhex('42656c676573656c').decode('utf-8'): bytes.fromhex('62656c676573656c').decode('utf-8'), bytes.fromhex('42696c696d6b75726775').decode('utf-8'): bytes.fromhex('62696c696d6b75726775').decode('utf-8'), bytes.fromhex('4269796f6772616669').decode('utf-8'): bytes.fromhex('6269796f6772616669').decode('utf-8'), bytes.fromhex('43617375736c756b').decode('utf-8'): bytes.fromhex('63617375736c756b').decode('utf-8'), bytes.fromhex('4472616d').decode('utf-8'): bytes.fromhex('6472616d').decode('utf-8'), bytes.fromhex('4472616d61').decode('utf-8'): bytes.fromhex('6472616d61').decode('utf-8'), bytes.fromhex('46616e74617374696b').decode('utf-8'): bytes.fromhex('66616e74617374696b').decode('utf-8'), bytes.fromhex('476572696c696d').decode('utf-8'): bytes.fromhex('676572696c696d').decode('utf-8'), bytes.fromhex('47697a656d').decode('utf-8'): bytes.fromhex('67697a656d').decode('utf-8'), bytes.fromhex('4b6f6d656469').decode('utf-8'): bytes.fromhex('6b6f6d656469').decode('utf-8'), bytes.fromhex('4b6f726b75').decode('utf-8'): bytes.fromhex('6b6f726b75').decode('utf-8'), bytes.fromhex('4d6163657261').decode('utf-8'): bytes.fromhex('6d6163657261').decode('utf-8'), bytes.fromhex('4d61686b656d65').decode('utf-8'): bytes.fromhex('6d61686b656d65').decode('utf-8'), bytes.fromhex('4dc3bc7a696b').decode('utf-8'): bytes.fromhex('6d757a696b').decode('utf-8'), bytes.fromhex('4dc3bc7a696b616c').decode('utf-8'): bytes.fromhex('6d757a696b616c').decode('utf-8'), bytes.fromhex('506f6c6973697965').decode('utf-8'): bytes.fromhex('706f6c6973697965').decode('utf-8'), bytes.fromhex('506f6c6974696b61').decode('utf-8'): bytes.fromhex('706f6c6974696b61').decode('utf-8'), bytes.fromhex('5265616c697479205456').decode('utf-8'): bytes.fromhex('7265616c6974792d7476').decode('utf-8'), bytes.fromhex('526f6d616e74696b').decode('utf-8'): bytes.fromhex('726f6d616e74696b').decode('utf-8'), bytes.fromhex('53617661c59f').decode('utf-8'): bytes.fromhex('7361766173').decode('utf-8'), bytes.fromhex('53706f72').decode('utf-8'): bytes.fromhex('73706f72').decode('utf-8'), bytes.fromhex('5375c3a7').decode('utf-8'): bytes.fromhex('737563').decode('utf-8'), bytes.fromhex('54616c6b2d53686f77').decode('utf-8'): bytes.fromhex('74616c6b2d73686f77').decode('utf-8'), bytes.fromhex('5461726968').decode('utf-8'): bytes.fromhex('7461726968').decode('utf-8'), bytes.fromhex('5765737465726e').decode('utf-8'): bytes.fromhex('7765737465726e').decode('utf-8'), bytes.fromhex('596172c4b1c59f6d61').decode('utf-8'): bytes.fromhex('79617269736d61').decode('utf-8')}

def parse_genres(page, base_url, IlIIl):
    lllIl = llIl(page, base_url, IlIIl)
    if lllIl:
        return lllIl
    return llII(page, base_url, IlIIl)

def fallback_genres(base_url):
    IlIIl = base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f64697a692d6172736976692f').decode('utf-8')
    lllIl = [(bytes.fromhex('5965726c69').decode('utf-8'), IlI(IlIIl, bytes.fromhex('7475726b697965').decode('utf-8')))]
    lllIl.extend(((name, IIII(IlIIl, name)) for name in I))
    return lllIl

def page_url(lIIII, page_number):
    page_number = int(page_number)
    if bytes.fromhex('5341594641').decode('utf-8') in lIIII:
        return lIIII.replace(bytes.fromhex('5341594641').decode('utf-8'), str(page_number))
    if page_number <= 1:
        return lIIII
    if bytes.fromhex('5b706167654e756d6265725d').decode('utf-8') in lIIII:
        return lIIII.replace(bytes.fromhex('5b706167654e756d6265725d').decode('utf-8'), str(page_number))
    IIlIII = urlparse(lIIII)
    query = dict(parse_qsl(IIlIII.query))
    query[bytes.fromhex('7361796661').decode('utf-8')] = str(page_number)
    query[bytes.fromhex('70616765').decode('utf-8')] = str(page_number)
    return urlunparse(IIlIII._replace(query=urlencode(query)))

def parse_page_items(page, base_url):
    IlIlII = IIIlI(page)
    if IlIlII is not None:
        lllIl = llll(IlIlII, base_url)
        if lllIl:
            return lllIl
    return lllI(page, base_url)

def has_next_page(page, page_number):
    IIIlII = int(page_number) + 1
    if re.search(bytes.fromhex('3e5c732a7b307d5c732a3c').decode('utf-8').format(IIIlII), page or bytes.fromhex('').decode('utf-8')):
        return True
    return bool(re.search(bytes.fromhex('3e5c732a283f3a536f6e72616b697c536f6e7ce286927c26726172723b29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.I))

def parse_detail(page, url, base_url):
    IlIlII = IIIlI(page)
    title = bytes.fromhex('').decode('utf-8')
    IIllII = bytes.fromhex('').decode('utf-8')
    plot = bytes.fromhex('').decode('utf-8')
    year = bytes.fromhex('').decode('utf-8')
    rating = bytes.fromhex('').decode('utf-8')
    tags = []
    IIlll = []
    if IlIlII is not None:
        lIlll = IlIlII.select_one(bytes.fromhex('6469762e74762d6f766572766965772068312061').decode('utf-8')) or IlIlII.find(bytes.fromhex('6831').decode('utf-8'))
        title = III(lIlll.get_text(bytes.fromhex('20').decode('utf-8'))) if lIlll else bytes.fromhex('').decode('utf-8')
        image = IlIlII.select_one(bytes.fromhex('6469762e74762d6f766572766965772066696775726520696d67').decode('utf-8')) or IlIlII.select_one(bytes.fromhex('696d675b6974656d70726f703d27696d616765275d').decode('utf-8')) or IlIlII.select_one(bytes.fromhex('6d6574615b70726f70657274793d276f673a696d616765275d').decode('utf-8')) or IlIlII.find(bytes.fromhex('696d67').decode('utf-8'), attrs={bytes.fromhex('737263').decode('utf-8'): True})
        IIllII = IIlI(image, base_url)
        lIIlI = IlIlII.select_one(bytes.fromhex('6469762e74762d73746f72792070').decode('utf-8')) or IlIlII.find(attrs={bytes.fromhex('6974656d70726f70').decode('utf-8'): bytes.fromhex('6465736372697074696f6e').decode('utf-8')}) or IlIlII.find(bytes.fromhex('70').decode('utf-8'))
        plot = III(lIIlI.get_text(bytes.fromhex('20').decode('utf-8'))) if lIIlI else bytes.fromhex('').decode('utf-8')
        IllllI = IlIlII.select_one(bytes.fromhex('615b687265662a3d272f79696c2f275d').decode('utf-8'))
        year = III(IllllI.get_text(bytes.fromhex('20').decode('utf-8'))) if IllllI else bytes.fromhex('').decode('utf-8')
        IIlllI = IlIlII.select_one(bytes.fromhex('7370616e2e6c6162656c2d696d64622062').decode('utf-8'))
        rating = III(IIlllI.get_text(bytes.fromhex('20').decode('utf-8'))) if IIlllI else bytes.fromhex('').decode('utf-8')
        tags = [III(IlllIl.get_text(bytes.fromhex('20').decode('utf-8'))) for IlllIl in IlIlII.select(bytes.fromhex('615b687265662a3d272f7475722f275d').decode('utf-8')) if III(IlllIl.get_text(bytes.fromhex('20').decode('utf-8')))]
        IIlll = [III(IlllIl.get_text(bytes.fromhex('20').decode('utf-8'))) for IlllIl in IlIlII.select(bytes.fromhex('615b687265662a3d272f6f79756e63752f275d').decode('utf-8')) if III(IlllIl.get_text(bytes.fromhex('20').decode('utf-8')))]
    if not title:
        title = III(lll(bytes.fromhex('3c68315b5e3e5d2a3e282e2a3f293c2f68313e').decode('utf-8'), page, re.S))
    if not IIllII:
        IIllII = IIIII(page, base_url)
    if not plot:
        plot = III(lll(bytes.fromhex('3c705b5e3e5d2a6974656d70726f703d5b275c225d6465736372697074696f6e5b275c225d5b5e3e5d2a3e282e2a3f293c2f703e').decode('utf-8'), page, re.S))
    if not year:
        year = lll(bytes.fromhex('5c622831395c647b327d7c32305c647b327d295c62').decode('utf-8'), page)
    year = lll(bytes.fromhex('5c622831395c647b327d7c32305c647b327d295c62').decode('utf-8'), year) or year
    return {bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('696d616765').decode('utf-8'): IIllII, bytes.fromhex('6261636b64726f70').decode('utf-8'): IIllII, bytes.fromhex('706c6f74').decode('utf-8'): plot, bytes.fromhex('79656172').decode('utf-8'): year, bytes.fromhex('726174696e67').decode('utf-8'): rating, bytes.fromhex('74616773').decode('utf-8'): tags, bytes.fromhex('6163746f7273').decode('utf-8'): IIlll, bytes.fromhex('736561736f6e5f6c696e6b73').decode('utf-8'): parse_season_links(page, base_url), bytes.fromhex('657069736f646573').decode('utf-8'): parse_episodes(page, base_url), bytes.fromhex('736f7572636573').decode('utf-8'): parse_video_sources(page, url, base_url)}

def parse_season_links(page, base_url):
    IlIlII = IIIlI(page)
    IIIIII = []
    IlIIIl = set()
    if IlIlII is not None:
        IIIllI = IlIlII.select(bytes.fromhex('64697623736561736f6e732d6c69737420615b687265665d').decode('utf-8'))
        for IIIlIl in IIIllI:
            url = fix_url(IIIlIl.get(bytes.fromhex('68726566').decode('utf-8')), base_url)
            if not url or url in IlIIIl:
                continue
            IlIIIl.add(url)
            title = III(IIIlIl.get_text(bytes.fromhex('20').decode('utf-8'))) or bytes.fromhex('53657a6f6e').decode('utf-8')
            IIIIII.append({bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url})
        if IIIIII:
            return IIIIII
    IlIll = lll(bytes.fromhex('3c6469765c625b5e3e5d2a69643d5b275c225d736561736f6e732d6c6973745b275c225d5b5e3e5d2a3e282e2a3f293c2f6469763e').decode('utf-8'), page, re.S)
    for lllll in re.findall(bytes.fromhex('3c615c625b5e3e5d2a687265663d5b275c225d5b5e275c225d2b5b275c225d5b5e3e5d2a3e2e2a3f3c2f613e').decode('utf-8'), IlIll or bytes.fromhex('').decode('utf-8'), re.S | re.I):
        url = fix_url(Il(lllll, bytes.fromhex('68726566').decode('utf-8')), base_url)
        if not url or url in IlIIIl:
            continue
        IlIIIl.add(url)
        title = III(lllll) or bytes.fromhex('53657a6f6e').decode('utf-8')
        IIIIII.append({bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url})
    return IIIIII

def parse_episodes(page, base_url):
    IlIlII = IIIlI(page)
    if IlIlII is not None:
        episodes = []
        IlIIIl = set()
        for IlIlI in IlIlII.select(bytes.fromhex('61727469636c652e677269642d626f78').decode('utf-8')):
            lllll = lII(IlIlI)
            if lllll is None:
                continue
            title = lIl(lllll)
            url = fix_url(lllll.get(bytes.fromhex('68726566').decode('utf-8')), base_url)
            if not IIll(title, url) or url in IlIIIl:
                continue
            IlIIIl.add(url)
            llIIl = IlIlI.find(bytes.fromhex('696d67').decode('utf-8'))
            image = fix_url(llIIl.get(bytes.fromhex('646174612d737263').decode('utf-8')) or llIIl.get(bytes.fromhex('737263').decode('utf-8')) if llIIl else bytes.fromhex('').decode('utf-8'), base_url)
            if IlII(title):
                title = IIllI(url) or title
            IlIIII, episode = parse_episode_numbers(title + bytes.fromhex('20').decode('utf-8') + url)
            episodes.append({bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('696d616765').decode('utf-8'): image, bytes.fromhex('736561736f6e').decode('utf-8'): IlIIII, bytes.fromhex('657069736f6465').decode('utf-8'): episode})
        if episodes:
            return episodes
    episodes = []
    IlIIIl = set()
    for IlIll in re.findall(bytes.fromhex('3c61727469636c655c625b5e3e5d2a636c6173733d5b275c225d5b5e275c225d2a5c62677269642d626f785c625b5e275c225d2a5b275c225d5b5e3e5d2a3e2e2a3f3c2f61727469636c653e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
        IIIIII = re.findall(bytes.fromhex('3c615c625b5e3e5d2a687265663d5b275c225d5b5e275c225d2b5b275c225d5b5e3e5d2a3e2e2a3f3c2f613e').decode('utf-8'), IlIll, re.S | re.I)
        lllll = bytes.fromhex('').decode('utf-8')
        for IllII in IIIIII:
            IlllI = fix_url(Il(IllII, bytes.fromhex('68726566').decode('utf-8')), base_url)
            IllIl = III(IllII) or Il(IllII, bytes.fromhex('7469746c65').decode('utf-8'))
            if IIll(IllIl, IlllI):
                lllll = IllII
                break
        href = Il(lllll, bytes.fromhex('68726566').decode('utf-8'))
        title = III(lllll) or Il(lllll, bytes.fromhex('7469746c65').decode('utf-8'))
        url = fix_url(href, base_url)
        if not IIll(title, url) or url in IlIIIl:
            continue
        IlIIIl.add(url)
        if IlII(title):
            title = IIllI(url) or title
        IlIIII, episode = parse_episode_numbers(title + bytes.fromhex('20').decode('utf-8') + url)
        episodes.append({bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('696d616765').decode('utf-8'): bytes.fromhex('').decode('utf-8'), bytes.fromhex('736561736f6e').decode('utf-8'): IlIIII, bytes.fromhex('657069736f6465').decode('utf-8'): episode})
    return episodes

def parse_episode_numbers(value):
    value = value or bytes.fromhex('').decode('utf-8')
    IIlIlI = (bytes.fromhex('285c642b295c2e3f5c732a73657a6f6e2e2a3f285c642b295c2e3f5c732a625b6fc3b65d6c5b75c3bc5d6d').decode('utf-8'), bytes.fromhex('285c642b292d73657a6f6e2d285c642b292d626f6c756d').decode('utf-8'), bytes.fromhex('285c642b2978285c642b29').decode('utf-8'))
    for IIlIIl in IIlIlI:
        match = re.search(IIlIIl, value, re.I)
        if match:
            return (int(match.group(1)), int(match.group(2)))
    return (0, 0)

def lII(IIIlIl):
    IIllIl = IIIlIl.select_one(bytes.fromhex('6469762e706f73742d7469746c6520615b687265665d2c20683220615b687265665d2c20683320615b687265665d').decode('utf-8'))
    if IIllIl is not None and IIll(lIl(IIllIl), IIllIl.get(bytes.fromhex('68726566').decode('utf-8'))):
        return IIllIl
    for lllll in IIIlIl.find_all(bytes.fromhex('61').decode('utf-8'), href=True):
        if IIll(lIl(lllll), lllll.get(bytes.fromhex('68726566').decode('utf-8'))):
            return lllll
    return None

def lIl(IIIlIl):
    if IIIlIl is None:
        return bytes.fromhex('').decode('utf-8')
    title = III(IIIlIl.get_text(bytes.fromhex('20').decode('utf-8')) or IIIlIl.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8'))
    if not title:
        image = IIIlIl.find(bytes.fromhex('696d67').decode('utf-8'))
        title = III((image.get(bytes.fromhex('616c74').decode('utf-8')) if image else bytes.fromhex('').decode('utf-8')) or IIIlIl.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8'))
    return title

def IIll(title, url):
    value = (title or bytes.fromhex('').decode('utf-8')) + bytes.fromhex('20').decode('utf-8') + (url or bytes.fromhex('').decode('utf-8'))
    if re.search(bytes.fromhex('283f3a706c617965727c667261676d616e7c747261696c65727c796f75747562657c6f6b5c2e72757c7669646d6f6c797c6a6176617363726970743a7c2329').decode('utf-8'), value, re.I):
        return False
    return bool(re.search(bytes.fromhex('283f3a5c642b5c2e3f5c732a73657a6f6e7c5c642b2d73657a6f6e7c5c642b785c642b292e2a3f283f3a5c642b5c2e3f5c732a625b6fc3b65d6c5b75c3bc5d6d7c5c642b2d626f6c756d297c626f6c756d2d697a6c65').decode('utf-8'), value, re.I))

def IlII(title):
    return III(title).lower() in (bytes.fromhex('64697a69626f78').decode('utf-8'), bytes.fromhex('64697a6920626f78').decode('utf-8'), bytes.fromhex('697a6c65').decode('utf-8'), bytes.fromhex('7761746368').decode('utf-8'), bytes.fromhex('').decode('utf-8'))

def IIllI(url):
    path = urlparse(url or bytes.fromhex('').decode('utf-8')).path.strip(bytes.fromhex('2f').decode('utf-8'))
    IlIIll = path.split(bytes.fromhex('2f').decode('utf-8'))[-1]
    if not IlIIll:
        return bytes.fromhex('').decode('utf-8')
    IlIlll = re.sub(bytes.fromhex('2d697a6c6524').decode('utf-8'), bytes.fromhex('').decode('utf-8'), IlIIll, flags=re.I)
    IlIlll = IlIlll.replace(bytes.fromhex('2d').decode('utf-8'), bytes.fromhex('20').decode('utf-8'))
    IlIlll = re.sub(bytes.fromhex('5c62285c642b295c732b73657a6f6e5c732b285c642b295c732b626f6c756d5c62').decode('utf-8'), bytes.fromhex('5c312e2053657a6f6e205c322e2042c3b66cc3bc6d').decode('utf-8'), IlIlll, flags=re.I)
    return III(IlIlll.title())

def parse_video_sources(page, page_url, base_url):
    IlIlII = IIIlI(page)
    sources = []
    IlIIIl = set()

    def add(label, url, referer=None, lllII=False):
        lIlIl = fix_url(url, base_url)
        if not lIlIl or lIlIl in IlIIIl:
            return
        label = III(label)
        IllIlI = bool(lllII) or IllI(lIlIl) or Illl(label, lIlIl)
        if IllIlI and (not label or label.lower() == bytes.fromhex('64697a69626f78').decode('utf-8')):
            label = bytes.fromhex('467261676d616e').decode('utf-8')
        elif not IllIlI and label.lower() == bytes.fromhex('64697a69626f78').decode('utf-8'):
            llIlI = IIIll(lIlIl)
            if llIlI != bytes.fromhex('44697a69426f78').decode('utf-8'):
                label = llIlI
        IlIIIl.add(lIlIl)
        sources.append({bytes.fromhex('6c6162656c').decode('utf-8'): Ill(label or IIIll(lIlIl), lIlIl), bytes.fromhex('75726c').decode('utf-8'): lIlIl, bytes.fromhex('72656665726572').decode('utf-8'): referer or page_url, bytes.fromhex('69735f747261696c6572').decode('utf-8'): IllIlI})
    if IlIlII is not None:
        for IIIlIl in IlIlII.select(bytes.fromhex('64697623747261696c65722d626f7820696672616d655b7372635d2c2064697623747261696c65722d626f7820696672616d655b646174612d7372635d2c20615b687265662a3d27796f7574756265275d2c20615b687265662a3d27796f7574752e6265275d2c20615b687265662a3d27667261676d616e275d2c20696672616d655b7372632a3d27796f7574756265275d2c20696672616d655b646174612d7372632a3d27796f7574756265275d2c20615b646174612d766964656f5f75726c5d').decode('utf-8')):
            href = IIlII(IIIlIl, base_url)
            label = III(IIIlIl.get_text(bytes.fromhex('20').decode('utf-8')) or IIIlIl.get(bytes.fromhex('7469746c65').decode('utf-8')) or IIIlIl.get(bytes.fromhex('646174612d7469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8'))
            if Illl(label, href):
                add(label or IIIll(href), href, page_url, True)
        IllIIl = [IIIlll for IIIlll in IlIlII.select(bytes.fromhex('6469762e766964656f2d746f6f6c626172206f7074696f6e5b76616c75655d2c206469762e766964656f2d746f6f6c626172206f7074696f6e5b687265665d').decode('utf-8')) if III(IIIlll.get(bytes.fromhex('76616c7565').decode('utf-8')) or IIIlll.get(bytes.fromhex('68726566').decode('utf-8')))]
        for IIIlll in IllIIl:
            url = IIlII(IIIlll, base_url)
            label = III(IIIlll.get_text(bytes.fromhex('20').decode('utf-8')) or IIIlll.get(bytes.fromhex('6c6162656c').decode('utf-8')) or IIIlll.get(bytes.fromhex('646174612d7469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')) or IIIll(url)
            add(label, url, page_url)
        if not IllIIl:
            llIII = IlIlII.select_one(bytes.fromhex('64697623766964656f2d6172656120696672616d655b7372635d2c2064697623766964656f2d6172656120696672616d655b646174612d7372635d').decode('utf-8')) or IlIlII.select_one(bytes.fromhex('696672616d655b7372632a3d272f706c617965722f275d2c20696672616d655b646174612d7372632a3d272f706c617965722f275d').decode('utf-8'))
            if llIII is not None:
                IlIIlI = IlIlII.select_one(bytes.fromhex('6469762e766964656f2d746f6f6c626172206f7074696f6e5b73656c65637465645d').decode('utf-8'))
                label = III(IlIIlI.get_text(bytes.fromhex('20').decode('utf-8'))) if IlIIlI else IIIll(llIII.get(bytes.fromhex('646174612d737263').decode('utf-8')) or llIII.get(bytes.fromhex('737263').decode('utf-8')))
                add(label, llIII.get(bytes.fromhex('646174612d737263').decode('utf-8')) or llIII.get(bytes.fromhex('737263').decode('utf-8')), page_url)
    if not any((not source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8')) for source in sources)):
        for IlIllI in re.findall(bytes.fromhex('3c6f7074696f6e5c625b5e3e5d2a283f3a76616c75657c68726566293d5b275c225d5b5e275c225d2b5b275c225d5b5e3e5d2a3e2e2a3f3c2f6f7074696f6e3e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            url = IIlIl(IlIllI, base_url)
            if not lIII(url) and (not IlIl(url, base_url)):
                continue
            add(III(IlIllI) or IIIll(url), url, page_url)
    if not any((not source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8')) for source in sources)):
        for llIII in re.findall(bytes.fromhex('3c696672616d655c625b5e3e5d2b283f3a646174612d7372637c737263293d5b275c225d285b5e275c225d2b295b275c225d').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            if IllI(llIII):
                continue
            add(IIIll(llIII), llIII, page_url)
    if not any((source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8')) for source in sources)):
        IllIll = lll(bytes.fromhex('3c6469765c625b5e3e5d2a69643d5b275c225d747261696c65722d626f785b275c225d5b5e3e5d2a3e282e2a3f293c2f6469763e').decode('utf-8'), page, re.S)
        for llIII in re.findall(bytes.fromhex('3c696672616d655c625b5e3e5d2b283f3a646174612d7372637c737263293d5b275c225d285b5e275c225d2b295b275c225d').decode('utf-8'), IllIll or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            add(bytes.fromhex('467261676d616e').decode('utf-8'), llIII, page_url, True)
    return sources

def parse_iframe(page, base_url):
    IlIlII = IIIlI(page)
    if IlIlII is not None:
        llIII = IlIlII.select_one(bytes.fromhex('64697623766964656f2d6172656120696672616d655b7372635d2c2064697623766964656f2d6172656120696672616d655b646174612d7372635d').decode('utf-8')) or IlIlII.select_one(bytes.fromhex('64697623506c6179657220696672616d655b7372635d2c2064697623506c6179657220696672616d655b646174612d7372635d').decode('utf-8')) or IlIlII.find(bytes.fromhex('696672616d65').decode('utf-8'), src=True) or IlIlII.find(bytes.fromhex('696672616d65').decode('utf-8'), attrs={bytes.fromhex('646174612d737263').decode('utf-8'): True})
        if llIII is not None:
            return fix_url(llIII.get(bytes.fromhex('646174612d737263').decode('utf-8')) or llIII.get(bytes.fromhex('737263').decode('utf-8')), base_url)
    return fix_url(lll(bytes.fromhex('3c696672616d655c625b5e3e5d2b283f3a646174612d7372637c737263293d5b275c225d285b5e275c225d2b295b275c225d').decode('utf-8'), page, re.S), base_url)

def IllI(url):
    return bool(re.search(bytes.fromhex('283f3a796f75747562655c2e636f6d7c796f7574755c2e626529').decode('utf-8'), url or bytes.fromhex('').decode('utf-8'), re.I))

def Illl(label, url):
    IlIlll = (label or bytes.fromhex('').decode('utf-8')) + bytes.fromhex('20').decode('utf-8') + (url or bytes.fromhex('').decode('utf-8'))
    return bool(re.search(bytes.fromhex('283f3a667261676d616e7c747261696c65727c796f75747562655c2e636f6d7c796f7574755c2e626529').decode('utf-8'), IlIlll, re.I))

def lIII(url):
    return bool(re.search(bytes.fromhex('283f3a2f706c617965722f7c6f6b5c2e72757c6f646e6f6b6c6173736e696b697c7669646d6f6c797c766964656f62696e7c6d6f6c7973747265616d7c736865696c615c2e73747265616d7c706f70636f726e76616b74697c7275666969677574617c796f75747562655c2e636f6d7c796f7574755c2e62657c5c2e6d3375387c5c2e6d703429').decode('utf-8'), url or bytes.fromhex('').decode('utf-8'), re.I))

def IlIl(url, base_url):
    if not url:
        return False
    return urlparse(fix_url(url, base_url)).netloc.lower() == urlparse(base_url).netloc.lower()

def IIIll(url):
    IlIlll = (url or bytes.fromhex('').decode('utf-8')).lower()
    if IllI(IlIlll) or bytes.fromhex('667261676d616e').decode('utf-8') in IlIlll:
        return bytes.fromhex('467261676d616e').decode('utf-8')
    llllI = ((bytes.fromhex('64627870726f').decode('utf-8'), bytes.fromhex('44425850726f').decode('utf-8')), (bytes.fromhex('2f706c617965722f64656278').decode('utf-8'), bytes.fromhex('44425850726f').decode('utf-8')), (bytes.fromhex('64656278').decode('utf-8'), bytes.fromhex('44425850726f').decode('utf-8')), (bytes.fromhex('6f6b2e7275').decode('utf-8'), bytes.fromhex('4f646e6f6b').decode('utf-8')), (bytes.fromhex('6f646e6f6b6c6173736e696b69').decode('utf-8'), bytes.fromhex('4f646e6f6b').decode('utf-8')), (bytes.fromhex('6f646e6f6b').decode('utf-8'), bytes.fromhex('4f646e6f6b').decode('utf-8')), (bytes.fromhex('7669646d6f6c79').decode('utf-8'), bytes.fromhex('5669644d6f6c79').decode('utf-8')), (bytes.fromhex('766964656f62696e').decode('utf-8'), bytes.fromhex('5669644d6f6c79').decode('utf-8')), (bytes.fromhex('6d6f6c79').decode('utf-8'), bytes.fromhex('4d6f6c792b').decode('utf-8')), (bytes.fromhex('6b696e67').decode('utf-8'), bytes.fromhex('4b696e67').decode('utf-8')), (bytes.fromhex('6861796469').decode('utf-8'), bytes.fromhex('4861796469').decode('utf-8')))
    for IIIIll, label in llllI:
        if IIIIll in IlIlll:
            return label
    return bytes.fromhex('44697a69426f78').decode('utf-8')

def Ill(label, url):
    IIllll = III(label)
    IIIIIl = IIllll.lower()
    IlIII = {bytes.fromhex('646278').decode('utf-8'): bytes.fromhex('44425850726f').decode('utf-8'), bytes.fromhex('64627870726f').decode('utf-8'): bytes.fromhex('44425850726f').decode('utf-8'), bytes.fromhex('6462782070726f').decode('utf-8'): bytes.fromhex('44425850726f').decode('utf-8'), bytes.fromhex('64656278').decode('utf-8'): bytes.fromhex('44425850726f').decode('utf-8'), bytes.fromhex('6d6f6c79').decode('utf-8'): bytes.fromhex('4d6f6c792b').decode('utf-8'), bytes.fromhex('6d6f6c792b').decode('utf-8'): bytes.fromhex('4d6f6c792b').decode('utf-8'), bytes.fromhex('6d6f6c7973747265616d').decode('utf-8'): bytes.fromhex('4d6f6c792b').decode('utf-8'), bytes.fromhex('6f646e6f6b').decode('utf-8'): bytes.fromhex('4f646e6f6b').decode('utf-8'), bytes.fromhex('6f646e6f6b6c6173736e696b69').decode('utf-8'): bytes.fromhex('4f646e6f6b').decode('utf-8'), bytes.fromhex('6f6b').decode('utf-8'): bytes.fromhex('4f646e6f6b').decode('utf-8'), bytes.fromhex('6f6b2e7275').decode('utf-8'): bytes.fromhex('4f646e6f6b').decode('utf-8')}
    if IIIIIl in IlIII:
        return IlIII[IIIIIl]
    if IIIIIl in (bytes.fromhex('').decode('utf-8'), bytes.fromhex('64697a69626f78').decode('utf-8'), bytes.fromhex('64697a6920626f78').decode('utf-8'), bytes.fromhex('616c7465726e61746966').decode('utf-8')):
        return IIIll(url)
    return IIllll

def IIlII(IIIlIl, base_url):
    if IIIlIl is None:
        return bytes.fromhex('').decode('utf-8')
    attrs = (bytes.fromhex('646174612d766964656f5f75726c').decode('utf-8'), bytes.fromhex('646174612d766964656f2d75726c').decode('utf-8'), bytes.fromhex('646174612d737263').decode('utf-8'), bytes.fromhex('646174612d696672616d65').decode('utf-8'), bytes.fromhex('646174612d75726c').decode('utf-8'), bytes.fromhex('646174612d68726566').decode('utf-8'), bytes.fromhex('68726566').decode('utf-8'), bytes.fromhex('737263').decode('utf-8'), bytes.fromhex('76616c7565').decode('utf-8'))
    for name in attrs:
        value = IIIlIl.get(name)
        if value and value != bytes.fromhex('23').decode('utf-8'):
            if lIII(value) or value.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'), bytes.fromhex('2f2f').decode('utf-8'))):
                return value
    IllIII = IIIlIl.get(bytes.fromhex('646174612d766964656f').decode('utf-8')) or IIIlIl.get(bytes.fromhex('646174612d68617368').decode('utf-8')) or IIIlIl.get(bytes.fromhex('646174612d6964').decode('utf-8')) or IIIlIl.get(bytes.fromhex('76616c7565').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
    IIlIll = III(IIIlIl.get(bytes.fromhex('646174612d74797065').decode('utf-8')) or IIIlIl.get(bytes.fromhex('646174612d706c61796572').decode('utf-8')) or IIIlIl.get(bytes.fromhex('646174612d7469746c65').decode('utf-8')) or IIIlIl.get(bytes.fromhex('6c6162656c').decode('utf-8')) or IIIlIl.get_text(bytes.fromhex('20').decode('utf-8')) or bytes.fromhex('').decode('utf-8')).lower()
    return lI(IllIII, IIlIll, base_url)

def IIlIl(IlIllI, base_url):
    for name in (bytes.fromhex('646174612d766964656f5f75726c').decode('utf-8'), bytes.fromhex('646174612d766964656f2d75726c').decode('utf-8'), bytes.fromhex('646174612d737263').decode('utf-8'), bytes.fromhex('646174612d696672616d65').decode('utf-8'), bytes.fromhex('646174612d75726c').decode('utf-8'), bytes.fromhex('646174612d68726566').decode('utf-8'), bytes.fromhex('68726566').decode('utf-8'), bytes.fromhex('737263').decode('utf-8'), bytes.fromhex('76616c7565').decode('utf-8')):
        value = Il(IlIllI, name)
        if value and value != bytes.fromhex('23').decode('utf-8'):
            if lIII(value) or value.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'), bytes.fromhex('2f2f').decode('utf-8'))):
                return value
    IllIII = Il(IlIllI, bytes.fromhex('646174612d766964656f').decode('utf-8')) or Il(IlIllI, bytes.fromhex('646174612d68617368').decode('utf-8')) or Il(IlIllI, bytes.fromhex('646174612d6964').decode('utf-8')) or Il(IlIllI, bytes.fromhex('76616c7565').decode('utf-8'))
    IIlIll = III(Il(IlIllI, bytes.fromhex('646174612d74797065').decode('utf-8')) or Il(IlIllI, bytes.fromhex('646174612d706c61796572').decode('utf-8')) or Il(IlIllI, bytes.fromhex('646174612d7469746c65').decode('utf-8')) or Il(IlIllI, bytes.fromhex('6c6162656c').decode('utf-8')) or IlIllI).lower()
    return lI(IllIII, IIlIll, base_url)

def lI(IllIII, IIlIll, base_url):
    IllIII = html.unescape((IllIII or bytes.fromhex('').decode('utf-8')).strip())
    if not IllIII or IllIII == bytes.fromhex('23').decode('utf-8'):
        return bytes.fromhex('').decode('utf-8')
    if lIII(IllIII) or IllIII.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'), bytes.fromhex('2f2f').decode('utf-8'))):
        return IllIII
    if bytes.fromhex('6f6b').decode('utf-8') in IIlIll or bytes.fromhex('6f646e6f6b6c6173736e696b69').decode('utf-8') in IIlIll:
        return bytes.fromhex('68747470733a2f2f6f6b2e72752f766964656f656d6265642f').decode('utf-8') + IllIII if IllIII.isdigit() else bytes.fromhex('').decode('utf-8')
    if bytes.fromhex('7669646d6f6c79').decode('utf-8') in IIlIll or bytes.fromhex('766964656f62696e').decode('utf-8') in IIlIll:
        if IllIII.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8'), bytes.fromhex('2f2f').decode('utf-8'))):
            return IllIII
        if re.match(bytes.fromhex('5e5b612d7a302d395f2d5d2b24').decode('utf-8'), IllIII, re.I):
            return bytes.fromhex('68747470733a2f2f7669646d6f6c792e746f2f656d6265642d').decode('utf-8') + IllIII + bytes.fromhex('2e68746d6c').decode('utf-8')
        return bytes.fromhex('').decode('utf-8')
    if bytes.fromhex('646278').decode('utf-8') in IIlIll or bytes.fromhex('64656278').decode('utf-8') in IIlIll:
        return base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f706c617965722f646562782e7068703f763d').decode('utf-8') + IllIII
    if bytes.fromhex('6d6f6c79').decode('utf-8') in IIlIll:
        return base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f706c617965722f6d6f6c792f6d6f6c792e7068703f683d').decode('utf-8') + IllIII
    if bytes.fromhex('6861796469').decode('utf-8') in IIlIll:
        return base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f706c617965722f68617964692e7068703f763d').decode('utf-8') + IllIII
    if bytes.fromhex('6b696e67').decode('utf-8') in IIlIll:
        return base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f706c617965722f6b696e672f6b696e672e7068703f763d').decode('utf-8') + IllIII
    return bytes.fromhex('').decode('utf-8')

def fix_url(url, base_url):
    if not url:
        return bytes.fromhex('').decode('utf-8')
    return urljoin(base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8'), html.unescape(url).strip())

def IIlI(IIIlIl, base_url):
    if IIIlIl is None:
        return bytes.fromhex('').decode('utf-8')
    if getattr(IIIlIl, bytes.fromhex('6e616d65').decode('utf-8'), bytes.fromhex('').decode('utf-8')) == bytes.fromhex('6d657461').decode('utf-8'):
        value = IIIlIl.get(bytes.fromhex('636f6e74656e74').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
    else:
        value = IIIlIl.get(bytes.fromhex('646174612d737263').decode('utf-8')) or IIIlIl.get(bytes.fromhex('646174612d6c617a792d737263').decode('utf-8')) or IIIlIl.get(bytes.fromhex('646174612d6f726967696e616c').decode('utf-8')) or IIIlIl.get(bytes.fromhex('646174612d737263736574').decode('utf-8')) or IIIlIl.get(bytes.fromhex('737263736574').decode('utf-8')) or IIIlIl.get(bytes.fromhex('737263').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
    value = (value or bytes.fromhex('').decode('utf-8')).split(bytes.fromhex('2c').decode('utf-8'))[0].strip().split(bytes.fromhex('20').decode('utf-8'))[0]
    if not value or value.lower().startswith(bytes.fromhex('646174613a696d616765').decode('utf-8')):
        return bytes.fromhex('').decode('utf-8')
    return fix_url(value, base_url)

def IIIII(page, base_url):
    IIlIlI = (bytes.fromhex('3c6d6574615c625b5e3e5d2a283f3a70726f70657274797c6e616d65293d5b275c225d6f673a696d6167655b275c225d5b5e3e5d2a3e').decode('utf-8'), bytes.fromhex('3c696d675c625b5e3e5d2a636c6173733d5b275c225d5b5e275c225d2a283f3a706f737465727c7468756d627c696d6167657c636f766572295b5e275c225d2a5b275c225d5b5e3e5d2a3e').decode('utf-8'), bytes.fromhex('3c696d675c625b5e3e5d2a3e').decode('utf-8'))
    for IIlIIl in IIlIlI:
        IlIllI = lll(IIlIIl, page, re.S)
        if not IlIllI:
            continue
        value = Il(IlIllI, bytes.fromhex('636f6e74656e74').decode('utf-8')) or Il(IlIllI, bytes.fromhex('646174612d737263').decode('utf-8')) or Il(IlIllI, bytes.fromhex('646174612d6c617a792d737263').decode('utf-8')) or Il(IlIllI, bytes.fromhex('646174612d6f726967696e616c').decode('utf-8')) or Il(IlIllI, bytes.fromhex('646174612d737263736574').decode('utf-8')) or Il(IlIllI, bytes.fromhex('737263736574').decode('utf-8')) or Il(IlIllI, bytes.fromhex('737263').decode('utf-8'))
        value = (value or bytes.fromhex('').decode('utf-8')).split(bytes.fromhex('2c').decode('utf-8'))[0].strip().split(bytes.fromhex('20').decode('utf-8'))[0]
        if value and (not value.lower().startswith(bytes.fromhex('646174613a696d616765').decode('utf-8'))):
            return fix_url(value, base_url)
    return bytes.fromhex('').decode('utf-8')

def llIl(page, base_url, IlIIl):
    IlIlII = IIIlI(page)
    if IlIlII is None:
        return []
    lIllI = llI(IlIlII, bytes.fromhex('54c3bc72').decode('utf-8'), stop_texts=(bytes.fromhex('c39c6c6b65').decode('utf-8'), bytes.fromhex('596170c4b16d2059c4b16cc4b1').decode('utf-8'), bytes.fromhex('494d4462').decode('utf-8'), bytes.fromhex('46c4b04c5452454c454d45').decode('utf-8')))
    Illll = lIllI.find_all([bytes.fromhex('61').decode('utf-8'), bytes.fromhex('6c6162656c').decode('utf-8'), bytes.fromhex('696e707574').decode('utf-8'), bytes.fromhex('6f7074696f6e').decode('utf-8')]) if lIllI is not None else []
    lllIl = []
    IlIIIl = set()
    for IIIlIl in Illll:
        IlIlll = III(IIIlIl.get_text(bytes.fromhex('20').decode('utf-8')))
        value = bytes.fromhex('').decode('utf-8')
        href = bytes.fromhex('').decode('utf-8')
        if getattr(IIIlIl, bytes.fromhex('6e616d65').decode('utf-8'), bytes.fromhex('').decode('utf-8')) == bytes.fromhex('696e707574').decode('utf-8'):
            IlIlll = III(IIIlIl.get(bytes.fromhex('76616c7565').decode('utf-8')) or IIIlIl.get(bytes.fromhex('646174612d7469746c65').decode('utf-8')) or IIIlIl.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8'))
            value = IIIlIl.get(bytes.fromhex('76616c7565').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
            name = IIIlIl.get(bytes.fromhex('6e616d65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        else:
            llIll = IIIlIl.find(bytes.fromhex('696e707574').decode('utf-8')) if hasattr(IIIlIl, bytes.fromhex('66696e64').decode('utf-8')) else None
            if llIll is not None:
                IlIlll = IlIlll or III(llIll.get(bytes.fromhex('76616c7565').decode('utf-8')) or bytes.fromhex('').decode('utf-8'))
                value = llIll.get(bytes.fromhex('76616c7565').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
                name = llIll.get(bytes.fromhex('6e616d65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
            else:
                name = IIIlIl.get(bytes.fromhex('6e616d65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        if getattr(IIIlIl, bytes.fromhex('6e616d65').decode('utf-8'), bytes.fromhex('').decode('utf-8')) == bytes.fromhex('61').decode('utf-8'):
            href = IIIlIl.get(bytes.fromhex('68726566').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        if IlIlll not in I and IlIlll.title() not in I:
            continue
        title = ll(IlIlll)
        if title in IlIIIl:
            continue
        IlIIIl.add(title)
        if href:
            url = fix_url(href, base_url)
        elif value and name:
            url = IIII(IlIIl, title, param=name, value=value)
        else:
            url = IIII(IlIIl, title)
        lllIl.append((title, url))
    return lllIl

def llII(page, base_url, IlIIl):
    IlIll = lll(bytes.fromhex('54c3bc725c732a282e2a3f29283f3ac39c6c6b657c596170c4b16d2059c4b16cc4b17c494d44627c46c4b04c5452454c454d4529').decode('utf-8'), IIIl(page), re.S | re.I)
    lllIl = []
    IlIIIl = set()
    for name in I:
        if re.search(bytes.fromhex('283f3a5e7c5c6e295c732a7b307d5c732a283f3a5c6e7c2429').decode('utf-8').format(re.escape(name)), IlIll or bytes.fromhex('').decode('utf-8'), re.I):
            if name not in IlIIIl:
                IlIIIl.add(name)
                lllIl.append((name, IIII(IlIIl, name)))
    return lllIl

def llll(IlIlII, base_url):
    lIlII = lIll(IlIlII, base_url)
    if lIlII:
        return lIlII
    lllIl = []
    IlIIIl = set()
    for lllll in IlIlII.find_all(bytes.fromhex('61').decode('utf-8'), href=True):
        href = lllll.get(bytes.fromhex('68726566').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        if bytes.fromhex('2f64697a696c65722f').decode('utf-8') not in href:
            continue
        title = III(lllll.get_text(bytes.fromhex('20').decode('utf-8')) or lllll.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8'))
        if not title:
            llIIl = lllll.find(bytes.fromhex('696d67').decode('utf-8'))
            title = III((llIIl.get(bytes.fromhex('616c74').decode('utf-8')) if llIIl else bytes.fromhex('').decode('utf-8')) or bytes.fromhex('').decode('utf-8'))
        title = IIl(title)
        if not title:
            continue
        url = fix_url(href, base_url)
        if url in IlIIIl:
            continue
        IlIIIl.add(url)
        llIIl = lllll.find(bytes.fromhex('696d67').decode('utf-8')) or lIIl(lllll)
        image = fix_url(llIIl.get(bytes.fromhex('646174612d737263').decode('utf-8')) or llIIl.get(bytes.fromhex('737263').decode('utf-8')) if llIIl else bytes.fromhex('').decode('utf-8'), base_url)
        plot = lIlI(lllll)
        lllIl.append({bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('696d616765').decode('utf-8'): image, bytes.fromhex('706c6f74').decode('utf-8'): plot})
    return lllIl

def lllI(page, base_url):
    lllIl = []
    IlIIIl = set()
    for IlIll in re.findall(bytes.fromhex('3c61727469636c655c625b5e3e5d2a636c6173733d5b275c225d5b5e275c225d2a5c6264657461696c65642d61727469636c655c625b5e275c225d2a5b275c225d5b5e3e5d2a3e2e2a3f3c2f61727469636c653e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
        lllll = lll(bytes.fromhex('3c68335b5e3e5d2a3e2e2a3f3c615c625b5e3e5d2a687265663d5b275c225d5b5e275c225d2b5b275c225d5b5e3e5d2a3e2e2a3f3c2f613e').decode('utf-8'), IlIll, re.S)
        href = Il(lllll, bytes.fromhex('68726566').decode('utf-8'))
        title = IIl(III(lllll))
        if not title or not href:
            continue
        url = fix_url(href, base_url)
        if url in IlIIIl:
            continue
        IlIIIl.add(url)
        image = fix_url(Il(lll(bytes.fromhex('3c696d675c625b5e3e5d2a3e').decode('utf-8'), IlIll, re.S), bytes.fromhex('646174612d737263').decode('utf-8')) or Il(lll(bytes.fromhex('3c696d675c625b5e3e5d2a3e').decode('utf-8'), IlIll, re.S), bytes.fromhex('737263').decode('utf-8')), base_url)
        plot = III(re.sub(bytes.fromhex('2e2a3f3c2f68333e').decode('utf-8'), bytes.fromhex('').decode('utf-8'), IlIll, flags=re.S | re.I))
        lllIl.append({bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('696d616765').decode('utf-8'): image, bytes.fromhex('706c6f74').decode('utf-8'): plot})
    if lllIl:
        return lllIl
    lllIl = []
    IlIIIl = set()
    for match in re.finditer(bytes.fromhex('3c615c625b5e3e5d2a687265663d5b275c225d285b5e275c225d2a2f64697a696c65722f5b5e275c225d2b295b275c225d5b5e3e5d2a3e282e2a3f293c2f613e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
        url = fix_url(match.group(1), base_url)
        title = IIl(III(match.group(2)) or Il(match.group(0), bytes.fromhex('7469746c65').decode('utf-8')))
        if not title or url in IlIIIl:
            continue
        IlIIIl.add(url)
        lllIl.append({bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('696d616765').decode('utf-8'): bytes.fromhex('').decode('utf-8'), bytes.fromhex('706c6f74').decode('utf-8'): bytes.fromhex('').decode('utf-8')})
    return lllIl

def IIII(IlIIl, title, param=bytes.fromhex('747572').decode('utf-8'), value=None):
    IlIIll = value or l.get(title) or IIIIl(title)
    if param.startswith(bytes.fromhex('747572').decode('utf-8')):
        return IlIIl.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f706167652f53415946412f3f7475725b305d3d7b307d2679696c26696d6462').decode('utf-8').format(quote_plus(IlIIll))
    return IlIIl.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f706167652f53415946412f3f7b307d3d7b317d2679696c26696d6462').decode('utf-8').format(param, quote_plus(IlIIll))

def IlI(IlIIl, value):
    return IlIIl.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f706167652f53415946412f3f756c6b655b5d3d7b307d2679696c3d26696d6462').decode('utf-8').format(quote_plus(value))

def lIll(IlIlII, base_url):
    lllIl = []
    IlIIIl = set()
    for IlIlI in IlIlII.select(bytes.fromhex('61727469636c652e64657461696c65642d61727469636c65').decode('utf-8')):
        lllll = IlIlI.select_one(bytes.fromhex('683320615b687265665d').decode('utf-8')) or IlIlI.find(bytes.fromhex('61').decode('utf-8'), href=True)
        if lllll is None:
            continue
        title = IIl(lllll.get_text(bytes.fromhex('20').decode('utf-8')) or lllll.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8'))
        href = lllll.get(bytes.fromhex('68726566').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        if not title or not href:
            continue
        url = fix_url(href, base_url)
        if url in IlIIIl:
            continue
        IlIIIl.add(url)
        llIIl = IlIlI.find(bytes.fromhex('696d67').decode('utf-8'))
        image = fix_url(llIIl.get(bytes.fromhex('646174612d737263').decode('utf-8')) or llIIl.get(bytes.fromhex('737263').decode('utf-8')) if llIIl else bytes.fromhex('').decode('utf-8'), base_url)
        lIIll = IlIlI.select_one(bytes.fromhex('70').decode('utf-8'))
        plot = III(lIIll.get_text(bytes.fromhex('20').decode('utf-8'))) if lIIll else bytes.fromhex('').decode('utf-8')
        lllIl.append({bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('696d616765').decode('utf-8'): image, bytes.fromhex('706c6f74').decode('utf-8'): plot})
    return lllIl

def IIIIl(value):
    IlIlIl = {bytes.fromhex('c4b1').decode('utf-8'): bytes.fromhex('69').decode('utf-8'), bytes.fromhex('c4b0').decode('utf-8'): bytes.fromhex('69').decode('utf-8'), bytes.fromhex('c49f').decode('utf-8'): bytes.fromhex('67').decode('utf-8'), bytes.fromhex('c49e').decode('utf-8'): bytes.fromhex('67').decode('utf-8'), bytes.fromhex('c3bc').decode('utf-8'): bytes.fromhex('75').decode('utf-8'), bytes.fromhex('c39c').decode('utf-8'): bytes.fromhex('75').decode('utf-8'), bytes.fromhex('c59f').decode('utf-8'): bytes.fromhex('73').decode('utf-8'), bytes.fromhex('c59e').decode('utf-8'): bytes.fromhex('73').decode('utf-8'), bytes.fromhex('c3b6').decode('utf-8'): bytes.fromhex('6f').decode('utf-8'), bytes.fromhex('c396').decode('utf-8'): bytes.fromhex('6f').decode('utf-8'), bytes.fromhex('c3a7').decode('utf-8'): bytes.fromhex('63').decode('utf-8'), bytes.fromhex('c387').decode('utf-8'): bytes.fromhex('63').decode('utf-8')}
    IlIlll = bytes.fromhex('').decode('utf-8').join((IlIlIl.get(lIIIl, lIIIl) for lIIIl in value.lower()))
    return re.sub(bytes.fromhex('5b5e612d7a302d395d2b').decode('utf-8'), bytes.fromhex('2d').decode('utf-8'), IlIlll).strip(bytes.fromhex('2d').decode('utf-8'))

def IIIlI(page):
    if manituxhttp.BeautifulSoup is None:
        return None
    return manituxhttp.BeautifulSoup(page or bytes.fromhex('').decode('utf-8'), bytes.fromhex('68746d6c2e706172736572').decode('utf-8'))

def llI(IlIlII, IlIlll, stop_texts=()):
    IIIIlI = IlIlII.find(string=lambda value: III(value) == IlIlll)
    if IIIIlI is None:
        return None
    IlllII = IIIIlI.parent
    while IlllII is not None and IlllII.name not in (bytes.fromhex('626f6479').decode('utf-8'), bytes.fromhex('666f726d').decode('utf-8'), bytes.fromhex('6173696465').decode('utf-8'), bytes.fromhex('73656374696f6e').decode('utf-8'), bytes.fromhex('646976').decode('utf-8')):
        IlllII = IlllII.parent
    if IlllII is None:
        return None
    return IlllII

def ll(IlIlll):
    for name in I:
        if name.lower() == IlIlll.lower():
            return name
    return IlIlll

def lIIl(lllll):
    parent = lllll.parent
    for II in range(4):
        if parent is None:
            return None
        llIIl = parent.find(bytes.fromhex('696d67').decode('utf-8')) if hasattr(parent, bytes.fromhex('66696e64').decode('utf-8')) else None
        if llIIl is not None:
            return llIIl
        parent = parent.parent
    return None

def lIlI(lllll):
    parent = lllll.parent
    for II in range(4):
        if parent is None:
            return bytes.fromhex('').decode('utf-8')
        IlIlll = III(parent.get_text(bytes.fromhex('20').decode('utf-8'))) if hasattr(parent, bytes.fromhex('6765745f74657874').decode('utf-8')) else bytes.fromhex('').decode('utf-8')
        if len(IlIlll) > 80:
            return IlIlll
        parent = parent.parent
    return bytes.fromhex('').decode('utf-8')

def IIIl(page):
    IlIlII = IIIlI(page)
    if IlIlII is not None:
        return IlIlII.get_text(bytes.fromhex('0a').decode('utf-8'))
    return III(page).replace(bytes.fromhex('202a20').decode('utf-8'), bytes.fromhex('0a').decode('utf-8'))

def Il(IlIllI, name):
    if not IlIllI:
        return bytes.fromhex('').decode('utf-8')
    match = re.search(bytes.fromhex('5c627b307d3d5b225c275d285b5e225c275d2b295b225c275d').decode('utf-8').format(re.escape(name)), IlIllI, re.I)
    return html.unescape(match.group(1)) if match else bytes.fromhex('').decode('utf-8')

def lll(IIlIIl, IlIlll, flags=0):
    match = re.search(IIlIIl, IlIlll or bytes.fromhex('').decode('utf-8'), flags | re.I)
    if not match:
        return bytes.fromhex('').decode('utf-8')
    return match.group(1) if match.lastindex else match.group(0)

def IIl(value):
    value = III(value)
    value = re.sub(bytes.fromhex('5c732b697a6c655c732a24').decode('utf-8'), bytes.fromhex('').decode('utf-8'), value, flags=re.I).strip()
    return value

def III(IlIlll):
    IlIlll = re.sub(bytes.fromhex('3c7363726970742e2a3f3c2f7363726970743e').decode('utf-8'), bytes.fromhex('20').decode('utf-8'), IlIlll or bytes.fromhex('').decode('utf-8'), flags=re.S | re.I)
    IlIlll = re.sub(bytes.fromhex('3c7374796c652e2a3f3c2f7374796c653e').decode('utf-8'), bytes.fromhex('20').decode('utf-8'), IlIlll, flags=re.S | re.I)
    IlIlll = re.sub(bytes.fromhex('3c5b5e3e5d2b3e').decode('utf-8'), bytes.fromhex('20').decode('utf-8'), IlIlll)
    IlIlll = html.unescape(IlIlll)
    return re.sub(bytes.fromhex('5c732b').decode('utf-8'), bytes.fromhex('20').decode('utf-8'), IlIlll).strip()
