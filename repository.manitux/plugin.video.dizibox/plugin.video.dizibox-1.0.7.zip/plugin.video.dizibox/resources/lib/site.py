from __future__ import absolute_import, unicode_literals
import time
import re
import manituxhttp
try:
    from urllib.parse import quote_plus, urlparse
except ImportError:
    from urllib import quote_plus
    from urlparse import urlparse
from .extractor import DiziBoxExtractor
from . import parsers

class DiziBoxSite(object):
    ARCHIVE_PATH = bytes.fromhex('2f64697a692d6172736976692f').decode('utf-8')

    def __init__(lIl, base_url, user_agent):
        lIl.base_url = base_url.rstrip(bytes.fromhex('2f').decode('utf-8'))
        lIl.user_agent = user_agent
        lIl.session = manituxhttp.Session()
        lIl.extractor = DiziBoxExtractor(user_agent, lIl.base_url)

    def headers(lIl, referer=None):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): lIl.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('746578742f68746d6c2c6170706c69636174696f6e2f7868746d6c2b786d6c2c6170706c69636174696f6e2f786d6c3b713d302e392c2a2f2a3b713d302e38').decode('utf-8'), bytes.fromhex('4163636570742d4c616e6775616765').decode('utf-8'): bytes.fromhex('74722d54522c74723b713d302e392c656e2d55533b713d302e382c656e3b713d302e37').decode('utf-8'), bytes.fromhex('436f6f6b6965').decode('utf-8'): bytes.fromhex('697354727573746564557365723d747275653b20646278753d7b307d').decode('utf-8').format(int(time.time() * 1000)), bytes.fromhex('557067726164652d496e7365637572652d5265717565737473').decode('utf-8'): bytes.fromhex('31').decode('utf-8')}
        if referer:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        return headers

    def get(lIl, url, referer=None):
        III = lIl.session.get(lIl.absolute(url), headers=lIl.headers(referer), timeout=25, allow_redirects=True)
        III.raise_for_status()
        return III.text

    def categories(lIl):
        return parsers.fallback_genres(lIl.base_url)

    def get_page_items(lIl, l, page_number=1):
        url = parsers.page_url(l, page_number)
        page = lIl.get(url, referer=lIl.base_url + lIl.ARCHIVE_PATH)
        return (parsers.parse_page_items(page, lIl.base_url), parsers.has_next_page(page, page_number))

    def search(lIl, query):
        page = lIl.get(lIl.base_url + bytes.fromhex('2f3f733d').decode('utf-8') + quote_plus(query), referer=lIl.base_url + bytes.fromhex('2f').decode('utf-8'))
        return (parsers.parse_page_items(page, lIl.base_url), parsers.has_next_page(page, 1))

    def detail(lIl, url):
        page = lIl.get(url)
        ll = parsers.parse_detail(page, url, lIl.base_url)
        ll[bytes.fromhex('657069736f646573').decode('utf-8')] = lIl.sort_episodes(ll.get(bytes.fromhex('657069736f646573').decode('utf-8')) or [])
        if not lIl.is_episode_url(url):
            ll[bytes.fromhex('736f7572636573').decode('utf-8')] = [source for source in ll.get(bytes.fromhex('736f7572636573').decode('utf-8'), []) if source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8'))]
        return ll

    def parse_detail(lIl, page, url):
        return parsers.parse_detail(page, url, lIl.base_url)

    def load_episodes(lIl, IlI, referer=None):
        episodes = []
        lII = set()
        for IIl in IlI:
            Ill = IIl.get(bytes.fromhex('75726c').decode('utf-8'))
            if not Ill:
                continue
            try:
                page = lIl.get(Ill, referer=referer or lIl.base_url)
            except Exception:
                continue
            for episode in parsers.parse_episodes(page, lIl.base_url):
                II = episode.get(bytes.fromhex('75726c').decode('utf-8'))
                if not II or II in lII:
                    continue
                lII.add(II)
                episodes.append(episode)
        return episodes

    def fetch_iframe(lIl, url, referer=None):
        page = lIl.get(url, referer=referer)
        lI = parsers.parse_iframe(page, lIl.base_url)
        if lI:
            return lI
        detail = parsers.parse_detail(page, url, lIl.base_url)
        sources = [source for source in detail.get(bytes.fromhex('736f7572636573').decode('utf-8'), []) if not source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8'))]
        return sources[0][bytes.fromhex('75726c').decode('utf-8')] if sources else bytes.fromhex('').decode('utf-8')

    def resolve_source(lIl, url, referer=None, label=bytes.fromhex('').decode('utf-8')):
        llI = lIl.absolute(url)
        if lIl.is_site_page(llI):
            lI = lIl.fetch_iframe(llI, referer=referer)
            if lI:
                return lIl.extractor.resolve(lI, llI, label)
        return lIl.extractor.resolve(llI, referer, label)

    def absolute(lIl, url):
        return parsers.fix_url(url, lIl.base_url)

    def is_site_page(lIl, url):
        Il = urlparse(url or bytes.fromhex('').decode('utf-8')).netloc.lower()
        I = urlparse(lIl.base_url).netloc.lower()
        return Il == I and bytes.fromhex('2f706c617965722f').decode('utf-8') not in (url or bytes.fromhex('').decode('utf-8'))

    @staticmethod
    def is_episode_url(url):
        return bool(re.search(bytes.fromhex('283f3a5c642b2d73657a6f6e2d5c642b2d626f6c756d7c5c642b785c642b7c626f6c756d283f3a2d7c242929').decode('utf-8'), url or bytes.fromhex('').decode('utf-8'), re.I))

    @staticmethod
    def sort_episodes(episodes):
        return sorted(episodes or [], key=lambda item: (item.get(bytes.fromhex('736561736f6e').decode('utf-8')) or 0, item.get(bytes.fromhex('657069736f6465').decode('utf-8')) or 0, item.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')))
