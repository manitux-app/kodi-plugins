from __future__ import absolute_import, unicode_literals
import json
import re
import manituxhttp
try:
    from urllib.parse import quote, urljoin, urlparse
except ImportError:
    from urllib import quote
    from urlparse import urljoin, urlparse
from . import parsers

class DiziMomExtractor(object):
    CLIENT_IDENTIFIERS = (bytes.fromhex('636c6f756473637261706572').decode('utf-8'), bytes.fromhex('6368726f6d655f313434').decode('utf-8'))

    def __init__(self, user_agent, main_url):
        self.user_agent = user_agent
        self.main_url = main_url.rstrip(bytes.fromhex('2f').decode('utf-8'))
        self.session = manituxhttp.Session(client_identifier=self.CLIENT_IDENTIFIERS[0])

    def resolve(self, url, referer=None, label=bytes.fromhex('').decode('utf-8')):
        if not url:
            return (None, [])
        url = self.normalize_url(url)
        page = self.fetch(url, referer or self.main_url + bytes.fromhex('2f').decode('utf-8'))
        j10 = parsers.parse_iframe(page, self.main_url)
        if not j10:
            source, IlIllIIllllIlllIIIlIlllIll = self.extract_jwplayer(page, self.origin(url))
            return (source + self.kodi_headers(url) if source else None, IlIllIIllllIlllIIIlIlllIll)
        j10 = self.normalize_url(j10)
        if self.is_youtube(j10):
            return (j10 + self.kodi_headers(referer), [])
        if bytes.fromhex('686473747265616d61626c652e636f6d').decode('utf-8') in urlparse(j10).netloc.lower() or bytes.fromhex('6864706c6179657273797374656d2e636f6d').decode('utf-8') in urlparse(j10).netloc.lower():
            return self.resolve_fireplayer(j10, url)
        if bytes.fromhex('766964656f736579726564').decode('utf-8') in urlparse(j10).netloc.lower():
            return self.resolve_videoseyred(j10)
        FDAKCuQUVicnCPYApXoHGJKWPlsEFdGtvktbCNeATnWPKKdRUusTMOICNouVkXONMtJnbYSczCJnrvz11 = self.fetch(j10, self.main_url + bytes.fromhex('2f').decode('utf-8'))
        source = self.resolve_fetch_stream(FDAKCuQUVicnCPYApXoHGJKWPlsEFdGtvktbCNeATnWPKKdRUusTMOICNouVkXONMtJnbYSczCJnrvz11, j10)
        if not source:
            source = self._first(bytes.fromhex('66696c655c732a3a5c732a5b22275d285b5e22275d2b29').decode('utf-8'), FDAKCuQUVicnCPYApXoHGJKWPlsEFdGtvktbCNeATnWPKKdRUusTMOICNouVkXONMtJnbYSczCJnrvz11)
        if not source:
            source, IlIllIIllllIlllIIIlIlllIll = self.extract_jwplayer(FDAKCuQUVicnCPYApXoHGJKWPlsEFdGtvktbCNeATnWPKKdRUusTMOICNouVkXONMtJnbYSczCJnrvz11, self.origin(j10))
        else:
            IlIllIIllllIlllIIIlIlllIll = self.parse_subtitles(FDAKCuQUVicnCPYApXoHGJKWPlsEFdGtvktbCNeATnWPKKdRUusTMOICNouVkXONMtJnbYSczCJnrvz11)
        if not source:
            source = self._first(bytes.fromhex('68747470733f3a2f2f5b5e5c7322273c3e5d2b3f5c2e283f3a6d3375387c6d703429283f3a5c3f5b5e5c7322273c3e5d2a293f').decode('utf-8'), FDAKCuQUVicnCPYApXoHGJKWPlsEFdGtvktbCNeATnWPKKdRUusTMOICNouVkXONMtJnbYSczCJnrvz11)
        return (self.normalize_url(source) + self.kodi_headers(j10, {bytes.fromhex('4f726967696e').decode('utf-8'): self.origin(j10)}) if source else None, IlIllIIllllIlllIIIlIlllIll)

    def resolve_fireplayer(self, url, page_url):
        video_id = self._first(bytes.fromhex('2f283f3a766964656f7c656d626564292f285b5e2f3f235d2b29').decode('utf-8'), url)
        if not video_id:
            return (None, [])
        a = url.split(bytes.fromhex('3f').decode('utf-8'), 1)[0].rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('3f646f3d676574566964656f').decode('utf-8')
        EEEE = bytes.fromhex('686173683d7b307d26723d7b317d26733d').decode('utf-8').format(quote(video_id), quote(page_url or self.main_url + bytes.fromhex('2f').decode('utf-8'))).encode(bytes.fromhex('7574662d38').decode('utf-8'))
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): self.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('2a2f2a').decode('utf-8'), bytes.fromhex('436f6e74656e742d54797065').decode('utf-8'): bytes.fromhex('6170706c69636174696f6e2f782d7777772d666f726d2d75726c656e636f6465643b20636861727365743d5554462d38').decode('utf-8'), bytes.fromhex('52656665726572').decode('utf-8'): url, bytes.fromhex('4f726967696e').decode('utf-8'): self.origin(url), bytes.fromhex('582d5265717565737465642d57697468').decode('utf-8'): bytes.fromhex('584d4c4874747052657175657374').decode('utf-8')}
        bbbbbbbbbbbbbbbbbbbbbbbb = self.session.post(a, data=EEEE, headers=headers, timeout=25, allow_redirects=True, tls_client_identifier=bytes.fromhex('6368726f6d655f313434').decode('utf-8'))
        bbbbbbbbbbbbbbbbbbbbbbbb.raise_for_status()
        try:
            CqnHXbEhMoOXgyNaPoUkNdUDLaPcCCuPtnznjLYtNPdPMmXnAumoipctFQyXkTVBGRTxwFaMzetxjNI20 = json.loads(bbbbbbbbbbbbbbbbbbbbbbbb.text)
        except Exception:
            CqnHXbEhMoOXgyNaPoUkNdUDLaPcCCuPtnznjLYtNPdPMmXnAumoipctFQyXkTVBGRTxwFaMzetxjNI20 = {}
        source = CqnHXbEhMoOXgyNaPoUkNdUDLaPcCCuPtnznjLYtNPdPMmXnAumoipctFQyXkTVBGRTxwFaMzetxjNI20.get(bytes.fromhex('736563757265644c696e6b').decode('utf-8')) or CqnHXbEhMoOXgyNaPoUkNdUDLaPcCCuPtnznjLYtNPdPMmXnAumoipctFQyXkTVBGRTxwFaMzetxjNI20.get(bytes.fromhex('766964656f536f75726365').decode('utf-8')) or CqnHXbEhMoOXgyNaPoUkNdUDLaPcCCuPtnznjLYtNPdPMmXnAumoipctFQyXkTVBGRTxwFaMzetxjNI20.get(bytes.fromhex('766964656f537263').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        for b12 in CqnHXbEhMoOXgyNaPoUkNdUDLaPcCCuPtnznjLYtNPdPMmXnAumoipctFQyXkTVBGRTxwFaMzetxjNI20.get(bytes.fromhex('766964656f536f7572636573').decode('utf-8')) or []:
            if b12.get(bytes.fromhex('66696c65').decode('utf-8')):
                source = b12[bytes.fromhex('66696c65').decode('utf-8')]
                break
        ifwydAAQSnokiXNUuqlPADkCmEYaltaNXHLgeRBnTaAWmAcrjVnithlyCBuTZDRIIAfZxdgbeefJYCP27 = []
        for b12 in CqnHXbEhMoOXgyNaPoUkNdUDLaPcCCuPtnznjLYtNPdPMmXnAumoipctFQyXkTVBGRTxwFaMzetxjNI20.get(bytes.fromhex('747261636b73').decode('utf-8')) or []:
            if b12.get(bytes.fromhex('66696c65').decode('utf-8')):
                ifwydAAQSnokiXNUuqlPADkCmEYaltaNXHLgeRBnTaAWmAcrjVnithlyCBuTZDRIIAfZxdgbeefJYCP27.append(self.normalize_url(b12[bytes.fromhex('66696c65').decode('utf-8')]))
        return (self.normalize_url(source) + self.kodi_headers(url, {bytes.fromhex('4f726967696e').decode('utf-8'): self.origin(url)}) if source else None, ifwydAAQSnokiXNUuqlPADkCmEYaltaNXHLgeRBnTaAWmAcrjVnithlyCBuTZDRIIAfZxdgbeefJYCP27)

    def resolve_fetch_stream(self, page, iframe_url):
        path = bytes.fromhex('').decode('utf-8')
        for aaAaA in re.findall(bytes.fromhex('66657463685c285c732a5b22275d285b5e22275d2b295b22275d').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.I):
            if bytes.fromhex('2f646c3f6f703d6765745f73747265616d').decode('utf-8') in aaAaA:
                path = aaAaA
                break
        if not path:
            return bytes.fromhex('').decode('utf-8')
        IIIlIlIlllllIlllIIlIllIIl = urljoin(self.origin(iframe_url) + bytes.fromhex('2f').decode('utf-8'), path.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')))
        data = self.fetch_stream_json(IIIlIlIlllllIlllIIlIllIIl, iframe_url, page)
        return (data.get(bytes.fromhex('75726c').decode('utf-8')) or bytes.fromhex('').decode('utf-8')).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')) if isinstance(data, dict) else bytes.fromhex('').decode('utf-8')

    def fetch_stream_json(self, url, referer, page):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): self.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('2a2f2a').decode('utf-8'), bytes.fromhex('52656665726572').decode('utf-8'): referer, bytes.fromhex('4f726967696e').decode('utf-8'): self.origin(referer), bytes.fromhex('582d5265717565737465642d57697468').decode('utf-8'): bytes.fromhex('584d4c4874747052657175657374').decode('utf-8'), bytes.fromhex('5365632d46657463682d53697465').decode('utf-8'): bytes.fromhex('73616d652d6f726967696e').decode('utf-8'), bytes.fromhex('5365632d46657463682d4d6f6465').decode('utf-8'): bytes.fromhex('636f7273').decode('utf-8'), bytes.fromhex('5365632d46657463682d44657374').decode('utf-8'): bytes.fromhex('656d707479').decode('utf-8')}
        lIIlll = self.parse_js_cookies(page)
        if lIIlll:
            headers[bytes.fromhex('436f6f6b6965').decode('utf-8')] = lIIlll
        TTTTTTTTTTTTTTT = None
        for xUaUzVCDHRAUuyVmjQxmtDxuGlEnAmqlTBrZwwfLEdtObnkEGIKLzLNRFCsKctjAsdazZrWxIkXacXn9 in (bytes.fromhex('6368726f6d655f313434').decode('utf-8'), bytes.fromhex('636c6f756473637261706572').decode('utf-8')):
            try:
                bbbbbbbbbbbbbbbbbbbbbbbb = self.session.get(url, headers=headers, timeout=25, allow_redirects=True, tls_client_identifier=xUaUzVCDHRAUuyVmjQxmtDxuGlEnAmqlTBrZwwfLEdtObnkEGIKLzLNRFCsKctjAsdazZrWxIkXacXn9)
                bbbbbbbbbbbbbbbbbbbbbbbb.raise_for_status()
                data = json.loads(bbbbbbbbbbbbbbbbbbbbbbbb.text)
                if data.get(bytes.fromhex('75726c').decode('utf-8')):
                    return data
                TTTTTTTTTTTTTTT = manituxhttp.HTTPError(bbbbbbbbbbbbbbbbbbbbbbbb)
            except (ValueError, manituxhttp.HTTPError, manituxhttp.RequestError) as exc:
                TTTTTTTTTTTTTTT = exc
        if TTTTTTTTTTTTTTT:
            raise TTTTTTTTTTTTTTT
        return {}

    @staticmethod
    def parse_js_cookies(page):
        lIIlll = []
        for HMoMgttewqaZcYIGLZMBNmaYblfJbbHUDehvlvmkEjkQQMJDiEdpDbkwGNbEIMbGUUmrmjCshVUPjhD17, value in re.findall(bytes.fromhex('5c245c2e636f6f6b69655c285b22275d285b5e22275d2b295b22275d5c732a2c5c732a5b22275d285b5e22275d2b29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.I):
            lIIlll.append(bytes.fromhex('7b307d3d7b317d').decode('utf-8').format(HMoMgttewqaZcYIGLZMBNmaYblfJbbHUDehvlvmkEjkQQMJDiEdpDbkwGNbEIMbGUUmrmjCshVUPjhD17, value))
        return bytes.fromhex('3b20').decode('utf-8').join(lIIlll)

    def resolve_videoseyred(self, url):
        video_id = self._first(bytes.fromhex('2f656d6265642f285b5e2f3f235d2b29').decode('utf-8'), url)
        if not video_id:
            return (None, [])
        TTTTTTTTTTTTTTTTTTTTTT = self.origin(url) + bytes.fromhex('2f706c61796c6973742f').decode('utf-8') + video_id + bytes.fromhex('2e6a736f6e').decode('utf-8')
        CqnHXbEhMoOXgyNaPoUkNdUDLaPcCCuPtnznjLYtNPdPMmXnAumoipctFQyXkTVBGRTxwFaMzetxjNI20 = self.fetch(TTTTTTTTTTTTTTTTTTTTTT, self.origin(url) + bytes.fromhex('2f').decode('utf-8'))
        try:
            M21 = json.loads(CqnHXbEhMoOXgyNaPoUkNdUDLaPcCCuPtnznjLYtNPdPMmXnAumoipctFQyXkTVBGRTxwFaMzetxjNI20)
        except Exception:
            M21 = []
        b12 = M21[0] if M21 else {}
        sources = b12.get(bytes.fromhex('736f7572636573').decode('utf-8')) or []
        source = bytes.fromhex('').decode('utf-8')
        for aaAaA in sources:
            source = aaAaA.get(bytes.fromhex('66696c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
            if source:
                break
        ifwydAAQSnokiXNUuqlPADkCmEYaltaNXHLgeRBnTaAWmAcrjVnithlyCBuTZDRIIAfZxdgbeefJYCP27 = []
        for sxTXkNkvuEemySZjgqrjDAgaVVqEbxMFWsyvWNYxXlsgzevFkZZeXwsyJZvzGAaLAooTDWHMbSxphXc28 in b12.get(bytes.fromhex('747261636b73').decode('utf-8')) or []:
            if (sxTXkNkvuEemySZjgqrjDAgaVVqEbxMFWsyvWNYxXlsgzevFkZZeXwsyJZvzGAaLAooTDWHMbSxphXc28.get(bytes.fromhex('6b696e64').decode('utf-8')) or bytes.fromhex('').decode('utf-8')).lower() == bytes.fromhex('63617074696f6e73').decode('utf-8') and sxTXkNkvuEemySZjgqrjDAgaVVqEbxMFWsyvWNYxXlsgzevFkZZeXwsyJZvzGAaLAooTDWHMbSxphXc28.get(bytes.fromhex('66696c65').decode('utf-8')):
                ifwydAAQSnokiXNUuqlPADkCmEYaltaNXHLgeRBnTaAWmAcrjVnithlyCBuTZDRIIAfZxdgbeefJYCP27.append(urljoin(self.origin(url) + bytes.fromhex('2f').decode('utf-8'), sxTXkNkvuEemySZjgqrjDAgaVVqEbxMFWsyvWNYxXlsgzevFkZZeXwsyJZvzGAaLAooTDWHMbSxphXc28[bytes.fromhex('66696c65').decode('utf-8')]))
        return (source + self.kodi_headers(self.origin(url) + bytes.fromhex('2f').decode('utf-8')) if source else None, ifwydAAQSnokiXNUuqlPADkCmEYaltaNXHLgeRBnTaAWmAcrjVnithlyCBuTZDRIIAfZxdgbeefJYCP27)

    def extract_jwplayer(self, page, base_url):
        source = bytes.fromhex('').decode('utf-8')
        IlIllIIllllIlllIIIlIlllIll = []
        for IlIIllIIllIlIIIllIIlIII in re.findall(bytes.fromhex('5b22275d3f736f75726365735b22275d3f5c732a3a5c732a285c5b2e2a3f5c5d29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            for b12 in self._parse_js_list(IlIIllIIllIlIIIllIIlIII):
                source = b12.get(bytes.fromhex('66696c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
                if source:
                    source = urljoin(base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8'), source.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')))
                    break
            if source:
                break
        for IlIIllIIllIlIIIllIIlIII in re.findall(bytes.fromhex('5b22275d3f747261636b735b22275d3f5c732a3a5c732a285c5b2e2a3f5c5d29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            for b12 in self._parse_js_list(IlIIllIIllIlIIIllIIlIII):
                Q14 = (b12.get(bytes.fromhex('6b696e64').decode('utf-8')) or bytes.fromhex('').decode('utf-8')).lower()
                lIllllI = b12.get(bytes.fromhex('66696c65').decode('utf-8'))
                if lIllllI and (bytes.fromhex('63617074696f6e').decode('utf-8') in Q14 or bytes.fromhex('7375627469746c65').decode('utf-8') in Q14):
                    IlIllIIllllIlllIIIlIlllIll.append(urljoin(base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8'), lIllllI.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'))))
        return (source, list(dict.fromkeys(IlIllIIllllIlllIIIlIlllIll)))

    def parse_subtitles(self, page):
        ifwydAAQSnokiXNUuqlPADkCmEYaltaNXHLgeRBnTaAWmAcrjVnithlyCBuTZDRIIAfZxdgbeefJYCP27 = []
        IlIIllIIllIlIIIllIIlIII = self._first(bytes.fromhex('227375627469746c65225c732a3a5c732a22285b5e225d2b2922').decode('utf-8'), page)
        for b12 in [n484739144149129.strip() for n484739144149129 in IlIIllIIllIlIIIllIIlIII.split(bytes.fromhex('2c').decode('utf-8')) if n484739144149129.strip()]:
            url = re.sub(bytes.fromhex('5c5b5b5e5c5d5d2b5c5d').decode('utf-8'), bytes.fromhex('').decode('utf-8'), b12).strip()
            if url:
                ifwydAAQSnokiXNUuqlPADkCmEYaltaNXHLgeRBnTaAWmAcrjVnithlyCBuTZDRIIAfZxdgbeefJYCP27.append(self.normalize_url(url))
        if ifwydAAQSnokiXNUuqlPADkCmEYaltaNXHLgeRBnTaAWmAcrjVnithlyCBuTZDRIIAfZxdgbeefJYCP27:
            return ifwydAAQSnokiXNUuqlPADkCmEYaltaNXHLgeRBnTaAWmAcrjVnithlyCBuTZDRIIAfZxdgbeefJYCP27
        for subtitle in re.findall(bytes.fromhex('5b22275d66696c655b22275d5c732a3a5c732a5b22275d285b5e22275d2b295b22275d5b5e7b7d5d2b5b22275d6b696e645b22275d5c732a3a5c732a5b22275d63617074696f6e735b22275d').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            ifwydAAQSnokiXNUuqlPADkCmEYaltaNXHLgeRBnTaAWmAcrjVnithlyCBuTZDRIIAfZxdgbeefJYCP27.append(self.normalize_url(subtitle.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'))))
        return list(dict.fromkeys(ifwydAAQSnokiXNUuqlPADkCmEYaltaNXHLgeRBnTaAWmAcrjVnithlyCBuTZDRIIAfZxdgbeefJYCP27))

    def fetch(self, url, referer=None):
        TTTTTTTTTTTTTTT = None
        for xUaUzVCDHRAUuyVmjQxmtDxuGlEnAmqlTBrZwwfLEdtObnkEGIKLzLNRFCsKctjAsdazZrWxIkXacXn9 in self.CLIENT_IDENTIFIERS:
            if self.session.client_identifier != xUaUzVCDHRAUuyVmjQxmtDxuGlEnAmqlTBrZwwfLEdtObnkEGIKLzLNRFCsKctjAsdazZrWxIkXacXn9:
                self.session = manituxhttp.Session(client_identifier=xUaUzVCDHRAUuyVmjQxmtDxuGlEnAmqlTBrZwwfLEdtObnkEGIKLzLNRFCsKctjAsdazZrWxIkXacXn9)
            try:
                bbbbbbbbbbbbbbbbbbbbbbbb = self.session.get(url, headers=self.headers(referer), timeout=25, allow_redirects=True, tls_client_identifier=xUaUzVCDHRAUuyVmjQxmtDxuGlEnAmqlTBrZwwfLEdtObnkEGIKLzLNRFCsKctjAsdazZrWxIkXacXn9)
                if bbbbbbbbbbbbbbbbbbbbbbbb.status_code in (403, 429) and xUaUzVCDHRAUuyVmjQxmtDxuGlEnAmqlTBrZwwfLEdtObnkEGIKLzLNRFCsKctjAsdazZrWxIkXacXn9 != self.CLIENT_IDENTIFIERS[-1]:
                    TTTTTTTTTTTTTTT = manituxhttp.HTTPError(bbbbbbbbbbbbbbbbbbbbbbbb)
                    continue
                bbbbbbbbbbbbbbbbbbbbbbbb.raise_for_status()
                return bbbbbbbbbbbbbbbbbbbbbbbb.text
            except (manituxhttp.HTTPError, manituxhttp.RequestError) as exc:
                TTTTTTTTTTTTTTT = exc
                if xUaUzVCDHRAUuyVmjQxmtDxuGlEnAmqlTBrZwwfLEdtObnkEGIKLzLNRFCsKctjAsdazZrWxIkXacXn9 == self.CLIENT_IDENTIFIERS[-1]:
                    raise
        raise TTTTTTTTTTTTTTT

    def headers(self, referer=None):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): self.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('746578742f68746d6c2c6170706c69636174696f6e2f7868746d6c2b786d6c2c6170706c69636174696f6e2f786d6c3b713d302e392c2a2f2a3b713d302e38').decode('utf-8')}
        if referer:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        return headers

    def kodi_headers(self, referer=None, extra=None):
        Aa = [bytes.fromhex('557365722d4167656e743d').decode('utf-8') + quote(self.user_agent)]
        if referer:
            Aa.append(bytes.fromhex('526566657265723d').decode('utf-8') + quote(referer))
        if extra:
            Aa.extend((bytes.fromhex('7b307d3d7b317d').decode('utf-8').format(B751966529441213, quote(value)) for B751966529441213, value in extra.items() if value))
        return bytes.fromhex('7c').decode('utf-8') + bytes.fromhex('26').decode('utf-8').join(Aa)

    def normalize_url(self, url):
        if not url:
            return bytes.fromhex('').decode('utf-8')
        url = url.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')).replace(bytes.fromhex('5c7530303236').decode('utf-8'), bytes.fromhex('26').decode('utf-8'))
        if url.startswith(bytes.fromhex('2f2f').decode('utf-8')):
            return bytes.fromhex('68747470733a').decode('utf-8') + url
        if url.startswith(bytes.fromhex('7777772e').decode('utf-8')):
            return bytes.fromhex('68747470733a2f2f').decode('utf-8') + url
        if not url.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8'))):
            return urljoin(self.main_url + bytes.fromhex('2f').decode('utf-8'), url)
        return url

    @staticmethod
    def is_youtube(url):
        aAAAAaaa = urlparse(url or bytes.fromhex('').decode('utf-8')).netloc.lower()
        return bytes.fromhex('796f7574756265').decode('utf-8') in aAAAAaaa or bytes.fromhex('796f7574752e6265').decode('utf-8') in aAAAAaaa

    @staticmethod
    def origin(url):
        NNNNNNNNNNNNNNNNNNN = urlparse(url)
        return NNNNNNNNNNNNNNNNNNN.scheme + bytes.fromhex('3a2f2f').decode('utf-8') + NNNNNNNNNNNNNNNNNNN.netloc

    @staticmethod
    def _parse_js_list(value):
        aaAaaAaaAaAAaaaaaa = value.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'))
        aaAaaAaaAaAAaaaaaa = re.sub(bytes.fromhex('285b7b2c5d5c732a292866696c657c6c6162656c7c747970657c6b696e64295c732a3a').decode('utf-8'), bytes.fromhex('5c31225c32223a').decode('utf-8'), aaAaaAaaAaAAaaaaaa)
        aaAaaAaaAaAAaaaaaa = aaAaaAaaAaAAaaaaaa.replace(bytes.fromhex('27').decode('utf-8'), bytes.fromhex('22').decode('utf-8'))
        aaAaaAaaAaAAaaaaaa = re.sub(bytes.fromhex('2c5c732a285b5c5d7d5d29').decode('utf-8'), bytes.fromhex('5c31').decode('utf-8'), aaAaaAaaAaAAaaaaaa)
        try:
            data = json.loads(aaAaaAaaAaAAaaaaaa)
            return data if isinstance(data, list) else []
        except Exception:
            items = []
            for B56257958954153 in re.findall(bytes.fromhex('5c7b282e2a3f295c7d').decode('utf-8'), value, re.S):
                b12 = {}
                for B751966529441213 in (bytes.fromhex('66696c65').decode('utf-8'), bytes.fromhex('6c6162656c').decode('utf-8'), bytes.fromhex('74797065').decode('utf-8'), bytes.fromhex('6b696e64').decode('utf-8')):
                    b12[B751966529441213] = DiziMomExtractor._first(bytes.fromhex('5b22275d3f25735b22275d3f5c732a3a5c732a5b22275d285b5e22275d2b29').decode('utf-8') % B751966529441213, B56257958954153)
                items.append(b12)
            return items

    @staticmethod
    def _first(pattern, text, flags=0):
        JJJJJJJJJJJJJJJJ = re.search(pattern, text or bytes.fromhex('').decode('utf-8'), flags | re.I)
        if not JJJJJJJJJJJJJJJJ:
            return bytes.fromhex('').decode('utf-8')
        return JJJJJJJJJJJJJJJJ.group(1) if JJJJJJJJJJJJJJJJ.lastindex else JJJJJJJJJJJJJJJJ.group(0)
