from __future__ import absolute_import, unicode_literals
import manituxhttp
try:
    from urllib.parse import quote_plus
except ImportError:
    from urllib import quote_plus
from .extractor import DiziMomExtractor
from . import parsers

class DiziMomSite(object):
    CLIENT_IDENTIFIERS = (bytes.fromhex('636c6f756473637261706572').decode('utf-8'), bytes.fromhex('6368726f6d655f313434').decode('utf-8'))
    ARCHIVE_PATH = bytes.fromhex('2f74756d2d64697a696c65722d6864312f').decode('utf-8')

    def __init__(self, base_url, user_agent):
        self.base_url = base_url.rstrip(bytes.fromhex('2f').decode('utf-8'))
        self.user_agent = user_agent
        self.session = manituxhttp.Session(client_identifier=self.CLIENT_IDENTIFIERS[0])
        self.extractor = DiziMomExtractor(user_agent, self.base_url)

    def headers(self, referer=None, ajax=False):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): self.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('746578742f68746d6c2c6170706c69636174696f6e2f7868746d6c2b786d6c2c6170706c69636174696f6e2f786d6c3b713d302e392c696d6167652f617669662c696d6167652f776562702c696d6167652f61706e672c2a2f2a3b713d302e38').decode('utf-8'), bytes.fromhex('4163636570742d4c616e6775616765').decode('utf-8'): bytes.fromhex('74722d54522c74723b713d302e392c656e2d55533b713d302e382c656e3b713d302e37').decode('utf-8')}
        if referer:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        if ajax:
            headers[bytes.fromhex('582d5265717565737465642d57697468').decode('utf-8')] = bytes.fromhex('584d4c4874747052657175657374').decode('utf-8')
            headers[bytes.fromhex('4f726967696e').decode('utf-8')] = self.base_url
        return headers

    def categories(self):
        page = self.get(self.base_url + self.ARCHIVE_PATH, referer=self.base_url + bytes.fromhex('2f').decode('utf-8'))
        return parsers.categories(page, self.base_url)

    def get(self, url, referer=None):
        return self._get(self.absolute(url), self.headers(referer)).text

    def get_page_items(self, category_url, page_number=1):
        page = self.get(parsers.page_url(category_url, page_number), referer=self.base_url + bytes.fromhex('2f').decode('utf-8'))
        return parsers.parse_page_items(page, self.base_url)

    def search(self, query):
        page = self.get(self.search_url(query), referer=self.base_url + bytes.fromhex('2f').decode('utf-8'))
        return parsers.parse_page_items(page, self.base_url, bytes.fromhex('4172616d61').decode('utf-8'))

    def detail(self, url):
        page = self.get(url, referer=self.base_url + bytes.fromhex('2f').decode('utf-8'))
        y35864281758492 = parsers.parse_media_info(page, url, self.base_url)
        y35864281758492[bytes.fromhex('657069736f646573').decode('utf-8')] = self.sort_episodes(y35864281758492.get(bytes.fromhex('657069736f646573').decode('utf-8')) or [])
        if self.is_series_page(url) and (not self.is_episode_page(url)):
            y35864281758492[bytes.fromhex('736f7572636573').decode('utf-8')] = [source for source in y35864281758492.get(bytes.fromhex('736f7572636573').decode('utf-8'), []) if source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8'))]
        return y35864281758492

    def resolve_source(self, url, referer=None, label=bytes.fromhex('').decode('utf-8')):
        return self.extractor.resolve(self.absolute(url), referer or self.base_url + bytes.fromhex('2f').decode('utf-8'), label)

    def absolute(self, url):
        return parsers.fix_url(url, self.base_url)

    def search_url(self, query):
        return self.base_url + bytes.fromhex('2f3f733d').decode('utf-8') + quote_plus(query)

    @staticmethod
    def is_series_page(url):
        return bytes.fromhex('2f64697a692f').decode('utf-8') in (url or bytes.fromhex('').decode('utf-8')).lower()

    @staticmethod
    def is_episode_page(url):
        AAAaa = (url or bytes.fromhex('').decode('utf-8')).lower()
        return bytes.fromhex('2f626f6c756d2f').decode('utf-8') in AAAaa or bytes.fromhex('2f73657a6f6e').decode('utf-8') in AAAaa

    @staticmethod
    def sort_episodes(episodes):
        return sorted(episodes or [], key=lambda lII: (int(lII.get(bytes.fromhex('736561736f6e').decode('utf-8')) or 0), int(lII.get(bytes.fromhex('657069736f6465').decode('utf-8')) or 0), lII.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')))

    def _get(self, url, headers):
        B93328543894614 = None
        for a in self.CLIENT_IDENTIFIERS:
            if self.session.client_identifier != a:
                self.session = manituxhttp.Session(client_identifier=a)
            try:
                AAAaAa = self.session.get(url, headers=headers, timeout=25, allow_redirects=True, tls_client_identifier=a)
                if AAAaAa.status_code in (403, 429) and a != self.CLIENT_IDENTIFIERS[-1]:
                    B93328543894614 = manituxhttp.HTTPError(AAAaAa)
                    continue
                AAAaAa.raise_for_status()
                return AAAaAa
            except (manituxhttp.HTTPError, manituxhttp.RequestError) as exc:
                B93328543894614 = exc
                if a == self.CLIENT_IDENTIFIERS[-1]:
                    raise
        raise B93328543894614
