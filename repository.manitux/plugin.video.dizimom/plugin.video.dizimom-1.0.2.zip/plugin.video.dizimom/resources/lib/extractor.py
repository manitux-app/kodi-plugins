from __future__ import absolute_import, unicode_literals
import json
import re
import manituxhttp
try:
    from urllib.parse import quote, urljoin, urlparse
except ImportError:
    from urllib import quote
    from urlparse import urljoin, urlparse
from . import parsers

class DiziMomExtractor(object):
    CLIENT_IDENTIFIERS = (bytes.fromhex('636c6f756473637261706572').decode('utf-8'), bytes.fromhex('6368726f6d655f313434').decode('utf-8'))

    def __init__(lllI, user_agent, main_url):
        lllI.user_agent = user_agent
        lllI.main_url = main_url.rstrip(bytes.fromhex('2f').decode('utf-8'))
        lllI.session = manituxhttp.Session(client_identifier=lllI.CLIENT_IDENTIFIERS[0])

    def resolve(lllI, url, referer=None, label=bytes.fromhex('').decode('utf-8')):
        if not url:
            return (None, [])
        url = lllI.normalize_url(url)
        page = lllI.fetch(url, referer or lllI.main_url + bytes.fromhex('2f').decode('utf-8'))
        lIl = parsers.parse_iframe(page, lllI.main_url)
        if not lIl:
            source, IIIII = lllI.extract_jwplayer(page, lllI.origin(url))
            return (source + lllI.kodi_headers(url) if source else None, IIIII)
        lIl = lllI.normalize_url(lIl)
        if lllI.is_youtube(lIl):
            return (lIl + lllI.kodi_headers(referer), [])
        if bytes.fromhex('686473747265616d61626c652e636f6d').decode('utf-8') in urlparse(lIl).netloc.lower() or bytes.fromhex('6864706c6179657273797374656d2e636f6d').decode('utf-8') in urlparse(lIl).netloc.lower():
            return lllI.resolve_fireplayer(lIl, url)
        if bytes.fromhex('766964656f736579726564').decode('utf-8') in urlparse(lIl).netloc.lower():
            return lllI.resolve_videoseyred(lIl)
        llI = lllI.fetch(lIl, lllI.main_url + bytes.fromhex('2f').decode('utf-8'))
        source = lllI.resolve_fetch_stream(llI, lIl)
        if not source:
            source = lllI._first(bytes.fromhex('66696c655c732a3a5c732a5b22275d285b5e22275d2b29').decode('utf-8'), llI)
        if not source:
            source, IIIII = lllI.extract_jwplayer(llI, lllI.origin(lIl))
        else:
            IIIII = lllI.parse_subtitles(llI)
        if not source:
            source = lllI._first(bytes.fromhex('68747470733f3a2f2f5b5e5c7322273c3e5d2b3f5c2e283f3a6d3375387c6d703429283f3a5c3f5b5e5c7322273c3e5d2a293f').decode('utf-8'), llI)
        return (lllI.normalize_url(source) + lllI.kodi_headers(lIl, {bytes.fromhex('4f726967696e').decode('utf-8'): lllI.origin(lIl)}) if source else None, IIIII)

    def resolve_fireplayer(lllI, url, page_url):
        IIlIl = lllI._first(bytes.fromhex('2f283f3a766964656f7c656d626564292f285b5e2f3f235d2b29').decode('utf-8'), url)
        if not IIlIl:
            return (None, [])
        I = url.split(bytes.fromhex('3f').decode('utf-8'), 1)[0].rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('3f646f3d676574566964656f').decode('utf-8')
        Il = bytes.fromhex('686173683d7b307d26723d7b317d26733d').decode('utf-8').format(quote(IIlIl), quote(page_url or lllI.main_url + bytes.fromhex('2f').decode('utf-8'))).encode(bytes.fromhex('7574662d38').decode('utf-8'))
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): lllI.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('2a2f2a').decode('utf-8'), bytes.fromhex('436f6e74656e742d54797065').decode('utf-8'): bytes.fromhex('6170706c69636174696f6e2f782d7777772d666f726d2d75726c656e636f6465643b20636861727365743d5554462d38').decode('utf-8'), bytes.fromhex('52656665726572').decode('utf-8'): url, bytes.fromhex('4f726967696e').decode('utf-8'): lllI.origin(url), bytes.fromhex('582d5265717565737465642d57697468').decode('utf-8'): bytes.fromhex('584d4c4874747052657175657374').decode('utf-8')}
        llIl = lllI.session.post(I, data=Il, headers=headers, timeout=25, allow_redirects=True, tls_client_identifier=bytes.fromhex('6368726f6d655f313434').decode('utf-8'))
        llIl.raise_for_status()
        try:
            lIIl = json.loads(llIl.text)
        except Exception:
            lIIl = {}
        source = lIIl.get(bytes.fromhex('736563757265644c696e6b').decode('utf-8')) or lIIl.get(bytes.fromhex('766964656f536f75726365').decode('utf-8')) or lIIl.get(bytes.fromhex('766964656f537263').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        for item in lIIl.get(bytes.fromhex('766964656f536f7572636573').decode('utf-8')) or []:
            if item.get(bytes.fromhex('66696c65').decode('utf-8')):
                source = item[bytes.fromhex('66696c65').decode('utf-8')]
                break
        IIIlI = []
        for item in lIIl.get(bytes.fromhex('747261636b73').decode('utf-8')) or []:
            if item.get(bytes.fromhex('66696c65').decode('utf-8')):
                IIIlI.append(lllI.normalize_url(item[bytes.fromhex('66696c65').decode('utf-8')]))
        return (lllI.normalize_url(source) + lllI.kodi_headers(url, {bytes.fromhex('4f726967696e').decode('utf-8'): lllI.origin(url)}) if source else None, IIIlI)

    def resolve_fetch_stream(lllI, page, lll):
        Illl = bytes.fromhex('').decode('utf-8')
        for lI in re.findall(bytes.fromhex('66657463685c285c732a5b22275d285b5e22275d2b295b22275d').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.I):
            if bytes.fromhex('2f646c3f6f703d6765745f73747265616d').decode('utf-8') in lI:
                Illl = lI
                break
        if not Illl:
            return bytes.fromhex('').decode('utf-8')
        llll = urljoin(lllI.origin(lll) + bytes.fromhex('2f').decode('utf-8'), Illl.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')))
        data = lllI.fetch_stream_json(llll, lll, page)
        return (data.get(bytes.fromhex('75726c').decode('utf-8')) or bytes.fromhex('').decode('utf-8')).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')) if isinstance(data, dict) else bytes.fromhex('').decode('utf-8')

    def fetch_stream_json(lllI, url, referer, page):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): lllI.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('2a2f2a').decode('utf-8'), bytes.fromhex('52656665726572').decode('utf-8'): referer, bytes.fromhex('4f726967696e').decode('utf-8'): lllI.origin(referer), bytes.fromhex('582d5265717565737465642d57697468').decode('utf-8'): bytes.fromhex('584d4c4874747052657175657374').decode('utf-8'), bytes.fromhex('5365632d46657463682d53697465').decode('utf-8'): bytes.fromhex('73616d652d6f726967696e').decode('utf-8'), bytes.fromhex('5365632d46657463682d4d6f6465').decode('utf-8'): bytes.fromhex('636f7273').decode('utf-8'), bytes.fromhex('5365632d46657463682d44657374').decode('utf-8'): bytes.fromhex('656d707479').decode('utf-8')}
        ll = lllI.parse_js_cookies(page)
        if ll:
            headers[bytes.fromhex('436f6f6b6965').decode('utf-8')] = ll
        IIlI = None
        for lII in (bytes.fromhex('6368726f6d655f313434').decode('utf-8'), bytes.fromhex('636c6f756473637261706572').decode('utf-8')):
            try:
                llIl = lllI.session.get(url, headers=headers, timeout=25, allow_redirects=True, tls_client_identifier=lII)
                llIl.raise_for_status()
                data = json.loads(llIl.text)
                if data.get(bytes.fromhex('75726c').decode('utf-8')):
                    return data
                IIlI = manituxhttp.HTTPError(llIl)
            except (ValueError, manituxhttp.HTTPError, manituxhttp.RequestError) as exc:
                IIlI = exc
        if IIlI:
            raise IIlI
        return {}

    @staticmethod
    def parse_js_cookies(page):
        ll = []
        for IlII, IIlII in re.findall(bytes.fromhex('5c245c2e636f6f6b69655c285b22275d285b5e22275d2b295b22275d5c732a2c5c732a5b22275d285b5e22275d2b29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.I):
            ll.append(bytes.fromhex('7b307d3d7b317d').decode('utf-8').format(IlII, IIlII))
        return bytes.fromhex('3b20').decode('utf-8').join(ll)

    def resolve_videoseyred(lllI, url):
        IIlIl = lllI._first(bytes.fromhex('2f656d6265642f285b5e2f3f235d2b29').decode('utf-8'), url)
        if not IIlIl:
            return (None, [])
        lIll = lllI.origin(url) + bytes.fromhex('2f706c61796c6973742f').decode('utf-8') + IIlIl + bytes.fromhex('2e6a736f6e').decode('utf-8')
        lIIl = lllI.fetch(lIll, lllI.origin(url) + bytes.fromhex('2f').decode('utf-8'))
        try:
            lIlI = json.loads(lIIl)
        except Exception:
            lIlI = []
        item = lIlI[0] if lIlI else {}
        sources = item.get(bytes.fromhex('736f7572636573').decode('utf-8')) or []
        source = bytes.fromhex('').decode('utf-8')
        for lI in sources:
            source = lI.get(bytes.fromhex('66696c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
            if source:
                break
        IIIlI = []
        for IIIll in item.get(bytes.fromhex('747261636b73').decode('utf-8')) or []:
            if (IIIll.get(bytes.fromhex('6b696e64').decode('utf-8')) or bytes.fromhex('').decode('utf-8')).lower() == bytes.fromhex('63617074696f6e73').decode('utf-8') and IIIll.get(bytes.fromhex('66696c65').decode('utf-8')):
                IIIlI.append(urljoin(lllI.origin(url) + bytes.fromhex('2f').decode('utf-8'), IIIll[bytes.fromhex('66696c65').decode('utf-8')]))
        return (source + lllI.kodi_headers(lllI.origin(url) + bytes.fromhex('2f').decode('utf-8')) if source else None, IIIlI)

    def extract_jwplayer(lllI, page, base_url):
        source = bytes.fromhex('').decode('utf-8')
        IIIII = []
        for llII in re.findall(bytes.fromhex('5b22275d3f736f75726365735b22275d3f5c732a3a5c732a285c5b2e2a3f5c5d29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            for item in lllI._parse_js_list(llII):
                source = item.get(bytes.fromhex('66696c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
                if source:
                    source = urljoin(base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8'), source.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')))
                    break
            if source:
                break
        for llII in re.findall(bytes.fromhex('5b22275d3f747261636b735b22275d3f5c732a3a5c732a285c5b2e2a3f5c5d29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            for item in lllI._parse_js_list(llII):
                IIIl = (item.get(bytes.fromhex('6b696e64').decode('utf-8')) or bytes.fromhex('').decode('utf-8')).lower()
                IIl = item.get(bytes.fromhex('66696c65').decode('utf-8'))
                if IIl and (bytes.fromhex('63617074696f6e').decode('utf-8') in IIIl or bytes.fromhex('7375627469746c65').decode('utf-8') in IIIl):
                    IIIII.append(urljoin(base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8'), IIl.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'))))
        return (source, list(dict.fromkeys(IIIII)))

    def parse_subtitles(lllI, page):
        IIIlI = []
        llII = lllI._first(bytes.fromhex('227375627469746c65225c732a3a5c732a22285b5e225d2b2922').decode('utf-8'), page)
        for item in [IIllI.strip() for IIllI in llII.split(bytes.fromhex('2c').decode('utf-8')) if IIllI.strip()]:
            url = re.sub(bytes.fromhex('5c5b5b5e5c5d5d2b5c5d').decode('utf-8'), bytes.fromhex('').decode('utf-8'), item).strip()
            if url:
                IIIlI.append(lllI.normalize_url(url))
        if IIIlI:
            return IIIlI
        for IIIIl in re.findall(bytes.fromhex('5b22275d66696c655b22275d5c732a3a5c732a5b22275d285b5e22275d2b295b22275d5b5e7b7d5d2b5b22275d6b696e645b22275d5c732a3a5c732a5b22275d63617074696f6e735b22275d').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            IIIlI.append(lllI.normalize_url(IIIIl.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'))))
        return list(dict.fromkeys(IIIlI))

    def fetch(lllI, url, referer=None):
        IIlI = None
        for lII in lllI.CLIENT_IDENTIFIERS:
            if lllI.session.client_identifier != lII:
                lllI.session = manituxhttp.Session(client_identifier=lII)
            try:
                llIl = lllI.session.get(url, headers=lllI.headers(referer), timeout=25, allow_redirects=True, tls_client_identifier=lII)
                if llIl.status_code in (403, 429) and lII != lllI.CLIENT_IDENTIFIERS[-1]:
                    IIlI = manituxhttp.HTTPError(llIl)
                    continue
                llIl.raise_for_status()
                return llIl.text
            except (manituxhttp.HTTPError, manituxhttp.RequestError) as exc:
                IIlI = exc
                if lII == lllI.CLIENT_IDENTIFIERS[-1]:
                    raise
        raise IIlI

    def headers(lllI, referer=None):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): lllI.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('746578742f68746d6c2c6170706c69636174696f6e2f7868746d6c2b786d6c2c6170706c69636174696f6e2f786d6c3b713d302e392c2a2f2a3b713d302e38').decode('utf-8')}
        if referer:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        return headers

    def kodi_headers(lllI, referer=None, III=None):
        l = [bytes.fromhex('557365722d4167656e743d').decode('utf-8') + quote(lllI.user_agent)]
        if referer:
            l.append(bytes.fromhex('526566657265723d').decode('utf-8') + quote(referer))
        if III:
            l.extend((bytes.fromhex('7b307d3d7b317d').decode('utf-8').format(IIII, quote(IIlII)) for IIII, IIlII in III.items() if IIlII))
        return bytes.fromhex('7c').decode('utf-8') + bytes.fromhex('26').decode('utf-8').join(l)

    def normalize_url(lllI, url):
        if not url:
            return bytes.fromhex('').decode('utf-8')
        url = url.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')).replace(bytes.fromhex('5c7530303236').decode('utf-8'), bytes.fromhex('26').decode('utf-8'))
        if url.startswith(bytes.fromhex('2f2f').decode('utf-8')):
            return bytes.fromhex('68747470733a').decode('utf-8') + url
        if url.startswith(bytes.fromhex('7777772e').decode('utf-8')):
            return bytes.fromhex('68747470733a2f2f').decode('utf-8') + url
        if not url.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8'))):
            return urljoin(lllI.main_url + bytes.fromhex('2f').decode('utf-8'), url)
        return url

    @staticmethod
    def is_youtube(url):
        Ill = urlparse(url or bytes.fromhex('').decode('utf-8')).netloc.lower()
        return bytes.fromhex('796f7574756265').decode('utf-8') in Ill or bytes.fromhex('796f7574752e6265').decode('utf-8') in Ill

    @staticmethod
    def origin(url):
        IllI = urlparse(url)
        return IllI.scheme + bytes.fromhex('3a2f2f').decode('utf-8') + IllI.netloc

    @staticmethod
    def _parse_js_list(IIlII):
        IlIl = IIlII.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'))
        IlIl = re.sub(bytes.fromhex('285b7b2c5d5c732a292866696c657c6c6162656c7c747970657c6b696e64295c732a3a').decode('utf-8'), bytes.fromhex('5c31225c32223a').decode('utf-8'), IlIl)
        IlIl = IlIl.replace(bytes.fromhex('27').decode('utf-8'), bytes.fromhex('22').decode('utf-8'))
        IlIl = re.sub(bytes.fromhex('2c5c732a285b5c5d7d5d29').decode('utf-8'), bytes.fromhex('5c31').decode('utf-8'), IlIl)
        try:
            data = json.loads(IlIl)
            return data if isinstance(data, list) else []
        except Exception:
            items = []
            for II in re.findall(bytes.fromhex('5c7b282e2a3f295c7d').decode('utf-8'), IIlII, re.S):
                item = {}
                for IIII in (bytes.fromhex('66696c65').decode('utf-8'), bytes.fromhex('6c6162656c').decode('utf-8'), bytes.fromhex('74797065').decode('utf-8'), bytes.fromhex('6b696e64').decode('utf-8')):
                    item[IIII] = DiziMomExtractor._first(bytes.fromhex('5b22275d3f25735b22275d3f5c732a3a5c732a5b22275d285b5e22275d2b29').decode('utf-8') % IIII, II)
                items.append(item)
            return items

    @staticmethod
    def _first(lIII, text, IlI=0):
        IIll = re.search(lIII, text or bytes.fromhex('').decode('utf-8'), IlI | re.I)
        if not IIll:
            return bytes.fromhex('').decode('utf-8')
        return IIll.group(1) if IIll.lastindex else IIll.group(0)
