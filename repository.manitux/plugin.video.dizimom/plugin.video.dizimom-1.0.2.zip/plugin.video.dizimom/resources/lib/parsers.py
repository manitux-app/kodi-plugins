from __future__ import absolute_import, unicode_literals
import html
import re
try:
    from urllib.parse import quote, urljoin
except ImportError:
    from urllib import quote
    from urlparse import urljoin

def categories(page, base_url):
    base_url = base_url.rstrip(bytes.fromhex('2f').decode('utf-8'))
    llI = Il(bytes.fromhex('3c6469765c625b5e3e5d2a69643d5b225c275d63617465676f72792d627574746f6e5b225c275d5b5e3e5d2a3e282e2a3f293c2f6469763e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S)
    lIIl = []
    IIIlI = set()
    for IlIII, title in re.findall(bytes.fromhex('3c696e7075745c625b5e3e5d2a5c6276616c75653d5b225c275d285b5e225c275d2b295b225c275d5b5e3e5d2a3e2e2a3f3c7370616e5b5e3e5d2a3e282e2a3f293c2f7370616e3e').decode('utf-8'), llI, re.S | re.I):
        IlIII = html.unescape(IlIII).strip()
        title = l(title) or IlIII
        if not IlIII or not title or IlIII in IIIlI:
            continue
        IIIlI.add(IlIII)
        lIIl.append((title, base_url + bytes.fromhex('2f74756d2d64697a696c65722d6864312f3f66696c7472656c653d696d646226736972616c613d444553432664697a69746970693d2679696c3d26696d64623d266b656c696d653d267475723d').decode('utf-8') + quote(IlIII.encode(bytes.fromhex('7574662d38').decode('utf-8')))))
    return lIIl

def page_url(IIIl, page_number):
    page_number = int(page_number)
    if page_number <= 1:
        return IIIl
    if bytes.fromhex('3f').decode('utf-8') in IIIl:
        lIl, query = IIIl.split(bytes.fromhex('3f').decode('utf-8'), 1)
        return lIl.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f706167652f7b307d2f3f').decode('utf-8').format(page_number) + query
    return IIIl.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f706167652f7b307d2f').decode('utf-8').format(page_number)

def parse_page_items(page, base_url, IIII=bytes.fromhex('').decode('utf-8')):
    lIIl = []
    IIIlI = set()
    for llI in III(page):
        IlI = Il(bytes.fromhex('3c615c625b5e3e5d2a687265663d5b275c225d5b5e275c225d2b5b275c225d5b5e3e5d2a3e').decode('utf-8'), llI, re.S)
        IlII = I(IlI, bytes.fromhex('68726566').decode('utf-8'))
        title = l(Il(bytes.fromhex('3c6469765c625b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c6263617465676f72797469746c655c625b5e225c275d2a5b225c275d5b5e3e5d2a3e2e2a3f3c615c625b5e3e5d2a3e282e2a3f293c2f613e').decode('utf-8'), llI, re.S))
        title = title or l(I(IlI, bytes.fromhex('7469746c65').decode('utf-8')) or I(Il(bytes.fromhex('3c696d675c625b5e3e5d2a3e').decode('utf-8'), llI, re.S), bytes.fromhex('616c74').decode('utf-8')))
        IIIII = IIl(llI, base_url)
        if not title or not IlII:
            continue
        url = fix_url(IlII, base_url)
        if url in IIIlI:
            continue
        IIIlI.add(url)
        lIIl.append({bytes.fromhex('63617465676f7279').decode('utf-8'): IIII, bytes.fromhex('7469746c65').decode('utf-8'): clean_title(title), bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('696d616765').decode('utf-8'): IIIII, bytes.fromhex('706c6f74').decode('utf-8'): bytes.fromhex('').decode('utf-8')})
    return lIIl

def parse_media_info(page, url, base_url):
    title = clean_title(l(Il(bytes.fromhex('3c6d61696e5c625b5e3e5d2a3e2e2a3f3c68315b5e3e5d2a3e282e2a3f293c2f68313e').decode('utf-8'), page, re.S)) or l(Il(bytes.fromhex('3c626f64795c625b5e3e5d2a3e2e2a3f3c68315b5e3e5d2a3e282e2a3f293c2f68313e').decode('utf-8'), page, re.S)) or lI(page, bytes.fromhex('70726f7065727479').decode('utf-8'), bytes.fromhex('6f673a7469746c65').decode('utf-8')))
    IIIII = lI(page, bytes.fromhex('70726f7065727479').decode('utf-8'), bytes.fromhex('6f673a696d616765').decode('utf-8')) or IIl(page, base_url)
    plot = lI(page, bytes.fromhex('70726f7065727479').decode('utf-8'), bytes.fromhex('6f673a6465736372697074696f6e').decode('utf-8')) or lI(page, bytes.fromhex('6e616d65').decode('utf-8'), bytes.fromhex('6465736372697074696f6e').decode('utf-8'))
    year = Il(bytes.fromhex('5c62285c647b347d295c62').decode('utf-8'), II(page, bytes.fromhex('596170c4b16d2059c4b16cc4b1').decode('utf-8')))
    rating = II(page, bytes.fromhex('494d4442205075616ec4b1').decode('utf-8'))
    duration = parse_duration(II(page, bytes.fromhex('53c3bc7265').decode('utf-8')))
    episodes = parse_episodes(page, base_url)
    sources = parse_video_sources(page, url, base_url, bool(episodes))
    IIlll = find_trailer_url(page, base_url)
    if IIlll:
        sources.insert(0, {bytes.fromhex('6c6162656c').decode('utf-8'): bytes.fromhex('467261676d616e').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): IIlll, bytes.fromhex('72656665726572').decode('utf-8'): url, bytes.fromhex('69735f747261696c6572').decode('utf-8'): True})
    return {bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('696d616765').decode('utf-8'): fix_url(IIIII, base_url) if IIIII else bytes.fromhex('').decode('utf-8'), bytes.fromhex('706c6f74').decode('utf-8'): l(plot), bytes.fromhex('79656172').decode('utf-8'): year, bytes.fromhex('726174696e67').decode('utf-8'): rating, bytes.fromhex('6475726174696f6e').decode('utf-8'): duration, bytes.fromhex('74616773').decode('utf-8'): ll(page, bytes.fromhex('54c3bc72').decode('utf-8')), bytes.fromhex('6163746f7273').decode('utf-8'): ll(page, bytes.fromhex('4f79756e63756c6172').decode('utf-8')), bytes.fromhex('736f7572636573').decode('utf-8'): sources, bytes.fromhex('657069736f646573').decode('utf-8'): episodes}

def parse_video_sources(page, page_url, base_url, IIlI=False):
    if IIlI:
        return []
    lIll = (page_url or bytes.fromhex('').decode('utf-8')).lower()
    if bytes.fromhex('2f64697a696c65722f').decode('utf-8') in lIll or (bytes.fromhex('2f64697a692f').decode('utf-8') in lIll and bytes.fromhex('626f6c756d').decode('utf-8') not in lIll):
        return []
    return [{bytes.fromhex('6c6162656c').decode('utf-8'): bytes.fromhex('4f796e6174').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): page_url, bytes.fromhex('72656665726572').decode('utf-8'): base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8'), bytes.fromhex('69735f747261696c6572').decode('utf-8'): False}]

def parse_episodes(page, base_url):
    episodes = []
    IIIlI = set()
    for llI in re.findall(bytes.fromhex('3c6469765c625b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c62626f6c756d7573745c625b5e225c275d2a5b225c275d5b5e3e5d2a3e2e2a3f3c2f6469763e5c732a3c2f613e5c732a3c2f6469763e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
        IlI = Il(bytes.fromhex('3c615c625b5e3e5d2a687265663d5b275c225d5b5e275c225d2b5b275c225d5b5e3e5d2a3e').decode('utf-8'), llI, re.S)
        IlII = I(IlI, bytes.fromhex('68726566').decode('utf-8'))
        title = l(Il(bytes.fromhex('3c6469765c625b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c626261736c696b5c625b5e225c275d2a5b225c275d5b5e3e5d2a3e282e2a3f293c2f6469763e').decode('utf-8'), llI, re.S))
        if not IlII:
            continue
        url = fix_url(IlII, base_url)
        if url in IIIlI:
            continue
        IIIlI.add(url)
        IIIIl = Il(bytes.fromhex('285c642b295c732a5c2e5c732a53657a6f6e').decode('utf-8'), title) or Il(bytes.fromhex('285c642b292d73657a6f6e').decode('utf-8'), IlII) or bytes.fromhex('30').decode('utf-8')
        episode = Il(bytes.fromhex('285c642b295c732a5c2e5c732a425bc3b66f5d6c5bc3bc755d6d').decode('utf-8'), title) or Il(bytes.fromhex('73657a6f6e2d285c642b292d626f6c756d').decode('utf-8'), IlII) or bytes.fromhex('30').decode('utf-8')
        episodes.append({bytes.fromhex('7469746c65').decode('utf-8'): title or bytes.fromhex('7b307d2e2053657a6f6e207b317d2e20426f6c756d').decode('utf-8').format(IIIIl, episode), bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('696d616765').decode('utf-8'): IIl(llI, base_url), bytes.fromhex('736561736f6e').decode('utf-8'): IIIIl, bytes.fromhex('657069736f6465').decode('utf-8'): episode})
    if episodes:
        return episodes
    for llI in re.findall(bytes.fromhex('3c6469765c625b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c62657069736f64652d6974656d5c625b5e225c275d2a5b225c275d5b5e3e5d2a3e2e2a3f283f3d3c6469765c625b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c62657069736f64652d6974656d5c627c2429').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
        IlI = Il(bytes.fromhex('3c615c625b5e3e5d2a687265663d5b275c225d5b5e275c225d2b5b275c225d5b5e3e5d2a3e').decode('utf-8'), llI, re.S)
        IlII = I(IlI, bytes.fromhex('68726566').decode('utf-8'))
        if not IlII:
            continue
        IIlIl = I(IlI, bytes.fromhex('7469746c65').decode('utf-8'))
        lIII = I(Il(bytes.fromhex('3c696d675c625b5e3e5d2a3e').decode('utf-8'), llI, re.S), bytes.fromhex('616c74').decode('utf-8'))
        title = l(Il(bytes.fromhex('3c68345c625b5e3e5d2a3e2e2a3f3c615c625b5e3e5d2a3e282e2a3f293c2f613e').decode('utf-8'), llI, re.S)) or lIII or IIlIl
        IIIIl = Il(bytes.fromhex('285c642b295c2e5c732a53657a6f6e').decode('utf-8'), IIlIl) or Il(bytes.fromhex('2f73657a6f6e2d3f285c642b29').decode('utf-8'), IlII) or bytes.fromhex('30').decode('utf-8')
        episode = Il(bytes.fromhex('285c642b295c2e5c732a425bc3b66f5d6c5bc3bc755d6d').decode('utf-8'), IIlIl) or Il(bytes.fromhex('2f626f6c756d2d3f285c642b29').decode('utf-8'), IlII) or bytes.fromhex('30').decode('utf-8')
        lIlI = (IIIIl, episode, IlII)
        if lIlI in IIIlI:
            continue
        IIIlI.add(lIlI)
        episodes.append({bytes.fromhex('7469746c65').decode('utf-8'): title or bytes.fromhex('7b307d2e2053657a6f6e207b317d2e20426f6c756d').decode('utf-8').format(IIIIl, episode), bytes.fromhex('75726c').decode('utf-8'): fix_url(IlII, base_url), bytes.fromhex('696d616765').decode('utf-8'): IIl(llI, base_url), bytes.fromhex('736561736f6e').decode('utf-8'): IIIIl, bytes.fromhex('657069736f6465').decode('utf-8'): episode})
    return episodes

def find_trailer_url(page, base_url):
    source = Il(bytes.fromhex('3c6469765c625b5e3e5d2a69643d5b225c275d747261696c65722d696672616d652d736f757263655b225c275d5b5e3e5d2a3e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S)
    IllI = I(source, bytes.fromhex('646174612d696672616d65').decode('utf-8'))
    IIlll = I(Il(bytes.fromhex('3c696672616d655c625b5e3e5d2a283f3a7372637c646174612d737263293d5b275c225d5b5e275c225d2b5b275c225d5b5e3e5d2a3e').decode('utf-8'), IllI, re.S), bytes.fromhex('646174612d737263').decode('utf-8'))
    IIlll = IIlll or I(Il(bytes.fromhex('3c696672616d655c625b5e3e5d2a283f3a7372637c646174612d737263293d5b275c225d5b5e275c225d2b5b275c225d5b5e3e5d2a3e').decode('utf-8'), IllI, re.S), bytes.fromhex('737263').decode('utf-8'))
    if IIlll:
        return fix_url(IIlll, base_url)
    IlIl = Il(bytes.fromhex('3c696672616d655c625b5e3e5d2a283f3a7372637c646174612d737263293d5b225c275d5b5e225c275d2a283f3a796f75747562657c796f7574755c2e6265295b5e225c275d2b5b225c275d5b5e3e5d2a3e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S)
    IIlll = I(IlIl, bytes.fromhex('646174612d737263').decode('utf-8')) or I(IlIl, bytes.fromhex('737263').decode('utf-8'))
    if IIlll:
        return fix_url(IIlll, base_url)
    IIIll = Il(bytes.fromhex('3c615c625b5e3e5d2a283f3a687265667c646174612d766964656f5f75726c293d5b275c225d5b5e275c225d2a283f3a796f75747562657c796f7574755c2e62657c667261676d616e295b5e275c225d2a5b275c225d5b5e3e5d2a3e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S)
    IlIII = I(IIIll, bytes.fromhex('646174612d766964656f5f75726c').decode('utf-8')) or I(IIIll, bytes.fromhex('68726566').decode('utf-8'))
    return fix_url(IlIII, base_url) if IlIII else bytes.fromhex('').decode('utf-8')

def parse_iframe(page, base_url):
    IlIl = Il(bytes.fromhex('3c5b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c627365726965732d706c617965722d636f6e7461696e65725c625b5e225c275d2a5b225c275d5b5e3e5d2a3e2e2a3f3c696672616d655c625b5e3e5d2a283f3a7372637c646174612d737263293d5b225c275d5b5e225c275d2b5b225c275d5b5e3e5d2a3e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S) or Il(bytes.fromhex('3c6469765b5e3e5d2a69643d5b225c275d766173745f6e65775b225c275d5b5e3e5d2a3e2e2a3f3c696672616d655c625b5e3e5d2a283f3a7372637c646174612d737263293d5b225c275d5b5e225c275d2b5b225c275d5b5e3e5d2a3e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S) or Il(bytes.fromhex('3c6469765b5e3e5d2a69643d5b225c275d766173745b225c275d5b5e3e5d2a3e2e2a3f3c696672616d655c625b5e3e5d2a283f3a7372637c646174612d737263293d5b225c275d5b5e225c275d2b5b225c275d5b5e3e5d2a3e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S) or Il(bytes.fromhex('3c5b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c62766964656f2d706c617965722d617265615c625b5e225c275d2a5b225c275d5b5e3e5d2a3e2e2a3f3c696672616d655c625b5e3e5d2a283f3a7372637c646174612d737263293d5b225c275d5b5e225c275d2b5b225c275d5b5e3e5d2a3e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S) or Il(bytes.fromhex('3c5b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c62726573706f6e736976652d706c617965725c625b5e225c275d2a5b225c275d5b5e3e5d2a3e2e2a3f3c696672616d655c625b5e3e5d2a283f3a7372637c646174612d737263293d5b225c275d5b5e225c275d2b5b225c275d5b5e3e5d2a3e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S) or Il(bytes.fromhex('3c696672616d655c625b5e3e5d2a283f3a7372637c646174612d737263293d5b275c225d5b5e275c225d2b5b275c225d5b5e3e5d2a3e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S)
    return fix_url(I(IlIl, bytes.fromhex('646174612d737263').decode('utf-8')) or I(IlIl, bytes.fromhex('737263').decode('utf-8')), base_url)

def fix_url(url, base_url):
    if not url:
        return bytes.fromhex('').decode('utf-8')
    return urljoin(base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8'), html.unescape(url).strip())

def clean_title(IlIII):
    IlIII = l(IlIII)
    IlIII = re.sub(bytes.fromhex('5c732b697a6c655c732a2d5c732a44697a6970616c5c732a24').decode('utf-8'), bytes.fromhex('').decode('utf-8'), IlIII, flags=re.I)
    IlIII = re.sub(bytes.fromhex('5c732b2d5c732a44697a6970616c5c732a24').decode('utf-8'), bytes.fromhex('').decode('utf-8'), IlIII, flags=re.I)
    IlIII = re.sub(bytes.fromhex('5c732b697a6c655c732a2d5c732a44697a694d6f6d5c732a24').decode('utf-8'), bytes.fromhex('').decode('utf-8'), IlIII, flags=re.I)
    IlIII = re.sub(bytes.fromhex('5c732b2d5c732a44697a694d6f6d5c732a24').decode('utf-8'), bytes.fromhex('').decode('utf-8'), IlIII, flags=re.I)
    return IlIII.strip()

def parse_duration(IlIII):
    IIllI = 0
    IIll = Il(bytes.fromhex('285c642b295c732a73').decode('utf-8'), IlIII)
    llIl = Il(bytes.fromhex('285c642b295c732a646b').decode('utf-8'), IlIII)
    if IIll:
        IIllI += int(IIll) * 60
    if llIl:
        IIllI += int(llIl)
    if IIllI:
        return str(IIllI)
    return Il(bytes.fromhex('285c642b29').decode('utf-8'), IlIII)

def III(page):
    lll = re.findall(bytes.fromhex('3c6469765c625b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c6273696e676c652d6974656d5c625b5e225c275d2a5b225c275d5b5e3e5d2a3e2e2a3f283f3d3c6469765c625b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c6273696e676c652d6974656d5c627c3c6469765c625b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c62706167696e6174652d6c696e6b735c627c2429').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I)
    if lll:
        return lll
    return re.findall(bytes.fromhex('3c6469765c625b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c62706f73742d6974656d5c625b5e225c275d2a5b225c275d5b5e3e5d2a3e2e2a3f283f3d3c6469765c625b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c62706f73742d6974656d5c627c2429').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I)

def IIl(llI, base_url):
    for Illl in re.findall(bytes.fromhex('3c696d675c625b5e3e5d2a3e').decode('utf-8'), llI or bytes.fromhex('').decode('utf-8'), re.S | re.I):
        IIIII = I(Illl, bytes.fromhex('646174612d737263').decode('utf-8')) or I(Illl, bytes.fromhex('737263').decode('utf-8'))
        lIll = (IIIII or bytes.fromhex('').decode('utf-8')).lower()
        if IIIII and (not lIll.startswith(bytes.fromhex('646174613a696d616765').decode('utf-8'))) and (bytes.fromhex('2f7468656d65732f').decode('utf-8') not in lIll):
            return fix_url(IIIII, base_url)
    return bytes.fromhex('').decode('utf-8')

def II(page, label):
    for llII in re.finditer(bytes.fromhex('3c7370616e5c625b5e3e5d2a3e282e2a3f293c2f7370616e3e283f503c7461696c3e2e7b302c3430307d29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
        if l(llII.group(1)).lower() == label.lower():
            return l(llII.group(bytes.fromhex('7461696c').decode('utf-8')).split(bytes.fromhex('3c2f').decode('utf-8'), 1)[0])
    return bytes.fromhex('').decode('utf-8')

def ll(page, label):
    IlIII = II(page, label)
    return re.sub(bytes.fromhex('5e7b307d5c732a').decode('utf-8').format(re.escape(label)), bytes.fromhex('').decode('utf-8'), IlIII, flags=re.I).strip()

def lI(page, Ill, lII):
    llll = bytes.fromhex('3c6d6574615c625b5e3e5d2a5c627b307d3d5b225c275d7b317d5b225c275d5b5e3e5d2a3e').decode('utf-8').format(re.escape(Ill), re.escape(lII))
    IIIll = Il(llll, page or bytes.fromhex('').decode('utf-8'), re.S)
    return I(IIIll, bytes.fromhex('636f6e74656e74').decode('utf-8'))

def I(IIIll, lllI):
    if not IIIll:
        return bytes.fromhex('').decode('utf-8')
    llII = re.search(bytes.fromhex('5c627b307d3d5b225c275d285b5e225c275d2b295b225c275d').decode('utf-8').format(re.escape(lllI)), IIIll, re.I)
    return html.unescape(llII.group(1)) if llII else bytes.fromhex('').decode('utf-8')

def Il(llll, IIlII, flags=0):
    llII = re.search(llll, IIlII or bytes.fromhex('').decode('utf-8'), flags | re.I)
    if not llII:
        return bytes.fromhex('').decode('utf-8')
    return llII.group(1) if llII.lastindex else llII.group(0)

def l(IIlII):
    IIlII = re.sub(bytes.fromhex('3c7363726970742e2a3f3c2f7363726970743e').decode('utf-8'), bytes.fromhex('20').decode('utf-8'), IIlII or bytes.fromhex('').decode('utf-8'), flags=re.S | re.I)
    IIlII = re.sub(bytes.fromhex('3c7376672e2a3f3c2f7376673e').decode('utf-8'), bytes.fromhex('20').decode('utf-8'), IIlII, flags=re.S | re.I)
    IIlII = re.sub(bytes.fromhex('3c5b5e3e5d2b3e').decode('utf-8'), bytes.fromhex('20').decode('utf-8'), IIlII)
    IIlII = html.unescape(IIlII)
    return re.sub(bytes.fromhex('5c732b').decode('utf-8'), bytes.fromhex('20').decode('utf-8'), IIlII).strip()
