from __future__ import absolute_import, unicode_literals
import manituxhttp
try:
    from urllib.parse import quote_plus
except ImportError:
    from urllib import quote_plus
from .extractor import DiziMomExtractor
from . import parsers

class DiziMomSite(object):
    CLIENT_IDENTIFIERS = (bytes.fromhex('636c6f756473637261706572').decode('utf-8'), bytes.fromhex('6368726f6d655f313434').decode('utf-8'))
    ARCHIVE_PATH = bytes.fromhex('2f74756d2d64697a696c65722d6864312f').decode('utf-8')

    def __init__(III, base_url, user_agent):
        III.base_url = base_url.rstrip(bytes.fromhex('2f').decode('utf-8'))
        III.user_agent = user_agent
        III.session = manituxhttp.Session(client_identifier=III.CLIENT_IDENTIFIERS[0])
        III.extractor = DiziMomExtractor(user_agent, III.base_url)

    def headers(III, referer=None, ajax=False):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): III.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('746578742f68746d6c2c6170706c69636174696f6e2f7868746d6c2b786d6c2c6170706c69636174696f6e2f786d6c3b713d302e392c696d6167652f617669662c696d6167652f776562702c696d6167652f61706e672c2a2f2a3b713d302e38').decode('utf-8'), bytes.fromhex('4163636570742d4c616e6775616765').decode('utf-8'): bytes.fromhex('74722d54522c74723b713d302e392c656e2d55533b713d302e382c656e3b713d302e37').decode('utf-8')}
        if referer:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        if ajax:
            headers[bytes.fromhex('582d5265717565737465642d57697468').decode('utf-8')] = bytes.fromhex('584d4c4874747052657175657374').decode('utf-8')
            headers[bytes.fromhex('4f726967696e').decode('utf-8')] = III.base_url
        return headers

    def categories(III):
        page = III.get(III.base_url + III.ARCHIVE_PATH, referer=III.base_url + bytes.fromhex('2f').decode('utf-8'))
        return parsers.categories(page, III.base_url)

    def get(III, url, referer=None):
        return III._get(III.absolute(url), III.headers(referer)).text

    def get_page_items(III, I, page_number=1):
        page = III.get(parsers.page_url(I, page_number), referer=III.base_url + bytes.fromhex('2f').decode('utf-8'))
        return parsers.parse_page_items(page, III.base_url)

    def search(III, query):
        page = III.get(III.search_url(query), referer=III.base_url + bytes.fromhex('2f').decode('utf-8'))
        return parsers.parse_page_items(page, III.base_url, bytes.fromhex('4172616d61').decode('utf-8'))

    def detail(III, url):
        page = III.get(url, referer=III.base_url + bytes.fromhex('2f').decode('utf-8'))
        II = parsers.parse_media_info(page, url, III.base_url)
        II[bytes.fromhex('657069736f646573').decode('utf-8')] = III.sort_episodes(II.get(bytes.fromhex('657069736f646573').decode('utf-8')) or [])
        if III.is_series_page(url) and (not III.is_episode_page(url)):
            II[bytes.fromhex('736f7572636573').decode('utf-8')] = [source for source in II.get(bytes.fromhex('736f7572636573').decode('utf-8'), []) if source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8'))]
        return II

    def resolve_source(III, url, referer=None, label=bytes.fromhex('').decode('utf-8')):
        return III.extractor.resolve(III.absolute(url), referer or III.base_url + bytes.fromhex('2f').decode('utf-8'), label)

    def absolute(III, url):
        return parsers.fix_url(url, III.base_url)

    def search_url(III, query):
        return III.base_url + bytes.fromhex('2f3f733d').decode('utf-8') + quote_plus(query)

    @staticmethod
    def is_series_page(url):
        return bytes.fromhex('2f64697a692f').decode('utf-8') in (url or bytes.fromhex('').decode('utf-8')).lower()

    @staticmethod
    def is_episode_page(url):
        lI = (url or bytes.fromhex('').decode('utf-8')).lower()
        return bytes.fromhex('2f626f6c756d2f').decode('utf-8') in lI or bytes.fromhex('2f73657a6f6e').decode('utf-8') in lI

    @staticmethod
    def sort_episodes(episodes):
        return sorted(episodes or [], key=lambda item: (int(item.get(bytes.fromhex('736561736f6e').decode('utf-8')) or 0), int(item.get(bytes.fromhex('657069736f6465').decode('utf-8')) or 0), item.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')))

    def _get(III, url, headers):
        Il = None
        for l in III.CLIENT_IDENTIFIERS:
            if III.session.client_identifier != l:
                III.session = manituxhttp.Session(client_identifier=l)
            try:
                ll = III.session.get(url, headers=headers, timeout=25, allow_redirects=True, tls_client_identifier=l)
                if ll.status_code in (403, 429) and l != III.CLIENT_IDENTIFIERS[-1]:
                    Il = manituxhttp.HTTPError(ll)
                    continue
                ll.raise_for_status()
                return ll
            except (manituxhttp.HTTPError, manituxhttp.RequestError) as exc:
                Il = exc
                if l == III.CLIENT_IDENTIFIERS[-1]:
                    raise
        raise Il
