from __future__ import absolute_import, unicode_literals
import re
import sys
import time
import os
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
try:
    from urllib.parse import parse_qsl, quote, urlencode
except ImportError:
    from urlparse import parse_qsl
    from urllib import quote, urlencode
from resources.lib.site import DiziPalSite
MANITUXUI_LIB = os.path.join(xbmcaddon.Addon(id=bytes.fromhex('7363726970742e6d6f64756c652e6d616e697475787569').decode('utf-8')).getAddonInfo(bytes.fromhex('70617468').decode('utf-8')), bytes.fromhex('6c6962').decode('utf-8'))
if MANITUXUI_LIB not in sys.path:
    sys.path.insert(0, MANITUXUI_LIB)
from manituxui import ManituxUI, open_browser
ADDON_ID = bytes.fromhex('706c7567696e2e766964656f2e64697a6970616c').decode('utf-8')
SKIP_GUI_UNTIL = ADDON_ID + bytes.fromhex('2e736b69705f6775695f756e74696c').decode('utf-8')
ADDON = xbmcaddon.Addon(id=ADDON_ID)
HANDLE = int(sys.argv[1])
BASE_URL = ADDON.getSetting(bytes.fromhex('626173655f75726c').decode('utf-8')) or bytes.fromhex('68747470733a2f2f64697a6970616c2e696d').decode('utf-8')
UA = ADDON.getSetting(bytes.fromhex('757365725f6167656e74').decode('utf-8')) or bytes.fromhex('4d6f7a696c6c612f352e30202857696e646f7773204e542031302e303b2057696e36343b2078363429204170706c655765624b69742f3533372e333620284b48544d4c2c206c696b65204765636b6f29204368726f6d652f3133342e302e302e30205361666172692f3533372e3336').decode('utf-8')
IIlIlIlIlII = DiziPalSite(BASE_URL, UA)

class DiziPalUI(ManituxUI):
    title = bytes.fromhex('44697a6950616c').decode('utf-8')

    def categories(self):
        categories = [{bytes.fromhex('7469746c65').decode('utf-8'): bytes.fromhex('417261').decode('utf-8'), bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('736561726368').decode('utf-8')}]
        for title, url in IIlIlIlIlII.categories():
            categories.append({bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url})
        return categories

    def videos(self, category, page=1):
        if category.get(bytes.fromhex('616374696f6e').decode('utf-8')) == bytes.fromhex('736561726368').decode('utf-8'):
            query = xbmcgui.Dialog().input(bytes.fromhex('44697a6950616c20417261').decode('utf-8'))
            return [self._art_item(item) for item in IIlIlIlIlII.search(query)] if query else []
        return [self._art_item(item) for item in IIlIlIlIlII.get_page_items(category[bytes.fromhex('75726c').decode('utf-8')], page)]

    def _art_item(self, item):
        Y67786688834003 = dict(item)
        image = Y67786688834003.get(bytes.fromhex('696d616765').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
        referer = Y67786688834003.get(bytes.fromhex('75726c').decode('utf-8')) or BASE_URL + bytes.fromhex('2f').decode('utf-8')
        Y67786688834003[bytes.fromhex('696d616765').decode('utf-8')] = art_url(image, referer)
        return Y67786688834003

    def detail(self, video):
        aaaAaAaA = video[bytes.fromhex('75726c').decode('utf-8')]
        W45734784224795 = IIlIlIlIlII.detail(aaaAaAaA)
        image = art_url(W45734784224795.get(bytes.fromhex('696d616765').decode('utf-8')) or video.get(bytes.fromhex('696d616765').decode('utf-8'), bytes.fromhex('').decode('utf-8')), aaaAaAaA)
        plot = W45734784224795.get(bytes.fromhex('706c6f74').decode('utf-8')) or video.get(bytes.fromhex('706c6f74').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
        sources = []
        for source in W45734784224795.get(bytes.fromhex('736f7572636573').decode('utf-8'), []):
            sources.append({bytes.fromhex('6c6162656c').decode('utf-8'): source.get(bytes.fromhex('6c6162656c').decode('utf-8')) or bytes.fromhex('4f796e6174').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('72656665726572').decode('utf-8'): source.get(bytes.fromhex('72656665726572').decode('utf-8')) or aaaAaAaA, bytes.fromhex('69735f747261696c6572').decode('utf-8'): source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8'), False)})
        cRgnYthJfPXdqhxgfcMOCqOBqvpRdfKCopHukkxltYQGuSjkTnmcrfWxkfEbwmRUQiDqMYyxDWOswAS4 = []
        for episode in W45734784224795.get(bytes.fromhex('657069736f646573').decode('utf-8'), []):
            cRgnYthJfPXdqhxgfcMOCqOBqvpRdfKCopHukkxltYQGuSjkTnmcrfWxkfEbwmRUQiDqMYyxDWOswAS4.append({bytes.fromhex('7469746c65').decode('utf-8'): episode.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('42c3b66cc3bc6d').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): episode.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('696d616765').decode('utf-8'): art_url(episode.get(bytes.fromhex('696d616765').decode('utf-8')) or image, episode.get(bytes.fromhex('75726c').decode('utf-8')) or aaaAaAaA), bytes.fromhex('706c6f74').decode('utf-8'): plot})
        return {bytes.fromhex('7469746c65').decode('utf-8'): W45734784224795.get(bytes.fromhex('7469746c65').decode('utf-8')) or video.get(bytes.fromhex('7469746c65').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('75726c').decode('utf-8'): aaaAaAaA, bytes.fromhex('696d616765').decode('utf-8'): image, bytes.fromhex('6261636b64726f70').decode('utf-8'): art_url(W45734784224795.get(bytes.fromhex('6261636b64726f70').decode('utf-8')) or W45734784224795.get(bytes.fromhex('66616e617274').decode('utf-8')) or image, aaaAaAaA), bytes.fromhex('706c6f74').decode('utf-8'): plot, bytes.fromhex('79656172').decode('utf-8'): W45734784224795.get(bytes.fromhex('79656172').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('636f756e747279').decode('utf-8'): W45734784224795.get(bytes.fromhex('636f756e747279').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('6475726174696f6e').decode('utf-8'): W45734784224795.get(bytes.fromhex('6475726174696f6e').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('726174696e67').decode('utf-8'): W45734784224795.get(bytes.fromhex('726174696e67').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('74616773').decode('utf-8'): W45734784224795.get(bytes.fromhex('74616773').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('6163746f7273').decode('utf-8'): W45734784224795.get(bytes.fromhex('6163746f7273').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('657069736f646573').decode('utf-8'): cRgnYthJfPXdqhxgfcMOCqOBqvpRdfKCopHukkxltYQGuSjkTnmcrfWxkfEbwmRUQiDqMYyxDWOswAS4, bytes.fromhex('736f7572636573').decode('utf-8'): sources}

    def episode_detail(self, episode, video=None):
        return self.detail(episode)

    def play(self, source, video=None):
        if source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8')):
            play_youtube_gui(source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
        else:
            play_source_gui(source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), source.get(bytes.fromhex('72656665726572').decode('utf-8')), source.get(bytes.fromhex('6c6162656c').decode('utf-8'), bytes.fromhex('').decode('utf-8')))

def build_url(query):
    return sys.argv[0] + bytes.fromhex('3f').decode('utf-8') + urlencode(query)

def art_url(url, referer=None):
    if not url or bytes.fromhex('7c').decode('utf-8') in url or (not url.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8')))):
        return url
    Y50033720972011 = [bytes.fromhex('557365722d4167656e743d').decode('utf-8') + quote(UA)]
    Y50033720972011.append(bytes.fromhex('526566657265723d').decode('utf-8') + quote(referer or BASE_URL + bytes.fromhex('2f').decode('utf-8')))
    return url + bytes.fromhex('7c').decode('utf-8') + bytes.fromhex('26').decode('utf-8').join(Y50033720972011)

def set_art(li, image, referer=None):
    image = art_url(image, referer)
    li.setArt({bytes.fromhex('7468756d62').decode('utf-8'): image, bytes.fromhex('69636f6e').decode('utf-8'): image, bytes.fromhex('706f73746572').decode('utf-8'): image, bytes.fromhex('66616e617274').decode('utf-8'): image})

def add_directory(title, action, url=bytes.fromhex('').decode('utf-8'), image=bytes.fromhex('').decode('utf-8'), plot=bytes.fromhex('').decode('utf-8')):
    li = xbmcgui.ListItem(label=title)
    set_art(li, image, url or BASE_URL + bytes.fromhex('2f').decode('utf-8'))
    li.setInfo(bytes.fromhex('766964656f').decode('utf-8'), {bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('706c6f74').decode('utf-8'): plot})
    xbmcplugin.addDirectoryItem(HANDLE, build_url({bytes.fromhex('616374696f6e').decode('utf-8'): action, bytes.fromhex('75726c').decode('utf-8'): url}), li, True)

def add_video(title, action, url, image=bytes.fromhex('').decode('utf-8'), plot=bytes.fromhex('').decode('utf-8'), extra=None):
    query = {bytes.fromhex('616374696f6e').decode('utf-8'): action, bytes.fromhex('75726c').decode('utf-8'): url}
    if extra:
        query.update(extra)
    li = xbmcgui.ListItem(label=title)
    set_art(li, image, extra.get(bytes.fromhex('72656665726572').decode('utf-8')) if extra else BASE_URL + bytes.fromhex('2f').decode('utf-8'))
    li.setInfo(bytes.fromhex('766964656f').decode('utf-8'), {bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('706c6f74').decode('utf-8'): plot})
    li.setProperty(bytes.fromhex('4973506c617961626c65').decode('utf-8'), bytes.fromhex('74727565').decode('utf-8'))
    xbmcplugin.addDirectoryItem(HANDLE, build_url(query), li, False)

def main_menu():
    add_directory(bytes.fromhex('417261').decode('utf-8'), bytes.fromhex('736561726368').decode('utf-8'))
    for title, url in IIlIlIlIlII.categories():
        add_directory(title, bytes.fromhex('6c697374').decode('utf-8'), url)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('747673686f7773').decode('utf-8'))

def list_page(url, page_number=1):
    aaaaAa = IIlIlIlIlII.get_page_items(url, page_number)
    for item in aaaaAa:
        add_directory(item[bytes.fromhex('7469746c65').decode('utf-8')], bytes.fromhex('64657461696c').decode('utf-8'), item[bytes.fromhex('75726c').decode('utf-8')], item[bytes.fromhex('696d616765').decode('utf-8')], item[bytes.fromhex('706c6f74').decode('utf-8')])
    if aaaaAa:
        xbmcplugin.addDirectoryItem(HANDLE, build_url({bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('6c697374').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('70616765').decode('utf-8'): str(int(page_number) + 1)}), xbmcgui.ListItem(label=bytes.fromhex('536f6e72616b69205361796661').decode('utf-8')), True)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('747673686f7773').decode('utf-8'))

def search():
    query = xbmcgui.Dialog().input(bytes.fromhex('44697a6950616c20417261').decode('utf-8'))
    if query:
        for item in IIlIlIlIlII.search(query):
            add_directory(item[bytes.fromhex('7469746c65').decode('utf-8')], bytes.fromhex('64657461696c').decode('utf-8'), item[bytes.fromhex('75726c').decode('utf-8')], item[bytes.fromhex('696d616765').decode('utf-8')], item.get(bytes.fromhex('706c6f74').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
        xbmcplugin.setContent(HANDLE, bytes.fromhex('747673686f7773').decode('utf-8'))

def detail(url):
    W45734784224795 = IIlIlIlIlII.detail(url)
    sources = W45734784224795.get(bytes.fromhex('736f7572636573').decode('utf-8'), [])
    cRgnYthJfPXdqhxgfcMOCqOBqvpRdfKCopHukkxltYQGuSjkTnmcrfWxkfEbwmRUQiDqMYyxDWOswAS4 = W45734784224795.get(bytes.fromhex('657069736f646573').decode('utf-8'), [])
    for source in sources if not cRgnYthJfPXdqhxgfcMOCqOBqvpRdfKCopHukkxltYQGuSjkTnmcrfWxkfEbwmRUQiDqMYyxDWOswAS4 else [source for source in sources if source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8'))]:
        add_video(source[bytes.fromhex('6c6162656c').decode('utf-8')], bytes.fromhex('706c61795f796f7574756265').decode('utf-8') if source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8')) else bytes.fromhex('706c61795f736f75726365').decode('utf-8'), source[bytes.fromhex('75726c').decode('utf-8')], W45734784224795.get(bytes.fromhex('696d616765').decode('utf-8'), bytes.fromhex('').decode('utf-8')), W45734784224795.get(bytes.fromhex('706c6f74').decode('utf-8'), bytes.fromhex('').decode('utf-8')), {bytes.fromhex('72656665726572').decode('utf-8'): source.get(bytes.fromhex('72656665726572').decode('utf-8')) or url, bytes.fromhex('6c6162656c').decode('utf-8'): source[bytes.fromhex('6c6162656c').decode('utf-8')]})
    if cRgnYthJfPXdqhxgfcMOCqOBqvpRdfKCopHukkxltYQGuSjkTnmcrfWxkfEbwmRUQiDqMYyxDWOswAS4:
        for episode in cRgnYthJfPXdqhxgfcMOCqOBqvpRdfKCopHukkxltYQGuSjkTnmcrfWxkfEbwmRUQiDqMYyxDWOswAS4:
            add_directory(episode.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('426f6c756d').decode('utf-8'), bytes.fromhex('64657461696c').decode('utf-8'), episode[bytes.fromhex('75726c').decode('utf-8')], episode.get(bytes.fromhex('696d616765').decode('utf-8')) or W45734784224795.get(bytes.fromhex('696d616765').decode('utf-8'), bytes.fromhex('').decode('utf-8')), W45734784224795.get(bytes.fromhex('706c6f74').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
    if not sources and (not cRgnYthJfPXdqhxgfcMOCqOBqvpRdfKCopHukkxltYQGuSjkTnmcrfWxkfEbwmRUQiDqMYyxDWOswAS4):
        xbmcgui.Dialog().notification(bytes.fromhex('44697a6950616c').decode('utf-8'), bytes.fromhex('4b61796e616b207665796120626f6c756d2062756c756e616d616469').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('747673686f7773').decode('utf-8'))

def youtube_plugin_url(url):
    video_id = bytes.fromhex('').decode('utf-8')
    for q9 in (bytes.fromhex('283f3a796f75747562655c2e636f6d2f656d6265642f7c796f75747562655c2e636f6d2f77617463685c3f763d7c796f7574755c2e62652f29285b412d5a612d7a302d395f2d5d7b362c7d29').decode('utf-8'), bytes.fromhex('5b3f265d763d285b412d5a612d7a302d395f2d5d7b362c7d29').decode('utf-8')):
        IIIIlII = re.search(q9, url or bytes.fromhex('').decode('utf-8'), re.I)
        if IIIIlII:
            video_id = IIIIlII.group(1)
            break
    return bytes.fromhex('706c7567696e3a2f2f706c7567696e2e766964656f2e796f75747562652f706c61792f3f766964656f5f69643d').decode('utf-8') + video_id if video_id else bytes.fromhex('').decode('utf-8')

def play_youtube(url):
    K116960546970610 = youtube_plugin_url(url)
    if not K116960546970610:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    try:
        xbmcaddon.Addon(id=bytes.fromhex('706c7567696e2e766964656f2e796f7574756265').decode('utf-8'))
    except Exception:
        xbmcgui.Dialog().notification(bytes.fromhex('596f7554756265').decode('utf-8'), bytes.fromhex('706c7567696e2e766964656f2e796f757475626520676572656b6c69').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=K116960546970610))

def play_youtube_gui(url):
    K116960546970610 = youtube_plugin_url(url)
    if not K116960546970610:
        return False
    try:
        xbmcaddon.Addon(id=bytes.fromhex('706c7567696e2e766964656f2e796f7574756265').decode('utf-8'))
    except Exception:
        xbmcgui.Dialog().notification(bytes.fromhex('596f7554756265').decode('utf-8'), bytes.fromhex('706c7567696e2e766964656f2e796f757475626520676572656b6c69').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
        return False
    xbmc.Player().play(K116960546970610)
    return True

def play_source(url, referer=None, label=bytes.fromhex('').decode('utf-8')):
    stream, subtitles = IIlIlIlIlII.resolve_source(url, referer, label)
    if not stream:
        xbmcgui.Dialog().notification(bytes.fromhex('44697a6950616c').decode('utf-8'), bytes.fromhex('4b61796e616b20636f7a756d6c656e656d656469').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    path = stream
    li = xbmcgui.ListItem(path=path)
    if is_hls_stream(stream):
        li.setMimeType(bytes.fromhex('6170706c69636174696f6e2f766e642e6170706c652e6d70656775726c').decode('utf-8'))
        li.setContentLookup(False)
        if has_addon(bytes.fromhex('696e70757473747265616d2e6164617074697665').decode('utf-8')):
            li.setProperty(bytes.fromhex('696e70757473747265616d').decode('utf-8'), bytes.fromhex('696e70757473747265616d2e6164617074697665').decode('utf-8'))
            li.setProperty(bytes.fromhex('696e70757473747265616d2e61646170746976652e73747265616d5f68656164657273').decode('utf-8'), stream_headers(stream))
            li.setProperty(bytes.fromhex('696e70757473747265616d2e61646170746976652e6d616e69666573745f68656164657273').decode('utf-8'), stream_headers(stream))
    if subtitles:
        li.setSubtitles(subtitles)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)

def play_source_gui(url, referer=None, label=bytes.fromhex('').decode('utf-8')):
    stream, subtitles = IIlIlIlIlII.resolve_source(url, referer, label)
    play_stream_gui(stream, subtitles)

def play_stream_gui(stream, subtitles=None):
    if not stream:
        xbmcgui.Dialog().notification(bytes.fromhex('44697a6950616c').decode('utf-8'), bytes.fromhex('4b61796e616b20636f7a756d6c656e656d656469').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    path = stream
    li = xbmcgui.ListItem(path=path)
    if is_hls_stream(stream):
        li.setMimeType(bytes.fromhex('6170706c69636174696f6e2f766e642e6170706c652e6d70656775726c').decode('utf-8'))
        li.setContentLookup(False)
        if has_addon(bytes.fromhex('696e70757473747265616d2e6164617074697665').decode('utf-8')):
            li.setProperty(bytes.fromhex('696e70757473747265616d').decode('utf-8'), bytes.fromhex('696e70757473747265616d2e6164617074697665').decode('utf-8'))
            li.setProperty(bytes.fromhex('696e70757473747265616d2e61646170746976652e73747265616d5f68656164657273').decode('utf-8'), stream_headers(stream))
            li.setProperty(bytes.fromhex('696e70757473747265616d2e61646170746976652e6d616e69666573745f68656164657273').decode('utf-8'), stream_headers(stream))
    if subtitles:
        li.setSubtitles(subtitles)
    xbmc.Player().play(path, li)

def is_hls_stream(url):
    ss = (url or bytes.fromhex('').decode('utf-8')).split(bytes.fromhex('7c').decode('utf-8'), 1)[0]
    return bool(re.search(bytes.fromhex('283f3a5c2e6d3375387c2f706c61796c6973742f5b5e2f3f235d2b5c2e6a736f6e29283f3a5b3f235d2e2a293f24').decode('utf-8'), ss, re.I))

def stream_headers(url):
    if bytes.fromhex('7c').decode('utf-8') not in (url or bytes.fromhex('').decode('utf-8')):
        return bytes.fromhex('').decode('utf-8')
    return url.split(bytes.fromhex('7c').decode('utf-8'), 1)[1]

def clean_stream_url(url):
    return (url or bytes.fromhex('').decode('utf-8')).split(bytes.fromhex('7c').decode('utf-8'), 1)[0]

def has_addon(addon_id):
    try:
        xbmcaddon.Addon(id=addon_id)
        return True
    except Exception:
        return False

def run():
    params = dict(parse_qsl(sys.argv[2][1:]))
    action = params.get(bytes.fromhex('616374696f6e').decode('utf-8'))
    url = params.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
    page_number = int(params.get(bytes.fromhex('70616765').decode('utf-8'), bytes.fromhex('31').decode('utf-8')))
    if not action:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
        AAAAAAAAAAAAA = xbmcgui.Window(10000)
        try:
            aAAAAaaAaAAA = float(AAAAAAAAAAAAA.getProperty(SKIP_GUI_UNTIL) or bytes.fromhex('30').decode('utf-8'))
        except ValueError:
            aAAAAaaAaAAA = 0
        if time.time() < aAAAAaaAaAAA:
            return
        AAAAAAAAAAAAA.clearProperty(SKIP_GUI_UNTIL)
        xbmc.executebuiltin(bytes.fromhex('52756e506c7567696e287b307d29').decode('utf-8').format(build_url({bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('677569').decode('utf-8')})))
        return
    elif action == bytes.fromhex('677569').decode('utf-8'):
        open_browser(DiziPalUI())
        xbmcgui.Window(10000).setProperty(SKIP_GUI_UNTIL, str(time.time() + 4))
        xbmc.executebuiltin(bytes.fromhex('416374697661746557696e646f7728486f6d6529').decode('utf-8'))
        return
    elif action == bytes.fromhex('636c6173736963').decode('utf-8'):
        main_menu()
    elif action == bytes.fromhex('6c697374').decode('utf-8'):
        list_page(url, page_number)
    elif action == bytes.fromhex('736561726368').decode('utf-8'):
        search()
    elif action == bytes.fromhex('64657461696c').decode('utf-8'):
        detail(url)
    elif action == bytes.fromhex('706c61795f736f75726365').decode('utf-8'):
        play_source(url, params.get(bytes.fromhex('72656665726572').decode('utf-8')), params.get(bytes.fromhex('6c6162656c').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
    elif action == bytes.fromhex('706c61795f796f7574756265').decode('utf-8'):
        play_youtube(url)
    xbmcplugin.endOfDirectory(HANDLE)
if __name__ == bytes.fromhex('5f5f6d61696e5f5f').decode('utf-8'):
    run()
