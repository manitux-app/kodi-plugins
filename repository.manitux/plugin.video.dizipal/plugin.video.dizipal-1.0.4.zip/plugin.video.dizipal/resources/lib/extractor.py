from __future__ import absolute_import, unicode_literals
import json
import re
import manituxhttp
try:
    from urllib.parse import quote, urljoin, urlparse
except ImportError:
    from urllib import quote
    from urlparse import urljoin, urlparse
from . import parsers

class DiziPalExtractor(object):
    CLIENT_IDENTIFIERS = (bytes.fromhex('636c6f756473637261706572').decode('utf-8'), bytes.fromhex('6368726f6d655f313434').decode('utf-8'))

    def __init__(self, user_agent, main_url):
        self.user_agent = user_agent
        self.main_url = main_url.rstrip(bytes.fromhex('2f').decode('utf-8'))
        self.session = manituxhttp.Session(client_identifier=self.CLIENT_IDENTIFIERS[0])

    def resolve(self, url, referer=None, label=bytes.fromhex('').decode('utf-8')):
        if not url:
            return (None, [])
        url = self.normalize_url(url)
        page = self.fetch(url, referer or self.main_url + bytes.fromhex('2f').decode('utf-8'))
        KokJKTyQaVqwsrMAMjoeIXxdhUGvVqxoKETyspugTumNzImKphBVmGukEQvPbfTLawLDiaHsWTysHku8 = parsers.parse_iframe(page, self.main_url)
        if not KokJKTyQaVqwsrMAMjoeIXxdhUGvVqxoKETyspugTumNzImKphBVmGukEQvPbfTLawLDiaHsWTysHku8:
            source, ZZZZZZZZZZZZZZZZZZZZZZZZ = self.extract_jwplayer(page, self.origin(url))
            return (source + self.kodi_headers(url) if source else None, ZZZZZZZZZZZZZZZZZZZZZZZZ)
        KokJKTyQaVqwsrMAMjoeIXxdhUGvVqxoKETyspugTumNzImKphBVmGukEQvPbfTLawLDiaHsWTysHku8 = self.normalize_url(KokJKTyQaVqwsrMAMjoeIXxdhUGvVqxoKETyspugTumNzImKphBVmGukEQvPbfTLawLDiaHsWTysHku8)
        if self.is_youtube(KokJKTyQaVqwsrMAMjoeIXxdhUGvVqxoKETyspugTumNzImKphBVmGukEQvPbfTLawLDiaHsWTysHku8):
            return (KokJKTyQaVqwsrMAMjoeIXxdhUGvVqxoKETyspugTumNzImKphBVmGukEQvPbfTLawLDiaHsWTysHku8 + self.kodi_headers(referer), [])
        if bytes.fromhex('766964656f736579726564').decode('utf-8') in urlparse(KokJKTyQaVqwsrMAMjoeIXxdhUGvVqxoKETyspugTumNzImKphBVmGukEQvPbfTLawLDiaHsWTysHku8).netloc.lower():
            return self.resolve_videoseyred(KokJKTyQaVqwsrMAMjoeIXxdhUGvVqxoKETyspugTumNzImKphBVmGukEQvPbfTLawLDiaHsWTysHku8)
        v24483944552379 = self.fetch(KokJKTyQaVqwsrMAMjoeIXxdhUGvVqxoKETyspugTumNzImKphBVmGukEQvPbfTLawLDiaHsWTysHku8, self.main_url + bytes.fromhex('2f').decode('utf-8'))
        source = self.resolve_fetch_stream(v24483944552379, KokJKTyQaVqwsrMAMjoeIXxdhUGvVqxoKETyspugTumNzImKphBVmGukEQvPbfTLawLDiaHsWTysHku8)
        if not source:
            source = self._first(bytes.fromhex('66696c655c732a3a5c732a5b22275d285b5e22275d2b29').decode('utf-8'), v24483944552379)
        if not source:
            source, ZZZZZZZZZZZZZZZZZZZZZZZZ = self.extract_jwplayer(v24483944552379, self.origin(KokJKTyQaVqwsrMAMjoeIXxdhUGvVqxoKETyspugTumNzImKphBVmGukEQvPbfTLawLDiaHsWTysHku8))
        else:
            ZZZZZZZZZZZZZZZZZZZZZZZZ = self.parse_subtitles(v24483944552379)
        if not source:
            source = self._first(bytes.fromhex('68747470733f3a2f2f5b5e5c7322273c3e5d2b3f5c2e283f3a6d3375387c6d703429283f3a5c3f5b5e5c7322273c3e5d2a293f').decode('utf-8'), v24483944552379)
        return (self.normalize_url(source) + self.kodi_headers(KokJKTyQaVqwsrMAMjoeIXxdhUGvVqxoKETyspugTumNzImKphBVmGukEQvPbfTLawLDiaHsWTysHku8, {bytes.fromhex('4f726967696e').decode('utf-8'): self.origin(KokJKTyQaVqwsrMAMjoeIXxdhUGvVqxoKETyspugTumNzImKphBVmGukEQvPbfTLawLDiaHsWTysHku8)}) if source else None, ZZZZZZZZZZZZZZZZZZZZZZZZ)

    def resolve_fetch_stream(self, page, iframe_url):
        path = bytes.fromhex('').decode('utf-8')
        for wuIBzhUOpWzlGJxQsCUSbqcqlfbSOaAHRKGLleZtDBVveDndefoxUtDJsYCPjfDuGcaJmVVvdNZFDTP3 in re.findall(bytes.fromhex('66657463685c285c732a5b22275d285b5e22275d2b295b22275d').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.I):
            if bytes.fromhex('2f646c3f6f703d6765745f73747265616d').decode('utf-8') in wuIBzhUOpWzlGJxQsCUSbqcqlfbSOaAHRKGLleZtDBVveDndefoxUtDJsYCPjfDuGcaJmVVvdNZFDTP3:
                path = wuIBzhUOpWzlGJxQsCUSbqcqlfbSOaAHRKGLleZtDBVveDndefoxUtDJsYCPjfDuGcaJmVVvdNZFDTP3
                break
        if not path:
            return bytes.fromhex('').decode('utf-8')
        sssssssssssssssssssssss = urljoin(self.origin(iframe_url) + bytes.fromhex('2f').decode('utf-8'), path.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')))
        data = self.fetch_stream_json(sssssssssssssssssssssss, iframe_url, page)
        return (data.get(bytes.fromhex('75726c').decode('utf-8')) or bytes.fromhex('').decode('utf-8')).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')) if isinstance(data, dict) else bytes.fromhex('').decode('utf-8')

    def fetch_stream_json(self, url, referer, page):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): self.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('2a2f2a').decode('utf-8'), bytes.fromhex('52656665726572').decode('utf-8'): referer, bytes.fromhex('4f726967696e').decode('utf-8'): self.origin(referer), bytes.fromhex('582d5265717565737465642d57697468').decode('utf-8'): bytes.fromhex('584d4c4874747052657175657374').decode('utf-8'), bytes.fromhex('5365632d46657463682d53697465').decode('utf-8'): bytes.fromhex('73616d652d6f726967696e').decode('utf-8'), bytes.fromhex('5365632d46657463682d4d6f6465').decode('utf-8'): bytes.fromhex('636f7273').decode('utf-8'), bytes.fromhex('5365632d46657463682d44657374').decode('utf-8'): bytes.fromhex('656d707479').decode('utf-8')}
        Y4 = self.parse_js_cookies(page)
        if Y4:
            headers[bytes.fromhex('436f6f6b6965').decode('utf-8')] = Y4
        lIIIlIlllllIl = None
        for l7 in (bytes.fromhex('6368726f6d655f313434').decode('utf-8'), bytes.fromhex('636c6f756473637261706572').decode('utf-8')):
            try:
                llIlIlIIIlIIlIlIlllIII = self.session.get(url, headers=headers, timeout=25, allow_redirects=True, tls_client_identifier=l7)
                llIlIlIIIlIIlIlIlllIII.raise_for_status()
                data = json.loads(llIlIlIIIlIIlIlIlllIII.text)
                if data.get(bytes.fromhex('75726c').decode('utf-8')):
                    return data
                lIIIlIlllllIl = manituxhttp.HTTPError(llIlIlIIIlIIlIlIlllIII)
            except (ValueError, manituxhttp.HTTPError, manituxhttp.RequestError) as exc:
                lIIIlIlllllIl = exc
        if lIIIlIlllllIl:
            raise lIIIlIlllllIl
        return {}

    @staticmethod
    def parse_js_cookies(page):
        Y4 = []
        for lIlllIIIlIlIlll, value in re.findall(bytes.fromhex('5c245c2e636f6f6b69655c285b22275d285b5e22275d2b295b22275d5c732a2c5c732a5b22275d285b5e22275d2b29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.I):
            Y4.append(bytes.fromhex('7b307d3d7b317d').decode('utf-8').format(lIlllIIIlIlIlll, value))
        return bytes.fromhex('3b20').decode('utf-8').join(Y4)

    def resolve_videoseyred(self, url):
        video_id = self._first(bytes.fromhex('2f656d6265642f285b5e2f3f235d2b29').decode('utf-8'), url)
        if not video_id:
            return (None, [])
        AAAaaAAAAaaaAaAaaAAA = self.origin(url) + bytes.fromhex('2f706c61796c6973742f').decode('utf-8') + video_id + bytes.fromhex('2e6a736f6e').decode('utf-8')
        IIIIlllllllIlIlIlI = self.fetch(AAAaaAAAAaaaAaAaaAAA, self.origin(url) + bytes.fromhex('2f').decode('utf-8'))
        try:
            WWWWWWWWWWWWWWWWWWW = json.loads(IIIIlllllllIlIlIlI)
        except Exception:
            WWWWWWWWWWWWWWWWWWW = []
        iQkHaoJPUAIAdxDwyWgdpqMjmATNtMKNOLlowpKADvHAmUZyzlrekNdFBWDTwIUcFZtIzhknjHRknqJ10 = WWWWWWWWWWWWWWWWWWW[0] if WWWWWWWWWWWWWWWWWWW else {}
        sources = iQkHaoJPUAIAdxDwyWgdpqMjmATNtMKNOLlowpKADvHAmUZyzlrekNdFBWDTwIUcFZtIzhknjHRknqJ10.get(bytes.fromhex('736f7572636573').decode('utf-8')) or []
        source = bytes.fromhex('').decode('utf-8')
        for wuIBzhUOpWzlGJxQsCUSbqcqlfbSOaAHRKGLleZtDBVveDndefoxUtDJsYCPjfDuGcaJmVVvdNZFDTP3 in sources:
            source = wuIBzhUOpWzlGJxQsCUSbqcqlfbSOaAHRKGLleZtDBVveDndefoxUtDJsYCPjfDuGcaJmVVvdNZFDTP3.get(bytes.fromhex('66696c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
            if source:
                break
        AaAaAaaaAaAaaaaAaaaAaaaAa = []
        for D26 in iQkHaoJPUAIAdxDwyWgdpqMjmATNtMKNOLlowpKADvHAmUZyzlrekNdFBWDTwIUcFZtIzhknjHRknqJ10.get(bytes.fromhex('747261636b73').decode('utf-8')) or []:
            if (D26.get(bytes.fromhex('6b696e64').decode('utf-8')) or bytes.fromhex('').decode('utf-8')).lower() == bytes.fromhex('63617074696f6e73').decode('utf-8') and D26.get(bytes.fromhex('66696c65').decode('utf-8')):
                AaAaAaaaAaAaaaaAaaaAaaaAa.append(urljoin(self.origin(url) + bytes.fromhex('2f').decode('utf-8'), D26[bytes.fromhex('66696c65').decode('utf-8')]))
        return (source + self.kodi_headers(self.origin(url) + bytes.fromhex('2f').decode('utf-8')) if source else None, AaAaAaaaAaAaaaaAaaaAaaaAa)

    def extract_jwplayer(self, page, base_url):
        source = bytes.fromhex('').decode('utf-8')
        ZZZZZZZZZZZZZZZZZZZZZZZZ = []
        for aaaaAaaAaaAaaaAAaaAaa in re.findall(bytes.fromhex('5b22275d3f736f75726365735b22275d3f5c732a3a5c732a285c5b2e2a3f5c5d29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            for iQkHaoJPUAIAdxDwyWgdpqMjmATNtMKNOLlowpKADvHAmUZyzlrekNdFBWDTwIUcFZtIzhknjHRknqJ10 in self._parse_js_list(aaaaAaaAaaAaaaAAaaAaa):
                source = iQkHaoJPUAIAdxDwyWgdpqMjmATNtMKNOLlowpKADvHAmUZyzlrekNdFBWDTwIUcFZtIzhknjHRknqJ10.get(bytes.fromhex('66696c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
                if source:
                    source = urljoin(base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8'), source.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')))
                    break
            if source:
                break
        for aaaaAaaAaaAaaaAAaaAaa in re.findall(bytes.fromhex('5b22275d3f747261636b735b22275d3f5c732a3a5c732a285c5b2e2a3f5c5d29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            for iQkHaoJPUAIAdxDwyWgdpqMjmATNtMKNOLlowpKADvHAmUZyzlrekNdFBWDTwIUcFZtIzhknjHRknqJ10 in self._parse_js_list(aaaaAaaAaaAaaaAAaaAaa):
                G846874810468712 = (iQkHaoJPUAIAdxDwyWgdpqMjmATNtMKNOLlowpKADvHAmUZyzlrekNdFBWDTwIUcFZtIzhknjHRknqJ10.get(bytes.fromhex('6b696e64').decode('utf-8')) or bytes.fromhex('').decode('utf-8')).lower()
                LLLLL = iQkHaoJPUAIAdxDwyWgdpqMjmATNtMKNOLlowpKADvHAmUZyzlrekNdFBWDTwIUcFZtIzhknjHRknqJ10.get(bytes.fromhex('66696c65').decode('utf-8'))
                if LLLLL and (bytes.fromhex('63617074696f6e').decode('utf-8') in G846874810468712 or bytes.fromhex('7375627469746c65').decode('utf-8') in G846874810468712):
                    ZZZZZZZZZZZZZZZZZZZZZZZZ.append(urljoin(base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8'), LLLLL.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'))))
        return (source, list(dict.fromkeys(ZZZZZZZZZZZZZZZZZZZZZZZZ)))

    def parse_subtitles(self, page):
        AaAaAaaaAaAaaaaAaaaAaaaAa = []
        aaaaAaaAaaAaaaAAaaAaa = self._first(bytes.fromhex('227375627469746c65225c732a3a5c732a22285b5e225d2b2922').decode('utf-8'), page)
        for iQkHaoJPUAIAdxDwyWgdpqMjmATNtMKNOLlowpKADvHAmUZyzlrekNdFBWDTwIUcFZtIzhknjHRknqJ10 in [aAaaAAaaaAaaAaAAAaaAaaAAaaa.strip() for aAaaAAaaaAaaAaAAAaaAaaAAaaa in aaaaAaaAaaAaaaAAaaAaa.split(bytes.fromhex('2c').decode('utf-8')) if aAaaAAaaaAaaAaAAAaaAaaAAaaa.strip()]:
            url = re.sub(bytes.fromhex('5c5b5b5e5c5d5d2b5c5d').decode('utf-8'), bytes.fromhex('').decode('utf-8'), iQkHaoJPUAIAdxDwyWgdpqMjmATNtMKNOLlowpKADvHAmUZyzlrekNdFBWDTwIUcFZtIzhknjHRknqJ10).strip()
            if url:
                AaAaAaaaAaAaaaaAaaaAaaaAa.append(self.normalize_url(url))
        if AaAaAaaaAaAaaaaAaaaAaaaAa:
            return AaAaAaaaAaAaaaaAaaaAaaaAa
        for subtitle in re.findall(bytes.fromhex('5b22275d66696c655b22275d5c732a3a5c732a5b22275d285b5e22275d2b295b22275d5b5e7b7d5d2b5b22275d6b696e645b22275d5c732a3a5c732a5b22275d63617074696f6e735b22275d').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            AaAaAaaaAaAaaaaAaaaAaaaAa.append(self.normalize_url(subtitle.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'))))
        return list(dict.fromkeys(AaAaAaaaAaAaaaaAaaaAaaaAa))

    def fetch(self, url, referer=None):
        lIIIlIlllllIl = None
        for l7 in self.CLIENT_IDENTIFIERS:
            if self.session.client_identifier != l7:
                self.session = manituxhttp.Session(client_identifier=l7)
            try:
                llIlIlIIIlIIlIlIlllIII = self.session.get(url, headers=self.headers(referer), timeout=25, allow_redirects=True, tls_client_identifier=l7)
                if llIlIlIIIlIIlIlIlllIII.status_code in (403, 429) and l7 != self.CLIENT_IDENTIFIERS[-1]:
                    lIIIlIlllllIl = manituxhttp.HTTPError(llIlIlIIIlIIlIlIlllIII)
                    continue
                llIlIlIIIlIIlIlIlllIII.raise_for_status()
                return llIlIlIIIlIIlIlIlllIII.text
            except (manituxhttp.HTTPError, manituxhttp.RequestError) as exc:
                lIIIlIlllllIl = exc
                if l7 == self.CLIENT_IDENTIFIERS[-1]:
                    raise
        raise lIIIlIlllllIl

    def headers(self, referer=None):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): self.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('746578742f68746d6c2c6170706c69636174696f6e2f7868746d6c2b786d6c2c6170706c69636174696f6e2f786d6c3b713d302e392c2a2f2a3b713d302e38').decode('utf-8')}
        if referer:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        return headers

    def kodi_headers(self, referer=None, extra=None):
        a = [bytes.fromhex('557365722d4167656e743d').decode('utf-8') + quote(self.user_agent)]
        if referer:
            a.append(bytes.fromhex('526566657265723d').decode('utf-8') + quote(referer))
        if extra:
            a.extend((bytes.fromhex('7b307d3d7b317d').decode('utf-8').format(UUUUUUUUUUU, quote(value)) for UUUUUUUUUUU, value in extra.items() if value))
        return bytes.fromhex('7c').decode('utf-8') + bytes.fromhex('26').decode('utf-8').join(a)

    def normalize_url(self, url):
        if not url:
            return bytes.fromhex('').decode('utf-8')
        url = url.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')).replace(bytes.fromhex('5c7530303236').decode('utf-8'), bytes.fromhex('26').decode('utf-8'))
        if url.startswith(bytes.fromhex('2f2f').decode('utf-8')):
            return bytes.fromhex('68747470733a').decode('utf-8') + url
        if url.startswith(bytes.fromhex('7777772e').decode('utf-8')):
            return bytes.fromhex('68747470733a2f2f').decode('utf-8') + url
        if not url.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8'))):
            return urljoin(self.main_url + bytes.fromhex('2f').decode('utf-8'), url)
        return url

    @staticmethod
    def is_youtube(url):
        AAaaAa = urlparse(url or bytes.fromhex('').decode('utf-8')).netloc.lower()
        return bytes.fromhex('796f7574756265').decode('utf-8') in AAaaAa or bytes.fromhex('796f7574752e6265').decode('utf-8') in AAaaAa

    @staticmethod
    def origin(url):
        IIIIIIIIIIIIIIIII = urlparse(url)
        return IIIIIIIIIIIIIIIII.scheme + bytes.fromhex('3a2f2f').decode('utf-8') + IIIIIIIIIIIIIIIII.netloc

    @staticmethod
    def _parse_js_list(value):
        HfvjLhRnCqIdAdRGLkUsPgNRgbUfMGFzqMHNBJLbnqvRpiIUhXOUUVdVeNYSfyYnQuLcPDHrROJECkL16 = value.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'))
        HfvjLhRnCqIdAdRGLkUsPgNRgbUfMGFzqMHNBJLbnqvRpiIUhXOUUVdVeNYSfyYnQuLcPDHrROJECkL16 = re.sub(bytes.fromhex('285b7b2c5d5c732a292866696c657c6c6162656c7c747970657c6b696e64295c732a3a').decode('utf-8'), bytes.fromhex('5c31225c32223a').decode('utf-8'), HfvjLhRnCqIdAdRGLkUsPgNRgbUfMGFzqMHNBJLbnqvRpiIUhXOUUVdVeNYSfyYnQuLcPDHrROJECkL16)
        HfvjLhRnCqIdAdRGLkUsPgNRgbUfMGFzqMHNBJLbnqvRpiIUhXOUUVdVeNYSfyYnQuLcPDHrROJECkL16 = HfvjLhRnCqIdAdRGLkUsPgNRgbUfMGFzqMHNBJLbnqvRpiIUhXOUUVdVeNYSfyYnQuLcPDHrROJECkL16.replace(bytes.fromhex('27').decode('utf-8'), bytes.fromhex('22').decode('utf-8'))
        HfvjLhRnCqIdAdRGLkUsPgNRgbUfMGFzqMHNBJLbnqvRpiIUhXOUUVdVeNYSfyYnQuLcPDHrROJECkL16 = re.sub(bytes.fromhex('2c5c732a285b5c5d7d5d29').decode('utf-8'), bytes.fromhex('5c31').decode('utf-8'), HfvjLhRnCqIdAdRGLkUsPgNRgbUfMGFzqMHNBJLbnqvRpiIUhXOUUVdVeNYSfyYnQuLcPDHrROJECkL16)
        try:
            data = json.loads(HfvjLhRnCqIdAdRGLkUsPgNRgbUfMGFzqMHNBJLbnqvRpiIUhXOUUVdVeNYSfyYnQuLcPDHrROJECkL16)
            return data if isinstance(data, list) else []
        except Exception:
            items = []
            for aA in re.findall(bytes.fromhex('5c7b282e2a3f295c7d').decode('utf-8'), value, re.S):
                iQkHaoJPUAIAdxDwyWgdpqMjmATNtMKNOLlowpKADvHAmUZyzlrekNdFBWDTwIUcFZtIzhknjHRknqJ10 = {}
                for UUUUUUUUUUU in (bytes.fromhex('66696c65').decode('utf-8'), bytes.fromhex('6c6162656c').decode('utf-8'), bytes.fromhex('74797065').decode('utf-8'), bytes.fromhex('6b696e64').decode('utf-8')):
                    iQkHaoJPUAIAdxDwyWgdpqMjmATNtMKNOLlowpKADvHAmUZyzlrekNdFBWDTwIUcFZtIzhknjHRknqJ10[UUUUUUUUUUU] = DiziPalExtractor._first(bytes.fromhex('5b22275d3f25735b22275d3f5c732a3a5c732a5b22275d285b5e22275d2b29').decode('utf-8') % UUUUUUUUUUU, aA)
                items.append(iQkHaoJPUAIAdxDwyWgdpqMjmATNtMKNOLlowpKADvHAmUZyzlrekNdFBWDTwIUcFZtIzhknjHRknqJ10)
            return items

    @staticmethod
    def _first(pattern, text, flags=0):
        aAaaAAAAaaaAAA = re.search(pattern, text or bytes.fromhex('').decode('utf-8'), flags | re.I)
        if not aAaaAAAAaaaAAA:
            return bytes.fromhex('').decode('utf-8')
        return aAaaAAAAaaaAAA.group(1) if aAaaAAAAaaaAAA.lastindex else aAaaAAAAaaaAAA.group(0)
