from __future__ import absolute_import, unicode_literals
import html
import re
try:
    from urllib.parse import urljoin
except ImportError:
    from urlparse import urljoin

def categories(base_url):
    base_url = base_url.rstrip(bytes.fromhex('2f').decode('utf-8'))
    return [(bytes.fromhex('41696c65').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f61696c652f706167652f').decode('utf-8')), (bytes.fromhex('416b7369796f6e').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f616b7369796f6e2f706167652f').decode('utf-8')), (bytes.fromhex('416e696d6173796f6e').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f616e696d6173796f6e2f706167652f').decode('utf-8')), (bytes.fromhex('42656c676573656c').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f62656c676573656c2f706167652f').decode('utf-8')), (bytes.fromhex('42696c696d204b75726775').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f62696c696d2d6b757267752f706167652f').decode('utf-8')), (bytes.fromhex('4472616d').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f6472616d2f706167652f').decode('utf-8')), (bytes.fromhex('46616e74617374696b').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f66616e74617374696b2f706167652f').decode('utf-8')), (bytes.fromhex('476572696c696d').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f676572696c696d2f706167652f').decode('utf-8')), (bytes.fromhex('47697a656d').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f67697a656d2f706167652f').decode('utf-8')), (bytes.fromhex('4b6f6d656469').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f6b6f6d6564692f706167652f').decode('utf-8')), (bytes.fromhex('4b6f726b75').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f6b6f726b752f706167652f').decode('utf-8')), (bytes.fromhex('4d6163657261').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f6d61636572612f706167652f').decode('utf-8')), (bytes.fromhex('4d757a696b').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f6d757a696b2f706167652f').decode('utf-8')), (bytes.fromhex('526f6d616e74696b').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f726f6d616e74696b2f706167652f').decode('utf-8')), (bytes.fromhex('5361766173').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f73617661732f706167652f').decode('utf-8')), (bytes.fromhex('537563').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f7375632f706167652f').decode('utf-8')), (bytes.fromhex('5461726968').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f74617269682f706167652f').decode('utf-8')), (bytes.fromhex('56616873692042617469').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f76616873692d626174692f706167652f').decode('utf-8')), (bytes.fromhex('5965726c69').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f7965726c692f706167652f').decode('utf-8'))]

def page_url(category_url, page_number):
    if int(page_number) <= 1:
        return category_url if not category_url.endswith(bytes.fromhex('2f706167652f').decode('utf-8')) else category_url + bytes.fromhex('312f').decode('utf-8')
    return category_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8') + str(page_number) + bytes.fromhex('2f').decode('utf-8') if category_url.endswith(bytes.fromhex('2f706167652f').decode('utf-8')) else category_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f706167652f7b307d2f').decode('utf-8').format(page_number)

def parse_page_items(page, base_url, category_title=bytes.fromhex('').decode('utf-8')):
    AaaAAAAAaAA = []
    IIlllIIlllllIlIllIl = set()
    for block in _post_blocks(page):
        l = _first(bytes.fromhex('3c615c625b5e3e5d2a687265663d5b275c225d5b5e275c225d2b5b275c225d5b5e3e5d2a3e').decode('utf-8'), block, re.S)
        gggggg = _attr(l, bytes.fromhex('68726566').decode('utf-8'))
        title = _clean(_attr(l, bytes.fromhex('7469746c65').decode('utf-8')) or _attr(_first(bytes.fromhex('3c696d675c625b5e3e5d2a3e').decode('utf-8'), block, re.S), bytes.fromhex('616c74').decode('utf-8')))
        HHHHHHHHHHHHHHHH = _poster_from(block, base_url)
        if not title or not gggggg:
            continue
        url = fix_url(gggggg, base_url)
        if url in IIlllIIlllllIlIllIl:
            continue
        IIlllIIlllllIlIllIl.add(url)
        AaaAAAAAaAA.append({bytes.fromhex('63617465676f7279').decode('utf-8'): category_title, bytes.fromhex('7469746c65').decode('utf-8'): clean_title(title), bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('696d616765').decode('utf-8'): HHHHHHHHHHHHHHHH, bytes.fromhex('706c6f74').decode('utf-8'): bytes.fromhex('').decode('utf-8')})
    return AaaAAAAAaAA

def parse_media_info(page, url, base_url):
    title = clean_title(_clean(_first(bytes.fromhex('3c6d61696e5c625b5e3e5d2a3e2e2a3f3c68315b5e3e5d2a3e282e2a3f293c2f68313e').decode('utf-8'), page, re.S)) or _clean(_first(bytes.fromhex('3c626f64795c625b5e3e5d2a3e2e2a3f3c68315b5e3e5d2a3e282e2a3f293c2f68313e').decode('utf-8'), page, re.S)) or _meta(page, bytes.fromhex('70726f7065727479').decode('utf-8'), bytes.fromhex('6f673a7469746c65').decode('utf-8')))
    HHHHHHHHHHHHHHHH = _meta(page, bytes.fromhex('70726f7065727479').decode('utf-8'), bytes.fromhex('6f673a696d616765').decode('utf-8')) or _poster_from(page, base_url)
    t15 = _meta(page, bytes.fromhex('70726f7065727479').decode('utf-8'), bytes.fromhex('6f673a6465736372697074696f6e').decode('utf-8')) or _meta(page, bytes.fromhex('6e616d65').decode('utf-8'), bytes.fromhex('6465736372697074696f6e').decode('utf-8'))
    G347042623404523 = _first(bytes.fromhex('5c62285c647b347d295c62').decode('utf-8'), _detail_value(page, bytes.fromhex('596170c4b16d2059c4b16cc4b1').decode('utf-8')))
    IllIlIlIIIIlIlIII = _detail_value(page, bytes.fromhex('494d4442205075616ec4b1').decode('utf-8'))
    AREefTRhhdavvQjluDAPYEyjulbeyyjxJienYbYqfUguapIAQwmVZwXjkCSeQsNdpIIlrEdbFJjCQif2 = parse_duration(_detail_value(page, bytes.fromhex('53c3bc7265').decode('utf-8')))
    sewdVDKPLlYBcCgEjixfjHFjqVspUuqJzlDVSnRKqwACWlhyvHmTvouKPRXBaKLcCmkDzeehbRtNhNT4 = parse_episodes(page, base_url)
    sources = parse_video_sources(page, url, base_url, bool(sewdVDKPLlYBcCgEjixfjHFjqVspUuqJzlDVSnRKqwACWlhyvHmTvouKPRXBaKLcCmkDzeehbRtNhNT4))
    IlllIIlIIllIlIIlIllIIl = find_trailer_url(page, base_url)
    if IlllIIlIIllIlIIlIllIIl:
        sources.insert(0, {bytes.fromhex('6c6162656c').decode('utf-8'): bytes.fromhex('467261676d616e').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): IlllIIlIIllIlIIlIllIIl, bytes.fromhex('72656665726572').decode('utf-8'): url, bytes.fromhex('69735f747261696c6572').decode('utf-8'): True})
    return {bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('696d616765').decode('utf-8'): fix_url(HHHHHHHHHHHHHHHH, base_url) if HHHHHHHHHHHHHHHH else bytes.fromhex('').decode('utf-8'), bytes.fromhex('706c6f74').decode('utf-8'): _clean(t15), bytes.fromhex('79656172').decode('utf-8'): G347042623404523, bytes.fromhex('726174696e67').decode('utf-8'): IllIlIlIIIIlIlIII, bytes.fromhex('6475726174696f6e').decode('utf-8'): AREefTRhhdavvQjluDAPYEyjulbeyyjxJienYbYqfUguapIAQwmVZwXjkCSeQsNdpIIlrEdbFJjCQif2, bytes.fromhex('74616773').decode('utf-8'): _meta_list(page, bytes.fromhex('54c3bc72').decode('utf-8')), bytes.fromhex('6163746f7273').decode('utf-8'): _meta_list(page, bytes.fromhex('4f79756e63756c6172').decode('utf-8')), bytes.fromhex('736f7572636573').decode('utf-8'): sources, bytes.fromhex('657069736f646573').decode('utf-8'): sewdVDKPLlYBcCgEjixfjHFjqVspUuqJzlDVSnRKqwACWlhyvHmTvouKPRXBaKLcCmkDzeehbRtNhNT4}

def parse_video_sources(page, page_url, base_url, has_episodes=False):
    if has_episodes:
        return []
    if bytes.fromhex('2f64697a692f').decode('utf-8') in (page_url or bytes.fromhex('').decode('utf-8')).lower() and bytes.fromhex('2f626f6c756d2f').decode('utf-8') not in (page_url or bytes.fromhex('').decode('utf-8')).lower():
        return []
    return [{bytes.fromhex('6c6162656c').decode('utf-8'): bytes.fromhex('4f796e6174').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): page_url, bytes.fromhex('72656665726572').decode('utf-8'): base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8'), bytes.fromhex('69735f747261696c6572').decode('utf-8'): False}]

def parse_episodes(page, base_url):
    sewdVDKPLlYBcCgEjixfjHFjqVspUuqJzlDVSnRKqwACWlhyvHmTvouKPRXBaKLcCmkDzeehbRtNhNT4 = []
    IIlllIIlllllIlIllIl = set()
    for block in re.findall(bytes.fromhex('3c6469765c625b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c62657069736f64652d6974656d5c625b5e225c275d2a5b225c275d5b5e3e5d2a3e2e2a3f283f3d3c6469765c625b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c62657069736f64652d6974656d5c627c2429').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
        l = _first(bytes.fromhex('3c615c625b5e3e5d2a687265663d5b275c225d5b5e275c225d2b5b275c225d5b5e3e5d2a3e').decode('utf-8'), block, re.S)
        gggggg = _attr(l, bytes.fromhex('68726566').decode('utf-8'))
        if not gggggg:
            continue
        W20 = _attr(l, bytes.fromhex('7469746c65').decode('utf-8'))
        aaaAAAAaAa = _attr(_first(bytes.fromhex('3c696d675c625b5e3e5d2a3e').decode('utf-8'), block, re.S), bytes.fromhex('616c74').decode('utf-8'))
        title = _clean(_first(bytes.fromhex('3c68345c625b5e3e5d2a3e2e2a3f3c615c625b5e3e5d2a3e282e2a3f293c2f613e').decode('utf-8'), block, re.S)) or aaaAAAAaAa or W20
        AAAaaAaAAAAAAaaAaa = _first(bytes.fromhex('285c642b295c2e5c732a53657a6f6e').decode('utf-8'), W20) or _first(bytes.fromhex('2f73657a6f6e2d3f285c642b29').decode('utf-8'), gggggg) or bytes.fromhex('30').decode('utf-8')
        wxeituMqmAruIKIqhrsoEKamLwdUTAnZFtzfMRUDmjwfKxQVfgNcNtnqKbQQBpPNVMBPIUVxFwzmIMN3 = _first(bytes.fromhex('285c642b295c2e5c732a425bc3b66f5d6c5bc3bc755d6d').decode('utf-8'), W20) or _first(bytes.fromhex('2f626f6c756d2d3f285c642b29').decode('utf-8'), gggggg) or bytes.fromhex('30').decode('utf-8')
        IIIIlIlIIllI = (AAAaaAaAAAAAAaaAaa, wxeituMqmAruIKIqhrsoEKamLwdUTAnZFtzfMRUDmjwfKxQVfgNcNtnqKbQQBpPNVMBPIUVxFwzmIMN3, gggggg)
        if IIIIlIlIIllI in IIlllIIlllllIlIllIl:
            continue
        IIlllIIlllllIlIllIl.add(IIIIlIlIIllI)
        sewdVDKPLlYBcCgEjixfjHFjqVspUuqJzlDVSnRKqwACWlhyvHmTvouKPRXBaKLcCmkDzeehbRtNhNT4.append({bytes.fromhex('7469746c65').decode('utf-8'): title or bytes.fromhex('7b307d2e2053657a6f6e207b317d2e20426f6c756d').decode('utf-8').format(AAAaaAaAAAAAAaaAaa, wxeituMqmAruIKIqhrsoEKamLwdUTAnZFtzfMRUDmjwfKxQVfgNcNtnqKbQQBpPNVMBPIUVxFwzmIMN3), bytes.fromhex('75726c').decode('utf-8'): fix_url(gggggg, base_url), bytes.fromhex('696d616765').decode('utf-8'): _poster_from(block, base_url), bytes.fromhex('736561736f6e').decode('utf-8'): AAAaaAaAAAAAAaaAaa, bytes.fromhex('657069736f6465').decode('utf-8'): wxeituMqmAruIKIqhrsoEKamLwdUTAnZFtzfMRUDmjwfKxQVfgNcNtnqKbQQBpPNVMBPIUVxFwzmIMN3})
    return sewdVDKPLlYBcCgEjixfjHFjqVspUuqJzlDVSnRKqwACWlhyvHmTvouKPRXBaKLcCmkDzeehbRtNhNT4

def find_trailer_url(page, base_url):
    source = _first(bytes.fromhex('3c6469765c625b5e3e5d2a69643d5b225c275d747261696c65722d696672616d652d736f757263655b225c275d5b5e3e5d2a3e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S)
    L14507704579808 = _attr(source, bytes.fromhex('646174612d696672616d65').decode('utf-8'))
    IlllIIlIIllIlIIlIllIIl = _attr(_first(bytes.fromhex('3c696672616d655c625b5e3e5d2a283f3a7372637c646174612d737263293d5b275c225d5b5e275c225d2b5b275c225d5b5e3e5d2a3e').decode('utf-8'), L14507704579808, re.S), bytes.fromhex('646174612d737263').decode('utf-8'))
    IlllIIlIIllIlIIlIllIIl = IlllIIlIIllIlIIlIllIIl or _attr(_first(bytes.fromhex('3c696672616d655c625b5e3e5d2a283f3a7372637c646174612d737263293d5b275c225d5b5e275c225d2b5b275c225d5b5e3e5d2a3e').decode('utf-8'), L14507704579808, re.S), bytes.fromhex('737263').decode('utf-8'))
    if IlllIIlIIllIlIIlIllIIl:
        return fix_url(IlllIIlIIllIlIIlIllIIl, base_url)
    q93678516959617 = _first(bytes.fromhex('3c696672616d655c625b5e3e5d2a283f3a7372637c646174612d737263293d5b225c275d5b5e225c275d2a283f3a796f75747562657c796f7574755c2e6265295b5e225c275d2b5b225c275d5b5e3e5d2a3e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S)
    IlllIIlIIllIlIIlIllIIl = _attr(q93678516959617, bytes.fromhex('646174612d737263').decode('utf-8')) or _attr(q93678516959617, bytes.fromhex('737263').decode('utf-8'))
    if IlllIIlIIllIlIIlIllIIl:
        return fix_url(IlllIIlIIllIlIIlIllIIl, base_url)
    tag = _first(bytes.fromhex('3c615c625b5e3e5d2a283f3a687265667c646174612d766964656f5f75726c293d5b275c225d5b5e275c225d2a283f3a796f75747562657c796f7574755c2e62657c667261676d616e295b5e275c225d2a5b275c225d5b5e3e5d2a3e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S)
    value = _attr(tag, bytes.fromhex('646174612d766964656f5f75726c').decode('utf-8')) or _attr(tag, bytes.fromhex('68726566').decode('utf-8'))
    return fix_url(value, base_url) if value else bytes.fromhex('').decode('utf-8')

def parse_iframe(page, base_url):
    q93678516959617 = _first(bytes.fromhex('3c5b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c627365726965732d706c617965722d636f6e7461696e65725c625b5e225c275d2a5b225c275d5b5e3e5d2a3e2e2a3f3c696672616d655c625b5e3e5d2a283f3a7372637c646174612d737263293d5b225c275d5b5e225c275d2b5b225c275d5b5e3e5d2a3e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S) or _first(bytes.fromhex('3c6469765b5e3e5d2a69643d5b225c275d766173745f6e65775b225c275d5b5e3e5d2a3e2e2a3f3c696672616d655c625b5e3e5d2a283f3a7372637c646174612d737263293d5b225c275d5b5e225c275d2b5b225c275d5b5e3e5d2a3e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S) or _first(bytes.fromhex('3c5b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c62766964656f2d706c617965722d617265615c625b5e225c275d2a5b225c275d5b5e3e5d2a3e2e2a3f3c696672616d655c625b5e3e5d2a283f3a7372637c646174612d737263293d5b225c275d5b5e225c275d2b5b225c275d5b5e3e5d2a3e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S) or _first(bytes.fromhex('3c5b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c62726573706f6e736976652d706c617965725c625b5e225c275d2a5b225c275d5b5e3e5d2a3e2e2a3f3c696672616d655c625b5e3e5d2a283f3a7372637c646174612d737263293d5b225c275d5b5e225c275d2b5b225c275d5b5e3e5d2a3e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S) or _first(bytes.fromhex('3c696672616d655c625b5e3e5d2a283f3a7372637c646174612d737263293d5b275c225d5b5e275c225d2b5b275c225d5b5e3e5d2a3e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S)
    return fix_url(_attr(q93678516959617, bytes.fromhex('646174612d737263').decode('utf-8')) or _attr(q93678516959617, bytes.fromhex('737263').decode('utf-8')), base_url)

def fix_url(url, base_url):
    if not url:
        return bytes.fromhex('').decode('utf-8')
    return urljoin(base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8'), html.unescape(url).strip())

def clean_title(value):
    value = _clean(value)
    value = re.sub(bytes.fromhex('5c732b697a6c655c732a2d5c732a44697a6970616c5c732a24').decode('utf-8'), bytes.fromhex('').decode('utf-8'), value, flags=re.I)
    value = re.sub(bytes.fromhex('5c732b2d5c732a44697a6970616c5c732a24').decode('utf-8'), bytes.fromhex('').decode('utf-8'), value, flags=re.I)
    return value.strip()

def parse_duration(value):
    IIlllllIlIIlIIIIIIIIl = 0
    h29789376562065 = _first(bytes.fromhex('285c642b295c732a73').decode('utf-8'), value)
    aaAAAaAaAAAAaA = _first(bytes.fromhex('285c642b295c732a646b').decode('utf-8'), value)
    if h29789376562065:
        IIlllllIlIIlIIIIIIIIl += int(h29789376562065) * 60
    if aaAAAaAaAAAAaA:
        IIlllllIlIIlIIIIIIIIl += int(aaAAAaAaAAAAaA)
    if IIlllllIlIIlIIIIIIIIl:
        return str(IIlllllIlIIlIIIIIIIIl)
    return _first(bytes.fromhex('285c642b29').decode('utf-8'), value)

def _post_blocks(page):
    return re.findall(bytes.fromhex('3c6469765c625b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c62706f73742d6974656d5c625b5e225c275d2a5b225c275d5b5e3e5d2a3e2e2a3f283f3d3c6469765c625b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c62706f73742d6974656d5c627c2429').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I)

def _poster_from(block, base_url):
    aAAAAaaaA = _first(bytes.fromhex('3c696d675c625b5e3e5d2a3e').decode('utf-8'), block or bytes.fromhex('').decode('utf-8'), re.S)
    HHHHHHHHHHHHHHHH = _attr(aAAAAaaaA, bytes.fromhex('646174612d737263').decode('utf-8')) or _attr(aAAAAaaaA, bytes.fromhex('737263').decode('utf-8'))
    return fix_url(HHHHHHHHHHHHHHHH, base_url) if HHHHHHHHHHHHHHHH and (not HHHHHHHHHHHHHHHH.lower().startswith(bytes.fromhex('646174613a696d616765').decode('utf-8'))) else bytes.fromhex('').decode('utf-8')

def _detail_value(page, label):
    for AaaAAaAaAAaAa in re.finditer(bytes.fromhex('3c7370616e5c625b5e3e5d2a3e282e2a3f293c2f7370616e3e283f503c7461696c3e2e7b302c3430307d29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
        if _clean(AaaAAaAaAAaAa.group(1)).lower() == label.lower():
            return _clean(AaaAAaAaAAaAa.group(bytes.fromhex('7461696c').decode('utf-8')).split(bytes.fromhex('3c2f').decode('utf-8'), 1)[0])
    return bytes.fromhex('').decode('utf-8')

def _meta_list(page, label):
    value = _detail_value(page, label)
    return re.sub(bytes.fromhex('5e7b307d5c732a').decode('utf-8').format(re.escape(label)), bytes.fromhex('').decode('utf-8'), value, flags=re.I).strip()

def _meta(page, attr_name, attr_value):
    pattern = bytes.fromhex('3c6d6574615c625b5e3e5d2a5c627b307d3d5b225c275d7b317d5b225c275d5b5e3e5d2a3e').decode('utf-8').format(re.escape(attr_name), re.escape(attr_value))
    tag = _first(pattern, page or bytes.fromhex('').decode('utf-8'), re.S)
    return _attr(tag, bytes.fromhex('636f6e74656e74').decode('utf-8'))

def _attr(tag, name):
    if not tag:
        return bytes.fromhex('').decode('utf-8')
    AaaAAaAaAAaAa = re.search(bytes.fromhex('5c627b307d3d5b225c275d285b5e225c275d2b295b225c275d').decode('utf-8').format(re.escape(name)), tag, re.I)
    return html.unescape(AaaAAaAaAAaAa.group(1)) if AaaAAaAaAAaAa else bytes.fromhex('').decode('utf-8')

def _first(pattern, text, flags=0):
    AaaAAaAaAAaAa = re.search(pattern, text or bytes.fromhex('').decode('utf-8'), flags | re.I)
    if not AaaAAaAaAAaAa:
        return bytes.fromhex('').decode('utf-8')
    return AaaAAaAaAAaAa.group(1) if AaaAAaAaAAaAa.lastindex else AaaAAaAaAAaAa.group(0)

def _clean(text):
    text = re.sub(bytes.fromhex('3c7363726970742e2a3f3c2f7363726970743e').decode('utf-8'), bytes.fromhex('20').decode('utf-8'), text or bytes.fromhex('').decode('utf-8'), flags=re.S | re.I)
    text = re.sub(bytes.fromhex('3c7376672e2a3f3c2f7376673e').decode('utf-8'), bytes.fromhex('20').decode('utf-8'), text, flags=re.S | re.I)
    text = re.sub(bytes.fromhex('3c5b5e3e5d2b3e').decode('utf-8'), bytes.fromhex('20').decode('utf-8'), text)
    text = html.unescape(text)
    return re.sub(bytes.fromhex('5c732b').decode('utf-8'), bytes.fromhex('20').decode('utf-8'), text).strip()
