from __future__ import absolute_import, unicode_literals
import json
import re
import manituxhttp
try:
    from urllib.parse import quote, urljoin, urlparse
except ImportError:
    from urllib import quote
    from urlparse import urljoin, urlparse
from . import parsers

class DiziPalExtractor(object):
    CLIENT_IDENTIFIERS = (bytes.fromhex('636c6f756473637261706572').decode('utf-8'), bytes.fromhex('6368726f6d655f313434').decode('utf-8'))

    def __init__(llIl, user_agent, main_url):
        llIl.user_agent = user_agent
        llIl.main_url = main_url.rstrip(bytes.fromhex('2f').decode('utf-8'))
        llIl.session = manituxhttp.Session(client_identifier=llIl.CLIENT_IDENTIFIERS[0])

    def resolve(llIl, url, referer=None, label=bytes.fromhex('').decode('utf-8')):
        if not url:
            return (None, [])
        url = llIl.normalize_url(url)
        page = llIl.fetch(url, referer or llIl.main_url + bytes.fromhex('2f').decode('utf-8'))
        lII = parsers.parse_iframe(page, llIl.main_url)
        if not lII:
            source, llll = llIl.extract_jwplayer(page, llIl.origin(url))
            return (source + llIl.kodi_headers(url) if source else None, llll)
        lII = llIl.normalize_url(lII)
        if llIl.is_youtube(lII):
            return (lII + llIl.kodi_headers(referer), [])
        if bytes.fromhex('766964656f736579726564').decode('utf-8') in urlparse(lII).netloc.lower():
            return llIl.resolve_videoseyred(lII)
        lIl = llIl.fetch(lII, llIl.main_url + bytes.fromhex('2f').decode('utf-8'))
        source = llIl.resolve_fetch_stream(lIl, lII)
        if not source:
            source = llIl._first(bytes.fromhex('66696c655c732a3a5c732a5b22275d285b5e22275d2b29').decode('utf-8'), lIl)
        if not source:
            source, llll = llIl.extract_jwplayer(lIl, llIl.origin(lII))
        else:
            llll = llIl.parse_subtitles(lIl)
        if not source:
            source = llIl._first(bytes.fromhex('68747470733f3a2f2f5b5e5c7322273c3e5d2b3f5c2e283f3a6d3375387c6d703429283f3a5c3f5b5e5c7322273c3e5d2a293f').decode('utf-8'), lIl)
        return (llIl.normalize_url(source) + llIl.kodi_headers(lII, {bytes.fromhex('4f726967696e').decode('utf-8'): llIl.origin(lII)}) if source else None, llll)

    def resolve_fetch_stream(llIl, page, llI):
        IllI = bytes.fromhex('').decode('utf-8')
        for II in re.findall(bytes.fromhex('66657463685c285c732a5b22275d285b5e22275d2b295b22275d').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.I):
            if bytes.fromhex('2f646c3f6f703d6765745f73747265616d').decode('utf-8') in II:
                IllI = II
                break
        if not IllI:
            return bytes.fromhex('').decode('utf-8')
        lllI = urljoin(llIl.origin(llI) + bytes.fromhex('2f').decode('utf-8'), IllI.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')))
        lI = llIl.fetch_stream_json(lllI, llI, page)
        return (lI.get(bytes.fromhex('75726c').decode('utf-8')) or bytes.fromhex('').decode('utf-8')).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')) if isinstance(lI, dict) else bytes.fromhex('').decode('utf-8')

    def fetch_stream_json(llIl, url, referer, page):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): llIl.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('2a2f2a').decode('utf-8'), bytes.fromhex('52656665726572').decode('utf-8'): referer, bytes.fromhex('4f726967696e').decode('utf-8'): llIl.origin(referer), bytes.fromhex('582d5265717565737465642d57697468').decode('utf-8'): bytes.fromhex('584d4c4874747052657175657374').decode('utf-8'), bytes.fromhex('5365632d46657463682d53697465').decode('utf-8'): bytes.fromhex('73616d652d6f726967696e').decode('utf-8'), bytes.fromhex('5365632d46657463682d4d6f6465').decode('utf-8'): bytes.fromhex('636f7273').decode('utf-8'), bytes.fromhex('5365632d46657463682d44657374').decode('utf-8'): bytes.fromhex('656d707479').decode('utf-8')}
        Il = llIl.parse_js_cookies(page)
        if Il:
            headers[bytes.fromhex('436f6f6b6965').decode('utf-8')] = Il
        IIIl = None
        for Ill in (bytes.fromhex('6368726f6d655f313434').decode('utf-8'), bytes.fromhex('636c6f756473637261706572').decode('utf-8')):
            try:
                llII = llIl.session.get(url, headers=headers, timeout=25, allow_redirects=True, tls_client_identifier=Ill)
                llII.raise_for_status()
                lI = json.loads(llII.text)
                if lI.get(bytes.fromhex('75726c').decode('utf-8')):
                    return lI
                IIIl = manituxhttp.HTTPError(llII)
            except (ValueError, manituxhttp.HTTPError, manituxhttp.RequestError) as exc:
                IIIl = exc
        if IIIl:
            raise IIIl
        return {}

    @staticmethod
    def parse_js_cookies(page):
        Il = []
        for IIll, IIIll in re.findall(bytes.fromhex('5c245c2e636f6f6b69655c285b22275d285b5e22275d2b295b22275d5c732a2c5c732a5b22275d285b5e22275d2b29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.I):
            Il.append(bytes.fromhex('7b307d3d7b317d').decode('utf-8').format(IIll, IIIll))
        return bytes.fromhex('3b20').decode('utf-8').join(Il)

    def resolve_videoseyred(llIl, url):
        IIlII = llIl._first(bytes.fromhex('2f656d6265642f285b5e2f3f235d2b29').decode('utf-8'), url)
        if not IIlII:
            return (None, [])
        lIlI = llIl.origin(url) + bytes.fromhex('2f706c61796c6973742f').decode('utf-8') + IIlII + bytes.fromhex('2e6a736f6e').decode('utf-8')
        lIII = llIl.fetch(lIlI, llIl.origin(url) + bytes.fromhex('2f').decode('utf-8'))
        try:
            lIIl = json.loads(lIII)
        except Exception:
            lIIl = []
        item = lIIl[0] if lIIl else {}
        sources = item.get(bytes.fromhex('736f7572636573').decode('utf-8')) or []
        source = bytes.fromhex('').decode('utf-8')
        for II in sources:
            source = II.get(bytes.fromhex('66696c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
            if source:
                break
        IIIIl = []
        for IIIlI in item.get(bytes.fromhex('747261636b73').decode('utf-8')) or []:
            if (IIIlI.get(bytes.fromhex('6b696e64').decode('utf-8')) or bytes.fromhex('').decode('utf-8')).lower() == bytes.fromhex('63617074696f6e73').decode('utf-8') and IIIlI.get(bytes.fromhex('66696c65').decode('utf-8')):
                IIIIl.append(urljoin(llIl.origin(url) + bytes.fromhex('2f').decode('utf-8'), IIIlI[bytes.fromhex('66696c65').decode('utf-8')]))
        return (source + llIl.kodi_headers(llIl.origin(url) + bytes.fromhex('2f').decode('utf-8')) if source else None, IIIIl)

    def extract_jwplayer(llIl, page, base_url):
        source = bytes.fromhex('').decode('utf-8')
        llll = []
        for lIll in re.findall(bytes.fromhex('5b22275d3f736f75726365735b22275d3f5c732a3a5c732a285c5b2e2a3f5c5d29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            for item in llIl._parse_js_list(lIll):
                source = item.get(bytes.fromhex('66696c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
                if source:
                    source = urljoin(base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8'), source.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')))
                    break
            if source:
                break
        for lIll in re.findall(bytes.fromhex('5b22275d3f747261636b735b22275d3f5c732a3a5c732a285c5b2e2a3f5c5d29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            for item in llIl._parse_js_list(lIll):
                IIII = (item.get(bytes.fromhex('6b696e64').decode('utf-8')) or bytes.fromhex('').decode('utf-8')).lower()
                III = item.get(bytes.fromhex('66696c65').decode('utf-8'))
                if III and (bytes.fromhex('63617074696f6e').decode('utf-8') in IIII or bytes.fromhex('7375627469746c65').decode('utf-8') in IIII):
                    llll.append(urljoin(base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8'), III.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'))))
        return (source, list(dict.fromkeys(llll)))

    def parse_subtitles(llIl, page):
        IIIIl = []
        lIll = llIl._first(bytes.fromhex('227375627469746c65225c732a3a5c732a22285b5e225d2b2922').decode('utf-8'), page)
        for item in [IIlIl.strip() for IIlIl in lIll.split(bytes.fromhex('2c').decode('utf-8')) if IIlIl.strip()]:
            url = re.sub(bytes.fromhex('5c5b5b5e5c5d5d2b5c5d').decode('utf-8'), bytes.fromhex('').decode('utf-8'), item).strip()
            if url:
                IIIIl.append(llIl.normalize_url(url))
        if IIIIl:
            return IIIIl
        for IIIII in re.findall(bytes.fromhex('5b22275d66696c655b22275d5c732a3a5c732a5b22275d285b5e22275d2b295b22275d5b5e7b7d5d2b5b22275d6b696e645b22275d5c732a3a5c732a5b22275d63617074696f6e735b22275d').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            IIIIl.append(llIl.normalize_url(IIIII.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'))))
        return list(dict.fromkeys(IIIIl))

    def fetch(llIl, url, referer=None):
        IIIl = None
        for Ill in llIl.CLIENT_IDENTIFIERS:
            if llIl.session.client_identifier != Ill:
                llIl.session = manituxhttp.Session(client_identifier=Ill)
            try:
                llII = llIl.session.get(url, headers=llIl.headers(referer), timeout=25, allow_redirects=True, tls_client_identifier=Ill)
                if llII.status_code in (403, 429) and Ill != llIl.CLIENT_IDENTIFIERS[-1]:
                    IIIl = manituxhttp.HTTPError(llII)
                    continue
                llII.raise_for_status()
                return llII.text
            except (manituxhttp.HTTPError, manituxhttp.RequestError) as exc:
                IIIl = exc
                if Ill == llIl.CLIENT_IDENTIFIERS[-1]:
                    raise
        raise IIIl

    def headers(llIl, referer=None):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): llIl.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('746578742f68746d6c2c6170706c69636174696f6e2f7868746d6c2b786d6c2c6170706c69636174696f6e2f786d6c3b713d302e392c2a2f2a3b713d302e38').decode('utf-8')}
        if referer:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        return headers

    def kodi_headers(llIl, referer=None, ll=None):
        I = [bytes.fromhex('557365722d4167656e743d').decode('utf-8') + quote(llIl.user_agent)]
        if referer:
            I.append(bytes.fromhex('526566657265723d').decode('utf-8') + quote(referer))
        if ll:
            I.extend((bytes.fromhex('7b307d3d7b317d').decode('utf-8').format(lll, quote(IIIll)) for lll, IIIll in ll.items() if IIIll))
        return bytes.fromhex('7c').decode('utf-8') + bytes.fromhex('26').decode('utf-8').join(I)

    def normalize_url(llIl, url):
        if not url:
            return bytes.fromhex('').decode('utf-8')
        url = url.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')).replace(bytes.fromhex('5c7530303236').decode('utf-8'), bytes.fromhex('26').decode('utf-8'))
        if url.startswith(bytes.fromhex('2f2f').decode('utf-8')):
            return bytes.fromhex('68747470733a').decode('utf-8') + url
        if url.startswith(bytes.fromhex('7777772e').decode('utf-8')):
            return bytes.fromhex('68747470733a2f2f').decode('utf-8') + url
        if not url.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8'))):
            return urljoin(llIl.main_url + bytes.fromhex('2f').decode('utf-8'), url)
        return url

    @staticmethod
    def is_youtube(url):
        IlI = urlparse(url or bytes.fromhex('').decode('utf-8')).netloc.lower()
        return bytes.fromhex('796f7574756265').decode('utf-8') in IlI or bytes.fromhex('796f7574752e6265').decode('utf-8') in IlI

    @staticmethod
    def origin(url):
        IlIl = urlparse(url)
        return IlIl.scheme + bytes.fromhex('3a2f2f').decode('utf-8') + IlIl.netloc

    @staticmethod
    def _parse_js_list(IIIll):
        IlII = IIIll.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'))
        IlII = re.sub(bytes.fromhex('285b7b2c5d5c732a292866696c657c6c6162656c7c747970657c6b696e64295c732a3a').decode('utf-8'), bytes.fromhex('5c31225c32223a').decode('utf-8'), IlII)
        IlII = IlII.replace(bytes.fromhex('27').decode('utf-8'), bytes.fromhex('22').decode('utf-8'))
        IlII = re.sub(bytes.fromhex('2c5c732a285b5c5d7d5d29').decode('utf-8'), bytes.fromhex('5c31').decode('utf-8'), IlII)
        try:
            lI = json.loads(IlII)
            return lI if isinstance(lI, list) else []
        except Exception:
            items = []
            for l in re.findall(bytes.fromhex('5c7b282e2a3f295c7d').decode('utf-8'), IIIll, re.S):
                item = {}
                for lll in (bytes.fromhex('66696c65').decode('utf-8'), bytes.fromhex('6c6162656c').decode('utf-8'), bytes.fromhex('74797065').decode('utf-8'), bytes.fromhex('6b696e64').decode('utf-8')):
                    item[lll] = DiziPalExtractor._first(bytes.fromhex('5b22275d3f25735b22275d3f5c732a3a5c732a5b22275d285b5e22275d2b29').decode('utf-8') % lll, l)
                items.append(item)
            return items

    @staticmethod
    def _first(Illl, text, IIl=0):
        IIlI = re.search(Illl, text or bytes.fromhex('').decode('utf-8'), IIl | re.I)
        if not IIlI:
            return bytes.fromhex('').decode('utf-8')
        return IIlI.group(1) if IIlI.lastindex else IIlI.group(0)
