from __future__ import absolute_import, unicode_literals
import html
import re
try:
    from urllib.parse import urljoin
except ImportError:
    from urlparse import urljoin

def categories(base_url):
    base_url = base_url.rstrip(bytes.fromhex('2f').decode('utf-8'))
    return [(bytes.fromhex('41696c65').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f61696c652f706167652f').decode('utf-8')), (bytes.fromhex('416b7369796f6e').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f616b7369796f6e2f706167652f').decode('utf-8')), (bytes.fromhex('416e696d6173796f6e').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f616e696d6173796f6e2f706167652f').decode('utf-8')), (bytes.fromhex('42656c676573656c').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f62656c676573656c2f706167652f').decode('utf-8')), (bytes.fromhex('42696c696d204b75726775').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f62696c696d2d6b757267752f706167652f').decode('utf-8')), (bytes.fromhex('4472616d').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f6472616d2f706167652f').decode('utf-8')), (bytes.fromhex('46616e74617374696b').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f66616e74617374696b2f706167652f').decode('utf-8')), (bytes.fromhex('476572696c696d').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f676572696c696d2f706167652f').decode('utf-8')), (bytes.fromhex('47697a656d').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f67697a656d2f706167652f').decode('utf-8')), (bytes.fromhex('4b6f6d656469').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f6b6f6d6564692f706167652f').decode('utf-8')), (bytes.fromhex('4b6f726b75').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f6b6f726b752f706167652f').decode('utf-8')), (bytes.fromhex('4d6163657261').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f6d61636572612f706167652f').decode('utf-8')), (bytes.fromhex('4d757a696b').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f6d757a696b2f706167652f').decode('utf-8')), (bytes.fromhex('526f6d616e74696b').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f726f6d616e74696b2f706167652f').decode('utf-8')), (bytes.fromhex('5361766173').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f73617661732f706167652f').decode('utf-8')), (bytes.fromhex('537563').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f7375632f706167652f').decode('utf-8')), (bytes.fromhex('5461726968').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f74617269682f706167652f').decode('utf-8')), (bytes.fromhex('56616873692042617469').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f76616873692d626174692f706167652f').decode('utf-8')), (bytes.fromhex('5965726c69').decode('utf-8'), base_url + bytes.fromhex('2f6b617465676f72692f7965726c692f706167652f').decode('utf-8'))]

def page_url(lll, page_number):
    if int(page_number) <= 1:
        return lll[:-len(bytes.fromhex('706167652f').decode('utf-8'))] if lll.endswith(bytes.fromhex('2f706167652f').decode('utf-8')) else lll
    return lll.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8') + str(page_number) + bytes.fromhex('2f').decode('utf-8') if lll.endswith(bytes.fromhex('2f706167652f').decode('utf-8')) else lll.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f706167652f7b307d2f').decode('utf-8').format(page_number)

def parse_page_items(page, base_url, llI=bytes.fromhex('').decode('utf-8')):
    Illl = []
    llll = set()
    for lIl in III(page):
        IlI = Il(bytes.fromhex('3c615c625b5e3e5d2a687265663d5b275c225d5b5e275c225d2b5b275c225d5b5e3e5d2a3e').decode('utf-8'), lIl, re.S)
        IIlI = I(IlI, bytes.fromhex('68726566').decode('utf-8'))
        title = l(I(IlI, bytes.fromhex('7469746c65').decode('utf-8')) or I(Il(bytes.fromhex('3c696d675c625b5e3e5d2a3e').decode('utf-8'), lIl, re.S), bytes.fromhex('616c74').decode('utf-8')))
        llIl = IIl(lIl, base_url)
        if not title or not IIlI:
            continue
        url = fix_url(IIlI, base_url)
        if url in llll:
            continue
        llll.add(url)
        Illl.append({bytes.fromhex('63617465676f7279').decode('utf-8'): llI, bytes.fromhex('7469746c65').decode('utf-8'): clean_title(title), bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('696d616765').decode('utf-8'): llIl, bytes.fromhex('706c6f74').decode('utf-8'): bytes.fromhex('').decode('utf-8')})
    return Illl

def parse_media_info(page, url, base_url):
    title = clean_title(l(Il(bytes.fromhex('3c6d61696e5c625b5e3e5d2a3e2e2a3f3c68315b5e3e5d2a3e282e2a3f293c2f68313e').decode('utf-8'), page, re.S)) or l(Il(bytes.fromhex('3c626f64795c625b5e3e5d2a3e2e2a3f3c68315b5e3e5d2a3e282e2a3f293c2f68313e').decode('utf-8'), page, re.S)) or lI(page, bytes.fromhex('70726f7065727479').decode('utf-8'), bytes.fromhex('6f673a7469746c65').decode('utf-8')))
    llIl = lI(page, bytes.fromhex('70726f7065727479').decode('utf-8'), bytes.fromhex('6f673a696d616765').decode('utf-8')) or IIl(page, base_url)
    plot = lI(page, bytes.fromhex('70726f7065727479').decode('utf-8'), bytes.fromhex('6f673a6465736372697074696f6e').decode('utf-8')) or lI(page, bytes.fromhex('6e616d65').decode('utf-8'), bytes.fromhex('6465736372697074696f6e').decode('utf-8'))
    year = Il(bytes.fromhex('5c62285c647b347d295c62').decode('utf-8'), II(page, bytes.fromhex('596170c4b16d2059c4b16cc4b1').decode('utf-8')))
    rating = II(page, bytes.fromhex('494d4442205075616ec4b1').decode('utf-8'))
    duration = parse_duration(II(page, bytes.fromhex('53c3bc7265').decode('utf-8')))
    episodes = parse_episodes(page, base_url)
    sources = parse_video_sources(page, url, base_url, bool(episodes))
    IIlII = find_trailer_url(page, base_url)
    if IIlII:
        sources.insert(0, {bytes.fromhex('6c6162656c').decode('utf-8'): bytes.fromhex('467261676d616e').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): IIlII, bytes.fromhex('72656665726572').decode('utf-8'): url, bytes.fromhex('69735f747261696c6572').decode('utf-8'): True})
    return {bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('696d616765').decode('utf-8'): fix_url(llIl, base_url) if llIl else bytes.fromhex('').decode('utf-8'), bytes.fromhex('706c6f74').decode('utf-8'): l(plot), bytes.fromhex('79656172').decode('utf-8'): year, bytes.fromhex('726174696e67').decode('utf-8'): rating, bytes.fromhex('6475726174696f6e').decode('utf-8'): duration, bytes.fromhex('74616773').decode('utf-8'): ll(page, bytes.fromhex('54c3bc72').decode('utf-8')), bytes.fromhex('6163746f7273').decode('utf-8'): ll(page, bytes.fromhex('4f79756e63756c6172').decode('utf-8')), bytes.fromhex('736f7572636573').decode('utf-8'): sources, bytes.fromhex('657069736f646573').decode('utf-8'): episodes}

def parse_video_sources(page, page_url, base_url, IIII=False):
    if IIII:
        return []
    if bytes.fromhex('2f64697a692f').decode('utf-8') in (page_url or bytes.fromhex('').decode('utf-8')).lower() and bytes.fromhex('2f626f6c756d2f').decode('utf-8') not in (page_url or bytes.fromhex('').decode('utf-8')).lower():
        return []
    return [{bytes.fromhex('6c6162656c').decode('utf-8'): bytes.fromhex('4f796e6174').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): page_url, bytes.fromhex('72656665726572').decode('utf-8'): base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8'), bytes.fromhex('69735f747261696c6572').decode('utf-8'): False}]

def parse_episodes(page, base_url):
    episodes = []
    llll = set()
    for lIl in re.findall(bytes.fromhex('3c6469765c625b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c62657069736f64652d6974656d5c625b5e225c275d2a5b225c275d5b5e3e5d2a3e2e2a3f283f3d3c6469765c625b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c62657069736f64652d6974656d5c627c2429').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
        IlI = Il(bytes.fromhex('3c615c625b5e3e5d2a687265663d5b275c225d5b5e275c225d2b5b275c225d5b5e3e5d2a3e').decode('utf-8'), lIl, re.S)
        IIlI = I(IlI, bytes.fromhex('68726566').decode('utf-8'))
        if not IIlI:
            continue
        IIIlI = I(IlI, bytes.fromhex('7469746c65').decode('utf-8'))
        IllI = I(Il(bytes.fromhex('3c696d675c625b5e3e5d2a3e').decode('utf-8'), lIl, re.S), bytes.fromhex('616c74').decode('utf-8'))
        title = l(Il(bytes.fromhex('3c68345c625b5e3e5d2a3e2e2a3f3c615c625b5e3e5d2a3e282e2a3f293c2f613e').decode('utf-8'), lIl, re.S)) or IllI or IIIlI
        lllI = Il(bytes.fromhex('285c642b295c2e5c732a53657a6f6e').decode('utf-8'), IIIlI) or Il(bytes.fromhex('2f73657a6f6e2d3f285c642b29').decode('utf-8'), IIlI) or bytes.fromhex('30').decode('utf-8')
        episode = Il(bytes.fromhex('285c642b295c2e5c732a425bc3b66f5d6c5bc3bc755d6d').decode('utf-8'), IIIlI) or Il(bytes.fromhex('2f626f6c756d2d3f285c642b29').decode('utf-8'), IIlI) or bytes.fromhex('30').decode('utf-8')
        lIII = (lllI, episode, IIlI)
        if lIII in llll:
            continue
        llll.add(lIII)
        episodes.append({bytes.fromhex('7469746c65').decode('utf-8'): title or bytes.fromhex('7b307d2e2053657a6f6e207b317d2e20426f6c756d').decode('utf-8').format(lllI, episode), bytes.fromhex('75726c').decode('utf-8'): fix_url(IIlI, base_url), bytes.fromhex('696d616765').decode('utf-8'): IIl(lIl, base_url), bytes.fromhex('736561736f6e').decode('utf-8'): lllI, bytes.fromhex('657069736f6465').decode('utf-8'): episode})
    return episodes

def find_trailer_url(page, base_url):
    source = Il(bytes.fromhex('3c6469765c625b5e3e5d2a69643d5b225c275d747261696c65722d696672616d652d736f757263655b225c275d5b5e3e5d2a3e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S)
    IlII = I(source, bytes.fromhex('646174612d696672616d65').decode('utf-8'))
    IIlII = I(Il(bytes.fromhex('3c696672616d655c625b5e3e5d2a283f3a7372637c646174612d737263293d5b275c225d5b5e275c225d2b5b275c225d5b5e3e5d2a3e').decode('utf-8'), IlII, re.S), bytes.fromhex('646174612d737263').decode('utf-8'))
    IIlII = IIlII or I(Il(bytes.fromhex('3c696672616d655c625b5e3e5d2a283f3a7372637c646174612d737263293d5b275c225d5b5e275c225d2b5b275c225d5b5e3e5d2a3e').decode('utf-8'), IlII, re.S), bytes.fromhex('737263').decode('utf-8'))
    if IIlII:
        return fix_url(IIlII, base_url)
    IIll = Il(bytes.fromhex('3c696672616d655c625b5e3e5d2a283f3a7372637c646174612d737263293d5b225c275d5b5e225c275d2a283f3a796f75747562657c796f7574755c2e6265295b5e225c275d2b5b225c275d5b5e3e5d2a3e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S)
    IIlII = I(IIll, bytes.fromhex('646174612d737263').decode('utf-8')) or I(IIll, bytes.fromhex('737263').decode('utf-8'))
    if IIlII:
        return fix_url(IIlII, base_url)
    IIIII = Il(bytes.fromhex('3c615c625b5e3e5d2a283f3a687265667c646174612d766964656f5f75726c293d5b275c225d5b5e275c225d2a283f3a796f75747562657c796f7574755c2e62657c667261676d616e295b5e275c225d2a5b275c225d5b5e3e5d2a3e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S)
    IIlIl = I(IIIII, bytes.fromhex('646174612d766964656f5f75726c').decode('utf-8')) or I(IIIII, bytes.fromhex('68726566').decode('utf-8'))
    return fix_url(IIlIl, base_url) if IIlIl else bytes.fromhex('').decode('utf-8')

def parse_iframe(page, base_url):
    IIll = Il(bytes.fromhex('3c5b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c627365726965732d706c617965722d636f6e7461696e65725c625b5e225c275d2a5b225c275d5b5e3e5d2a3e2e2a3f3c696672616d655c625b5e3e5d2a283f3a7372637c646174612d737263293d5b225c275d5b5e225c275d2b5b225c275d5b5e3e5d2a3e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S) or Il(bytes.fromhex('3c6469765b5e3e5d2a69643d5b225c275d766173745f6e65775b225c275d5b5e3e5d2a3e2e2a3f3c696672616d655c625b5e3e5d2a283f3a7372637c646174612d737263293d5b225c275d5b5e225c275d2b5b225c275d5b5e3e5d2a3e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S) or Il(bytes.fromhex('3c5b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c62766964656f2d706c617965722d617265615c625b5e225c275d2a5b225c275d5b5e3e5d2a3e2e2a3f3c696672616d655c625b5e3e5d2a283f3a7372637c646174612d737263293d5b225c275d5b5e225c275d2b5b225c275d5b5e3e5d2a3e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S) or Il(bytes.fromhex('3c5b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c62726573706f6e736976652d706c617965725c625b5e225c275d2a5b225c275d5b5e3e5d2a3e2e2a3f3c696672616d655c625b5e3e5d2a283f3a7372637c646174612d737263293d5b225c275d5b5e225c275d2b5b225c275d5b5e3e5d2a3e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S) or Il(bytes.fromhex('3c696672616d655c625b5e3e5d2a283f3a7372637c646174612d737263293d5b275c225d5b5e275c225d2b5b275c225d5b5e3e5d2a3e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S)
    return fix_url(I(IIll, bytes.fromhex('646174612d737263').decode('utf-8')) or I(IIll, bytes.fromhex('737263').decode('utf-8')), base_url)

def fix_url(url, base_url):
    if not url:
        return bytes.fromhex('').decode('utf-8')
    return urljoin(base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8'), html.unescape(url).strip())

def clean_title(IIlIl):
    IIlIl = l(IIlIl)
    IIlIl = re.sub(bytes.fromhex('5c732b697a6c655c732a2d5c732a44697a6970616c5c732a24').decode('utf-8'), bytes.fromhex('').decode('utf-8'), IIlIl, flags=re.I)
    IIlIl = re.sub(bytes.fromhex('5c732b2d5c732a44697a6970616c5c732a24').decode('utf-8'), bytes.fromhex('').decode('utf-8'), IIlIl, flags=re.I)
    return IIlIl.strip()

def parse_duration(IIlIl):
    IIIll = 0
    IIIl = Il(bytes.fromhex('285c642b295c732a73').decode('utf-8'), IIlIl)
    lIlI = Il(bytes.fromhex('285c642b295c732a646b').decode('utf-8'), IIlIl)
    if IIIl:
        IIIll += int(IIIl) * 60
    if lIlI:
        IIIll += int(lIlI)
    if IIIll:
        return str(IIIll)
    return Il(bytes.fromhex('285c642b29').decode('utf-8'), IIlIl)

def III(page):
    return re.findall(bytes.fromhex('3c6469765c625b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c62706f73742d6974656d5c625b5e225c275d2a5b225c275d5b5e3e5d2a3e2e2a3f283f3d3c6469765c625b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c62706f73742d6974656d5c627c2429').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I)

def IIl(lIl, base_url):
    IlIl = Il(bytes.fromhex('3c696d675c625b5e3e5d2a3e').decode('utf-8'), lIl or bytes.fromhex('').decode('utf-8'), re.S)
    llIl = I(IlIl, bytes.fromhex('646174612d737263').decode('utf-8')) or I(IlIl, bytes.fromhex('737263').decode('utf-8'))
    return fix_url(llIl, base_url) if llIl and (not llIl.lower().startswith(bytes.fromhex('646174613a696d616765').decode('utf-8'))) else bytes.fromhex('').decode('utf-8')

def II(page, label):
    for lIIl in re.finditer(bytes.fromhex('3c7370616e5c625b5e3e5d2a3e282e2a3f293c2f7370616e3e283f503c7461696c3e2e7b302c3430307d29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
        if l(lIIl.group(1)).lower() == label.lower():
            return l(lIIl.group(bytes.fromhex('7461696c').decode('utf-8')).split(bytes.fromhex('3c2f').decode('utf-8'), 1)[0])
    return bytes.fromhex('').decode('utf-8')

def ll(page, label):
    IIlIl = II(page, label)
    return re.sub(bytes.fromhex('5e7b307d5c732a').decode('utf-8').format(re.escape(label)), bytes.fromhex('').decode('utf-8'), IIlIl, flags=re.I).strip()

def lI(page, Ill, lII):
    llII = bytes.fromhex('3c6d6574615c625b5e3e5d2a5c627b307d3d5b225c275d7b317d5b225c275d5b5e3e5d2a3e').decode('utf-8').format(re.escape(Ill), re.escape(lII))
    IIIII = Il(llII, page or bytes.fromhex('').decode('utf-8'), re.S)
    return I(IIIII, bytes.fromhex('636f6e74656e74').decode('utf-8'))

def I(IIIII, lIll):
    if not IIIII:
        return bytes.fromhex('').decode('utf-8')
    lIIl = re.search(bytes.fromhex('5c627b307d3d5b225c275d285b5e225c275d2b295b225c275d').decode('utf-8').format(re.escape(lIll)), IIIII, re.I)
    return html.unescape(lIIl.group(1)) if lIIl else bytes.fromhex('').decode('utf-8')

def Il(llII, IIIIl, flags=0):
    lIIl = re.search(llII, IIIIl or bytes.fromhex('').decode('utf-8'), flags | re.I)
    if not lIIl:
        return bytes.fromhex('').decode('utf-8')
    return lIIl.group(1) if lIIl.lastindex else lIIl.group(0)

def l(IIIIl):
    IIIIl = re.sub(bytes.fromhex('3c7363726970742e2a3f3c2f7363726970743e').decode('utf-8'), bytes.fromhex('20').decode('utf-8'), IIIIl or bytes.fromhex('').decode('utf-8'), flags=re.S | re.I)
    IIIIl = re.sub(bytes.fromhex('3c7376672e2a3f3c2f7376673e').decode('utf-8'), bytes.fromhex('20').decode('utf-8'), IIIIl, flags=re.S | re.I)
    IIIIl = re.sub(bytes.fromhex('3c5b5e3e5d2b3e').decode('utf-8'), bytes.fromhex('20').decode('utf-8'), IIIIl)
    IIIIl = html.unescape(IIIIl)
    return re.sub(bytes.fromhex('5c732b').decode('utf-8'), bytes.fromhex('20').decode('utf-8'), IIIIl).strip()
