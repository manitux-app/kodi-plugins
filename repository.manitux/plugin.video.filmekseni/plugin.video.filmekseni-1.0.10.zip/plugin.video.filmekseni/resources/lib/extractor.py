from __future__ import absolute_import, unicode_literals
import json
import re
import string
import manituxhttp
try:
    from urllib.parse import quote, urljoin, urlparse
except ImportError:
    from urllib import quote
    from urlparse import urljoin, urlparse

class VideoExtractor(object):
    CLIENT_IDENTIFIERS = (bytes.fromhex('636c6f756473637261706572').decode('utf-8'), bytes.fromhex('6368726f6d655f313434').decode('utf-8'))

    def __init__(Illl, user_agent, main_url):
        Illl.user_agent = user_agent
        Illl.main_url = main_url.rstrip(bytes.fromhex('2f').decode('utf-8'))
        Illl.session = manituxhttp.Session(client_identifier=Illl.CLIENT_IDENTIFIERS[0])

    def resolve(Illl, url, referer=None, label=bytes.fromhex('').decode('utf-8')):
        if not url:
            return (None, [])
        url = Illl.normalize_url(url)
        III = urlparse(url).netloc.lower()
        if bytes.fromhex('796f7574756265').decode('utf-8') in III or bytes.fromhex('796f7574752e6265').decode('utf-8') in III:
            return (url + Illl.kodi_headers(referer), [])
        if bytes.fromhex('656b73656e6c6f6164').decode('utf-8') in III:
            return Illl.resolve_eksenload(url, referer, label)
        if bytes.fromhex('7669646d6f6c79').decode('utf-8') in III or bytes.fromhex('766964656f62696e').decode('utf-8') in III:
            return Illl.resolve_vidmoly(url, referer)
        if bytes.fromhex('6f6b2e7275').decode('utf-8') in III or bytes.fromhex('6f646e6f6b6c6173736e696b69').decode('utf-8') in III:
            return Illl.resolve_okru(url)
        if bytes.fromhex('73747265616d74617065').decode('utf-8') in III or bytes.fromhex('77617463686164736f6e74617065').decode('utf-8') in III or bytes.fromhex('736861766574617065').decode('utf-8') in III:
            return Illl.resolve_streamtape(url, referer)
        page = Illl.fetch(url, referer)
        source, lIII = Illl.extract_jwplayer(page, Illl.origin(url))
        if source:
            return (source + Illl.kodi_headers(url), lIII)
        Il = Illl._first(bytes.fromhex('68747470733f3a2f2f5b5e5c7322273c3e5d2b3f5c2e283f3a6d3375387c6d703429283f3a5c3f5b5e5c7322273c3e5d2a293f').decode('utf-8'), page)
        return (Il + Illl.kodi_headers(url) if Il else url + Illl.kodi_headers(referer), [])

    def resolve_eksenload(Illl, url, referer=None, label=bytes.fromhex('').decode('utf-8')):
        page = Illl.fetch(url, referer, origin=Illl.main_url)
        origin = Illl.origin(url)
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): Illl.user_agent, bytes.fromhex('4f726967696e').decode('utf-8'): origin}
        source, lIII = Illl.extract_jwplayer(page, origin, headers)
        if not source:
            lIlI = url.rstrip(bytes.fromhex('2f').decode('utf-8')).split(bytes.fromhex('2f').decode('utf-8'))[-1]
            if lIlI:
                source = origin + bytes.fromhex('2f75706c6f6164732f656e636f64652f').decode('utf-8') + lIlI + bytes.fromhex('2f6d61737465722e6d337538').decode('utf-8')
        if not source:
            return (None, lIII)
        return (source + Illl.kodi_headers(url, headers), lIII)

    def resolve_vidmoly(Illl, url, referer=None):
        url = Illl.normalize_url(url)
        II = [url]
        IIII = re.search(bytes.fromhex('2f772f285b612d7a302d395d2b292f2a24').decode('utf-8'), url, re.I)
        if IIII:
            II.insert(0, re.sub(bytes.fromhex('2f772f285b612d7a302d395d2b292f2a24').decode('utf-8'), bytes.fromhex('2f656d6265642d5c312e68746d6c').decode('utf-8'), url, flags=re.I))
        IIl = bytes.fromhex('').decode('utf-8')
        page_url = url
        for l in II:
            IIl = Illl.fetch(l, referer)
            page_url = l
            if bytes.fromhex('2e6d337538').decode('utf-8') in IIl or bytes.fromhex('736f7572636573').decode('utf-8') in IIl or bytes.fromhex('6a77706c61796572').decode('utf-8') in IIl:
                break
        source, lIII = Illl.extract_jwplayer(IIl, Illl.origin(page_url), {bytes.fromhex('557365722d4167656e74').decode('utf-8'): Illl.user_agent})
        if not source:
            source = Illl._first(bytes.fromhex('68747470733f3a2f2f5b5e5c7322273c3e5d2b3f5c2e283f3a6d3375387c6d703429283f3a5c3f5b5e5c7322273c3e5d2a293f').decode('utf-8'), IIl)
        return (source + Illl.kodi_headers(page_url) if source else None, lIII)

    def resolve_okru(Illl, url):
        url = Illl.normalize_url(url)
        lIlI = Illl._first(bytes.fromhex('283f3a766964656f656d6265642f7c766964656f2f7c6d69643d29285c642b29').decode('utf-8'), url)
        if not lIlI:
            return (url + Illl.kodi_headers(bytes.fromhex('68747470733a2f2f6f6b2e72752f').decode('utf-8')), [])
        IllI = Illl.session.post(bytes.fromhex('68747470733a2f2f7777772e6f6b2e72752f646b').decode('utf-8'), data={bytes.fromhex('636d64').decode('utf-8'): bytes.fromhex('766964656f506c617965724d65746164617461').decode('utf-8'), bytes.fromhex('6d6964').decode('utf-8'): lIlI}, headers=Illl.headers(bytes.fromhex('68747470733a2f2f6f6b2e72752f').decode('utf-8')), timeout=25)
        IllI.raise_for_status()
        data = IllI.text.replace(bytes.fromhex('5c7530303236').decode('utf-8'), bytes.fromhex('26').decode('utf-8')).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'))
        source = Illl._first(bytes.fromhex('22283f3a6f6e64656d616e64486c737c6f6e64656d616e644461736829225c732a3a5c732a22285b5e225d2b2922').decode('utf-8'), data)
        if not source:
            source = Illl._first(bytes.fromhex('22283f3a6e616d657c7175616c69747929225c732a3a5c732a22283f3a756c7472617c717561647c66756c6c7c68647c73647c6c6f777c6d6f62696c6529225b5e7b7d5d2a2275726c225c732a3a5c732a22285b5e225d2b2922').decode('utf-8'), data, re.S)
        return (source + Illl.kodi_headers(bytes.fromhex('68747470733a2f2f6f6b2e72752f').decode('utf-8')) if source else None, [])

    def resolve_streamtape(Illl, url, referer=None):
        page = Illl.fetch(url, referer)
        llI = bytes.fromhex('').decode('utf-8')
        for l in page.splitlines():
            if bytes.fromhex('626f746c696e6b27292e696e6e657248544d4c').decode('utf-8') in l or bytes.fromhex('626f746c696e6b22292e696e6e657248544d4c').decode('utf-8') in l:
                llI = l
                break
        lll = re.findall(bytes.fromhex('5b27225d285b5e27225d2a295b27225d').decode('utf-8'), llI)
        IIll = [lIll for lIll in lll if bytes.fromhex('2f').decode('utf-8') in lIll or bytes.fromhex('26').decode('utf-8') in lIll or bytes.fromhex('3d').decode('utf-8') in lIll]
        source = bytes.fromhex('').decode('utf-8').join(IIll)
        if source.startswith(bytes.fromhex('2f2f').decode('utf-8')):
            source = bytes.fromhex('68747470733a').decode('utf-8') + source
        if source:
            source += bytes.fromhex('2673747265616d3d31').decode('utf-8')
        return (source + Illl.kodi_headers(url) if source else None, [])

    def extract_jwplayer(Illl, page, base_url, headers=None):
        source = bytes.fromhex('').decode('utf-8')
        lIII = []
        for IlIl in re.findall(bytes.fromhex('5b22275d3f736f75726365735b22275d3f5c732a3a5c732a285c5b2e2a3f5c5d29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            for item in Illl._parse_js_list(IlIl):
                url = item.get(bytes.fromhex('66696c65').decode('utf-8'))
                if url:
                    source = urljoin(base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8'), url.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')))
                    break
            if source:
                break
        if not source:
            IIII = re.search(bytes.fromhex('5b3a3d5d5c732a5b22275d285b5e22275c735d2b283f3a5c2e6d3375387c6d61737465725c2e747874295b5e22275c735d2a29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I)
            if IIII:
                source = urljoin(base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8'), IIII.group(1).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')))
        for IlIl in re.findall(bytes.fromhex('5b22275d3f747261636b735b22275d3f5c732a3a5c732a285c5b2e2a3f5c5d29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            for item in Illl._parse_js_list(IlIl):
                lII = (item.get(bytes.fromhex('6b696e64').decode('utf-8')) or bytes.fromhex('').decode('utf-8')).lower()
                ll = item.get(bytes.fromhex('66696c65').decode('utf-8'))
                if ll and (bytes.fromhex('63617074696f6e').decode('utf-8') in lII or bytes.fromhex('7375627469746c65').decode('utf-8') in lII):
                    lIII.append(urljoin(base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8'), ll.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'))))
        return (source, list(dict.fromkeys(lIII)))

    def _parse_js_list(Illl, lIIl):
        IIIl = lIIl.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'))
        IIIl = re.sub(bytes.fromhex('285b7b2c5d5c732a292866696c657c6c6162656c7c747970657c6b696e64295c732a3a').decode('utf-8'), bytes.fromhex('5c31225c32223a').decode('utf-8'), IIIl)
        IIIl = IIIl.replace(bytes.fromhex('27').decode('utf-8'), bytes.fromhex('22').decode('utf-8'))
        IIIl = re.sub(bytes.fromhex('2c5c732a285b5c5d7d5d29').decode('utf-8'), bytes.fromhex('5c31').decode('utf-8'), IIIl)
        try:
            data = json.loads(IIIl)
            return data if isinstance(data, list) else []
        except Exception:
            items = []
            for I in re.findall(bytes.fromhex('5c7b282e2a3f295c7d').decode('utf-8'), lIIl, re.S):
                item = {}
                for Ill in (bytes.fromhex('66696c65').decode('utf-8'), bytes.fromhex('6c6162656c').decode('utf-8'), bytes.fromhex('74797065').decode('utf-8'), bytes.fromhex('6b696e64').decode('utf-8')):
                    item[Ill] = Illl._first(bytes.fromhex('5b22275d3f25735b22275d3f5c732a3a5c732a5b22275d285b5e22275d2b29').decode('utf-8') % Ill, I)
                items.append(item)
            return items

    def fetch(Illl, url, referer=None, origin=None):
        lIl = None
        for IlI in Illl.CLIENT_IDENTIFIERS:
            if Illl.session.client_identifier != IlI:
                Illl.session = manituxhttp.Session(client_identifier=IlI)
            try:
                IllI = Illl.session.get(url, headers=Illl.headers(referer, origin), timeout=25, allow_redirects=True, tls_client_identifier=IlI)
                if IllI.status_code in (403, 429) and IlI != Illl.CLIENT_IDENTIFIERS[-1]:
                    lIl = manituxhttp.HTTPError(IllI)
                    continue
                IllI.raise_for_status()
                return IllI.text
            except (manituxhttp.HTTPError, manituxhttp.RequestError) as exc:
                lIl = exc
                if IlI == Illl.CLIENT_IDENTIFIERS[-1]:
                    raise
        raise lIl

    def headers(Illl, referer=None, origin=None):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): Illl.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('746578742f68746d6c2c6170706c69636174696f6e2f7868746d6c2b786d6c2c6170706c69636174696f6e2f786d6c3b713d302e392c2a2f2a3b713d302e38').decode('utf-8')}
        if referer:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        if origin:
            headers[bytes.fromhex('4f726967696e').decode('utf-8')] = origin
        return headers

    def kodi_headers(Illl, referer=None, lI=None):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): Illl.user_agent}
        if referer:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        if lI:
            headers.update(lI)
        return bytes.fromhex('7c').decode('utf-8') + bytes.fromhex('26').decode('utf-8').join((bytes.fromhex('7b307d3d7b317d').decode('utf-8').format(Ill, quote(lIIl)) for Ill, lIIl in headers.items() if lIIl))

    def normalize_url(Illl, url):
        if url.startswith(bytes.fromhex('2f2f').decode('utf-8')):
            return bytes.fromhex('68747470733a').decode('utf-8') + url
        if url.startswith(bytes.fromhex('7777772e').decode('utf-8')):
            return bytes.fromhex('68747470733a2f2f').decode('utf-8') + url
        if not url.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8'))):
            return urljoin(Illl.main_url + bytes.fromhex('2f').decode('utf-8'), url)
        return url

    def origin(Illl, url):
        IIlI = urlparse(url)
        return IIlI.scheme + bytes.fromhex('3a2f2f').decode('utf-8') + IIlI.netloc

    @staticmethod
    def _first(IlII, text, flags=0):
        IIII = re.search(IlII, text or bytes.fromhex('').decode('utf-8'), flags | re.I)
        if not IIII:
            return bytes.fromhex('').decode('utf-8')
        return IIII.group(1) if IIII.lastindex else IIII.group(0)
