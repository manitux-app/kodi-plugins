from __future__ import absolute_import, unicode_literals
import manituxhttp
try:
    from urllib.parse import quote_plus
except ImportError:
    from urllib import quote_plus
from . import parsers

class FilmEkseniSite(object):
    CLIENT_IDENTIFIERS = (bytes.fromhex('636c6f756473637261706572').decode('utf-8'), bytes.fromhex('6368726f6d655f313434').decode('utf-8'))

    def __init__(ll, base_url, user_agent):
        ll.base_url = base_url.rstrip(bytes.fromhex('2f').decode('utf-8'))
        ll.user_agent = user_agent
        ll.session = manituxhttp.Session(client_identifier=ll.CLIENT_IDENTIFIERS[0])

    def headers(ll, referer=None, ajax=False):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): ll.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('746578742f68746d6c2c6170706c69636174696f6e2f7868746d6c2b786d6c2c6170706c69636174696f6e2f786d6c3b713d302e392c2a2f2a3b713d302e38').decode('utf-8')}
        if referer:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        if ajax:
            headers[bytes.fromhex('582d5265717565737465642d57697468').decode('utf-8')] = bytes.fromhex('584d4c4874747052657175657374').decode('utf-8')
            headers[bytes.fromhex('4f726967696e').decode('utf-8')] = ll.base_url
        return headers

    def categories(ll):
        return parsers.categories(ll.base_url)

    def get(ll, url, referer=None):
        return ll._get(ll.absolute(url), ll.headers(referer)).text

    def post(ll, url, data, referer=None):
        return ll._post(ll.absolute(url), data, ll.headers(referer, ajax=True)).text

    def get_page_items(ll, I, page_number=1, title=bytes.fromhex('').decode('utf-8')):
        page = ll.get(parsers.page_url(I, page_number), referer=I)
        return parsers.parse_page_items(page, ll.base_url, title)

    def search(ll, query):
        Il = ll.get(ll.base_url + bytes.fromhex('2f6170692f7365617263683f713d').decode('utf-8') + quote_plus(query), referer=ll.base_url + bytes.fromhex('2f').decode('utf-8'))
        return parsers.parse_search_results(Il, ll.base_url)

    def parse_detail(ll, page, url):
        return parsers.parse_media_info(page, url, ll.base_url)

    def fetch_iframe(ll, III, referer=None):
        page = ll.get(III, referer=referer or ll.base_url + bytes.fromhex('2f').decode('utf-8'))
        return parsers.parse_iframe(page, ll.base_url)

    def absolute(ll, url):
        return parsers.fix_url(url, ll.base_url)

    def search_url(ll, query):
        return ll.base_url + bytes.fromhex('2f7365617263682f3f713d').decode('utf-8') + quote_plus(query)

    def _get(ll, url, headers):
        II = None
        for l in ll.CLIENT_IDENTIFIERS:
            if ll.session.client_identifier != l:
                ll.session = manituxhttp.Session(client_identifier=l)
            try:
                lI = ll.session.get(url, headers=headers, timeout=25, tls_client_identifier=l)
                if lI.status_code in (403, 429) and l != ll.CLIENT_IDENTIFIERS[-1]:
                    II = manituxhttp.HTTPError(lI)
                    continue
                lI.raise_for_status()
                return lI
            except (manituxhttp.HTTPError, manituxhttp.RequestError) as exc:
                II = exc
                if l == ll.CLIENT_IDENTIFIERS[-1]:
                    raise
        raise II

    def _post(ll, url, data, headers):
        II = None
        for l in ll.CLIENT_IDENTIFIERS:
            if ll.session.client_identifier != l:
                ll.session = manituxhttp.Session(client_identifier=l)
            try:
                lI = ll.session.post(url, data=data, headers=headers, timeout=25, tls_client_identifier=l)
                if lI.status_code in (403, 429) and l != ll.CLIENT_IDENTIFIERS[-1]:
                    II = manituxhttp.HTTPError(lI)
                    continue
                lI.raise_for_status()
                return lI
            except (manituxhttp.HTTPError, manituxhttp.RequestError) as exc:
                II = exc
                if l == ll.CLIENT_IDENTIFIERS[-1]:
                    raise
        raise II
