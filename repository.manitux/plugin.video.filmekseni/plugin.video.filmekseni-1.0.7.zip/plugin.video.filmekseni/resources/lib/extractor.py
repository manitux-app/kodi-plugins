from __future__ import absolute_import, unicode_literals
import json
import re
import string
import manituxhttp
try:
    from urllib.parse import quote, urljoin, urlparse
except ImportError:
    from urllib import quote
    from urlparse import urljoin, urlparse

class VideoExtractor(object):
    CLIENT_IDENTIFIERS = (bytes.fromhex('636c6f756473637261706572').decode('utf-8'), bytes.fromhex('6368726f6d655f313434').decode('utf-8'))

    def __init__(aaAAAaAaAaAaAAAAAaAa, user_agent, main_url):
        aaAAAaAaAaAaAAAAAaAa.user_agent = user_agent
        aaAAAaAaAaAaAAAAAaAa.main_url = main_url.rstrip(bytes.fromhex('2f').decode('utf-8'))
        aaAAAaAaAaAaAAAAAaAa.session = manituxhttp.Session(client_identifier=aaAAAaAaAaAaAAAAAaAa.CLIENT_IDENTIFIERS[0])

    def resolve(aaAAAaAaAaAaAAAAAaAa, url, referer=None, label=bytes.fromhex('').decode('utf-8')):
        if not url:
            return (None, [])
        url = aaAAAaAaAaAaAAAAAaAa.normalize_url(url)
        AaaAaA = urlparse(url).netloc.lower()
        if bytes.fromhex('796f7574756265').decode('utf-8') in AaaAaA or bytes.fromhex('796f7574752e6265').decode('utf-8') in AaaAaA:
            return (url + aaAAAaAaAaAaAAAAAaAa.kodi_headers(referer), [])
        if bytes.fromhex('656b73656e6c6f6164').decode('utf-8') in AaaAaA:
            return aaAAAaAaAaAaAAAAAaAa.resolve_eksenload(url, referer, label)
        if bytes.fromhex('7669646d6f6c79').decode('utf-8') in AaaAaA or bytes.fromhex('766964656f62696e').decode('utf-8') in AaaAaA:
            return aaAAAaAaAaAaAAAAAaAa.resolve_vidmoly(url, referer)
        if bytes.fromhex('6f6b2e7275').decode('utf-8') in AaaAaA or bytes.fromhex('6f646e6f6b6c6173736e696b69').decode('utf-8') in AaaAaA:
            return aaAAAaAaAaAaAAAAAaAa.resolve_okru(url)
        if bytes.fromhex('73747265616d74617065').decode('utf-8') in AaaAaA or bytes.fromhex('77617463686164736f6e74617065').decode('utf-8') in AaaAaA or bytes.fromhex('736861766574617065').decode('utf-8') in AaaAaA:
            return aaAAAaAaAaAaAAAAAaAa.resolve_streamtape(url, referer)
        page = aaAAAaAaAaAaAAAAAaAa.fetch(url, referer)
        source, qSFbrvtDPepsgtkMKOzIqlEAAUYvKMvISccqSwpTlbZxCWPcUtnBrIwjirknmlMPZgkLZDVITujtRmA21 = aaAAAaAaAaAaAAAAAaAa.extract_jwplayer(page, aaAAAaAaAaAaAAAAAaAa.origin(url))
        if source:
            return (source + aaAAAaAaAaAaAAAAAaAa.kodi_headers(url), qSFbrvtDPepsgtkMKOzIqlEAAUYvKMvISccqSwpTlbZxCWPcUtnBrIwjirknmlMPZgkLZDVITujtRmA21)
        aAAA = aaAAAaAaAaAaAAAAAaAa._first(bytes.fromhex('68747470733f3a2f2f5b5e5c7322273c3e5d2b3f5c2e283f3a6d3375387c6d703429283f3a5c3f5b5e5c7322273c3e5d2a293f').decode('utf-8'), page)
        return (aAAA + aaAAAaAaAaAaAAAAAaAa.kodi_headers(url) if aAAA else url + aaAAAaAaAaAaAAAAAaAa.kodi_headers(referer), [])

    def resolve_eksenload(aaAAAaAaAaAaAAAAAaAa, url, referer=None, label=bytes.fromhex('').decode('utf-8')):
        page = aaAAAaAaAaAaAAAAAaAa.fetch(url, referer, origin=aaAAAaAaAaAaAAAAAaAa.main_url)
        origin = aaAAAaAaAaAaAAAAAaAa.origin(url)
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): aaAAAaAaAaAaAAAAAaAa.user_agent, bytes.fromhex('4f726967696e').decode('utf-8'): origin}
        source, qSFbrvtDPepsgtkMKOzIqlEAAUYvKMvISccqSwpTlbZxCWPcUtnBrIwjirknmlMPZgkLZDVITujtRmA21 = aaAAAaAaAaAaAAAAAaAa.extract_jwplayer(page, origin, headers)
        if not source:
            CCCCCCCCCCCCCCCCCCCCCCC = url.rstrip(bytes.fromhex('2f').decode('utf-8')).split(bytes.fromhex('2f').decode('utf-8'))[-1]
            if CCCCCCCCCCCCCCCCCCCCCCC:
                source = origin + bytes.fromhex('2f75706c6f6164732f656e636f64652f').decode('utf-8') + CCCCCCCCCCCCCCCCCCCCCCC + bytes.fromhex('2f6d61737465722e6d337538').decode('utf-8')
        if not source:
            return (None, qSFbrvtDPepsgtkMKOzIqlEAAUYvKMvISccqSwpTlbZxCWPcUtnBrIwjirknmlMPZgkLZDVITujtRmA21)
        return (source + aaAAAaAaAaAaAAAAAaAa.kodi_headers(url, headers), qSFbrvtDPepsgtkMKOzIqlEAAUYvKMvISccqSwpTlbZxCWPcUtnBrIwjirknmlMPZgkLZDVITujtRmA21)

    def resolve_vidmoly(aaAAAaAaAaAaAAAAAaAa, url, referer=None):
        url = aaAAAaAaAaAaAAAAAaAa.normalize_url(url)
        IlI = [url]
        lGltHvWeunqiiMaLyOSxsFCDlNLaiYjOtaWYMmOShIpWGsaoXSbzFVoebaUkuhWjlchHopocCkdoUcW14 = re.search(bytes.fromhex('2f772f285b612d7a302d395d2b292f2a24').decode('utf-8'), url, re.I)
        if lGltHvWeunqiiMaLyOSxsFCDlNLaiYjOtaWYMmOShIpWGsaoXSbzFVoebaUkuhWjlchHopocCkdoUcW14:
            IlI.insert(0, re.sub(bytes.fromhex('2f772f285b612d7a302d395d2b292f2a24').decode('utf-8'), bytes.fromhex('2f656d6265642d5c312e68746d6c').decode('utf-8'), url, flags=re.I))
        W44948942166777 = bytes.fromhex('').decode('utf-8')
        page_url = url
        for C46893737674222 in IlI:
            W44948942166777 = aaAAAaAaAaAaAAAAAaAa.fetch(C46893737674222, referer)
            page_url = C46893737674222
            if bytes.fromhex('2e6d337538').decode('utf-8') in W44948942166777 or bytes.fromhex('736f7572636573').decode('utf-8') in W44948942166777 or bytes.fromhex('6a77706c61796572').decode('utf-8') in W44948942166777:
                break
        source, qSFbrvtDPepsgtkMKOzIqlEAAUYvKMvISccqSwpTlbZxCWPcUtnBrIwjirknmlMPZgkLZDVITujtRmA21 = aaAAAaAaAaAaAAAAAaAa.extract_jwplayer(W44948942166777, aaAAAaAaAaAaAAAAAaAa.origin(page_url), {bytes.fromhex('557365722d4167656e74').decode('utf-8'): aaAAAaAaAaAaAAAAAaAa.user_agent})
        if not source:
            source = aaAAAaAaAaAaAAAAAaAa._first(bytes.fromhex('68747470733f3a2f2f5b5e5c7322273c3e5d2b3f5c2e283f3a6d3375387c6d703429283f3a5c3f5b5e5c7322273c3e5d2a293f').decode('utf-8'), W44948942166777)
        return (source + aaAAAaAaAaAaAAAAAaAa.kodi_headers(page_url) if source else None, qSFbrvtDPepsgtkMKOzIqlEAAUYvKMvISccqSwpTlbZxCWPcUtnBrIwjirknmlMPZgkLZDVITujtRmA21)

    def resolve_okru(aaAAAaAaAaAaAAAAAaAa, url):
        url = aaAAAaAaAaAaAAAAAaAa.normalize_url(url)
        CCCCCCCCCCCCCCCCCCCCCCC = aaAAAaAaAaAaAAAAAaAa._first(bytes.fromhex('283f3a766964656f656d6265642f7c766964656f2f7c6d69643d29285c642b29').decode('utf-8'), url)
        if not CCCCCCCCCCCCCCCCCCCCCCC:
            return (url + aaAAAaAaAaAaAAAAAaAa.kodi_headers(bytes.fromhex('68747470733a2f2f6f6b2e72752f').decode('utf-8')), [])
        a387741284987219 = aaAAAaAaAaAaAAAAAaAa.session.post(bytes.fromhex('68747470733a2f2f7777772e6f6b2e72752f646b').decode('utf-8'), data={bytes.fromhex('636d64').decode('utf-8'): bytes.fromhex('766964656f506c617965724d65746164617461').decode('utf-8'), bytes.fromhex('6d6964').decode('utf-8'): CCCCCCCCCCCCCCCCCCCCCCC}, headers=aaAAAaAaAaAaAAAAAaAa.headers(bytes.fromhex('68747470733a2f2f6f6b2e72752f').decode('utf-8')), timeout=25)
        a387741284987219.raise_for_status()
        data = a387741284987219.text.replace(bytes.fromhex('5c7530303236').decode('utf-8'), bytes.fromhex('26').decode('utf-8')).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'))
        source = aaAAAaAaAaAaAAAAAaAa._first(bytes.fromhex('22283f3a6f6e64656d616e64486c737c6f6e64656d616e644461736829225c732a3a5c732a22285b5e225d2b2922').decode('utf-8'), data)
        if not source:
            source = aaAAAaAaAaAaAAAAAaAa._first(bytes.fromhex('22283f3a6e616d657c7175616c69747929225c732a3a5c732a22283f3a756c7472617c717561647c66756c6c7c68647c73647c6c6f777c6d6f62696c6529225b5e7b7d5d2a2275726c225c732a3a5c732a22285b5e225d2b2922').decode('utf-8'), data, re.S)
        return (source + aaAAAaAaAaAaAAAAAaAa.kodi_headers(bytes.fromhex('68747470733a2f2f6f6b2e72752f').decode('utf-8')) if source else None, [])

    def resolve_streamtape(aaAAAaAaAaAaAAAAAaAa, url, referer=None):
        page = aaAAAaAaAaAaAAAAAaAa.fetch(url, referer)
        I440965920240812 = bytes.fromhex('').decode('utf-8')
        for C46893737674222 in page.splitlines():
            if bytes.fromhex('626f746c696e6b27292e696e6e657248544d4c').decode('utf-8') in C46893737674222 or bytes.fromhex('626f746c696e6b22292e696e6e657248544d4c').decode('utf-8') in C46893737674222:
                I440965920240812 = C46893737674222
                break
        D13 = re.findall(bytes.fromhex('5b27225d285b5e27225d2a295b27225d').decode('utf-8'), I440965920240812)
        J241236352960217 = [i354601057294824 for i354601057294824 in D13 if bytes.fromhex('2f').decode('utf-8') in i354601057294824 or bytes.fromhex('26').decode('utf-8') in i354601057294824 or bytes.fromhex('3d').decode('utf-8') in i354601057294824]
        source = bytes.fromhex('').decode('utf-8').join(J241236352960217)
        if source.startswith(bytes.fromhex('2f2f').decode('utf-8')):
            source = bytes.fromhex('68747470733a').decode('utf-8') + source
        if source:
            source += bytes.fromhex('2673747265616d3d31').decode('utf-8')
        return (source + aaAAAaAaAaAaAAAAAaAa.kodi_headers(url) if source else None, [])

    def extract_jwplayer(aaAAAaAaAaAaAAAAAaAa, page, base_url, headers=None):
        source = bytes.fromhex('').decode('utf-8')
        qSFbrvtDPepsgtkMKOzIqlEAAUYvKMvISccqSwpTlbZxCWPcUtnBrIwjirknmlMPZgkLZDVITujtRmA21 = []
        for fvcWKJEKAPSynOBKhBdiubTPsLYNtWQQzkflSfFIloGEqXsLWDfGucOtXlrIxsaNMkcAyfaFUTOUyNY18 in re.findall(bytes.fromhex('5b22275d3f736f75726365735b22275d3f5c732a3a5c732a285c5b2e2a3f5c5d29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            for item in aaAAAaAaAaAaAAAAAaAa._parse_js_list(fvcWKJEKAPSynOBKhBdiubTPsLYNtWQQzkflSfFIloGEqXsLWDfGucOtXlrIxsaNMkcAyfaFUTOUyNY18):
                url = item.get(bytes.fromhex('66696c65').decode('utf-8'))
                if url:
                    source = urljoin(base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8'), url.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')))
                    break
            if source:
                break
        if not source:
            lGltHvWeunqiiMaLyOSxsFCDlNLaiYjOtaWYMmOShIpWGsaoXSbzFVoebaUkuhWjlchHopocCkdoUcW14 = re.search(bytes.fromhex('5b3a3d5d5c732a5b22275d285b5e22275c735d2b283f3a5c2e6d3375387c6d61737465725c2e747874295b5e22275c735d2a29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I)
            if lGltHvWeunqiiMaLyOSxsFCDlNLaiYjOtaWYMmOShIpWGsaoXSbzFVoebaUkuhWjlchHopocCkdoUcW14:
                source = urljoin(base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8'), lGltHvWeunqiiMaLyOSxsFCDlNLaiYjOtaWYMmOShIpWGsaoXSbzFVoebaUkuhWjlchHopocCkdoUcW14.group(1).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')))
        for fvcWKJEKAPSynOBKhBdiubTPsLYNtWQQzkflSfFIloGEqXsLWDfGucOtXlrIxsaNMkcAyfaFUTOUyNY18 in re.findall(bytes.fromhex('5b22275d3f747261636b735b22275d3f5c732a3a5c732a285c5b2e2a3f5c5d29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            for item in aaAAAaAaAaAaAAAAAaAa._parse_js_list(fvcWKJEKAPSynOBKhBdiubTPsLYNtWQQzkflSfFIloGEqXsLWDfGucOtXlrIxsaNMkcAyfaFUTOUyNY18):
                AAAaaaAaaA = (item.get(bytes.fromhex('6b696e64').decode('utf-8')) or bytes.fromhex('').decode('utf-8')).lower()
                aAaaa = item.get(bytes.fromhex('66696c65').decode('utf-8'))
                if aAaaa and (bytes.fromhex('63617074696f6e').decode('utf-8') in AAAaaaAaaA or bytes.fromhex('7375627469746c65').decode('utf-8') in AAAaaaAaaA):
                    qSFbrvtDPepsgtkMKOzIqlEAAUYvKMvISccqSwpTlbZxCWPcUtnBrIwjirknmlMPZgkLZDVITujtRmA21.append(urljoin(base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8'), aAaaa.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'))))
        return (source, list(dict.fromkeys(qSFbrvtDPepsgtkMKOzIqlEAAUYvKMvISccqSwpTlbZxCWPcUtnBrIwjirknmlMPZgkLZDVITujtRmA21)))

    def _parse_js_list(aaAAAaAaAaAaAAAAAaAa, H107208030851822):
        aAaaaaAaaAAAaaa = H107208030851822.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'))
        aAaaaaAaaAAAaaa = re.sub(bytes.fromhex('285b7b2c5d5c732a292866696c657c6c6162656c7c747970657c6b696e64295c732a3a').decode('utf-8'), bytes.fromhex('5c31225c32223a').decode('utf-8'), aAaaaaAaaAAAaaa)
        aAaaaaAaaAAAaaa = aAaaaaAaaAAAaaa.replace(bytes.fromhex('27').decode('utf-8'), bytes.fromhex('22').decode('utf-8'))
        aAaaaaAaaAAAaaa = re.sub(bytes.fromhex('2c5c732a285b5c5d7d5d29').decode('utf-8'), bytes.fromhex('5c31').decode('utf-8'), aAaaaaAaaAAAaaa)
        try:
            data = json.loads(aAaaaaAaaAAAaaa)
            return data if isinstance(data, list) else []
        except Exception:
            items = []
            for Q1 in re.findall(bytes.fromhex('5c7b282e2a3f295c7d').decode('utf-8'), H107208030851822, re.S):
                item = {}
                for AAAAAAAAA in (bytes.fromhex('66696c65').decode('utf-8'), bytes.fromhex('6c6162656c').decode('utf-8'), bytes.fromhex('74797065').decode('utf-8'), bytes.fromhex('6b696e64').decode('utf-8')):
                    item[AAAAAAAAA] = aaAAAaAaAaAaAAAAAaAa._first(bytes.fromhex('5b22275d3f25735b22275d3f5c732a3a5c732a5b22275d285b5e22275d2b29').decode('utf-8') % AAAAAAAAA, Q1)
                items.append(item)
            return items

    def fetch(aaAAAaAaAaAaAAAAAaAa, url, referer=None, origin=None):
        FFFFFFFFFFF = None
        for llllIIll in aaAAAaAaAaAaAAAAAaAa.CLIENT_IDENTIFIERS:
            if aaAAAaAaAaAaAAAAAaAa.session.client_identifier != llllIIll:
                aaAAAaAaAaAaAAAAAaAa.session = manituxhttp.Session(client_identifier=llllIIll)
            try:
                a387741284987219 = aaAAAaAaAaAaAAAAAaAa.session.get(url, headers=aaAAAaAaAaAaAAAAAaAa.headers(referer, origin), timeout=25, allow_redirects=True, tls_client_identifier=llllIIll)
                if a387741284987219.status_code in (403, 429) and llllIIll != aaAAAaAaAaAaAAAAAaAa.CLIENT_IDENTIFIERS[-1]:
                    FFFFFFFFFFF = manituxhttp.HTTPError(a387741284987219)
                    continue
                a387741284987219.raise_for_status()
                return a387741284987219.text
            except (manituxhttp.HTTPError, manituxhttp.RequestError) as exc:
                FFFFFFFFFFF = exc
                if llllIIll == aaAAAaAaAaAaAAAAAaAa.CLIENT_IDENTIFIERS[-1]:
                    raise
        raise FFFFFFFFFFF

    def headers(aaAAAaAaAaAaAAAAAaAa, referer=None, origin=None):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): aaAAAaAaAaAaAAAAAaAa.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('746578742f68746d6c2c6170706c69636174696f6e2f7868746d6c2b786d6c2c6170706c69636174696f6e2f786d6c3b713d302e392c2a2f2a3b713d302e38').decode('utf-8')}
        if referer:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        if origin:
            headers[bytes.fromhex('4f726967696e').decode('utf-8')] = origin
        return headers

    def kodi_headers(aaAAAaAaAaAaAAAAAaAa, referer=None, extra=None):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): aaAAAaAaAaAaAAAAAaAa.user_agent}
        if referer:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        if extra:
            headers.update(extra)
        return bytes.fromhex('7c').decode('utf-8') + bytes.fromhex('26').decode('utf-8').join((bytes.fromhex('7b307d3d7b317d').decode('utf-8').format(AAAAAAAAA, quote(H107208030851822)) for AAAAAAAAA, H107208030851822 in headers.items() if H107208030851822))

    def normalize_url(aaAAAaAaAaAaAAAAAaAa, url):
        if url.startswith(bytes.fromhex('2f2f').decode('utf-8')):
            return bytes.fromhex('68747470733a').decode('utf-8') + url
        if url.startswith(bytes.fromhex('7777772e').decode('utf-8')):
            return bytes.fromhex('68747470733a2f2f').decode('utf-8') + url
        if not url.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8'))):
            return urljoin(aaAAAaAaAaAaAAAAAaAa.main_url + bytes.fromhex('2f').decode('utf-8'), url)
        return url

    def origin(aaAAAaAaAaAaAAAAAaAa, url):
        R950672593924116 = urlparse(url)
        return R950672593924116.scheme + bytes.fromhex('3a2f2f').decode('utf-8') + R950672593924116.netloc

    @staticmethod
    def _first(pattern, text, flags=0):
        lGltHvWeunqiiMaLyOSxsFCDlNLaiYjOtaWYMmOShIpWGsaoXSbzFVoebaUkuhWjlchHopocCkdoUcW14 = re.search(pattern, text or bytes.fromhex('').decode('utf-8'), flags | re.I)
        if not lGltHvWeunqiiMaLyOSxsFCDlNLaiYjOtaWYMmOShIpWGsaoXSbzFVoebaUkuhWjlchHopocCkdoUcW14:
            return bytes.fromhex('').decode('utf-8')
        return lGltHvWeunqiiMaLyOSxsFCDlNLaiYjOtaWYMmOShIpWGsaoXSbzFVoebaUkuhWjlchHopocCkdoUcW14.group(1) if lGltHvWeunqiiMaLyOSxsFCDlNLaiYjOtaWYMmOShIpWGsaoXSbzFVoebaUkuhWjlchHopocCkdoUcW14.lastindex else lGltHvWeunqiiMaLyOSxsFCDlNLaiYjOtaWYMmOShIpWGsaoXSbzFVoebaUkuhWjlchHopocCkdoUcW14.group(0)
