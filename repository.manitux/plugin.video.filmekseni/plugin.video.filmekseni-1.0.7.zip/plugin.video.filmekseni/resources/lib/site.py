from __future__ import absolute_import, unicode_literals
import manituxhttp
try:
    from urllib.parse import quote_plus
except ImportError:
    from urllib import quote_plus
from . import parsers

class FilmEkseniSite(object):
    CLIENT_IDENTIFIERS = (bytes.fromhex('636c6f756473637261706572').decode('utf-8'), bytes.fromhex('6368726f6d655f313434').decode('utf-8'))

    def __init__(D13604808802975, base_url, user_agent):
        D13604808802975.base_url = base_url.rstrip(bytes.fromhex('2f').decode('utf-8'))
        D13604808802975.user_agent = user_agent
        D13604808802975.session = manituxhttp.Session(client_identifier=D13604808802975.CLIENT_IDENTIFIERS[0])

    def headers(D13604808802975, referer=None, ajax=False):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): D13604808802975.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('746578742f68746d6c2c6170706c69636174696f6e2f7868746d6c2b786d6c2c6170706c69636174696f6e2f786d6c3b713d302e392c2a2f2a3b713d302e38').decode('utf-8')}
        if referer:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        if ajax:
            headers[bytes.fromhex('582d5265717565737465642d57697468').decode('utf-8')] = bytes.fromhex('584d4c4874747052657175657374').decode('utf-8')
            headers[bytes.fromhex('4f726967696e').decode('utf-8')] = D13604808802975.base_url
        return headers

    def categories(D13604808802975):
        return parsers.categories(D13604808802975.base_url)

    def get(D13604808802975, url, referer=None):
        return D13604808802975._get(D13604808802975.absolute(url), D13604808802975.headers(referer)).text

    def post(D13604808802975, url, data, referer=None):
        return D13604808802975._post(D13604808802975.absolute(url), data, D13604808802975.headers(referer, ajax=True)).text

    def get_page_items(D13604808802975, category_url, page_number=1, title=bytes.fromhex('').decode('utf-8')):
        page = D13604808802975.get(parsers.page_url(category_url, page_number), referer=category_url)
        return parsers.parse_page_items(page, D13604808802975.base_url, title)

    def search(D13604808802975, query):
        DxeWrnMyBkTUQVTCFoSRiaEgGcDDBrGxbGMmpewNsuniBcWXqvnyUCqBYQYKnqSabuWLocgEpJxbLJH3 = D13604808802975.get(D13604808802975.base_url + bytes.fromhex('2f6170692f7365617263683f713d').decode('utf-8') + quote_plus(query), referer=D13604808802975.base_url + bytes.fromhex('2f').decode('utf-8'))
        return parsers.parse_search_results(DxeWrnMyBkTUQVTCFoSRiaEgGcDDBrGxbGMmpewNsuniBcWXqvnyUCqBYQYKnqSabuWLocgEpJxbLJH3, D13604808802975.base_url)

    def parse_detail(D13604808802975, page, url):
        return parsers.parse_media_info(page, url, D13604808802975.base_url)

    def fetch_iframe(D13604808802975, IIIlII, referer=None):
        page = D13604808802975.get(IIIlII, referer=referer or D13604808802975.base_url + bytes.fromhex('2f').decode('utf-8'))
        return parsers.parse_iframe(page, D13604808802975.base_url)

    def absolute(D13604808802975, url):
        return parsers.fix_url(url, D13604808802975.base_url)

    def search_url(D13604808802975, query):
        return D13604808802975.base_url + bytes.fromhex('2f7365617263682f3f713d').decode('utf-8') + quote_plus(query)

    def _get(D13604808802975, url, headers):
        i2 = None
        for LOaCDleeIzFMQIvoFkkXrjWObumbMdRDnYkvHoswGzUjMNpXoZBvOtCxjEdzBtPABXzkjmaNGKRKwOC1 in D13604808802975.CLIENT_IDENTIFIERS:
            if D13604808802975.session.client_identifier != LOaCDleeIzFMQIvoFkkXrjWObumbMdRDnYkvHoswGzUjMNpXoZBvOtCxjEdzBtPABXzkjmaNGKRKwOC1:
                D13604808802975.session = manituxhttp.Session(client_identifier=LOaCDleeIzFMQIvoFkkXrjWObumbMdRDnYkvHoswGzUjMNpXoZBvOtCxjEdzBtPABXzkjmaNGKRKwOC1)
            try:
                Y4 = D13604808802975.session.get(url, headers=headers, timeout=25, tls_client_identifier=LOaCDleeIzFMQIvoFkkXrjWObumbMdRDnYkvHoswGzUjMNpXoZBvOtCxjEdzBtPABXzkjmaNGKRKwOC1)
                if Y4.status_code in (403, 429) and LOaCDleeIzFMQIvoFkkXrjWObumbMdRDnYkvHoswGzUjMNpXoZBvOtCxjEdzBtPABXzkjmaNGKRKwOC1 != D13604808802975.CLIENT_IDENTIFIERS[-1]:
                    i2 = manituxhttp.HTTPError(Y4)
                    continue
                Y4.raise_for_status()
                return Y4
            except (manituxhttp.HTTPError, manituxhttp.RequestError) as exc:
                i2 = exc
                if LOaCDleeIzFMQIvoFkkXrjWObumbMdRDnYkvHoswGzUjMNpXoZBvOtCxjEdzBtPABXzkjmaNGKRKwOC1 == D13604808802975.CLIENT_IDENTIFIERS[-1]:
                    raise
        raise i2

    def _post(D13604808802975, url, data, headers):
        i2 = None
        for LOaCDleeIzFMQIvoFkkXrjWObumbMdRDnYkvHoswGzUjMNpXoZBvOtCxjEdzBtPABXzkjmaNGKRKwOC1 in D13604808802975.CLIENT_IDENTIFIERS:
            if D13604808802975.session.client_identifier != LOaCDleeIzFMQIvoFkkXrjWObumbMdRDnYkvHoswGzUjMNpXoZBvOtCxjEdzBtPABXzkjmaNGKRKwOC1:
                D13604808802975.session = manituxhttp.Session(client_identifier=LOaCDleeIzFMQIvoFkkXrjWObumbMdRDnYkvHoswGzUjMNpXoZBvOtCxjEdzBtPABXzkjmaNGKRKwOC1)
            try:
                Y4 = D13604808802975.session.post(url, data=data, headers=headers, timeout=25, tls_client_identifier=LOaCDleeIzFMQIvoFkkXrjWObumbMdRDnYkvHoswGzUjMNpXoZBvOtCxjEdzBtPABXzkjmaNGKRKwOC1)
                if Y4.status_code in (403, 429) and LOaCDleeIzFMQIvoFkkXrjWObumbMdRDnYkvHoswGzUjMNpXoZBvOtCxjEdzBtPABXzkjmaNGKRKwOC1 != D13604808802975.CLIENT_IDENTIFIERS[-1]:
                    i2 = manituxhttp.HTTPError(Y4)
                    continue
                Y4.raise_for_status()
                return Y4
            except (manituxhttp.HTTPError, manituxhttp.RequestError) as exc:
                i2 = exc
                if LOaCDleeIzFMQIvoFkkXrjWObumbMdRDnYkvHoswGzUjMNpXoZBvOtCxjEdzBtPABXzkjmaNGKRKwOC1 == D13604808802975.CLIENT_IDENTIFIERS[-1]:
                    raise
        raise i2
