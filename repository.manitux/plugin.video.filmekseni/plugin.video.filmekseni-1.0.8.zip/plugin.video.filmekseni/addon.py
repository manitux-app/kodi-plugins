from __future__ import absolute_import, unicode_literals
import re
import sys
import time
import os
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
try:
    from urllib.parse import parse_qsl, urlencode
except ImportError:
    from urlparse import parse_qsl
    from urllib import urlencode
from resources.lib.extractor import VideoExtractor
from resources.lib.site import FilmEkseniSite
Illll = os.path.join(xbmcaddon.Addon(id=bytes.fromhex('7363726970742e6d6f64756c652e6d616e697475787569').decode('utf-8')).getAddonInfo(bytes.fromhex('70617468').decode('utf-8')), bytes.fromhex('6c6962').decode('utf-8'))
if Illll not in sys.path:
    sys.path.insert(0, Illll)
from manituxui import ManituxUI, open_browser
aa = bytes.fromhex('706c7567696e2e766964656f2e66696c6d656b73656e69').decode('utf-8')
LcGInNvLkBwDkhkVAsaBGibPyfldpWGhULdWQijBwixSICVMUVJsjKupUpYnhdDxVprxtuCIBGTeWOx6 = aa + bytes.fromhex('2e736b69705f6775695f756e74696c').decode('utf-8')
I = xbmcaddon.Addon(id=aa)
r97696359883074 = int(sys.argv[1])
T13301875320763 = I.getSetting(bytes.fromhex('626173655f75726c').decode('utf-8')) or bytes.fromhex('68747470733a2f2f66696c6d656b73656e692e6e6c').decode('utf-8')
AaaaaAA = I.getSetting(bytes.fromhex('757365725f6167656e74').decode('utf-8')) or bytes.fromhex('4d6f7a696c6c612f352e3020285831313b204c696e7578207838365f363429204170706c655765624b69742f3533372e333620284b48544d4c2c206c696b65204765636b6f29204368726f6d652f3132342e30205361666172692f3533372e3336').decode('utf-8')
x795561373033319 = FilmEkseniSite(T13301875320763, AaaaaAA)
l9 = VideoExtractor(AaaaaAA, T13301875320763)

class FilmEkseniUI(ManituxUI):
    title = bytes.fromhex('46696c6d456b73656e69').decode('utf-8')

    def categories(jjjjjjjjjjjjjjjjjj):
        categories = [{bytes.fromhex('7469746c65').decode('utf-8'): bytes.fromhex('417261').decode('utf-8'), bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('736561726368').decode('utf-8')}]
        for title, url in x795561373033319.categories():
            categories.append({bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url})
        return categories

    def videos(jjjjjjjjjjjjjjjjjj, category, page=1):
        if category.get(bytes.fromhex('616374696f6e').decode('utf-8')) == bytes.fromhex('736561726368').decode('utf-8'):
            query = xbmcgui.Dialog().input(bytes.fromhex('46696c6d456b73656e6920417261').decode('utf-8'))
            return x795561373033319.search(query) if query else []
        return x795561373033319.get_page_items(category[bytes.fromhex('75726c').decode('utf-8')], page)

    def detail(jjjjjjjjjjjjjjjjjj, video):
        page_url = video[bytes.fromhex('75726c').decode('utf-8')]
        page = x795561373033319.get(page_url)
        w12 = x795561373033319.parse_detail(page, page_url)
        IIIllIIIlll = w12.get(bytes.fromhex('696d616765').decode('utf-8')) or video.get(bytes.fromhex('696d616765').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
        aaaAAAaaAAaAaaaA = w12.get(bytes.fromhex('706c6f74').decode('utf-8')) or video.get(bytes.fromhex('706c6f74').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
        sources = []
        for source in w12.get(bytes.fromhex('736f7572636573').decode('utf-8'), []):
            sources.append({bytes.fromhex('6c6162656c').decode('utf-8'): source.get(bytes.fromhex('6c6162656c').decode('utf-8')) or bytes.fromhex('4f796e6174').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('72656665726572').decode('utf-8'): source.get(bytes.fromhex('72656665726572').decode('utf-8')) or page_url, bytes.fromhex('69735f747261696c6572').decode('utf-8'): source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8'), False)})
        return {bytes.fromhex('7469746c65').decode('utf-8'): w12.get(bytes.fromhex('7469746c65').decode('utf-8')) or video.get(bytes.fromhex('7469746c65').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('75726c').decode('utf-8'): page_url, bytes.fromhex('696d616765').decode('utf-8'): IIIllIIIlll, bytes.fromhex('6261636b64726f70').decode('utf-8'): w12.get(bytes.fromhex('6261636b64726f70').decode('utf-8')) or w12.get(bytes.fromhex('66616e617274').decode('utf-8')) or IIIllIIIlll, bytes.fromhex('706c6f74').decode('utf-8'): aaaAAAaaAAaAaaaA, bytes.fromhex('79656172').decode('utf-8'): w12.get(bytes.fromhex('79656172').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('636f756e747279').decode('utf-8'): w12.get(bytes.fromhex('636f756e747279').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('6475726174696f6e').decode('utf-8'): w12.get(bytes.fromhex('6475726174696f6e').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('726174696e67').decode('utf-8'): w12.get(bytes.fromhex('726174696e67').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('74616773').decode('utf-8'): w12.get(bytes.fromhex('74616773').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('6163746f7273').decode('utf-8'): w12.get(bytes.fromhex('6163746f7273').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('657069736f646573').decode('utf-8'): w12.get(bytes.fromhex('657069736f646573').decode('utf-8'), []), bytes.fromhex('736f7572636573').decode('utf-8'): sources}

    def episode_detail(jjjjjjjjjjjjjjjjjj, hhhhhhhh, video=None):
        return jjjjjjjjjjjjjjjjjj.detail(hhhhhhhh)

    def play(jjjjjjjjjjjjjjjjjj, source, video=None):
        if source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8')):
            play_iframe_gui(source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), source.get(bytes.fromhex('72656665726572').decode('utf-8')), source.get(bytes.fromhex('6c6162656c').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
        else:
            play_source_gui(source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), source.get(bytes.fromhex('72656665726572').decode('utf-8')), source.get(bytes.fromhex('6c6162656c').decode('utf-8'), bytes.fromhex('').decode('utf-8')))

def build_url(query):
    return sys.argv[0] + bytes.fromhex('3f').decode('utf-8') + urlencode(query)

def add_directory(title, action, url=bytes.fromhex('').decode('utf-8'), IIIllIIIlll=bytes.fromhex('').decode('utf-8'), aaaAAAaaAAaAaaaA=bytes.fromhex('').decode('utf-8')):
    X13 = xbmcgui.ListItem(label=title)
    X13.setArt({bytes.fromhex('7468756d62').decode('utf-8'): IIIllIIIlll, bytes.fromhex('69636f6e').decode('utf-8'): IIIllIIIlll, bytes.fromhex('706f73746572').decode('utf-8'): IIIllIIIlll, bytes.fromhex('66616e617274').decode('utf-8'): IIIllIIIlll})
    X13.setInfo(bytes.fromhex('766964656f').decode('utf-8'), {bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('706c6f74').decode('utf-8'): aaaAAAaaAAaAaaaA})
    xbmcplugin.addDirectoryItem(r97696359883074, build_url({bytes.fromhex('616374696f6e').decode('utf-8'): action, bytes.fromhex('75726c').decode('utf-8'): url}), X13, True)

def add_video(title, action, url, IIIllIIIlll=bytes.fromhex('').decode('utf-8'), aaaAAAaaAAaAaaaA=bytes.fromhex('').decode('utf-8'), extra=None):
    query = {bytes.fromhex('616374696f6e').decode('utf-8'): action, bytes.fromhex('75726c').decode('utf-8'): url}
    if extra:
        query.update(extra)
    X13 = xbmcgui.ListItem(label=title)
    X13.setArt({bytes.fromhex('7468756d62').decode('utf-8'): IIIllIIIlll, bytes.fromhex('69636f6e').decode('utf-8'): IIIllIIIlll, bytes.fromhex('706f73746572').decode('utf-8'): IIIllIIIlll, bytes.fromhex('66616e617274').decode('utf-8'): IIIllIIIlll})
    X13.setInfo(bytes.fromhex('766964656f').decode('utf-8'), {bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('706c6f74').decode('utf-8'): aaaAAAaaAAaAaaaA})
    X13.setProperty(bytes.fromhex('4973506c617961626c65').decode('utf-8'), bytes.fromhex('74727565').decode('utf-8'))
    xbmcplugin.addDirectoryItem(r97696359883074, build_url(query), X13, False)

def main_menu():
    add_directory(bytes.fromhex('417261').decode('utf-8'), bytes.fromhex('736561726368').decode('utf-8'))
    for title, url in x795561373033319.categories():
        add_directory(title, bytes.fromhex('6c697374').decode('utf-8'), url)
    xbmcplugin.setContent(r97696359883074, bytes.fromhex('766964656f73').decode('utf-8'))

def list_page(url, page_number=1):
    items = x795561373033319.get_page_items(url, page_number)
    for item in items:
        add_directory(item[bytes.fromhex('7469746c65').decode('utf-8')], bytes.fromhex('64657461696c').decode('utf-8'), item[bytes.fromhex('75726c').decode('utf-8')], item[bytes.fromhex('696d616765').decode('utf-8')], item[bytes.fromhex('706c6f74').decode('utf-8')])
    if items:
        X13 = xbmcgui.ListItem(label=bytes.fromhex('536f6e72616b69205361796661').decode('utf-8'))
        xbmcplugin.addDirectoryItem(r97696359883074, build_url({bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('6c697374').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('70616765').decode('utf-8'): str(int(page_number) + 1)}), X13, True)
    xbmcplugin.setContent(r97696359883074, bytes.fromhex('6d6f76696573').decode('utf-8'))

def search():
    query = xbmcgui.Dialog().input(bytes.fromhex('46696c6d456b73656e6920417261').decode('utf-8'))
    if query:
        for item in x795561373033319.search(query):
            add_directory(item[bytes.fromhex('7469746c65').decode('utf-8')], bytes.fromhex('64657461696c').decode('utf-8'), item[bytes.fromhex('75726c').decode('utf-8')], item[bytes.fromhex('696d616765').decode('utf-8')], item.get(bytes.fromhex('706c6f74').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
        xbmcplugin.setContent(r97696359883074, bytes.fromhex('6d6f76696573').decode('utf-8'))

def detail(url):
    page = x795561373033319.get(url)
    w12 = x795561373033319.parse_detail(page, url)
    sources = w12.get(bytes.fromhex('736f7572636573').decode('utf-8'), [])
    I286562817915415 = [source for source in sources if not source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8'))]
    for source in sources:
        add_video(source[bytes.fromhex('6c6162656c').decode('utf-8')], bytes.fromhex('706c61795f696672616d65').decode('utf-8') if source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8')) else bytes.fromhex('706c61795f736f75726365').decode('utf-8'), source[bytes.fromhex('75726c').decode('utf-8')], w12[bytes.fromhex('696d616765').decode('utf-8')], w12[bytes.fromhex('706c6f74').decode('utf-8')], {bytes.fromhex('72656665726572').decode('utf-8'): source.get(bytes.fromhex('72656665726572').decode('utf-8')) or url, bytes.fromhex('6c6162656c').decode('utf-8'): source[bytes.fromhex('6c6162656c').decode('utf-8')]})
    if not I286562817915415:
        for hhhhhhhh in w12.get(bytes.fromhex('657069736f646573').decode('utf-8'), []):
            add_directory(hhhhhhhh[bytes.fromhex('7469746c65').decode('utf-8')], bytes.fromhex('64657461696c').decode('utf-8'), hhhhhhhh[bytes.fromhex('75726c').decode('utf-8')], w12[bytes.fromhex('696d616765').decode('utf-8')], w12[bytes.fromhex('706c6f74').decode('utf-8')])
    if not sources and (not w12.get(bytes.fromhex('657069736f646573').decode('utf-8'))):
        xbmcgui.Dialog().notification(bytes.fromhex('46696c6d456b73656e69').decode('utf-8'), bytes.fromhex('566964656f206b61796e6167692062756c756e616d616469').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)

def play_source(url, referer=None, label=bytes.fromhex('').decode('utf-8')):
    if is_external_url(url):
        ZZZZZZZZZZ = url
    else:
        ZZZZZZZZZZ = x795561373033319.fetch_iframe(url, referer) or url
    play_iframe(ZZZZZZZZZZ, url, label)

def youtube_plugin_url(url):
    aaaaAaAAAaaAAAaAAAAaAA = bytes.fromhex('').decode('utf-8')
    for pattern in (bytes.fromhex('283f3a796f75747562655c2e636f6d2f656d6265642f7c796f75747562655c2e636f6d2f77617463685c3f763d7c796f7574755c2e62652f29285b412d5a612d7a302d395f2d5d7b362c7d29').decode('utf-8'), bytes.fromhex('5b3f265d763d285b412d5a612d7a302d395f2d5d7b362c7d29').decode('utf-8')):
        dddddddddddddd = re.search(pattern, url or bytes.fromhex('').decode('utf-8'), re.I)
        if dddddddddddddd:
            aaaaAaAAAaaAAAaAAAAaAA = dddddddddddddd.group(1)
            break
    return bytes.fromhex('706c7567696e3a2f2f706c7567696e2e766964656f2e796f75747562652f706c61792f3f766964656f5f69643d').decode('utf-8') + aaaaAaAAAaaAAAaAAAAaAA if aaaaAaAAAaaAAAaAAAAaAA else bytes.fromhex('').decode('utf-8')

def play_youtube(url):
    IlllIllIIIlIIIlIl = youtube_plugin_url(url)
    if not IlllIllIIIlIIIlIl:
        xbmcplugin.setResolvedUrl(r97696359883074, False, xbmcgui.ListItem())
        return
    try:
        xbmcaddon.Addon(id=bytes.fromhex('706c7567696e2e766964656f2e796f7574756265').decode('utf-8'))
    except Exception:
        xbmcgui.Dialog().notification(bytes.fromhex('596f7554756265').decode('utf-8'), bytes.fromhex('706c7567696e2e766964656f2e796f757475626520676572656b6c69').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.setResolvedUrl(r97696359883074, False, xbmcgui.ListItem())
        return
    xbmcplugin.setResolvedUrl(r97696359883074, True, xbmcgui.ListItem(path=IlllIllIIIlIIIlIl))

def play_youtube_gui(url):
    IlllIllIIIlIIIlIl = youtube_plugin_url(url)
    if not IlllIllIIIlIIIlIl:
        return False
    try:
        xbmcaddon.Addon(id=bytes.fromhex('706c7567696e2e766964656f2e796f7574756265').decode('utf-8'))
    except Exception:
        xbmcgui.Dialog().notification(bytes.fromhex('596f7554756265').decode('utf-8'), bytes.fromhex('706c7567696e2e766964656f2e796f757475626520676572656b6c69').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
        return False
    xbmc.Player().play(IlllIllIIIlIIIlIl)
    return True

def play_iframe(url, referer=None, label=bytes.fromhex('').decode('utf-8')):
    if youtube_plugin_url(url):
        play_youtube(url)
        return
    IlllIIlIlllIIllIIllll, subtitles = l9.resolve(url, referer, label)
    if not IlllIIlIlllIIllIIllll:
        xbmcplugin.setResolvedUrl(r97696359883074, False, xbmcgui.ListItem())
        return
    X13 = xbmcgui.ListItem(path=IlllIIlIlllIIllIIllll)
    if is_hls(IlllIIlIlllIIllIIllll):
        X13.setMimeType(bytes.fromhex('6170706c69636174696f6e2f766e642e6170706c652e6d70656775726c').decode('utf-8'))
        X13.setContentLookup(False)
    if subtitles:
        X13.setSubtitles(subtitles)
    xbmcplugin.setResolvedUrl(r97696359883074, True, X13)

def play_iframe_gui(url, referer=None, label=bytes.fromhex('').decode('utf-8')):
    if youtube_plugin_url(url):
        play_youtube_gui(url)
        return
    IlllIIlIlllIIllIIllll, subtitles = l9.resolve(url, referer, label)
    play_stream_gui(IlllIIlIlllIIllIIllll, subtitles)

def play_source_gui(url, referer=None, label=bytes.fromhex('').decode('utf-8')):
    if is_external_url(url):
        ZZZZZZZZZZ = url
    else:
        ZZZZZZZZZZ = x795561373033319.fetch_iframe(url, referer) or url
    play_iframe_gui(ZZZZZZZZZZ, url, label)

def play_stream_gui(IlllIIlIlllIIllIIllll, subtitles=None):
    if not IlllIIlIlllIIllIIllll:
        xbmcgui.Dialog().notification(bytes.fromhex('46696c6d456b73656e69').decode('utf-8'), bytes.fromhex('4b61796e616b20c3a7c3b67ac3bc6c6d656469').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    X13 = xbmcgui.ListItem(path=IlllIIlIlllIIllIIllll)
    if is_hls(IlllIIlIlllIIllIIllll):
        X13.setMimeType(bytes.fromhex('6170706c69636174696f6e2f766e642e6170706c652e6d70656775726c').decode('utf-8'))
        X13.setContentLookup(False)
    if subtitles:
        X13.setSubtitles(subtitles)
    xbmc.Player().play(IlllIIlIlllIIllIIllll, X13)

def is_hls(url):
    return bytes.fromhex('2e6d337538').decode('utf-8') in (url or bytes.fromhex('').decode('utf-8')).split(bytes.fromhex('7c').decode('utf-8'), 1)[0].lower()

def is_external_url(url):
    return (url or bytes.fromhex('').decode('utf-8')).startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8'))) and (not url.startswith(T13301875320763.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8')))

def run():
    params = dict(parse_qsl(sys.argv[2][1:]))
    action = params.get(bytes.fromhex('616374696f6e').decode('utf-8'))
    url = params.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
    page_number = int(params.get(bytes.fromhex('70616765').decode('utf-8'), bytes.fromhex('31').decode('utf-8')))
    if not action:
        xbmcplugin.endOfDirectory(r97696359883074, succeeded=True, cacheToDisc=False)
        V533742218874223 = xbmcgui.Window(10000)
        try:
            P20 = float(V533742218874223.getProperty(LcGInNvLkBwDkhkVAsaBGibPyfldpWGhULdWQijBwixSICVMUVJsjKupUpYnhdDxVprxtuCIBGTeWOx6) or bytes.fromhex('30').decode('utf-8'))
        except ValueError:
            P20 = 0
        if time.time() < P20:
            return
        V533742218874223.clearProperty(LcGInNvLkBwDkhkVAsaBGibPyfldpWGhULdWQijBwixSICVMUVJsjKupUpYnhdDxVprxtuCIBGTeWOx6)
        xbmc.executebuiltin(bytes.fromhex('52756e506c7567696e287b307d29').decode('utf-8').format(build_url({bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('677569').decode('utf-8')})))
        return
    elif action == bytes.fromhex('677569').decode('utf-8'):
        open_browser(FilmEkseniUI())
        xbmcgui.Window(10000).setProperty(LcGInNvLkBwDkhkVAsaBGibPyfldpWGhULdWQijBwixSICVMUVJsjKupUpYnhdDxVprxtuCIBGTeWOx6, str(time.time() + 4))
        xbmc.executebuiltin(bytes.fromhex('416374697661746557696e646f7728486f6d6529').decode('utf-8'))
        return
    elif action == bytes.fromhex('636c6173736963').decode('utf-8'):
        main_menu()
    elif action == bytes.fromhex('6c697374').decode('utf-8'):
        list_page(url, page_number)
    elif action == bytes.fromhex('736561726368').decode('utf-8'):
        search()
    elif action == bytes.fromhex('64657461696c').decode('utf-8'):
        detail(url)
    elif action == bytes.fromhex('706c61795f736f75726365').decode('utf-8'):
        play_source(url, params.get(bytes.fromhex('72656665726572').decode('utf-8')), params.get(bytes.fromhex('6c6162656c').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
    elif action == bytes.fromhex('706c61795f696672616d65').decode('utf-8'):
        play_iframe(url, params.get(bytes.fromhex('72656665726572').decode('utf-8')), params.get(bytes.fromhex('6c6162656c').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
    xbmcplugin.endOfDirectory(r97696359883074)
if __name__ == bytes.fromhex('5f5f6d61696e5f5f').decode('utf-8'):
    run()
