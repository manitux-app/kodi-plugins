from __future__ import absolute_import, unicode_literals
import json
import re
import string
import manituxhttp
try:
    from urllib.parse import quote, urljoin, urlparse
except ImportError:
    from urllib import quote
    from urlparse import urljoin, urlparse

class VideoExtractor(object):
    CLIENT_IDENTIFIERS = (bytes.fromhex('636c6f756473637261706572').decode('utf-8'), bytes.fromhex('6368726f6d655f313434').decode('utf-8'))

    def __init__(Q20, user_agent, main_url):
        Q20.user_agent = user_agent
        Q20.main_url = main_url.rstrip(bytes.fromhex('2f').decode('utf-8'))
        Q20.session = manituxhttp.Session(client_identifier=Q20.CLIENT_IDENTIFIERS[0])

    def resolve(Q20, url, referer=None, label=bytes.fromhex('').decode('utf-8')):
        if not url:
            return (None, [])
        url = Q20.normalize_url(url)
        R94937303035276 = urlparse(url).netloc.lower()
        if bytes.fromhex('796f7574756265').decode('utf-8') in R94937303035276 or bytes.fromhex('796f7574752e6265').decode('utf-8') in R94937303035276:
            return (url + Q20.kodi_headers(referer), [])
        if bytes.fromhex('656b73656e6c6f6164').decode('utf-8') in R94937303035276:
            return Q20.resolve_eksenload(url, referer, label)
        if bytes.fromhex('7669646d6f6c79').decode('utf-8') in R94937303035276 or bytes.fromhex('766964656f62696e').decode('utf-8') in R94937303035276:
            return Q20.resolve_vidmoly(url, referer)
        if bytes.fromhex('6f6b2e7275').decode('utf-8') in R94937303035276 or bytes.fromhex('6f646e6f6b6c6173736e696b69').decode('utf-8') in R94937303035276:
            return Q20.resolve_okru(url)
        if bytes.fromhex('73747265616d74617065').decode('utf-8') in R94937303035276 or bytes.fromhex('77617463686164736f6e74617065').decode('utf-8') in R94937303035276 or bytes.fromhex('736861766574617065').decode('utf-8') in R94937303035276:
            return Q20.resolve_streamtape(url, referer)
        page = Q20.fetch(url, referer)
        source, sssssssssssssssssssss = Q20.extract_jwplayer(page, Q20.origin(url))
        if source:
            return (source + Q20.kodi_headers(url), sssssssssssssssssssss)
        IllI = Q20._first(bytes.fromhex('68747470733f3a2f2f5b5e5c7322273c3e5d2b3f5c2e283f3a6d3375387c6d703429283f3a5c3f5b5e5c7322273c3e5d2a293f').decode('utf-8'), page)
        return (IllI + Q20.kodi_headers(url) if IllI else url + Q20.kodi_headers(referer), [])

    def resolve_eksenload(Q20, url, referer=None, label=bytes.fromhex('').decode('utf-8')):
        page = Q20.fetch(url, referer, origin=Q20.main_url)
        origin = Q20.origin(url)
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): Q20.user_agent, bytes.fromhex('4f726967696e').decode('utf-8'): origin}
        source, sssssssssssssssssssss = Q20.extract_jwplayer(page, origin, headers)
        if not source:
            e23 = url.rstrip(bytes.fromhex('2f').decode('utf-8')).split(bytes.fromhex('2f').decode('utf-8'))[-1]
            if e23:
                source = origin + bytes.fromhex('2f75706c6f6164732f656e636f64652f').decode('utf-8') + e23 + bytes.fromhex('2f6d61737465722e6d337538').decode('utf-8')
        if not source:
            return (None, sssssssssssssssssssss)
        return (source + Q20.kodi_headers(url, headers), sssssssssssssssssssss)

    def resolve_vidmoly(Q20, url, referer=None):
        url = Q20.normalize_url(url)
        Z52918475755023 = [url]
        x14 = re.search(bytes.fromhex('2f772f285b612d7a302d395d2b292f2a24').decode('utf-8'), url, re.I)
        if x14:
            Z52918475755023.insert(0, re.sub(bytes.fromhex('2f772f285b612d7a302d395d2b292f2a24').decode('utf-8'), bytes.fromhex('2f656d6265642d5c312e68746d6c').decode('utf-8'), url, flags=re.I))
        BBBBBBB = bytes.fromhex('').decode('utf-8')
        page_url = url
        for AA in Z52918475755023:
            BBBBBBB = Q20.fetch(AA, referer)
            page_url = AA
            if bytes.fromhex('2e6d337538').decode('utf-8') in BBBBBBB or bytes.fromhex('736f7572636573').decode('utf-8') in BBBBBBB or bytes.fromhex('6a77706c61796572').decode('utf-8') in BBBBBBB:
                break
        source, sssssssssssssssssssss = Q20.extract_jwplayer(BBBBBBB, Q20.origin(page_url), {bytes.fromhex('557365722d4167656e74').decode('utf-8'): Q20.user_agent})
        if not source:
            source = Q20._first(bytes.fromhex('68747470733f3a2f2f5b5e5c7322273c3e5d2b3f5c2e283f3a6d3375387c6d703429283f3a5c3f5b5e5c7322273c3e5d2a293f').decode('utf-8'), BBBBBBB)
        return (source + Q20.kodi_headers(page_url) if source else None, sssssssssssssssssssss)

    def resolve_okru(Q20, url):
        url = Q20.normalize_url(url)
        e23 = Q20._first(bytes.fromhex('283f3a766964656f656d6265642f7c766964656f2f7c6d69643d29285c642b29').decode('utf-8'), url)
        if not e23:
            return (url + Q20.kodi_headers(bytes.fromhex('68747470733a2f2f6f6b2e72752f').decode('utf-8')), [])
        AAAaAAaAAaaAaAaaaaA = Q20.session.post(bytes.fromhex('68747470733a2f2f7777772e6f6b2e72752f646b').decode('utf-8'), data={bytes.fromhex('636d64').decode('utf-8'): bytes.fromhex('766964656f506c617965724d65746164617461').decode('utf-8'), bytes.fromhex('6d6964').decode('utf-8'): e23}, headers=Q20.headers(bytes.fromhex('68747470733a2f2f6f6b2e72752f').decode('utf-8')), timeout=25)
        AAAaAAaAAaaAaAaaaaA.raise_for_status()
        data = AAAaAAaAAaaAaAaaaaA.text.replace(bytes.fromhex('5c7530303236').decode('utf-8'), bytes.fromhex('26').decode('utf-8')).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'))
        source = Q20._first(bytes.fromhex('22283f3a6f6e64656d616e64486c737c6f6e64656d616e644461736829225c732a3a5c732a22285b5e225d2b2922').decode('utf-8'), data)
        if not source:
            source = Q20._first(bytes.fromhex('22283f3a6e616d657c7175616c69747929225c732a3a5c732a22283f3a756c7472617c717561647c66756c6c7c68647c73647c6c6f777c6d6f62696c6529225b5e7b7d5d2a2275726c225c732a3a5c732a22285b5e225d2b2922').decode('utf-8'), data, re.S)
        return (source + Q20.kodi_headers(bytes.fromhex('68747470733a2f2f6f6b2e72752f').decode('utf-8')) if source else None, [])

    def resolve_streamtape(Q20, url, referer=None):
        page = Q20.fetch(url, referer)
        Y12 = bytes.fromhex('').decode('utf-8')
        for AA in page.splitlines():
            if bytes.fromhex('626f746c696e6b27292e696e6e657248544d4c').decode('utf-8') in AA or bytes.fromhex('626f746c696e6b22292e696e6e657248544d4c').decode('utf-8') in AA:
                Y12 = AA
                break
        ccccccccccccc = re.findall(bytes.fromhex('5b27225d285b5e27225d2a295b27225d').decode('utf-8'), Y12)
        J984567645675217 = [u310187186440024 for u310187186440024 in ccccccccccccc if bytes.fromhex('2f').decode('utf-8') in u310187186440024 or bytes.fromhex('26').decode('utf-8') in u310187186440024 or bytes.fromhex('3d').decode('utf-8') in u310187186440024]
        source = bytes.fromhex('').decode('utf-8').join(J984567645675217)
        if source.startswith(bytes.fromhex('2f2f').decode('utf-8')):
            source = bytes.fromhex('68747470733a').decode('utf-8') + source
        if source:
            source += bytes.fromhex('2673747265616d3d31').decode('utf-8')
        return (source + Q20.kodi_headers(url) if source else None, [])

    def extract_jwplayer(Q20, page, base_url, headers=None):
        source = bytes.fromhex('').decode('utf-8')
        sssssssssssssssssssss = []
        for aAaAaAAAaAAaaAAaaA in re.findall(bytes.fromhex('5b22275d3f736f75726365735b22275d3f5c732a3a5c732a285c5b2e2a3f5c5d29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            for item in Q20._parse_js_list(aAaAaAAAaAAaaAAaaA):
                url = item.get(bytes.fromhex('66696c65').decode('utf-8'))
                if url:
                    source = urljoin(base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8'), url.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')))
                    break
            if source:
                break
        if not source:
            x14 = re.search(bytes.fromhex('5b3a3d5d5c732a5b22275d285b5e22275c735d2b283f3a5c2e6d3375387c6d61737465725c2e747874295b5e22275c735d2a29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I)
            if x14:
                source = urljoin(base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8'), x14.group(1).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')))
        for aAaAaAAAaAAaaAAaaA in re.findall(bytes.fromhex('5b22275d3f747261636b735b22275d3f5c732a3a5c732a285c5b2e2a3f5c5d29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            for item in Q20._parse_js_list(aAaAaAAAaAAaaAAaaA):
                lllIlIlIll = (item.get(bytes.fromhex('6b696e64').decode('utf-8')) or bytes.fromhex('').decode('utf-8')).lower()
                aaAaa = item.get(bytes.fromhex('66696c65').decode('utf-8'))
                if aaAaa and (bytes.fromhex('63617074696f6e').decode('utf-8') in lllIlIlIll or bytes.fromhex('7375627469746c65').decode('utf-8') in lllIlIlIll):
                    sssssssssssssssssssss.append(urljoin(base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8'), aaAaa.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'))))
        return (source, list(dict.fromkeys(sssssssssssssssssssss)))

    def _parse_js_list(Q20, lIlIlIlIIllIlllIIllIll):
        WWWWWWWWWWWWWWW = lIlIlIlIIllIlllIIllIll.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'))
        WWWWWWWWWWWWWWW = re.sub(bytes.fromhex('285b7b2c5d5c732a292866696c657c6c6162656c7c747970657c6b696e64295c732a3a').decode('utf-8'), bytes.fromhex('5c31225c32223a').decode('utf-8'), WWWWWWWWWWWWWWW)
        WWWWWWWWWWWWWWW = WWWWWWWWWWWWWWW.replace(bytes.fromhex('27').decode('utf-8'), bytes.fromhex('22').decode('utf-8'))
        WWWWWWWWWWWWWWW = re.sub(bytes.fromhex('2c5c732a285b5c5d7d5d29').decode('utf-8'), bytes.fromhex('5c31').decode('utf-8'), WWWWWWWWWWWWWWW)
        try:
            data = json.loads(WWWWWWWWWWWWWWW)
            return data if isinstance(data, list) else []
        except Exception:
            items = []
            for a in re.findall(bytes.fromhex('5c7b282e2a3f295c7d').decode('utf-8'), lIlIlIlIIllIlllIIllIll, re.S):
                item = {}
                for AUIbIETJopUAkPKGojjddjjyPZYLbOspqXYyQUGGnHtoFdWuDJfEKWFlpPgwoLvCVTEGLQXDsjfCouA9 in (bytes.fromhex('66696c65').decode('utf-8'), bytes.fromhex('6c6162656c').decode('utf-8'), bytes.fromhex('74797065').decode('utf-8'), bytes.fromhex('6b696e64').decode('utf-8')):
                    item[AUIbIETJopUAkPKGojjddjjyPZYLbOspqXYyQUGGnHtoFdWuDJfEKWFlpPgwoLvCVTEGLQXDsjfCouA9] = Q20._first(bytes.fromhex('5b22275d3f25735b22275d3f5c732a3a5c732a5b22275d285b5e22275d2b29').decode('utf-8') % AUIbIETJopUAkPKGojjddjjyPZYLbOspqXYyQUGGnHtoFdWuDJfEKWFlpPgwoLvCVTEGLQXDsjfCouA9, a)
                items.append(item)
            return items

    def fetch(Q20, url, referer=None, origin=None):
        E649445539539911 = None
        for MMMMMMMM in Q20.CLIENT_IDENTIFIERS:
            if Q20.session.client_identifier != MMMMMMMM:
                Q20.session = manituxhttp.Session(client_identifier=MMMMMMMM)
            try:
                AAAaAAaAAaaAaAaaaaA = Q20.session.get(url, headers=Q20.headers(referer, origin), timeout=25, allow_redirects=True, tls_client_identifier=MMMMMMMM)
                if AAAaAAaAAaaAaAaaaaA.status_code in (403, 429) and MMMMMMMM != Q20.CLIENT_IDENTIFIERS[-1]:
                    E649445539539911 = manituxhttp.HTTPError(AAAaAAaAAaaAaAaaaaA)
                    continue
                AAAaAAaAAaaAaAaaaaA.raise_for_status()
                return AAAaAAaAAaaAaAaaaaA.text
            except (manituxhttp.HTTPError, manituxhttp.RequestError) as exc:
                E649445539539911 = exc
                if MMMMMMMM == Q20.CLIENT_IDENTIFIERS[-1]:
                    raise
        raise E649445539539911

    def headers(Q20, referer=None, origin=None):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): Q20.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('746578742f68746d6c2c6170706c69636174696f6e2f7868746d6c2b786d6c2c6170706c69636174696f6e2f786d6c3b713d302e392c2a2f2a3b713d302e38').decode('utf-8')}
        if referer:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        if origin:
            headers[bytes.fromhex('4f726967696e').decode('utf-8')] = origin
        return headers

    def kodi_headers(Q20, referer=None, extra=None):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): Q20.user_agent}
        if referer:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        if extra:
            headers.update(extra)
        return bytes.fromhex('7c').decode('utf-8') + bytes.fromhex('26').decode('utf-8').join((bytes.fromhex('7b307d3d7b317d').decode('utf-8').format(AUIbIETJopUAkPKGojjddjjyPZYLbOspqXYyQUGGnHtoFdWuDJfEKWFlpPgwoLvCVTEGLQXDsjfCouA9, quote(lIlIlIlIIllIlllIIllIll)) for AUIbIETJopUAkPKGojjddjjyPZYLbOspqXYyQUGGnHtoFdWuDJfEKWFlpPgwoLvCVTEGLQXDsjfCouA9, lIlIlIlIIllIlllIIllIll in headers.items() if lIlIlIlIIllIlllIIllIll))

    def normalize_url(Q20, url):
        if url.startswith(bytes.fromhex('2f2f').decode('utf-8')):
            return bytes.fromhex('68747470733a').decode('utf-8') + url
        if url.startswith(bytes.fromhex('7777772e').decode('utf-8')):
            return bytes.fromhex('68747470733a2f2f').decode('utf-8') + url
        if not url.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8'))):
            return urljoin(Q20.main_url + bytes.fromhex('2f').decode('utf-8'), url)
        return url

    def origin(Q20, url):
        AaAaaAaAaaaaaAAa = urlparse(url)
        return AaAaaAaAaaaaaAAa.scheme + bytes.fromhex('3a2f2f').decode('utf-8') + AaAaaAaAaaaaaAAa.netloc

    @staticmethod
    def _first(pattern, text, flags=0):
        x14 = re.search(pattern, text or bytes.fromhex('').decode('utf-8'), flags | re.I)
        if not x14:
            return bytes.fromhex('').decode('utf-8')
        return x14.group(1) if x14.lastindex else x14.group(0)
