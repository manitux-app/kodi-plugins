from __future__ import absolute_import, unicode_literals
import manituxhttp
try:
    from urllib.parse import quote_plus
except ImportError:
    from urllib import quote_plus
from . import parsers

class FilmEkseniSite(object):
    CLIENT_IDENTIFIERS = (bytes.fromhex('636c6f756473637261706572').decode('utf-8'), bytes.fromhex('6368726f6d655f313434').decode('utf-8'))

    def __init__(WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5, base_url, user_agent):
        WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.base_url = base_url.rstrip(bytes.fromhex('2f').decode('utf-8'))
        WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.user_agent = user_agent
        WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.session = manituxhttp.Session(client_identifier=WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.CLIENT_IDENTIFIERS[0])

    def headers(WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5, referer=None, ajax=False):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('746578742f68746d6c2c6170706c69636174696f6e2f7868746d6c2b786d6c2c6170706c69636174696f6e2f786d6c3b713d302e392c2a2f2a3b713d302e38').decode('utf-8')}
        if referer:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        if ajax:
            headers[bytes.fromhex('582d5265717565737465642d57697468').decode('utf-8')] = bytes.fromhex('584d4c4874747052657175657374').decode('utf-8')
            headers[bytes.fromhex('4f726967696e').decode('utf-8')] = WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.base_url
        return headers

    def categories(WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5):
        return parsers.categories(WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.base_url)

    def get(WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5, url, referer=None):
        return WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5._get(WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.absolute(url), WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.headers(referer)).text

    def post(WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5, url, data, referer=None):
        return WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5._post(WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.absolute(url), data, WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.headers(referer, ajax=True)).text

    def get_page_items(WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5, category_url, page_number=1, title=bytes.fromhex('').decode('utf-8')):
        page = WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.get(parsers.page_url(category_url, page_number), referer=category_url)
        return parsers.parse_page_items(page, WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.base_url, title)

    def search(WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5, query):
        llI = WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.get(WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.base_url + bytes.fromhex('2f6170692f7365617263683f713d').decode('utf-8') + quote_plus(query), referer=WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.base_url + bytes.fromhex('2f').decode('utf-8'))
        return parsers.parse_search_results(llI, WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.base_url)

    def parse_detail(WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5, page, url):
        return parsers.parse_media_info(page, url, WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.base_url)

    def fetch_iframe(WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5, OOOOOO, referer=None):
        page = WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.get(OOOOOO, referer=referer or WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.base_url + bytes.fromhex('2f').decode('utf-8'))
        return parsers.parse_iframe(page, WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.base_url)

    def absolute(WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5, url):
        return parsers.fix_url(url, WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.base_url)

    def search_url(WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5, query):
        return WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.base_url + bytes.fromhex('2f7365617263682f3f713d').decode('utf-8') + quote_plus(query)

    def _get(WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5, url, headers):
        s2 = None
        for j in WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.CLIENT_IDENTIFIERS:
            if WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.session.client_identifier != j:
                WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.session = manituxhttp.Session(client_identifier=j)
            try:
                lIll = WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.session.get(url, headers=headers, timeout=25, tls_client_identifier=j)
                if lIll.status_code in (403, 429) and j != WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.CLIENT_IDENTIFIERS[-1]:
                    s2 = manituxhttp.HTTPError(lIll)
                    continue
                lIll.raise_for_status()
                return lIll
            except (manituxhttp.HTTPError, manituxhttp.RequestError) as exc:
                s2 = exc
                if j == WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.CLIENT_IDENTIFIERS[-1]:
                    raise
        raise s2

    def _post(WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5, url, data, headers):
        s2 = None
        for j in WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.CLIENT_IDENTIFIERS:
            if WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.session.client_identifier != j:
                WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.session = manituxhttp.Session(client_identifier=j)
            try:
                lIll = WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.session.post(url, data=data, headers=headers, timeout=25, tls_client_identifier=j)
                if lIll.status_code in (403, 429) and j != WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.CLIENT_IDENTIFIERS[-1]:
                    s2 = manituxhttp.HTTPError(lIll)
                    continue
                lIll.raise_for_status()
                return lIll
            except (manituxhttp.HTTPError, manituxhttp.RequestError) as exc:
                s2 = exc
                if j == WtGxfpFbpDqVYADdVJDXwtgYuPOELfslqXpvMlAwUtoZJeVLmomTgABwRCVgRDzplyeZyVyYpWHIyap5.CLIENT_IDENTIFIERS[-1]:
                    raise
        raise s2
