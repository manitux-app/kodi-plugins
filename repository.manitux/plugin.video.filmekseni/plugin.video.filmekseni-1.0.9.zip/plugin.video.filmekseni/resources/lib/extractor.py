from __future__ import absolute_import, unicode_literals
import json
import re
import string
import manituxhttp
try:
    from urllib.parse import quote, urljoin, urlparse
except ImportError:
    from urllib import quote
    from urlparse import urljoin, urlparse

class VideoExtractor(object):
    CLIENT_IDENTIFIERS = (bytes.fromhex('636c6f756473637261706572').decode('utf-8'), bytes.fromhex('6368726f6d655f313434').decode('utf-8'))

    def __init__(self, user_agent, main_url):
        self.user_agent = user_agent
        self.main_url = main_url.rstrip(bytes.fromhex('2f').decode('utf-8'))
        self.session = manituxhttp.Session(client_identifier=self.CLIENT_IDENTIFIERS[0])

    def resolve(self, url, referer=None, label=bytes.fromhex('').decode('utf-8')):
        if not url:
            return (None, [])
        url = self.normalize_url(url)
        O6 = urlparse(url).netloc.lower()
        if bytes.fromhex('796f7574756265').decode('utf-8') in O6 or bytes.fromhex('796f7574752e6265').decode('utf-8') in O6:
            return (url + self.kodi_headers(referer), [])
        if bytes.fromhex('656b73656e6c6f6164').decode('utf-8') in O6:
            return self.resolve_eksenload(url, referer, label)
        if bytes.fromhex('7669646d6f6c79').decode('utf-8') in O6 or bytes.fromhex('766964656f62696e').decode('utf-8') in O6:
            return self.resolve_vidmoly(url, referer)
        if bytes.fromhex('6f6b2e7275').decode('utf-8') in O6 or bytes.fromhex('6f646e6f6b6c6173736e696b69').decode('utf-8') in O6:
            return self.resolve_okru(url)
        if bytes.fromhex('73747265616d74617065').decode('utf-8') in O6 or bytes.fromhex('77617463686164736f6e74617065').decode('utf-8') in O6 or bytes.fromhex('736861766574617065').decode('utf-8') in O6:
            return self.resolve_streamtape(url, referer)
        page = self.fetch(url, referer)
        source, W22 = self.extract_jwplayer(page, self.origin(url))
        if source:
            return (source + self.kodi_headers(url), W22)
        j4 = self._first(bytes.fromhex('68747470733f3a2f2f5b5e5c7322273c3e5d2b3f5c2e283f3a6d3375387c6d703429283f3a5c3f5b5e5c7322273c3e5d2a293f').decode('utf-8'), page)
        return (j4 + self.kodi_headers(url) if j4 else url + self.kodi_headers(referer), [])

    def resolve_eksenload(self, url, referer=None, label=bytes.fromhex('').decode('utf-8')):
        page = self.fetch(url, referer, origin=self.main_url)
        origin = self.origin(url)
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): self.user_agent, bytes.fromhex('4f726967696e').decode('utf-8'): origin}
        source, W22 = self.extract_jwplayer(page, origin, headers)
        if not source:
            video_id = url.rstrip(bytes.fromhex('2f').decode('utf-8')).split(bytes.fromhex('2f').decode('utf-8'))[-1]
            if video_id:
                source = origin + bytes.fromhex('2f75706c6f6164732f656e636f64652f').decode('utf-8') + video_id + bytes.fromhex('2f6d61737465722e6d337538').decode('utf-8')
        if not source:
            return (None, W22)
        return (source + self.kodi_headers(url, headers), W22)

    def resolve_vidmoly(self, url, referer=None):
        url = self.normalize_url(url)
        III = [url]
        AAAaAAAAaaAaAaa = re.search(bytes.fromhex('2f772f285b612d7a302d395d2b292f2a24').decode('utf-8'), url, re.I)
        if AAAaAAAAaaAaAaa:
            III.insert(0, re.sub(bytes.fromhex('2f772f285b612d7a302d395d2b292f2a24').decode('utf-8'), bytes.fromhex('2f656d6265642d5c312e68746d6c').decode('utf-8'), url, flags=re.I))
        YYYYYYY = bytes.fromhex('').decode('utf-8')
        L796351286824517 = url
        for J2 in III:
            YYYYYYY = self.fetch(J2, referer)
            L796351286824517 = J2
            if bytes.fromhex('2e6d337538').decode('utf-8') in YYYYYYY or bytes.fromhex('736f7572636573').decode('utf-8') in YYYYYYY or bytes.fromhex('6a77706c61796572').decode('utf-8') in YYYYYYY:
                break
        source, W22 = self.extract_jwplayer(YYYYYYY, self.origin(L796351286824517), {bytes.fromhex('557365722d4167656e74').decode('utf-8'): self.user_agent})
        if not source:
            source = self._first(bytes.fromhex('68747470733f3a2f2f5b5e5c7322273c3e5d2b3f5c2e283f3a6d3375387c6d703429283f3a5c3f5b5e5c7322273c3e5d2a293f').decode('utf-8'), YYYYYYY)
        return (source + self.kodi_headers(L796351286824517) if source else None, W22)

    def resolve_okru(self, url):
        url = self.normalize_url(url)
        video_id = self._first(bytes.fromhex('283f3a766964656f656d6265642f7c766964656f2f7c6d69643d29285c642b29').decode('utf-8'), url)
        if not video_id:
            return (url + self.kodi_headers(bytes.fromhex('68747470733a2f2f6f6b2e72752f').decode('utf-8')), [])
        lIIIlIllIlllIlllIIlIl = self.session.post(bytes.fromhex('68747470733a2f2f7777772e6f6b2e72752f646b').decode('utf-8'), data={bytes.fromhex('636d64').decode('utf-8'): bytes.fromhex('766964656f506c617965724d65746164617461').decode('utf-8'), bytes.fromhex('6d6964').decode('utf-8'): video_id}, headers=self.headers(bytes.fromhex('68747470733a2f2f6f6b2e72752f').decode('utf-8')), timeout=25)
        lIIIlIllIlllIlllIIlIl.raise_for_status()
        data = lIIIlIllIlllIlllIIlIl.text.replace(bytes.fromhex('5c7530303236').decode('utf-8'), bytes.fromhex('26').decode('utf-8')).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'))
        source = self._first(bytes.fromhex('22283f3a6f6e64656d616e64486c737c6f6e64656d616e644461736829225c732a3a5c732a22285b5e225d2b2922').decode('utf-8'), data)
        if not source:
            source = self._first(bytes.fromhex('22283f3a6e616d657c7175616c69747929225c732a3a5c732a22283f3a756c7472617c717561647c66756c6c7c68647c73647c6c6f777c6d6f62696c6529225b5e7b7d5d2a2275726c225c732a3a5c732a22285b5e225d2b2922').decode('utf-8'), data, re.S)
        return (source + self.kodi_headers(bytes.fromhex('68747470733a2f2f6f6b2e72752f').decode('utf-8')) if source else None, [])

    def resolve_streamtape(self, url, referer=None):
        page = self.fetch(url, referer)
        S445131382403013 = bytes.fromhex('').decode('utf-8')
        for J2 in page.splitlines():
            if bytes.fromhex('626f746c696e6b27292e696e6e657248544d4c').decode('utf-8') in J2 or bytes.fromhex('626f746c696e6b22292e696e6e657248544d4c').decode('utf-8') in J2:
                S445131382403013 = J2
                break
        uuuuuuuuuuuuuu = re.findall(bytes.fromhex('5b27225d285b5e27225d2a295b27225d').decode('utf-8'), S445131382403013)
        uuuuuuuuuuuuuuuuuuu = [LaMBuAgmlwNhEfYCAsFsTAVuziXmEtkKWJFqKccIqvIbuNGXGfGiuKzMxeheEXsvehBeuMGPmcFzRnk23 for LaMBuAgmlwNhEfYCAsFsTAVuziXmEtkKWJFqKccIqvIbuNGXGfGiuKzMxeheEXsvehBeuMGPmcFzRnk23 in uuuuuuuuuuuuuu if bytes.fromhex('2f').decode('utf-8') in LaMBuAgmlwNhEfYCAsFsTAVuziXmEtkKWJFqKccIqvIbuNGXGfGiuKzMxeheEXsvehBeuMGPmcFzRnk23 or bytes.fromhex('26').decode('utf-8') in LaMBuAgmlwNhEfYCAsFsTAVuziXmEtkKWJFqKccIqvIbuNGXGfGiuKzMxeheEXsvehBeuMGPmcFzRnk23 or bytes.fromhex('3d').decode('utf-8') in LaMBuAgmlwNhEfYCAsFsTAVuziXmEtkKWJFqKccIqvIbuNGXGfGiuKzMxeheEXsvehBeuMGPmcFzRnk23]
        source = bytes.fromhex('').decode('utf-8').join(uuuuuuuuuuuuuuuuuuu)
        if source.startswith(bytes.fromhex('2f2f').decode('utf-8')):
            source = bytes.fromhex('68747470733a').decode('utf-8') + source
        if source:
            source += bytes.fromhex('2673747265616d3d31').decode('utf-8')
        return (source + self.kodi_headers(url) if source else None, [])

    def extract_jwplayer(self, page, base_url, headers=None):
        source = bytes.fromhex('').decode('utf-8')
        W22 = []
        for gggggggggggggggggggg in re.findall(bytes.fromhex('5b22275d3f736f75726365735b22275d3f5c732a3a5c732a285c5b2e2a3f5c5d29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            for OOOOOOOOO in self._parse_js_list(gggggggggggggggggggg):
                url = OOOOOOOOO.get(bytes.fromhex('66696c65').decode('utf-8'))
                if url:
                    source = urljoin(base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8'), url.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')))
                    break
            if source:
                break
        if not source:
            AAAaAAAAaaAaAaa = re.search(bytes.fromhex('5b3a3d5d5c732a5b22275d285b5e22275c735d2b283f3a5c2e6d3375387c6d61737465725c2e747874295b5e22275c735d2a29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I)
            if AAAaAAAAaaAaAaa:
                source = urljoin(base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8'), AAAaAAAAaaAaAaa.group(1).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')))
        for gggggggggggggggggggg in re.findall(bytes.fromhex('5b22275d3f747261636b735b22275d3f5c732a3a5c732a285c5b2e2a3f5c5d29').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            for OOOOOOOOO in self._parse_js_list(gggggggggggggggggggg):
                IlllIIllllI = (OOOOOOOOO.get(bytes.fromhex('6b696e64').decode('utf-8')) or bytes.fromhex('').decode('utf-8')).lower()
                j37154487161015 = OOOOOOOOO.get(bytes.fromhex('66696c65').decode('utf-8'))
                if j37154487161015 and (bytes.fromhex('63617074696f6e').decode('utf-8') in IlllIIllllI or bytes.fromhex('7375627469746c65').decode('utf-8') in IlllIIllllI):
                    W22.append(urljoin(base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8'), j37154487161015.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'))))
        return (source, list(dict.fromkeys(W22)))

    def _parse_js_list(self, value):
        cccccccccccccccc = value.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'))
        cccccccccccccccc = re.sub(bytes.fromhex('285b7b2c5d5c732a292866696c657c6c6162656c7c747970657c6b696e64295c732a3a').decode('utf-8'), bytes.fromhex('5c31225c32223a').decode('utf-8'), cccccccccccccccc)
        cccccccccccccccc = cccccccccccccccc.replace(bytes.fromhex('27').decode('utf-8'), bytes.fromhex('22').decode('utf-8'))
        cccccccccccccccc = re.sub(bytes.fromhex('2c5c732a285b5c5d7d5d29').decode('utf-8'), bytes.fromhex('5c31').decode('utf-8'), cccccccccccccccc)
        try:
            data = json.loads(cccccccccccccccc)
            return data if isinstance(data, list) else []
        except Exception:
            items = []
            for a1 in re.findall(bytes.fromhex('5c7b282e2a3f295c7d').decode('utf-8'), value, re.S):
                OOOOOOOOO = {}
                for ZpySRDwgTpVQXwncfwsHKPfRbMjUuFmQqdYzqMoJEDtPLeIzJnXPrlSgmEwnUresPdCQhLkfjeNTQsb10 in (bytes.fromhex('66696c65').decode('utf-8'), bytes.fromhex('6c6162656c').decode('utf-8'), bytes.fromhex('74797065').decode('utf-8'), bytes.fromhex('6b696e64').decode('utf-8')):
                    OOOOOOOOO[ZpySRDwgTpVQXwncfwsHKPfRbMjUuFmQqdYzqMoJEDtPLeIzJnXPrlSgmEwnUresPdCQhLkfjeNTQsb10] = self._first(bytes.fromhex('5b22275d3f25735b22275d3f5c732a3a5c732a5b22275d285b5e22275d2b29').decode('utf-8') % ZpySRDwgTpVQXwncfwsHKPfRbMjUuFmQqdYzqMoJEDtPLeIzJnXPrlSgmEwnUresPdCQhLkfjeNTQsb10, a1)
                items.append(OOOOOOOOO)
            return items

    def fetch(self, url, referer=None, origin=None):
        VMIEkfOsuzFmClUJkZcdiwpKyFhJgLtYuZFbUKaoYqTPUhFPfWbYMebemHDsavYAjwDGWeRyAveDzDc12 = None
        for JkPzwnrptfnjGcMYwHfdelgLonEXujLTRnCLgQdfxGEUhqFSlNptWKpBFRRtSYNLxTHCUyFPUbXlAOw8 in self.CLIENT_IDENTIFIERS:
            if self.session.client_identifier != JkPzwnrptfnjGcMYwHfdelgLonEXujLTRnCLgQdfxGEUhqFSlNptWKpBFRRtSYNLxTHCUyFPUbXlAOw8:
                self.session = manituxhttp.Session(client_identifier=JkPzwnrptfnjGcMYwHfdelgLonEXujLTRnCLgQdfxGEUhqFSlNptWKpBFRRtSYNLxTHCUyFPUbXlAOw8)
            try:
                lIIIlIllIlllIlllIIlIl = self.session.get(url, headers=self.headers(referer, origin), timeout=25, allow_redirects=True, tls_client_identifier=JkPzwnrptfnjGcMYwHfdelgLonEXujLTRnCLgQdfxGEUhqFSlNptWKpBFRRtSYNLxTHCUyFPUbXlAOw8)
                if lIIIlIllIlllIlllIIlIl.status_code in (403, 429) and JkPzwnrptfnjGcMYwHfdelgLonEXujLTRnCLgQdfxGEUhqFSlNptWKpBFRRtSYNLxTHCUyFPUbXlAOw8 != self.CLIENT_IDENTIFIERS[-1]:
                    VMIEkfOsuzFmClUJkZcdiwpKyFhJgLtYuZFbUKaoYqTPUhFPfWbYMebemHDsavYAjwDGWeRyAveDzDc12 = manituxhttp.HTTPError(lIIIlIllIlllIlllIIlIl)
                    continue
                lIIIlIllIlllIlllIIlIl.raise_for_status()
                return lIIIlIllIlllIlllIIlIl.text
            except (manituxhttp.HTTPError, manituxhttp.RequestError) as exc:
                VMIEkfOsuzFmClUJkZcdiwpKyFhJgLtYuZFbUKaoYqTPUhFPfWbYMebemHDsavYAjwDGWeRyAveDzDc12 = exc
                if JkPzwnrptfnjGcMYwHfdelgLonEXujLTRnCLgQdfxGEUhqFSlNptWKpBFRRtSYNLxTHCUyFPUbXlAOw8 == self.CLIENT_IDENTIFIERS[-1]:
                    raise
        raise VMIEkfOsuzFmClUJkZcdiwpKyFhJgLtYuZFbUKaoYqTPUhFPfWbYMebemHDsavYAjwDGWeRyAveDzDc12

    def headers(self, referer=None, origin=None):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): self.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('746578742f68746d6c2c6170706c69636174696f6e2f7868746d6c2b786d6c2c6170706c69636174696f6e2f786d6c3b713d302e392c2a2f2a3b713d302e38').decode('utf-8')}
        if referer:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        if origin:
            headers[bytes.fromhex('4f726967696e').decode('utf-8')] = origin
        return headers

    def kodi_headers(self, referer=None, extra=None):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): self.user_agent}
        if referer:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        if extra:
            headers.update(extra)
        return bytes.fromhex('7c').decode('utf-8') + bytes.fromhex('26').decode('utf-8').join((bytes.fromhex('7b307d3d7b317d').decode('utf-8').format(ZpySRDwgTpVQXwncfwsHKPfRbMjUuFmQqdYzqMoJEDtPLeIzJnXPrlSgmEwnUresPdCQhLkfjeNTQsb10, quote(value)) for ZpySRDwgTpVQXwncfwsHKPfRbMjUuFmQqdYzqMoJEDtPLeIzJnXPrlSgmEwnUresPdCQhLkfjeNTQsb10, value in headers.items() if value))

    def normalize_url(self, url):
        if url.startswith(bytes.fromhex('2f2f').decode('utf-8')):
            return bytes.fromhex('68747470733a').decode('utf-8') + url
        if url.startswith(bytes.fromhex('7777772e').decode('utf-8')):
            return bytes.fromhex('68747470733a2f2f').decode('utf-8') + url
        if not url.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8'))):
            return urljoin(self.main_url + bytes.fromhex('2f').decode('utf-8'), url)
        return url

    def origin(self, url):
        jSDxjrgfvRZogRxJyNrLIQadZVOLhxrNHputZKMwemeiaUbBLmigBvuzYsNmkxPgcmWVEbuQNGysbyJ18 = urlparse(url)
        return jSDxjrgfvRZogRxJyNrLIQadZVOLhxrNHputZKMwemeiaUbBLmigBvuzYsNmkxPgcmWVEbuQNGysbyJ18.scheme + bytes.fromhex('3a2f2f').decode('utf-8') + jSDxjrgfvRZogRxJyNrLIQadZVOLhxrNHputZKMwemeiaUbBLmigBvuzYsNmkxPgcmWVEbuQNGysbyJ18.netloc

    @staticmethod
    def _first(pattern, text, flags=0):
        AAAaAAAAaaAaAaa = re.search(pattern, text or bytes.fromhex('').decode('utf-8'), flags | re.I)
        if not AAAaAAAAaaAaAaa:
            return bytes.fromhex('').decode('utf-8')
        return AAAaAAAAaaAaAaa.group(1) if AAAaAAAAaaAaAaa.lastindex else AAAaAAAAaaAaAaa.group(0)
