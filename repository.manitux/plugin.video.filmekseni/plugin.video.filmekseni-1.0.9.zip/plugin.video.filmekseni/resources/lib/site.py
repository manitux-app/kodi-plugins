from __future__ import absolute_import, unicode_literals
import manituxhttp
try:
    from urllib.parse import quote_plus
except ImportError:
    from urllib import quote_plus
from . import parsers

class FilmEkseniSite(object):
    CLIENT_IDENTIFIERS = (bytes.fromhex('636c6f756473637261706572').decode('utf-8'), bytes.fromhex('6368726f6d655f313434').decode('utf-8'))

    def __init__(self, base_url, user_agent):
        self.base_url = base_url.rstrip(bytes.fromhex('2f').decode('utf-8'))
        self.user_agent = user_agent
        self.session = manituxhttp.Session(client_identifier=self.CLIENT_IDENTIFIERS[0])

    def headers(self, referer=None, ajax=False):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): self.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('746578742f68746d6c2c6170706c69636174696f6e2f7868746d6c2b786d6c2c6170706c69636174696f6e2f786d6c3b713d302e392c2a2f2a3b713d302e38').decode('utf-8')}
        if referer:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        if ajax:
            headers[bytes.fromhex('582d5265717565737465642d57697468').decode('utf-8')] = bytes.fromhex('584d4c4874747052657175657374').decode('utf-8')
            headers[bytes.fromhex('4f726967696e').decode('utf-8')] = self.base_url
        return headers

    def categories(self):
        return parsers.categories(self.base_url)

    def get(self, url, referer=None):
        return self._get(self.absolute(url), self.headers(referer)).text

    def post(self, url, data, referer=None):
        return self._post(self.absolute(url), data, self.headers(referer, ajax=True)).text

    def get_page_items(self, category_url, page_number=1, title=bytes.fromhex('').decode('utf-8')):
        page = self.get(parsers.page_url(category_url, page_number), referer=category_url)
        return parsers.parse_page_items(page, self.base_url, title)

    def search(self, query):
        llI = self.get(self.base_url + bytes.fromhex('2f6170692f7365617263683f713d').decode('utf-8') + quote_plus(query), referer=self.base_url + bytes.fromhex('2f').decode('utf-8'))
        return parsers.parse_search_results(llI, self.base_url)

    def parse_detail(self, page, url):
        return parsers.parse_media_info(page, url, self.base_url)

    def fetch_iframe(self, source_url, referer=None):
        page = self.get(source_url, referer=referer or self.base_url + bytes.fromhex('2f').decode('utf-8'))
        return parsers.parse_iframe(page, self.base_url)

    def absolute(self, url):
        return parsers.fix_url(url, self.base_url)

    def search_url(self, query):
        return self.base_url + bytes.fromhex('2f7365617263682f3f713d').decode('utf-8') + quote_plus(query)

    def _get(self, url, headers):
        E2 = None
        for A in self.CLIENT_IDENTIFIERS:
            if self.session.client_identifier != A:
                self.session = manituxhttp.Session(client_identifier=A)
            try:
                IIII = self.session.get(url, headers=headers, timeout=25, tls_client_identifier=A)
                if IIII.status_code in (403, 429) and A != self.CLIENT_IDENTIFIERS[-1]:
                    E2 = manituxhttp.HTTPError(IIII)
                    continue
                IIII.raise_for_status()
                return IIII
            except (manituxhttp.HTTPError, manituxhttp.RequestError) as exc:
                E2 = exc
                if A == self.CLIENT_IDENTIFIERS[-1]:
                    raise
        raise E2

    def _post(self, url, data, headers):
        E2 = None
        for A in self.CLIENT_IDENTIFIERS:
            if self.session.client_identifier != A:
                self.session = manituxhttp.Session(client_identifier=A)
            try:
                IIII = self.session.post(url, data=data, headers=headers, timeout=25, tls_client_identifier=A)
                if IIII.status_code in (403, 429) and A != self.CLIENT_IDENTIFIERS[-1]:
                    E2 = manituxhttp.HTTPError(IIII)
                    continue
                IIII.raise_for_status()
                return IIII
            except (manituxhttp.HTTPError, manituxhttp.RequestError) as exc:
                E2 = exc
                if A == self.CLIENT_IDENTIFIERS[-1]:
                    raise
        raise E2
