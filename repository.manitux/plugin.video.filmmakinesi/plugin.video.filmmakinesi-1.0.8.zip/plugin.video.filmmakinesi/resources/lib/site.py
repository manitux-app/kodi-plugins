from __future__ import absolute_import, unicode_literals
import manituxhttp
try:
    from urllib.parse import quote_plus
except ImportError:
    from urllib import quote_plus
from . import parsers

class FilmMakinesiSite(object):
    CLIENT_IDENTIFIERS = (bytes.fromhex('636c6f756473637261706572').decode('utf-8'), bytes.fromhex('6368726f6d655f313434').decode('utf-8'))

    def __init__(self, base_url, user_agent):
        self.base_url = base_url.rstrip(bytes.fromhex('2f').decode('utf-8'))
        self.user_agent = user_agent
        self.session = manituxhttp.Session(client_identifier=self.CLIENT_IDENTIFIERS[0])

    def headers(self, referer=None):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): self.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('746578742f68746d6c2c6170706c69636174696f6e2f7868746d6c2b786d6c2c6170706c69636174696f6e2f786d6c3b713d302e392c2a2f2a3b713d302e38').decode('utf-8'), bytes.fromhex('4163636570742d4c616e6775616765').decode('utf-8'): bytes.fromhex('74722d54522c74723b713d302e392c656e2d55533b713d302e382c656e3b713d302e37').decode('utf-8'), bytes.fromhex('557067726164652d496e7365637572652d5265717565737473').decode('utf-8'): bytes.fromhex('31').decode('utf-8')}
        if referer:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        return headers

    def categories(self):
        return parsers.categories(self.base_url)

    def page_url(self, category_url, page_number):
        return parsers.page_url(category_url, page_number)

    def get(self, url, referer=None):
        return self._get(self.absolute(url), self.headers(referer)).text

    def get_page_items(self, category_url, page_number=1, title=bytes.fromhex('').decode('utf-8')):
        url = self.page_url(category_url, page_number)
        page = self.get(url, referer=category_url)
        return parsers.parse_page_items(page, self.base_url, title)

    def search(self, query):
        page = self.get(self.base_url + bytes.fromhex('2f6172616d612f3f733d').decode('utf-8') + quote_plus(query), referer=self.base_url + bytes.fromhex('2f').decode('utf-8'))
        return parsers.parse_page_items(page, self.base_url, bytes.fromhex('4172616d61').decode('utf-8'))

    def parse_detail(self, page, url):
        return parsers.parse_media_info(page, url, self.base_url)

    def absolute(self, url):
        return parsers.fix_url(url, self.base_url)

    def _get(self, url, headers):
        Il = None
        for l39267943332781 in self.CLIENT_IDENTIFIERS:
            if self.session.client_identifier != l39267943332781:
                self.session = manituxhttp.Session(client_identifier=l39267943332781)
            try:
                s27952358168533 = self.session.get(url, headers=headers, timeout=25, tls_client_identifier=l39267943332781)
                if s27952358168533.status_code in (403, 429) and l39267943332781 != self.CLIENT_IDENTIFIERS[-1]:
                    Il = manituxhttp.HTTPError(s27952358168533)
                    continue
                s27952358168533.raise_for_status()
                return s27952358168533
            except (manituxhttp.HTTPError, manituxhttp.RequestError) as exc:
                Il = exc
                if l39267943332781 == self.CLIENT_IDENTIFIERS[-1]:
                    raise
        raise Il
