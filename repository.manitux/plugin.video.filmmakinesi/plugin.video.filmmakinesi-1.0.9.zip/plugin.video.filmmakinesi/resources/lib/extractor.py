from __future__ import absolute_import, unicode_literals
import base64
import binascii
import json
import re
import string
import manituxhttp
try:
    from urllib.parse import quote, urlparse, urlunparse
except ImportError:
    from urllib import quote
    from urlparse import urlparse, urlunparse

class VideoExtractor(object):
    CLIENT_IDENTIFIERS = (bytes.fromhex('6368726f6d655f313434').decode('utf-8'), bytes.fromhex('636c6f756473637261706572').decode('utf-8'))

    def __init__(llIIl, user_agent):
        llIIl.user_agent = user_agent
        llIIl.session = manituxhttp.Session(client_identifier=llIIl.CLIENT_IDENTIFIERS[0])

    def headers(llIIl, referer=None):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): llIIl.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('746578742f68746d6c2c6170706c69636174696f6e2f7868746d6c2b786d6c2c6170706c69636174696f6e2f786d6c3b713d302e392c2a2f2a3b713d302e38').decode('utf-8'), bytes.fromhex('436f6e74656e742d54797065').decode('utf-8'): bytes.fromhex('6170706c69636174696f6e2f6a736f6e').decode('utf-8'), bytes.fromhex('582d5265717565737465642d57697468').decode('utf-8'): bytes.fromhex('584d4c4874747052657175657374').decode('utf-8')}
        if referer:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        return headers

    def hdfilmcehennemi_extractor(llIIl, url, referer=None):
        url = llIIl.normalize_url(url)
        referer = referer or url
        page = llIIl.fetch(url, referer)
        IllI = llIIl.origin(url)
        llIll = []
        source = llIIl._extract_obfuscated_video_link(page)
        IIIIII = llIIl._unpack_first_eval(page)
        if IIIIII:
            if not source:
                source = llIIl._extract_obfuscated_video_link(IIIIII)
            if not source:
                source = llIIl._first(bytes.fromhex('736f75726365735c732a3a5c732a5c5b5c732a5c7b5c732a66696c655c732a3a5c732a5b275c225d285b5e275c225d2b29').decode('utf-8'), IIIIII, re.S)
            if not source:
                lI = llIIl._first(bytes.fromhex('5b225c275d2861485230635b5e225c275d2b295b225c275d').decode('utf-8'), IIIIII)
                if lI:
                    source = base64.b64decode(lI).decode(bytes.fromhex('7574662d38').decode('utf-8'), bytes.fromhex('7265706c616365').decode('utf-8'))
            llIll = llIIl._extract_subtitles(page + bytes.fromhex('0a').decode('utf-8') + IIIIII, IllI)
        else:
            source = llIIl._first(bytes.fromhex('22636f6e74656e7455726c225c732a3a5c732a22285b5e225d2b2922').decode('utf-8'), page)
            if not source:
                source = llIIl._first(bytes.fromhex('283f3a2266696c65227c66696c65295c732a3a5c732a5b225c275d285b5e225c275d2b29').decode('utf-8'), page)
            llIll = llIIl._extract_subtitles(page, IllI)
        if not source:
            llll = llIIl._first(bytes.fromhex('3c696672616d655b5e3e5d2b283f3a7372637c646174612d737263293d5b225c275d285b5e225c275d2b29').decode('utf-8'), page)
            if llll and llll != url:
                return llIIl.resolve(llll.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')), url)
            return (None, llIll)
        source = source.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')).replace(bytes.fromhex('5c7530303236').decode('utf-8'), bytes.fromhex('26').decode('utf-8'))
        return (source + llIIl.kodi_headers(IllI), llIll)

    def resolve(llIIl, url, referer=None):
        if not url:
            return (None, [])
        url = llIIl.normalize_url(url)
        if llIIl.is_hdfilm_url(url):
            return llIIl.hdfilmcehennemi_extractor(url, referer)
        if bytes.fromhex('7669646d6f6c79').decode('utf-8') in url or bytes.fromhex('666c6d706c61796572').decode('utf-8') in url:
            return llIIl.resolve_vidmoly(url)
        if bytes.fromhex('6f646e6f6b6c6173736e696b69').decode('utf-8') in url or bytes.fromhex('6f6b2e7275').decode('utf-8') in url:
            return llIIl.resolve_okru(url)
        return (url + llIIl.kodi_headers(referer), [])

    def resolve_hdfilm_embed(llIIl, url, referer=None):
        return llIIl.hdfilmcehennemi_extractor(url, referer)

    def resolve_vidmoly(llIIl, url):
        url = llIIl.normalize_url(url).replace(bytes.fromhex('2e746f70').decode('utf-8'), bytes.fromhex('2e746f').decode('utf-8'))
        page = llIIl.fetch(url, bytes.fromhex('68747470733a2f2f7669646d6f6c792e746f2f').decode('utf-8'))
        lIIll = llIIl._first(bytes.fromhex('77696e646f775c2e6c6f636174696f6e5c732a3d5c732a27285b5e275d2b2927').decode('utf-8'), page)
        if lIIll:
            page = llIIl.fetch(url.replace(bytes.fromhex('656d6265642d').decode('utf-8'), lIIll), url)
        source = llIIl._first(bytes.fromhex('285b5e275c225c735d2b5c2e6d3375385b5e275c225c735d2a29').decode('utf-8'), page)
        lllIl = re.findall(bytes.fromhex('66696c655c732a3a5c732a27285b5e275d2b2f7372745b5e275d2a2927').decode('utf-8'), page)
        return (source + llIIl.kodi_headers(bytes.fromhex('68747470733a2f2f7669646d6f6c792e746f2f').decode('utf-8')), lllIl)

    def resolve_okru(llIIl, url):
        url = llIIl.normalize_url(url)
        IIIIlI = llIIl._first(bytes.fromhex('283f3a766964656f656d6265642f7c6d69643d29285c642b29').decode('utf-8'), url)
        if not IIIIlI:
            return (url + llIIl.kodi_headers(bytes.fromhex('68747470733a2f2f6f6b2e72752f').decode('utf-8')), [])
        lIlIl = llIIl.session.post(bytes.fromhex('68747470733a2f2f7777772e6f6b2e72752f646b').decode('utf-8'), data={bytes.fromhex('636d64').decode('utf-8'): bytes.fromhex('766964656f506c617965724d65746164617461').decode('utf-8'), bytes.fromhex('6d6964').decode('utf-8'): IIIIlI}, headers=llIIl.headers(bytes.fromhex('68747470733a2f2f6f6b2e72752f').decode('utf-8')), timeout=25)
        lIlIl.raise_for_status()
        data = lIlIl.text
        source = llIIl._first(bytes.fromhex('283f3a756c7472617c717561647c66756c6c7c68647c73647c6c6f777c6c6f7765737429222c2275726c223a22282e2a3f2922').decode('utf-8'), data)
        return (source.replace(bytes.fromhex('5c7530303236').decode('utf-8'), bytes.fromhex('26').decode('utf-8')) + llIIl.kodi_headers(bytes.fromhex('68747470733a2f2f6f6b2e72752f').decode('utf-8')), [])

    def fetch(llIIl, url, referer=None):
        IIIll = None
        for llIl in llIIl.CLIENT_IDENTIFIERS:
            if llIIl.session.client_identifier != llIl:
                llIIl.session = manituxhttp.Session(client_identifier=llIl)
            try:
                lIlIl = llIIl.session.get(url, headers=llIIl.headers(referer), timeout=25, allow_redirects=True, tls_client_identifier=llIl)
                if lIlIl.status_code in (403, 429) and llIl != llIIl.CLIENT_IDENTIFIERS[-1]:
                    IIIll = manituxhttp.HTTPError(lIlIl)
                    continue
                lIlIl.raise_for_status()
                return lIlIl.text
            except (manituxhttp.HTTPError, manituxhttp.RequestError) as exc:
                IIIll = exc
                if llIl == llIIl.CLIENT_IDENTIFIERS[-1]:
                    raise
        raise IIIll

    def normalize_url(llIIl, url):
        if url.startswith(bytes.fromhex('2f2f').decode('utf-8')):
            url = bytes.fromhex('68747470733a').decode('utf-8') + url
        elif url.startswith(bytes.fromhex('7777772e').decode('utf-8')):
            url = bytes.fromhex('68747470733a2f2f').decode('utf-8') + url
        elif not url.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8'))):
            url = bytes.fromhex('68747470733a2f2f').decode('utf-8') + url
        IlIll = urlparse(url)
        return urlunparse(IlIll._replace(scheme=bytes.fromhex('6874747073').decode('utf-8')))

    def kodi_headers(llIIl, referer=None):
        III = [bytes.fromhex('557365722d4167656e743d').decode('utf-8') + quote(llIIl.user_agent)]
        if referer:
            III.append(bytes.fromhex('526566657265723d').decode('utf-8') + quote(referer))
        return bytes.fromhex('7c').decode('utf-8') + bytes.fromhex('26').decode('utf-8').join(III)

    def is_hdfilm_url(llIIl, url):
        lIll = urlparse(url).netloc.lower()
        return bytes.fromhex('686466696c6d636568656e6e656d69').decode('utf-8') in lIll or bytes.fromhex('66696c6d6d616b696e657369').decode('utf-8') in lIll or bytes.fromhex('64697a69636568656e6e656d69').decode('utf-8') in lIll or (bytes.fromhex('636c6f73656c6f6164').decode('utf-8') in lIll) or (bytes.fromhex('706c61796d6978').decode('utf-8') in lIll) or (bytes.fromhex('726170696472616d65').decode('utf-8') in lIll)

    def origin(llIIl, url):
        IlIll = urlparse(url)
        return IlIll.scheme + bytes.fromhex('3a2f2f').decode('utf-8') + IlIll.netloc

    def _extract_subtitles(llIIl, page, origin):
        lllIl = []
        for lllII in re.findall(bytes.fromhex('2266696c65225c732a3a5c732a22285b5e225d2b29225b5e7b7d5d2a226b696e64225c732a3a5c732a2263617074696f6e7322').decode('utf-8'), page, re.S):
            lllIl.append(llIIl._absolute_url(lllII.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')), origin))
        for lllll in re.findall(bytes.fromhex('747261636b735c732a3a5c732a285c5b2e2a3f5c5d295c732a2c').decode('utf-8'), page, re.S):
            for lllII in re.findall(bytes.fromhex('2266696c65225c732a3a5c732a22285b5e225d2b2922').decode('utf-8'), lllll):
                lllIl.append(llIIl._absolute_url(lllII.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')), origin))
        for lllII in re.findall(bytes.fromhex('747261636b5c732b7372633d5b275c225d285b5e275c225d2b29').decode('utf-8'), page, re.S | re.I):
            lllIl.append(llIIl._absolute_url(lllII.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')), origin))
        return list(dict.fromkeys(lllIl))

    def _absolute_url(llIIl, url, origin):
        if url.startswith(bytes.fromhex('2f2f').decode('utf-8')):
            return bytes.fromhex('68747470733a').decode('utf-8') + url
        if url.startswith(bytes.fromhex('2f').decode('utf-8')):
            return origin.rstrip(bytes.fromhex('2f').decode('utf-8')) + url
        return url

    def _unpack_first_eval(llIIl, page):
        IIllI = re.search(bytes.fromhex('6576616c5c2866756e6374696f6e5c28702c612c632c6b2c652c645c292e2a3f5c7d5c28283f503c7061796c6f61643e5b275c225d2e2a3f5b275c225d295c732a2c5c732a283f503c626173653e5c642b295c732a2c5c732a283f503c636f756e743e5c642b295c732a2c5c732a283f503c73796d626f6c733e5b275c225d2e2a3f5b275c225d295c2e73706c69745c285b275c225d5c7c5b275c225d5c29').decode('utf-8'), page, re.S)
        if not IIllI:
            return bytes.fromhex('').decode('utf-8')
        lIIII = llIIl._js_string(IIllI.group(bytes.fromhex('7061796c6f6164').decode('utf-8')))
        ll = int(IIllI.group(bytes.fromhex('62617365').decode('utf-8')))
        IIII = int(IIllI.group(bytes.fromhex('636f756e74').decode('utf-8')))
        llllI = llIIl._js_string(IIllI.group(bytes.fromhex('73796d626f6c73').decode('utf-8'))).split(bytes.fromhex('7c').decode('utf-8'))
        if IIII > len(llllI):
            llllI.extend([bytes.fromhex('').decode('utf-8')] * (IIII - len(llllI)))
        for IIIII in range(IIII - 1, -1, -1):
            IIIIll = llIIl._base_n(IIIII, ll)
            if llllI[IIIII]:
                lIIII = re.sub(bytes.fromhex('5c62').decode('utf-8') + re.escape(IIIIll) + bytes.fromhex('5c62').decode('utf-8'), llllI[IIIII], lIIII)
        return lIIII

    def _js_string(llIIl, IIIIIl):
        lIIlI = IIIIIl[0]
        if IIIIIl[-1] == lIIlI:
            IIIIIl = IIIIIl[1:-1]
        return bytes(IIIIIl, bytes.fromhex('7574662d38').decode('utf-8')).decode(bytes.fromhex('756e69636f64655f657363617065').decode('utf-8'))

    def _base_n(llIIl, IlIIl, ll):
        I = string.digits + string.ascii_lowercase + string.ascii_uppercase
        if IlIIl == 0:
            return bytes.fromhex('30').decode('utf-8')
        lIllI = bytes.fromhex('').decode('utf-8')
        while IlIIl:
            IlIIl, lIlII = divmod(IlIIl, ll)
            lIllI = I[lIlII] + lIllI
        return lIllI

    def _decode_obfuscated_source(llIIl, page):
        IIIIII = llIIl._unpack_first_eval(page)
        for lIlll in (page, IIIIII):
            IIllI = re.search(bytes.fromhex('7661725c732b28735f5b412d5a612d7a302d395f5d2b295c732a3d5c732a2864635f5b412d5a612d7a302d395f5d2b295c732a5c28285c5b2e2a3f5c5d295c29').decode('utf-8'), lIlll or bytes.fromhex('').decode('utf-8'), re.S)
            if not IIllI:
                continue
            IIll = IIllI.group(2)
            IIlI = re.search(bytes.fromhex('66756e6374696f6e5c732b').decode('utf-8') + re.escape(IIll) + bytes.fromhex('5c732a5c285b5e295d2a5c295c732a5c7b282e2a3f2972657475726e5c732b756e6d69785c732a3b3f5c732a5c7d').decode('utf-8'), lIlll, re.S)
            if not IIlI:
                continue
            IIIlI = re.search(bytes.fromhex('63686172436f64655c732a2d5c732a5c285c732a285c642b295c732a255c732a5c285c732a695c732a5c2b5c732a355c732a5c295c732a5c29').decode('utf-8'), IIlI.group(1))
            if not IIIlI:
                continue
            IlllI = json.loads(IIllI.group(3).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')))
            IIIIIl = llIIl._rot13(bytes.fromhex('').decode('utf-8').join(IlllI)[::-1])
            IIIl = base64.b64decode(IIIIIl).decode(bytes.fromhex('6c6174696e2d31').decode('utf-8'))
            IIIIl = int(IIIlI.group(1))
            llI = []
            for lllI, lII in enumerate(IIIl):
                lll = (ord(lII) - IIIIl % (lllI + 5) + 256) % 256
                llI.append(chr(lll))
            return bytes.fromhex('').decode('utf-8').join(llI)
        return bytes.fromhex('').decode('utf-8')

    @staticmethod
    def _rot13(IIIIIl):
        IlIlI = []
        for lII in IIIIIl:
            lll = ord(lII)
            if 65 <= lll <= 90:
                IlIlI.append(chr((lll - 65 + 13) % 26 + 65))
            elif 97 <= lll <= 122:
                IlIlI.append(chr((lll - 97 + 13) % 26 + 97))
            else:
                IlIlI.append(lII)
        return bytes.fromhex('').decode('utf-8').join(IlIlI)

    def _extract_obfuscated_video_link(llIIl, llII):
        for IlI in llIIl._get_base64_candidates_from_html(llII):
            source = llIIl._try_decrypt_candidate(IlI)
            if source:
                return source
        source = llIIl._decode_obfuscated_source(llII)
        if source:
            return llIIl._get_url(source)
        return llIIl._direct_video_link(llII)

    def _try_decrypt_candidate(llIIl, IIIIIl):
        llIlI = (lambda IIIlII: llIIl._unmix(llIIl._rot13(llIIl._base64_decode_js(IIIlII[::-1]))), lambda IIIlII: llIIl._unmix(llIIl._base64_decode_js(llIIl._rot13(IIIlII))[::-1]), lambda IIIlII: llIIl._unmix(llIIl._rot13(llIIl._base64_decode_js(IIIlII))[::-1]), lambda IIIlII: llIIl._unmix(llIIl._base64_decode_js(llIIl._base64_decode_js(IIIlII[::-1]))), lambda IIIlII: llIIl._unmix(llIIl._base64_decode_js(llIIl._rot13(IIIlII)[::-1])), llIIl._decrypt_rot13_base64_reverse_unmix, llIIl._decrypt_reversed_double_base64_unmix, llIIl._decrypt_text_base64_rot13_reverse_unmix, llIIl._decrypt_rot13_reversed_base64_unmix)
        for IIlI in llIlI:
            try:
                IIIl = IIlI(IIIIIl)
            except Exception:
                IIIl = None
            source = llIIl._get_url(IIIl)
            if source:
                return source
        return None

    def _decrypt_rot13_base64_reverse_unmix(llIIl, IIIIIl):
        IIIl = llIIl._base64_decode_js(llIIl._rot13(IIIIIl))
        if not IIIl:
            return None
        return llIIl._get_url(llIIl._unmix(IIIl[::-1]))

    def _decrypt_reversed_double_base64_unmix(llIIl, IIIIIl):
        lIIl = llIIl._base64_decode_js(IIIIIl[::-1])
        if not lIIl:
            return None
        llIII = llIIl._base64_decode_js(lIIl)
        if not llIII:
            return None
        return llIIl._get_url(llIIl._unmix(llIII))

    def _decrypt_text_base64_rot13_reverse_unmix(llIIl, IIIIIl):
        IIIl = llIIl._base64_decode_js(IIIIIl)
        if not IIIl or llIIl._printable_ratio(IIIl) <= 0.75:
            return None
        return llIIl._get_url(llIIl._unmix(llIIl._rot13(IIIl)[::-1]))

    def _decrypt_rot13_reversed_base64_unmix(llIIl, IIIIIl):
        IIIl = llIIl._base64_decode_js(llIIl._rot13(IIIIIl)[::-1])
        if not IIIl or llIIl._printable_ratio(IIIl) <= 0.75:
            return None
        return llIIl._get_url(llIIl._unmix(IIIl))

    def _get_base64_candidates_from_html(llIIl, llII):
        Ill = []
        llIIl._add_direct_array_values(llII, Ill)
        llIIl._add_quoted_base64_values(llII, Ill)
        IIIIII = llIIl._unpack_first_eval(llII)
        if IIIIII:
            llIIl._add_direct_array_values(IIIIII, Ill)
            llIIl._add_quoted_base64_values(IIIIII, Ill)
        llIIl._add_packed_array_values(llII, Ill)
        lIllI = []
        for IlI in Ill:
            IlI = (IlI or bytes.fromhex('').decode('utf-8')).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')).strip()
            if llIIl._is_likely_encrypted_payload(IlI) and IlI not in lIllI:
                lIllI.append(IlI)
        return lIllI

    def _add_direct_array_values(llIIl, llII, Ill):
        II = re.compile(bytes.fromhex('5c625c772b5c732a5c285c732a285c5b5c732a283f3a5c225b5e5c225d2a5c227c275b5e275d2a27295c732a283f3a2c5c732a283f3a5c225b5e5c225d2a5c227c275b5e275d2a27295c732a292a5c5d295c732a5c29').decode('utf-8'), re.S)
        for IIllI in II.finditer(llII or bytes.fromhex('').decode('utf-8')):
            Il = IIllI.group(1)
            IlIll = llIIl._parse_string_array(Il)
            if IlIll:
                Ill.append(IlIll)
            else:
                IlllI = re.findall(bytes.fromhex('5b22275d285b5e22275d2b295b22275d').decode('utf-8'), Il)
                Ill.append(bytes.fromhex('').decode('utf-8').join(IlllI))

    def _add_quoted_base64_values(llIIl, llII, Ill):
        Illll = re.compile(bytes.fromhex('5b22275d283f503c76616c75653e283f3a3d7b302c327d295b412d5a612d7a302d392b2f5d7b38302c7d3d7b302c327d295b22275d').decode('utf-8'), re.S)
        for IIllI in Illll.finditer(llII or bytes.fromhex('').decode('utf-8')):
            Ill.append(IIllI.group(bytes.fromhex('76616c7565').decode('utf-8')))

    def _add_packed_array_values(llIIl, llII, Ill):
        lIII = re.compile(bytes.fromhex('6576616c5c2866756e6374696f6e5c28702c612c632c6b2c652c645c292e2a3f5c2e73706c69745c285b275c225d5c7c5b275c225d5c292c5c642b2c5c7b5c7d5c295c29').decode('utf-8'), re.S)
        for Illl in lIII.finditer(llII or bytes.fromhex('').decode('utf-8')):
            IIl = Illl.group(0)
            IlII = re.search(bytes.fromhex('5b27225d285b5e27225d2a295b27225d5c2e73706c6974').decode('utf-8'), IIl, re.S)
            if not IlII:
                continue
            IlIl = IlII.group(1).split(bytes.fromhex('7c').decode('utf-8'))
            IIlII = string.digits + string.ascii_lowercase + string.ascii_uppercase
            for l in re.finditer(bytes.fromhex('5c5b5c732a285b22275d2e2a3f5b22275d5c732a2c3f5c732a292b5c732a5c5d').decode('utf-8'), IIl, re.S):
                IlllI = []
                for IllIl in re.finditer(bytes.fromhex('5b22275d283f503c76616c3e2e2a3f295b22275d').decode('utf-8'), l.group(0), re.S):
                    IllII = re.sub(bytes.fromhex('5c772b').decode('utf-8'), lambda IIlIl: llIIl._base62_lookup(IIlIl.group(0), IIlII, IlIl), IllIl.group(bytes.fromhex('76616c').decode('utf-8')))
                    IlllI.append(IllII)
                Ill.append(bytes.fromhex('').decode('utf-8').join(IlllI))

    def _parse_string_array(llIIl, Il):
        IlIII = re.sub(bytes.fromhex('27285b5e275c5c5d2a283f3a5c5c2e5b5e275c5c5d2a292a2927').decode('utf-8'), lambda IIlIl: json.dumps(IIlIl.group(1)), Il)
        try:
            return bytes.fromhex('').decode('utf-8').join(json.loads(IlIII))
        except (TypeError, ValueError):
            return bytes.fromhex('').decode('utf-8')

    def _base62_lookup(llIIl, IIIIIl, IIlII, IlIl):
        IIIII = 0
        IIlll = 1
        for lII in reversed(IIIIIl):
            lIl = IIlII.find(lII)
            if lIl == -1:
                return IIIIIl
            IIIII += lIl * IIlll
            IIlll *= 62
        if IIIII < len(IlIl) and IlIl[IIIII]:
            return IlIl[IIIII]
        return IIIIIl

    def _base64_decode_js(llIIl, IIIIIl):
        if not IIIIIl:
            return bytes.fromhex('').decode('utf-8')
        try:
            if not isinstance(IIIIIl, bytes):
                IIIIIl = IIIIIl.encode(bytes.fromhex('6c6174696e2d31').decode('utf-8'))
            IIIIIl += b'=' * ((4 - len(IIIIIl) % 4) % 4)
            return base64.b64decode(IIIIIl).decode(bytes.fromhex('6c6174696e2d31').decode('utf-8'))
        except (TypeError, binascii.Error, UnicodeError):
            return bytes.fromhex('').decode('utf-8')

    def _is_likely_encrypted_payload(llIIl, IIIIIl):
        if len(IIIIIl) < 40:
            return False
        IIII = sum((1 for lII in IIIIIl if lII.isalnum() or lII in bytes.fromhex('2b2f3d').decode('utf-8')))
        return float(IIII) / len(IIIIIl) > 0.85

    def _unmix(llIIl, IIIIIl):
        llI = []
        for lllI, lII in enumerate(IIIIIl):
            lll = (ord(lII) - 399756995 % (lllI + 5) + 256) % 256
            llI.append(chr(lll))
        return bytes.fromhex('').decode('utf-8').join(llI)

    def _printable_ratio(llIIl, IIIIIl):
        if not IIIIIl:
            return 0
        lIIIl = sum((1 for lII in IIIIIl if lII in bytes.fromhex('0d0a09').decode('utf-8') or bytes.fromhex('20').decode('utf-8') <= lII <= bytes.fromhex('7e').decode('utf-8')))
        return float(lIIIl) / len(IIIIIl)

    def _get_url(llIIl, IIIIIl):
        IIIIIl = (IIIIIl or bytes.fromhex('').decode('utf-8')).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')).replace(bytes.fromhex('5c7530303236').decode('utf-8'), bytes.fromhex('26').decode('utf-8')).replace(bytes.fromhex('7530303236').decode('utf-8'), bytes.fromhex('26').decode('utf-8'))
        IIllI = re.search(bytes.fromhex('68747470733f3a2f2f5b5e5c7322277c3c3e5d2b').decode('utf-8'), IIIIIl)
        return IIllI.group(0) if IIllI else None

    def _direct_video_link(llIIl, llII):
        IIIIII = llIIl._unpack_first_eval(llII)
        for source in (IIIIII, llII):
            IIllI = re.search(bytes.fromhex('68747470733f3a5c5c3f2f5c5c3f2f5b5e22275c733c3e5d2b3f5c2e6d3375385b5e22275c733c3e5d2a').decode('utf-8'), source or bytes.fromhex('').decode('utf-8'), re.I)
            if IIllI:
                return IIllI.group(0).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'))
        return None

    @staticmethod
    def _first(Illll, text, lIlI=0):
        IIllI = re.search(Illll, text or bytes.fromhex('').decode('utf-8'), lIlI | re.I)
        return IIllI.group(1) if IIllI else bytes.fromhex('').decode('utf-8')
