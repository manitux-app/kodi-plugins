from __future__ import absolute_import, unicode_literals
import html
import re
try:
    from urllib.parse import urljoin
except ImportError:
    from urlparse import urljoin

def categories(base_url):
    base_url = base_url.rstrip(bytes.fromhex('2f').decode('utf-8'))
    return [(bytes.fromhex('536f6e2046696c6d6c6572').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d6c65722d312f').decode('utf-8')), (bytes.fromhex('44697a696c6572').decode('utf-8'), base_url + bytes.fromhex('2f796162616e63692d64697a692d697a6c652d312f').decode('utf-8')), (bytes.fromhex('416b7369796f6e').decode('utf-8'), base_url + bytes.fromhex('2f7475722f616b7369796f6e2d666d312f66696c6d2f').decode('utf-8')), (bytes.fromhex('41696c65').decode('utf-8'), base_url + bytes.fromhex('2f7475722f61696c652d666d312f66696c6d2f').decode('utf-8')), (bytes.fromhex('416e696d6173796f6e').decode('utf-8'), base_url + bytes.fromhex('2f7475722f616e696d6173796f6e2d666d322f66696c6d2f').decode('utf-8')), (bytes.fromhex('42656c676573656c').decode('utf-8'), base_url + bytes.fromhex('2f7475722f62656c676573656c2f66696c6d2f').decode('utf-8')), (bytes.fromhex('4269796f6772616669').decode('utf-8'), base_url + bytes.fromhex('2f7475722f6269796f67726166692f66696c6d2f').decode('utf-8')), (bytes.fromhex('42696c696d204b75726775').decode('utf-8'), base_url + bytes.fromhex('2f7475722f62696c696d2d6b757267752d666d332f66696c6d2f').decode('utf-8')), (bytes.fromhex('4472616d').decode('utf-8'), base_url + bytes.fromhex('2f7475722f6472616d2d666d312f66696c6d2f').decode('utf-8')), (bytes.fromhex('46616e74617374696b').decode('utf-8'), base_url + bytes.fromhex('2f7475722f66616e74617374696b2d666d312f66696c6d2f').decode('utf-8')), (bytes.fromhex('476572696c696d').decode('utf-8'), base_url + bytes.fromhex('2f7475722f676572696c696d2d666d312f66696c6d2f').decode('utf-8')), (bytes.fromhex('47697a656d').decode('utf-8'), base_url + bytes.fromhex('2f7475722f67697a656d2f66696c6d2f').decode('utf-8')), (bytes.fromhex('4b6f6d656469').decode('utf-8'), base_url + bytes.fromhex('2f7475722f6b6f6d6564692d666d312f66696c6d2f').decode('utf-8')), (bytes.fromhex('4b6f726b75').decode('utf-8'), base_url + bytes.fromhex('2f7475722f6b6f726b752d666d312f66696c6d2f').decode('utf-8')), (bytes.fromhex('4d6163657261').decode('utf-8'), base_url + bytes.fromhex('2f7475722f6d61636572612d666d312f66696c6d2f').decode('utf-8')), (bytes.fromhex('4dc3bc7a696b').decode('utf-8'), base_url + bytes.fromhex('2f7475722f6d757a696b2f66696c6d2f').decode('utf-8')), (bytes.fromhex('506f6c6973697965').decode('utf-8'), base_url + bytes.fromhex('2f7475722f706f6c69736979652f66696c6d2f').decode('utf-8')), (bytes.fromhex('526f6d616e74696b').decode('utf-8'), base_url + bytes.fromhex('2f7475722f726f6d616e74696b2d666d312f66696c6d2f').decode('utf-8')), (bytes.fromhex('53617661c59f').decode('utf-8'), base_url + bytes.fromhex('2f7475722f73617661732d666d312f66696c6d2f').decode('utf-8')), (bytes.fromhex('53706f72').decode('utf-8'), base_url + bytes.fromhex('2f7475722f73706f722f66696c6d2f').decode('utf-8')), (bytes.fromhex('5461726968').decode('utf-8'), base_url + bytes.fromhex('2f7475722f74617269682f66696c6d2f').decode('utf-8')), (bytes.fromhex('5765737465726e').decode('utf-8'), base_url + bytes.fromhex('2f7475722f7765737465726e2d666d312f66696c6d2f').decode('utf-8')), (bytes.fromhex('4e6574666c6978').decode('utf-8'), base_url + bytes.fromhex('2f6b616e616c2f6e6574666c69782d666d312f').decode('utf-8')), (bytes.fromhex('4469736e6579').decode('utf-8'), base_url + bytes.fromhex('2f6b616e616c2f6469736e65792d666d322f').decode('utf-8')), (bytes.fromhex('416d617a6f6e').decode('utf-8'), base_url + bytes.fromhex('2f6b616e616c2f616d617a6f6e2f').decode('utf-8')), (bytes.fromhex('4170706c65').decode('utf-8'), base_url + bytes.fromhex('2f6b616e616c2f6170706c652f').decode('utf-8')), (bytes.fromhex('48756c75').decode('utf-8'), base_url + bytes.fromhex('2f6b616e616c2f68756c752f').decode('utf-8')), (bytes.fromhex('506172616d6f756e74').decode('utf-8'), base_url + bytes.fromhex('2f6b616e616c2f706172616d6f756e742f').decode('utf-8')), (bytes.fromhex('48626f').decode('utf-8'), base_url + bytes.fromhex('2f6b616e616c2f68626f2f').decode('utf-8')), (bytes.fromhex('506561636f636b').decode('utf-8'), base_url + bytes.fromhex('2f6b616e616c2f706561636f636b2f').decode('utf-8'))]

def page_url(lII, page_number):
    if int(page_number) <= 1:
        return II(lII)
    return II(lII.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f73617966612f7b307d2f').decode('utf-8').format(page_number))

def parse_page_items(page, base_url, Ill=bytes.fromhex('').decode('utf-8')):
    IllI = []
    lllI = set()
    for IIl in lI(page):
        III = Il(bytes.fromhex('3c615c625b5e3e5d2a3e').decode('utf-8'), IIl, re.S)
        IIII = I(III, bytes.fromhex('68726566').decode('utf-8'))
        title = l(Il(bytes.fromhex('3c6469765b5e3e5d2a636c6173733d225b5e225d2a5c627469746c655c625b5e225d2a225b5e3e5d2a3e282e2a3f293c2f6469763e').decode('utf-8'), IIl, re.S))
        IIll = Il(bytes.fromhex('3c696d675c625b5e3e5d2a3e').decode('utf-8'), IIl, re.S)
        lIll = I(IIll, bytes.fromhex('646174612d737263').decode('utf-8')) or I(IIll, bytes.fromhex('737263').decode('utf-8'))
        lIll = lIll.replace(bytes.fromhex('6c69737465').decode('utf-8'), bytes.fromhex('6465746179').decode('utf-8')) if lIll else bytes.fromhex('').decode('utf-8')
        rating = l(Il(bytes.fromhex('3c6469765b5e3e5d2a636c6173733d225b5e225d2a5c62726174696e675c625b5e225d2a225b5e3e5d2a3e282e2a3f293c2f6469763e').decode('utf-8'), IIl, re.S))
        year = l(Il(bytes.fromhex('3c6469765b5e3e5d2a636c6173733d225b5e225d2a5c62696e666f5c625b5e225d2a225b5e3e5d2a3e2e2a3f3c7370616e5b5e3e5d2a3e282e2a3f293c2f7370616e3e').decode('utf-8'), IIl, re.S))
        if not title:
            title = l(I(III, bytes.fromhex('646174612d7469746c65').decode('utf-8')))
        if not title or not IIII:
            continue
        url = fix_url(IIII, base_url)
        if url in lllI:
            continue
        lllI.add(url)
        IllI.append({bytes.fromhex('63617465676f7279').decode('utf-8'): Ill, bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('696d616765').decode('utf-8'): fix_url(lIll, base_url) if lIll else bytes.fromhex('').decode('utf-8'), bytes.fromhex('726174696e67').decode('utf-8'): rating, bytes.fromhex('79656172').decode('utf-8'): year, bytes.fromhex('706c6f74').decode('utf-8'): bytes.fromhex('20').decode('utf-8').join((IIlIl for IIlIl in [year, rating] if IIlIl))})
    return IllI

def parse_media_info(page, url, base_url):
    title = l(Il(bytes.fromhex('3c68315b5e3e5d2a636c6173733d225b5e225d2a5c627469746c655c625b5e225d2a225b5e3e5d2a3e282e2a3f293c2f68313e').decode('utf-8'), page, re.S))
    lIl = Il(bytes.fromhex('3c696d675b5e3e5d2a636c6173733d225b5e225d2a5c62636f7665722d696d675c625b5e225d2a225b5e3e5d2a3e').decode('utf-8'), page, re.S)
    lIll = I(lIl, bytes.fromhex('737263').decode('utf-8'))
    lIlI = Il(bytes.fromhex('3c706963747572655c625b5e3e5d2a3e2e2a3f3c2f706963747572653e').decode('utf-8'), page, re.S)
    IIIII = Il(bytes.fromhex('3c736f757263655c625b5e3e5d2a3e').decode('utf-8'), lIlI, re.S)
    IlII = Il(bytes.fromhex('3c696d675c625b5e3e5d2a3e').decode('utf-8'), lIlI, re.S)
    backdrop = I(IIIII, bytes.fromhex('737263736574').decode('utf-8')) or I(IlII, bytes.fromhex('737263').decode('utf-8'))
    plot = l(Il(bytes.fromhex('3c6469765b5e3e5d2a636c6173733d225b5e225d2a5c62696e666f2d6465736372697074696f6e5c625b5e225d2a225b5e3e5d2a3e282e2a3f293c2f6469763e').decode('utf-8'), page, re.S))
    rating = l(Il(bytes.fromhex('3c6469765b5e3e5d2a636c6173733d225b5e225d2a5c62696d64625c625b5e225d2a225b5e3e5d2a3e2e2a3f3c625b5e3e5d2a3e282e2a3f293c2f623e').decode('utf-8'), page, re.S))
    year = l(Il(bytes.fromhex('3c7370616e5b5e3e5d2a636c6173733d225b5e225d2a5c62646174655c625b5e225d2a225b5e3e5d2a3e2e2a3f3c615b5e3e5d2a3e282e2a3f293c2f613e').decode('utf-8'), page, re.S))
    ll = bytes.fromhex('2c20').decode('utf-8').join((l(IIlIl) for IIlIl in re.findall(bytes.fromhex('3c6469765b5e3e5d2a636c6173733d225b5e225d2a5c62636173742d6e616d655c625b5e225d2a225b5e3e5d2a3e282e2a3f293c2f6469763e').decode('utf-8'), page, re.S)))
    tags = bytes.fromhex('2c20').decode('utf-8').join((l(IIlIl) for IIlIl in re.findall(bytes.fromhex('3c6469765b5e3e5d2a636c6173733d225b5e225d2a5c62747970655c625b5e225d2a225b5e3e5d2a3e2e2a3f3c615b5e3e5d2a687265663d225b5e225d2a2f7475722f5b5e225d2a225b5e3e5d2a3e282e2a3f293c2f613e').decode('utf-8'), page, re.S)))
    country = l(Il(bytes.fromhex('3c6469765b5e3e5d2a636c6173733d225b5e225d2a5c62636f756e7472795c625b5e225d2a225b5e3e5d2a3e2e2a3f3c615b5e3e5d2a3e282e2a3f293c2f613e').decode('utf-8'), page, re.S))
    duration = Il(bytes.fromhex('285c642b29').decode('utf-8'), l(Il(bytes.fromhex('3c6469765b5e3e5d2a636c6173733d225b5e225d2a5c6274696d655c625b5e225d2a225b5e3e5d2a3e282e2a3f293c2f6469763e').decode('utf-8'), page, re.S)))
    sources = parse_video_sources(page, base_url)
    episodes = parse_episodes(page, base_url)
    llII = parse_related(page, base_url)
    return {bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('696d616765').decode('utf-8'): fix_url(lIll, base_url) if lIll else bytes.fromhex('').decode('utf-8'), bytes.fromhex('6261636b64726f70').decode('utf-8'): fix_url(backdrop, base_url) if backdrop else bytes.fromhex('').decode('utf-8'), bytes.fromhex('706c6f74').decode('utf-8'): plot, bytes.fromhex('726174696e67').decode('utf-8'): rating, bytes.fromhex('79656172').decode('utf-8'): year, bytes.fromhex('6163746f7273').decode('utf-8'): ll, bytes.fromhex('74616773').decode('utf-8'): tags, bytes.fromhex('636f756e747279').decode('utf-8'): country, bytes.fromhex('6475726174696f6e').decode('utf-8'): duration or bytes.fromhex('30').decode('utf-8'), bytes.fromhex('736f7572636573').decode('utf-8'): sources, bytes.fromhex('657069736f646573').decode('utf-8'): episodes, bytes.fromhex('72656c61746564').decode('utf-8'): llII}

def parse_video_sources(page, base_url):
    sources = []
    llll = set()
    IIlII = I(Il(bytes.fromhex('3c615b5e3e5d2a636c6173733d225b5e225d2a5c62747261696c65722d627574746f6e5c625b5e225d2a225b5e3e5d2a3e').decode('utf-8'), page, re.S), bytes.fromhex('646174612d766964656f5f75726c').decode('utf-8'))
    if IIlII:
        sources.append({bytes.fromhex('6c6162656c').decode('utf-8'): bytes.fromhex('467261676d616e').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): fix_url(IIlII, base_url), bytes.fromhex('69735f747261696c6572').decode('utf-8'): True})
    for IIIlI in re.findall(bytes.fromhex('3c283f3a617c627574746f6e295c625b5e3e5d2a646174612d766964656f5f75726c3d5b225c275d5b5e225c275d2b5b225c275d5b5e3e5d2a3e2e2a3f3c2f283f3a617c627574746f6e293e').decode('utf-8'), page, re.S | re.I):
        url = I(IIIlI, bytes.fromhex('646174612d766964656f5f75726c').decode('utf-8'))
        label = l(IIIlI) or bytes.fromhex('506c6179').decode('utf-8')
        lll = fix_url(url, base_url)
        if url and bytes.fromhex('796f7574756265').decode('utf-8') not in url.lower() and (lll not in llll):
            llll.add(lll)
            sources.append({bytes.fromhex('6c6162656c').decode('utf-8'): label, bytes.fromhex('75726c').decode('utf-8'): lll, bytes.fromhex('69735f747261696c6572').decode('utf-8'): False})
    if len(sources) <= 1:
        IIIl = Il(bytes.fromhex('3c696672616d655c625b5e3e5d2a283f3a646174612d7372637c737263293d225b5e225d2b225b5e3e5d2a3e').decode('utf-8'), page, re.S)
        IIlI = I(IIIl, bytes.fromhex('646174612d737263').decode('utf-8')) or I(IIIl, bytes.fromhex('737263').decode('utf-8'))
        lll = fix_url(IIlI, base_url)
        if IIlI and bytes.fromhex('796f7574756265').decode('utf-8') not in IIlI.lower() and (lll not in llll):
            sources.append({bytes.fromhex('6c6162656c').decode('utf-8'): bytes.fromhex('506c6179').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): lll, bytes.fromhex('69735f747261696c6572').decode('utf-8'): False})
    return sources

def parse_episodes(page, base_url):
    episodes = []
    lllI = set()
    for IIIlI in re.findall(bytes.fromhex('3c615c625b5e3e5d2a687265663d5b225c275d5b5e225c275d2b5b225c275d5b5e3e5d2a3e2e2a3f3c2f613e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
        IIII = I(IIIlI, bytes.fromhex('68726566').decode('utf-8'))
        IIIll = l(IIIlI)
        llIl = Il(bytes.fromhex('283f3a5e7c2f2973657a6f6e2d285c642b29283f3a2f7c2429').decode('utf-8'), IIII) or Il(bytes.fromhex('285c642b292d73657a6f6e').decode('utf-8'), IIII) or Il(bytes.fromhex('285c642b295c2e3f5c732a73657a6f6e').decode('utf-8'), IIIll, re.I)
        episode = Il(bytes.fromhex('283f3a5e7c2f29625b6fc3b65d6c756d2d285c642b29283f3a2f7c2429').decode('utf-8'), IIII) or Il(bytes.fromhex('285c642b292d625b6fc3b65d6c756d').decode('utf-8'), IIII) or Il(bytes.fromhex('285c642b295c2e3f5c732a625b6fc3b65d6c5b75c3bc5d6d').decode('utf-8'), IIIll, re.I)
        if not llIl or not episode:
            continue
        key = (llIl, episode)
        if key in lllI:
            continue
        lllI.add(key)
        title = l(Il(bytes.fromhex('3c6469765b5e3e5d2a636c6173733d225b5e225d2a5c6265702d7469746c655c625b5e225d2a225b5e3e5d2a3e282e2a3f293c2f6469763e').decode('utf-8'), IIIlI, re.S)) or IIIll
        detail = l(Il(bytes.fromhex('3c6469765b5e3e5d2a636c6173733d225b5e225d2a5c6265702d64657461696c735c625b5e225d2a225b5e3e5d2a3e282e2a3f293c2f6469763e').decode('utf-8'), IIIlI, re.S))
        if detail and detail not in title:
            title = bytes.fromhex('7b307d202d207b317d').decode('utf-8').format(title, detail)
        episodes.append({bytes.fromhex('7469746c65').decode('utf-8'): title or bytes.fromhex('7b307d2e2053657a6f6e207b317d2e20426f6c756d').decode('utf-8').format(llIl, episode), bytes.fromhex('75726c').decode('utf-8'): fix_url(IIII, base_url), bytes.fromhex('736561736f6e').decode('utf-8'): llIl, bytes.fromhex('657069736f6465').decode('utf-8'): episode})
    return sorted(episodes, key=lambda item: (int(item[bytes.fromhex('736561736f6e').decode('utf-8')]), int(item[bytes.fromhex('657069736f6465').decode('utf-8')])))

def parse_related(page, base_url):
    llII = []
    for IIl in lI(page):
        title = l(Il(bytes.fromhex('3c6469765b5e3e5d2a636c6173733d225b5e225d2a5c627469746c655c625b5e225d2a225b5e3e5d2a3e282e2a3f293c2f6469763e').decode('utf-8'), IIl, re.S))
        III = Il(bytes.fromhex('3c615c625b5e3e5d2a636c6173733d225b5e225d2a5c626974656d5c625b5e225d2a225b5e3e5d2a3e').decode('utf-8'), IIl, re.S) or Il(bytes.fromhex('3c615c625b5e3e5d2a3e').decode('utf-8'), IIl, re.S)
        IIII = I(III, bytes.fromhex('68726566').decode('utf-8'))
        image = I(Il(bytes.fromhex('3c696d675c625b5e3e5d2a3e').decode('utf-8'), IIl, re.S), bytes.fromhex('737263').decode('utf-8'))
        if title and IIII:
            llII.append({bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): fix_url(IIII, base_url), bytes.fromhex('696d616765').decode('utf-8'): fix_url(image, base_url) if image else bytes.fromhex('').decode('utf-8')})
    return llII

def fix_url(url, base_url):
    if not url:
        return bytes.fromhex('').decode('utf-8')
    return urljoin(base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8'), html.unescape(url).strip())

def lI(page):
    IIIIl = [Illl.start() for Illl in re.finditer(bytes.fromhex('3c6469765b5e3e5d2a636c6173733d225b5e225d2a5c626974656d2d72656c61746976655c625b5e225d2a225b5e3e5d2a3e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.I)]
    IlI = []
    for IlIl, start in enumerate(IIIIl):
        llI = IIIIl[IlIl + 1] if IlIl + 1 < len(IIIIl) else len(page)
        IlI.append(page[start:llI])
    return IlI

def II(url):
    return url if url.endswith(bytes.fromhex('2f').decode('utf-8')) else url + bytes.fromhex('2f').decode('utf-8')

def I(IIIlI, lIII):
    if not IIIlI:
        return bytes.fromhex('').decode('utf-8')
    Illl = re.search(bytes.fromhex('5c627b307d3d5b225c275d285b5e225c275d2b295b225c275d').decode('utf-8').format(re.escape(lIII)), IIIlI, re.I)
    return html.unescape(Illl.group(1)) if Illl else bytes.fromhex('').decode('utf-8')

def Il(lIIl, IIIll, flags=0):
    Illl = re.search(lIIl, IIIll or bytes.fromhex('').decode('utf-8'), flags | re.I)
    if not Illl:
        return bytes.fromhex('').decode('utf-8')
    return Illl.group(1) if Illl.lastindex else Illl.group(0)

def l(IIIll):
    IIIll = re.sub(bytes.fromhex('3c7376672e2a3f3c2f7376673e').decode('utf-8'), bytes.fromhex('20').decode('utf-8'), IIIll or bytes.fromhex('').decode('utf-8'), flags=re.S | re.I)
    IIIll = re.sub(bytes.fromhex('3c5b5e3e5d2b3e').decode('utf-8'), bytes.fromhex('20').decode('utf-8'), IIIll)
    IIIll = html.unescape(IIIll)
    return re.sub(bytes.fromhex('5c732b').decode('utf-8'), bytes.fromhex('20').decode('utf-8'), IIIll).strip()
