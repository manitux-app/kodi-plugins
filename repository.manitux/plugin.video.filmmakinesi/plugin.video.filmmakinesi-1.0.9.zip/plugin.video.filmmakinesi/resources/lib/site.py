from __future__ import absolute_import, unicode_literals
import manituxhttp
try:
    from urllib.parse import quote_plus
except ImportError:
    from urllib import quote_plus
from . import parsers

class FilmMakinesiSite(object):
    CLIENT_IDENTIFIERS = (bytes.fromhex('636c6f756473637261706572').decode('utf-8'), bytes.fromhex('6368726f6d655f313434').decode('utf-8'))

    def __init__(lI, base_url, user_agent):
        lI.base_url = base_url.rstrip(bytes.fromhex('2f').decode('utf-8'))
        lI.user_agent = user_agent
        lI.session = manituxhttp.Session(client_identifier=lI.CLIENT_IDENTIFIERS[0])

    def headers(lI, referer=None):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): lI.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('746578742f68746d6c2c6170706c69636174696f6e2f7868746d6c2b786d6c2c6170706c69636174696f6e2f786d6c3b713d302e392c2a2f2a3b713d302e38').decode('utf-8'), bytes.fromhex('4163636570742d4c616e6775616765').decode('utf-8'): bytes.fromhex('74722d54522c74723b713d302e392c656e2d55533b713d302e382c656e3b713d302e37').decode('utf-8'), bytes.fromhex('557067726164652d496e7365637572652d5265717565737473').decode('utf-8'): bytes.fromhex('31').decode('utf-8')}
        if referer:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        return headers

    def categories(lI):
        return parsers.categories(lI.base_url)

    def page_url(lI, I, page_number):
        return parsers.page_url(I, page_number)

    def get(lI, url, referer=None):
        return lI._get(lI.absolute(url), lI.headers(referer)).text

    def get_page_items(lI, I, page_number=1, title=bytes.fromhex('').decode('utf-8')):
        url = lI.page_url(I, page_number)
        page = lI.get(url, referer=I)
        return parsers.parse_page_items(page, lI.base_url, title)

    def search(lI, query):
        page = lI.get(lI.base_url + bytes.fromhex('2f6172616d612f3f733d').decode('utf-8') + quote_plus(query), referer=lI.base_url + bytes.fromhex('2f').decode('utf-8'))
        return parsers.parse_page_items(page, lI.base_url, bytes.fromhex('4172616d61').decode('utf-8'))

    def parse_detail(lI, page, url):
        return parsers.parse_media_info(page, url, lI.base_url)

    def absolute(lI, url):
        return parsers.fix_url(url, lI.base_url)

    def _get(lI, url, headers):
        II = None
        for l in lI.CLIENT_IDENTIFIERS:
            if lI.session.client_identifier != l:
                lI.session = manituxhttp.Session(client_identifier=l)
            try:
                Il = lI.session.get(url, headers=headers, timeout=25, tls_client_identifier=l)
                if Il.status_code in (403, 429) and l != lI.CLIENT_IDENTIFIERS[-1]:
                    II = manituxhttp.HTTPError(Il)
                    continue
                Il.raise_for_status()
                return Il
            except (manituxhttp.HTTPError, manituxhttp.RequestError) as exc:
                II = exc
                if l == lI.CLIENT_IDENTIFIERS[-1]:
                    raise
        raise II
