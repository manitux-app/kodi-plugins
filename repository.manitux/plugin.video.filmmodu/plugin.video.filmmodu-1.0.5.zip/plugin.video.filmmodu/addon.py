from __future__ import absolute_import, unicode_literals
import re
import sys
import time
import os
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
try:
    from urllib.parse import parse_qsl, quote, urlencode
except ImportError:
    from urlparse import parse_qsl
    from urllib import quote, urlencode
from resources.lib.site import FilmModuSite
MANITUXUI_LIB = os.path.join(xbmcaddon.Addon(id=bytes.fromhex('7363726970742e6d6f64756c652e6d616e697475787569').decode('utf-8')).getAddonInfo(bytes.fromhex('70617468').decode('utf-8')), bytes.fromhex('6c6962').decode('utf-8'))
if MANITUXUI_LIB not in sys.path:
    sys.path.insert(0, MANITUXUI_LIB)
from manituxui import ManituxUI, open_browser
ADDON_ID = bytes.fromhex('706c7567696e2e766964656f2e66696c6d6d6f6475').decode('utf-8')
SKIP_GUI_UNTIL = ADDON_ID + bytes.fromhex('2e736b69705f6775695f756e74696c').decode('utf-8')
ADDON = xbmcaddon.Addon(id=ADDON_ID)
HANDLE = int(sys.argv[1])
BASE_URL = ADDON.getSetting(bytes.fromhex('626173655f75726c').decode('utf-8')) or bytes.fromhex('68747470733a2f2f66696c6d6d6f64752e6f6e65').decode('utf-8')
UA = ADDON.getSetting(bytes.fromhex('757365725f6167656e74').decode('utf-8')) or bytes.fromhex('4d6f7a696c6c612f352e3020285831313b204c696e7578207838365f363429204170706c655765624b69742f3533372e333620284b48544d4c2c206c696b65204765636b6f29204368726f6d652f3132342e30205361666172692f3533372e3336').decode('utf-8')
K11 = FilmModuSite(BASE_URL, UA)

class FilmModuUI(ManituxUI):
    title = bytes.fromhex('46696c6d4d6f6475').decode('utf-8')

    def categories(self):
        categories = [{bytes.fromhex('7469746c65').decode('utf-8'): bytes.fromhex('417261').decode('utf-8'), bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('736561726368').decode('utf-8')}]
        for title, url in K11.categories():
            categories.append({bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url})
        return categories

    def videos(self, category, page=1):
        if category.get(bytes.fromhex('616374696f6e').decode('utf-8')) == bytes.fromhex('736561726368').decode('utf-8'):
            query = xbmcgui.Dialog().input(bytes.fromhex('46696c6d4d6f647520417261').decode('utf-8'))
            return [self._art_item(item) for item in K11.search(query)] if query else []
        return [self._art_item(item) for item in K11.get_page_items(category[bytes.fromhex('75726c').decode('utf-8')], page)]

    def _art_item(self, item):
        PP = dict(item)
        PP[bytes.fromhex('696d616765').decode('utf-8')] = art_url(PP.get(bytes.fromhex('696d616765').decode('utf-8'), bytes.fromhex('').decode('utf-8')), PP.get(bytes.fromhex('75726c').decode('utf-8')) or BASE_URL + bytes.fromhex('2f').decode('utf-8'))
        return PP

    def detail(self, video):
        AAaaaaAA = video[bytes.fromhex('75726c').decode('utf-8')]
        try:
            page = K11.get(AAaaaaAA)
        except Exception:
            xbmcgui.Dialog().notification(bytes.fromhex('46696c6d4d6f6475').decode('utf-8'), bytes.fromhex('44657461792073617966617369206163696c616d616469').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
            return video
        WSDyHADTxqUbhQtKUnOZzBLIILNAYkuoHOMZYpudorOeHKPXEkiwnlxylAbItaSEbDLsZJvlDnnJXDY4 = K11.parse_detail(page, AAaaaaAA)
        image = art_url(WSDyHADTxqUbhQtKUnOZzBLIILNAYkuoHOMZYpudorOeHKPXEkiwnlxylAbItaSEbDLsZJvlDnnJXDY4.get(bytes.fromhex('696d616765').decode('utf-8')) or video.get(bytes.fromhex('696d616765').decode('utf-8'), bytes.fromhex('').decode('utf-8')), AAaaaaAA)
        plot = WSDyHADTxqUbhQtKUnOZzBLIILNAYkuoHOMZYpudorOeHKPXEkiwnlxylAbItaSEbDLsZJvlDnnJXDY4.get(bytes.fromhex('706c6f74').decode('utf-8')) or video.get(bytes.fromhex('706c6f74').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
        sources = []
        for source in WSDyHADTxqUbhQtKUnOZzBLIILNAYkuoHOMZYpudorOeHKPXEkiwnlxylAbItaSEbDLsZJvlDnnJXDY4.get(bytes.fromhex('736f7572636573').decode('utf-8'), []):
            sources.append({bytes.fromhex('6c6162656c').decode('utf-8'): source.get(bytes.fromhex('6c6162656c').decode('utf-8')) or bytes.fromhex('4f796e6174').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('72656665726572').decode('utf-8'): source.get(bytes.fromhex('72656665726572').decode('utf-8')) or AAaaaaAA, bytes.fromhex('7375627469746c65').decode('utf-8'): source.get(bytes.fromhex('7375627469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8'), bytes.fromhex('69735f747261696c6572').decode('utf-8'): source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8'), False)})
        return {bytes.fromhex('7469746c65').decode('utf-8'): WSDyHADTxqUbhQtKUnOZzBLIILNAYkuoHOMZYpudorOeHKPXEkiwnlxylAbItaSEbDLsZJvlDnnJXDY4.get(bytes.fromhex('7469746c65').decode('utf-8')) or video.get(bytes.fromhex('7469746c65').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('75726c').decode('utf-8'): AAaaaaAA, bytes.fromhex('696d616765').decode('utf-8'): image, bytes.fromhex('6261636b64726f70').decode('utf-8'): WSDyHADTxqUbhQtKUnOZzBLIILNAYkuoHOMZYpudorOeHKPXEkiwnlxylAbItaSEbDLsZJvlDnnJXDY4.get(bytes.fromhex('6261636b64726f70').decode('utf-8')) or WSDyHADTxqUbhQtKUnOZzBLIILNAYkuoHOMZYpudorOeHKPXEkiwnlxylAbItaSEbDLsZJvlDnnJXDY4.get(bytes.fromhex('66616e617274').decode('utf-8')) or image, bytes.fromhex('706c6f74').decode('utf-8'): plot, bytes.fromhex('79656172').decode('utf-8'): WSDyHADTxqUbhQtKUnOZzBLIILNAYkuoHOMZYpudorOeHKPXEkiwnlxylAbItaSEbDLsZJvlDnnJXDY4.get(bytes.fromhex('79656172').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('636f756e747279').decode('utf-8'): WSDyHADTxqUbhQtKUnOZzBLIILNAYkuoHOMZYpudorOeHKPXEkiwnlxylAbItaSEbDLsZJvlDnnJXDY4.get(bytes.fromhex('636f756e747279').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('6475726174696f6e').decode('utf-8'): WSDyHADTxqUbhQtKUnOZzBLIILNAYkuoHOMZYpudorOeHKPXEkiwnlxylAbItaSEbDLsZJvlDnnJXDY4.get(bytes.fromhex('6475726174696f6e').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('726174696e67').decode('utf-8'): WSDyHADTxqUbhQtKUnOZzBLIILNAYkuoHOMZYpudorOeHKPXEkiwnlxylAbItaSEbDLsZJvlDnnJXDY4.get(bytes.fromhex('726174696e67').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('74616773').decode('utf-8'): WSDyHADTxqUbhQtKUnOZzBLIILNAYkuoHOMZYpudorOeHKPXEkiwnlxylAbItaSEbDLsZJvlDnnJXDY4.get(bytes.fromhex('74616773').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('6163746f7273').decode('utf-8'): WSDyHADTxqUbhQtKUnOZzBLIILNAYkuoHOMZYpudorOeHKPXEkiwnlxylAbItaSEbDLsZJvlDnnJXDY4.get(bytes.fromhex('6163746f7273').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('657069736f646573').decode('utf-8'): [self._art_episode(episode, image, AAaaaaAA) for episode in WSDyHADTxqUbhQtKUnOZzBLIILNAYkuoHOMZYpudorOeHKPXEkiwnlxylAbItaSEbDLsZJvlDnnJXDY4.get(bytes.fromhex('657069736f646573').decode('utf-8'), [])], bytes.fromhex('736f7572636573').decode('utf-8'): sources}

    def _art_episode(self, episode, fallback_image, referer):
        PP = dict(episode)
        PP[bytes.fromhex('696d616765').decode('utf-8')] = art_url(PP.get(bytes.fromhex('696d616765').decode('utf-8')) or fallback_image, PP.get(bytes.fromhex('75726c').decode('utf-8')) or referer)
        return PP

    def play(self, source, video=None):
        if source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8')):
            play_youtube_gui(source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
        else:
            play_source_gui(source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), source.get(bytes.fromhex('72656665726572').decode('utf-8')), source.get(bytes.fromhex('7375627469746c65').decode('utf-8'), bytes.fromhex('').decode('utf-8')))

def build_url(query):
    return sys.argv[0] + bytes.fromhex('3f').decode('utf-8') + urlencode(query)

def art_url(url, referer=None):
    if not url or bytes.fromhex('7c').decode('utf-8') in url or (not url.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8')))):
        return url
    return url + kodi_headers(referer or BASE_URL + bytes.fromhex('2f').decode('utf-8'))

def add_directory(title, action, url=bytes.fromhex('').decode('utf-8'), image=bytes.fromhex('').decode('utf-8'), plot=bytes.fromhex('').decode('utf-8')):
    RgKHOInASNwbRWUEEWZTNUWOtxWcwwpYlmsNXzGvRbDdEfHhbXzixwBeuLWXCUOyankqHDSqnLMtYPR6 = xbmcgui.ListItem(label=title)
    image = art_url(image, url or BASE_URL + bytes.fromhex('2f').decode('utf-8'))
    RgKHOInASNwbRWUEEWZTNUWOtxWcwwpYlmsNXzGvRbDdEfHhbXzixwBeuLWXCUOyankqHDSqnLMtYPR6.setArt({bytes.fromhex('7468756d62').decode('utf-8'): image, bytes.fromhex('69636f6e').decode('utf-8'): image, bytes.fromhex('706f73746572').decode('utf-8'): image, bytes.fromhex('66616e617274').decode('utf-8'): image})
    RgKHOInASNwbRWUEEWZTNUWOtxWcwwpYlmsNXzGvRbDdEfHhbXzixwBeuLWXCUOyankqHDSqnLMtYPR6.setInfo(bytes.fromhex('766964656f').decode('utf-8'), {bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('706c6f74').decode('utf-8'): plot})
    xbmcplugin.addDirectoryItem(HANDLE, build_url({bytes.fromhex('616374696f6e').decode('utf-8'): action, bytes.fromhex('75726c').decode('utf-8'): url}), RgKHOInASNwbRWUEEWZTNUWOtxWcwwpYlmsNXzGvRbDdEfHhbXzixwBeuLWXCUOyankqHDSqnLMtYPR6, True)

def add_video(title, action, url, image=bytes.fromhex('').decode('utf-8'), plot=bytes.fromhex('').decode('utf-8'), extra=None):
    query = {bytes.fromhex('616374696f6e').decode('utf-8'): action, bytes.fromhex('75726c').decode('utf-8'): url}
    if extra:
        query.update(extra)
    RgKHOInASNwbRWUEEWZTNUWOtxWcwwpYlmsNXzGvRbDdEfHhbXzixwBeuLWXCUOyankqHDSqnLMtYPR6 = xbmcgui.ListItem(label=title)
    image = art_url(image, extra.get(bytes.fromhex('72656665726572').decode('utf-8')) if extra else url or BASE_URL + bytes.fromhex('2f').decode('utf-8'))
    RgKHOInASNwbRWUEEWZTNUWOtxWcwwpYlmsNXzGvRbDdEfHhbXzixwBeuLWXCUOyankqHDSqnLMtYPR6.setArt({bytes.fromhex('7468756d62').decode('utf-8'): image, bytes.fromhex('69636f6e').decode('utf-8'): image, bytes.fromhex('706f73746572').decode('utf-8'): image, bytes.fromhex('66616e617274').decode('utf-8'): image})
    RgKHOInASNwbRWUEEWZTNUWOtxWcwwpYlmsNXzGvRbDdEfHhbXzixwBeuLWXCUOyankqHDSqnLMtYPR6.setInfo(bytes.fromhex('766964656f').decode('utf-8'), {bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('706c6f74').decode('utf-8'): plot})
    RgKHOInASNwbRWUEEWZTNUWOtxWcwwpYlmsNXzGvRbDdEfHhbXzixwBeuLWXCUOyankqHDSqnLMtYPR6.setProperty(bytes.fromhex('4973506c617961626c65').decode('utf-8'), bytes.fromhex('74727565').decode('utf-8'))
    xbmcplugin.addDirectoryItem(HANDLE, build_url(query), RgKHOInASNwbRWUEEWZTNUWOtxWcwwpYlmsNXzGvRbDdEfHhbXzixwBeuLWXCUOyankqHDSqnLMtYPR6, False)

def main_menu():
    add_directory(bytes.fromhex('417261').decode('utf-8'), bytes.fromhex('736561726368').decode('utf-8'))
    for title, url in K11.categories():
        add_directory(title, bytes.fromhex('6c697374').decode('utf-8'), url)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('766964656f73').decode('utf-8'))

def list_page(url, page_number=1):
    items = K11.get_page_items(url, page_number)
    for item in items:
        add_directory(item[bytes.fromhex('7469746c65').decode('utf-8')], bytes.fromhex('64657461696c').decode('utf-8'), item[bytes.fromhex('75726c').decode('utf-8')], item[bytes.fromhex('696d616765').decode('utf-8')], item[bytes.fromhex('706c6f74').decode('utf-8')])
    if items:
        xbmcplugin.addDirectoryItem(HANDLE, build_url({bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('6c697374').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('70616765').decode('utf-8'): str(int(page_number) + 1)}), xbmcgui.ListItem(label=bytes.fromhex('536f6e72616b69205361796661').decode('utf-8')), True)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('6d6f76696573').decode('utf-8'))

def search():
    query = xbmcgui.Dialog().input(bytes.fromhex('46696c6d4d6f647520417261').decode('utf-8'))
    if query:
        for item in K11.search(query):
            add_directory(item[bytes.fromhex('7469746c65').decode('utf-8')], bytes.fromhex('64657461696c').decode('utf-8'), item[bytes.fromhex('75726c').decode('utf-8')], item[bytes.fromhex('696d616765').decode('utf-8')], item.get(bytes.fromhex('706c6f74').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
        xbmcplugin.setContent(HANDLE, bytes.fromhex('6d6f76696573').decode('utf-8'))

def detail(url):
    try:
        page = K11.get(url)
    except Exception:
        xbmcgui.Dialog().notification(bytes.fromhex('46696c6d4d6f6475').decode('utf-8'), bytes.fromhex('44657461792073617966617369206163696c616d616469').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    WSDyHADTxqUbhQtKUnOZzBLIILNAYkuoHOMZYpudorOeHKPXEkiwnlxylAbItaSEbDLsZJvlDnnJXDY4 = K11.parse_detail(page, url)
    for source in WSDyHADTxqUbhQtKUnOZzBLIILNAYkuoHOMZYpudorOeHKPXEkiwnlxylAbItaSEbDLsZJvlDnnJXDY4.get(bytes.fromhex('736f7572636573').decode('utf-8'), []):
        add_video(source[bytes.fromhex('6c6162656c').decode('utf-8')], bytes.fromhex('706c61795f796f7574756265').decode('utf-8') if source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8')) else bytes.fromhex('706c61795f736f75726365').decode('utf-8'), source[bytes.fromhex('75726c').decode('utf-8')], WSDyHADTxqUbhQtKUnOZzBLIILNAYkuoHOMZYpudorOeHKPXEkiwnlxylAbItaSEbDLsZJvlDnnJXDY4[bytes.fromhex('696d616765').decode('utf-8')], WSDyHADTxqUbhQtKUnOZzBLIILNAYkuoHOMZYpudorOeHKPXEkiwnlxylAbItaSEbDLsZJvlDnnJXDY4[bytes.fromhex('706c6f74').decode('utf-8')], {bytes.fromhex('72656665726572').decode('utf-8'): source.get(bytes.fromhex('72656665726572').decode('utf-8')) or url, bytes.fromhex('7375627469746c65').decode('utf-8'): source.get(bytes.fromhex('7375627469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')})
    if not WSDyHADTxqUbhQtKUnOZzBLIILNAYkuoHOMZYpudorOeHKPXEkiwnlxylAbItaSEbDLsZJvlDnnJXDY4.get(bytes.fromhex('736f7572636573').decode('utf-8')):
        xbmcgui.Dialog().notification(bytes.fromhex('46696c6d4d6f6475').decode('utf-8'), bytes.fromhex('566964656f206b61796e6167692062756c756e616d616469').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)

def youtube_plugin_url(url):
    video_id = bytes.fromhex('').decode('utf-8')
    for aaAAaAaaA in (bytes.fromhex('283f3a796f75747562655c2e636f6d2f656d6265642f7c796f75747562655c2e636f6d2f77617463685c3f763d7c796f7574755c2e62652f29285b412d5a612d7a302d395f2d5d7b362c7d29').decode('utf-8'), bytes.fromhex('5b3f265d763d285b412d5a612d7a302d395f2d5d7b362c7d29').decode('utf-8')):
        t41332794931867 = re.search(aaAAaAaaA, url or bytes.fromhex('').decode('utf-8'), re.I)
        if t41332794931867:
            video_id = t41332794931867.group(1)
            break
    return bytes.fromhex('706c7567696e3a2f2f706c7567696e2e766964656f2e796f75747562652f706c61792f3f766964656f5f69643d').decode('utf-8') + video_id if video_id else bytes.fromhex('').decode('utf-8')

def play_youtube(url):
    asHtqfkWaCFwYSOBGvPiSXROfRSEcylcpRrKsUcOfkaMuvLmJfwWCRQBjFciBtSqGoMQXgByMogHgYg10 = youtube_plugin_url(url)
    if not asHtqfkWaCFwYSOBGvPiSXROfRSEcylcpRrKsUcOfkaMuvLmJfwWCRQBjFciBtSqGoMQXgByMogHgYg10:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    try:
        xbmcaddon.Addon(id=bytes.fromhex('706c7567696e2e766964656f2e796f7574756265').decode('utf-8'))
    except Exception:
        xbmcgui.Dialog().notification(bytes.fromhex('596f7554756265').decode('utf-8'), bytes.fromhex('706c7567696e2e766964656f2e796f757475626520676572656b6c69').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=asHtqfkWaCFwYSOBGvPiSXROfRSEcylcpRrKsUcOfkaMuvLmJfwWCRQBjFciBtSqGoMQXgByMogHgYg10))

def play_youtube_gui(url):
    asHtqfkWaCFwYSOBGvPiSXROfRSEcylcpRrKsUcOfkaMuvLmJfwWCRQBjFciBtSqGoMQXgByMogHgYg10 = youtube_plugin_url(url)
    if not asHtqfkWaCFwYSOBGvPiSXROfRSEcylcpRrKsUcOfkaMuvLmJfwWCRQBjFciBtSqGoMQXgByMogHgYg10:
        return False
    try:
        xbmcaddon.Addon(id=bytes.fromhex('706c7567696e2e766964656f2e796f7574756265').decode('utf-8'))
    except Exception:
        xbmcgui.Dialog().notification(bytes.fromhex('596f7554756265').decode('utf-8'), bytes.fromhex('706c7567696e2e766964656f2e796f757475626520676572656b6c69').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
        return False
    xbmc.Player().play(asHtqfkWaCFwYSOBGvPiSXROfRSEcylcpRrKsUcOfkaMuvLmJfwWCRQBjFciBtSqGoMQXgByMogHgYg10)
    return True

def play_source(url, referer=None, subtitle=bytes.fromhex('').decode('utf-8')):
    llllIlIllIllI = url + kodi_headers(referer)
    RgKHOInASNwbRWUEEWZTNUWOtxWcwwpYlmsNXzGvRbDdEfHhbXzixwBeuLWXCUOyankqHDSqnLMtYPR6 = xbmcgui.ListItem(path=llllIlIllIllI)
    if is_hls(url):
        RgKHOInASNwbRWUEEWZTNUWOtxWcwwpYlmsNXzGvRbDdEfHhbXzixwBeuLWXCUOyankqHDSqnLMtYPR6.setMimeType(bytes.fromhex('6170706c69636174696f6e2f766e642e6170706c652e6d70656775726c').decode('utf-8'))
        RgKHOInASNwbRWUEEWZTNUWOtxWcwwpYlmsNXzGvRbDdEfHhbXzixwBeuLWXCUOyankqHDSqnLMtYPR6.setContentLookup(False)
    elif is_extensionless(url):
        RgKHOInASNwbRWUEEWZTNUWOtxWcwwpYlmsNXzGvRbDdEfHhbXzixwBeuLWXCUOyankqHDSqnLMtYPR6.setMimeType(bytes.fromhex('766964656f2f6d7034').decode('utf-8'))
        RgKHOInASNwbRWUEEWZTNUWOtxWcwwpYlmsNXzGvRbDdEfHhbXzixwBeuLWXCUOyankqHDSqnLMtYPR6.setContentLookup(False)
    if subtitle:
        RgKHOInASNwbRWUEEWZTNUWOtxWcwwpYlmsNXzGvRbDdEfHhbXzixwBeuLWXCUOyankqHDSqnLMtYPR6.setSubtitles([subtitle + kodi_headers(referer)])
    xbmcplugin.setResolvedUrl(HANDLE, True, RgKHOInASNwbRWUEEWZTNUWOtxWcwwpYlmsNXzGvRbDdEfHhbXzixwBeuLWXCUOyankqHDSqnLMtYPR6)

def play_source_gui(url, referer=None, subtitle=bytes.fromhex('').decode('utf-8')):
    llllIlIllIllI = url + kodi_headers(referer)
    RgKHOInASNwbRWUEEWZTNUWOtxWcwwpYlmsNXzGvRbDdEfHhbXzixwBeuLWXCUOyankqHDSqnLMtYPR6 = xbmcgui.ListItem(path=llllIlIllIllI)
    if is_hls(url):
        RgKHOInASNwbRWUEEWZTNUWOtxWcwwpYlmsNXzGvRbDdEfHhbXzixwBeuLWXCUOyankqHDSqnLMtYPR6.setMimeType(bytes.fromhex('6170706c69636174696f6e2f766e642e6170706c652e6d70656775726c').decode('utf-8'))
        RgKHOInASNwbRWUEEWZTNUWOtxWcwwpYlmsNXzGvRbDdEfHhbXzixwBeuLWXCUOyankqHDSqnLMtYPR6.setContentLookup(False)
    elif is_extensionless(url):
        RgKHOInASNwbRWUEEWZTNUWOtxWcwwpYlmsNXzGvRbDdEfHhbXzixwBeuLWXCUOyankqHDSqnLMtYPR6.setMimeType(bytes.fromhex('766964656f2f6d7034').decode('utf-8'))
        RgKHOInASNwbRWUEEWZTNUWOtxWcwwpYlmsNXzGvRbDdEfHhbXzixwBeuLWXCUOyankqHDSqnLMtYPR6.setContentLookup(False)
    if subtitle:
        RgKHOInASNwbRWUEEWZTNUWOtxWcwwpYlmsNXzGvRbDdEfHhbXzixwBeuLWXCUOyankqHDSqnLMtYPR6.setSubtitles([subtitle + kodi_headers(referer)])
    xbmc.Player().play(llllIlIllIllI, RgKHOInASNwbRWUEEWZTNUWOtxWcwwpYlmsNXzGvRbDdEfHhbXzixwBeuLWXCUOyankqHDSqnLMtYPR6)

def kodi_headers(referer=None):
    Ill = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): UA}
    if referer:
        Ill[bytes.fromhex('52656665726572').decode('utf-8')] = referer
    return bytes.fromhex('7c').decode('utf-8') + bytes.fromhex('26').decode('utf-8').join((bytes.fromhex('7b307d3d7b317d').decode('utf-8').format(U5, quote(llIllllIlIlIlI)) for U5, llIllllIlIlIlI in Ill.items() if llIllllIlIlIlI))

def is_hls(url):
    return bytes.fromhex('2e6d337538').decode('utf-8') in (url or bytes.fromhex('').decode('utf-8')).split(bytes.fromhex('7c').decode('utf-8'), 1)[0].lower()

def is_extensionless(url):
    w = (url or bytes.fromhex('').decode('utf-8')).split(bytes.fromhex('7c').decode('utf-8'), 1)[0].split(bytes.fromhex('3f').decode('utf-8'), 1)[0].rstrip(bytes.fromhex('2f').decode('utf-8'))
    return bool(w) and bytes.fromhex('2e').decode('utf-8') not in w.rsplit(bytes.fromhex('2f').decode('utf-8'), 1)[-1]

def run():
    params = dict(parse_qsl(sys.argv[2][1:]))
    action = params.get(bytes.fromhex('616374696f6e').decode('utf-8'))
    url = params.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
    page_number = int(params.get(bytes.fromhex('70616765').decode('utf-8'), bytes.fromhex('31').decode('utf-8')))
    if not action:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
        IlIlIIllIllIIII = xbmcgui.Window(10000)
        try:
            H12 = float(IlIlIIllIllIIII.getProperty(SKIP_GUI_UNTIL) or bytes.fromhex('30').decode('utf-8'))
        except ValueError:
            H12 = 0
        if time.time() < H12:
            return
        IlIlIIllIllIIII.clearProperty(SKIP_GUI_UNTIL)
        xbmc.executebuiltin(bytes.fromhex('52756e506c7567696e287b307d29').decode('utf-8').format(build_url({bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('677569').decode('utf-8')})))
        return
    elif action == bytes.fromhex('677569').decode('utf-8'):
        open_browser(FilmModuUI())
        xbmcgui.Window(10000).setProperty(SKIP_GUI_UNTIL, str(time.time() + 4))
        xbmc.executebuiltin(bytes.fromhex('416374697661746557696e646f7728486f6d6529').decode('utf-8'))
        return
    elif action == bytes.fromhex('636c6173736963').decode('utf-8'):
        main_menu()
    elif action == bytes.fromhex('6c697374').decode('utf-8'):
        list_page(url, page_number)
    elif action == bytes.fromhex('736561726368').decode('utf-8'):
        search()
    elif action == bytes.fromhex('64657461696c').decode('utf-8'):
        detail(url)
    elif action == bytes.fromhex('706c61795f736f75726365').decode('utf-8'):
        play_source(url, params.get(bytes.fromhex('72656665726572').decode('utf-8')), params.get(bytes.fromhex('7375627469746c65').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
    elif action == bytes.fromhex('706c61795f796f7574756265').decode('utf-8'):
        play_youtube(url)
    xbmcplugin.endOfDirectory(HANDLE)
if __name__ == bytes.fromhex('5f5f6d61696e5f5f').decode('utf-8'):
    run()
