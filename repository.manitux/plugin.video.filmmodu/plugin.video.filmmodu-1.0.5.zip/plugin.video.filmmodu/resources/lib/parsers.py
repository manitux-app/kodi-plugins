from __future__ import absolute_import, unicode_literals
import html
import json
import re
try:
    from urllib.parse import urljoin
except ImportError:
    from urlparse import urljoin

def categories(base_url):
    base_url = base_url.rstrip(bytes.fromhex('2f').decode('utf-8'))
    return [(bytes.fromhex('344b').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f346b2d66696c6d2d697a6c653f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('41696c65').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f61696c652d66696c6d6c6572693f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('416b7369796f6e').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f616b7369796f6e3f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('416e696d6173796f6e').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f616e696d6173796f6e3f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('42656c676573656c').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f62656c676573656c6c65723f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('42696c696d2d4b75726775').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f62696c696d2d6b757267752d66696c6d6c6572693f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('4472616d').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f6472616d2d66696c6d6c6572693f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('46616e74617374696b').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f66616e74617374696b2d66696c6d6c65723f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('476572696c696d').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f676572696c696d3f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('47697a656d').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f67697a656d2d66696c6d6c6572693f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('48696e742046696c6d6c657269').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f68642d68696e742d66696c6d6c6572693f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('4bc4b173612046696c6d').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f6b6973612d66696c6d3f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('4b6f6d656469').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f68642d6b6f6d6564692d66696c6d6c6572693f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('4b6f726b75').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f6b6f726b752d66696c6d6c6572693f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('4bc3bc6c742046696c6d6c6572').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f6b756c742d66696c6d6c65722d697a6c653f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('4d6163657261').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f6d61636572612d66696c6d6c6572693f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('4dc3bc7a696b').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f6d757a696b3f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('4f7363617220c39664c3bc6c6cc3bc2046696c6d6c6572').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f6f64756c6c752d66696c6d6c65722d697a6c653f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('526f6d616e74696b').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f726f6d616e74696b2d66696c6d6c65723f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('53617661c59f').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f73617661732d66696c6d6c6572693f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('5374616e64205570').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f7374616e642d75703f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('5375c3a7').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f7375632d66696c6d6c6572693f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('5461726968').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f74617269683f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('546176736979652046696c6d6c6572').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f746176736979652d66696c6d6c65723f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('54562066696c6d').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f74762d66696c6d3f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('566168c59f6920426174c4b1').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f76616873692d626174692d66696c6d6c6572693f706167653d5b706167654e756d6265725d').decode('utf-8'))]

def page_url(category_url, page_number):
    return category_url.replace(bytes.fromhex('5b706167654e756d6265725d').decode('utf-8'), str(page_number))

def parse_page_items(page, base_url, category_title=bytes.fromhex('').decode('utf-8')):
    IlIIIIlI = []
    H15 = set()
    for block in re.findall(bytes.fromhex('3c6469765c625b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c626d6f7669655c625b5e225c275d2a5b225c275d5b5e3e5d2a3e2e2a3f283f3d3c6469765c625b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c626d6f7669655c627c2429').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
        III = _first(bytes.fromhex('3c615c625b5e3e5d2a687265663d5b275c225d5b5e275c225d2b5b275c225d5b5e3e5d2a3e').decode('utf-8'), block, re.S)
        mmmmm = _attr(III, bytes.fromhex('68726566').decode('utf-8'))
        title = _clean(III) or _attr(III, bytes.fromhex('7469746c65').decode('utf-8')) or _attr(_first(bytes.fromhex('3c696d675c625b5e3e5d2a3e').decode('utf-8'), block, re.S), bytes.fromhex('616c74').decode('utf-8'))
        oooooooooooo = _poster_from(block, base_url)
        if not title or not mmmmm:
            continue
        url = fix_url(mmmmm, base_url)
        if url in H15:
            continue
        H15.add(url)
        IlIIIIlI.append({bytes.fromhex('63617465676f7279').decode('utf-8'): category_title, bytes.fromhex('7469746c65').decode('utf-8'): _clean_title(title), bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('696d616765').decode('utf-8'): oooooooooooo, bytes.fromhex('706c6f74').decode('utf-8'): bytes.fromhex('').decode('utf-8')})
    return IlIIIIlI

def parse_media_info(page, url, base_url):
    title = _clean(_first(bytes.fromhex('3c6469765b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c627469746c65735c625b5e225c275d2a5b225c275d5b5e3e5d2a3e2e2a3f3c68315b5e3e5d2a3e282e2a3f293c2f68313e').decode('utf-8'), page, re.S))
    kk = _clean(_first(bytes.fromhex('3c6469765b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c627469746c65735c625b5e225c275d2a5b225c275d5b5e3e5d2a3e2e2a3f3c68325b5e3e5d2a3e282e2a3f293c2f68323e').decode('utf-8'), page, re.S))
    oooooooooooo = fix_url(_attr(_first(bytes.fromhex('3c696d675c625b5e3e5d2a636c6173733d5b275c225d5b5e275c225d2a5c62696d672d726573706f6e736976655c625b5e275c225d2a5b275c225d5b5e3e5d2a3e').decode('utf-8'), page, re.S), bytes.fromhex('737263').decode('utf-8')), base_url)
    z4 = fix_url(_attr(_first(bytes.fromhex('3c6469765b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c62656d6265642d726573706f6e736976655c625b5e225c275d2a5b225c275d5b5e3e5d2a3e2e2a3f3c6469765c625b5e3e5d2a706f737465723d5b225c275d5b5e225c275d2b5b225c275d5b5e3e5d2a3e').decode('utf-8'), page, re.S), bytes.fromhex('706f73746572').decode('utf-8')), base_url)
    i11 = _clean(_first(bytes.fromhex('3c705c625b5e3e5d2a6974656d70726f703d5b275c225d6465736372697074696f6e5b275c225d5b5e3e5d2a3e282e2a3f293c2f703e').decode('utf-8'), page, re.S))
    YAKSpzJwYmkCvEoenJZJaPARwWBtGkxfpycQomicCRgYHfDnZfvqzdeOuErCljAxUwTbpoxWZozHosL14 = _clean(_first(bytes.fromhex('3c7370616e5c625b5e3e5d2a6974656d70726f703d5b275c225d726174696e6756616c75655b275c225d5b5e3e5d2a3e282e2a3f293c2f7370616e3e').decode('utf-8'), page, re.S))
    aAaaAaAaAaaaaAAAaaAaaA = _first(bytes.fromhex('5c62285c647b347d295c62').decode('utf-8'), _clean(_first(bytes.fromhex('3c7370616e5c625b5e3e5d2a6974656d70726f703d5b275c225d64617465437265617465645b275c225d5b5e3e5d2a3e282e2a3f293c2f7370616e3e').decode('utf-8'), page, re.S)))
    q = bytes.fromhex('2c20').decode('utf-8').join(dict.fromkeys((_clean(SPlQUuFktUGOcIipLrTiIqyKaxNTPQJfzkSufdkJeVAiNpHqVkJXMGranAlNhAPynUbyZOiBkcQaeEC21) for SPlQUuFktUGOcIipLrTiIqyKaxNTPQJfzkSufdkJeVAiNpHqVkJXMGranAlNhAPynUbyZOiBkcQaeEC21 in re.findall(bytes.fromhex('3c615c625b5e3e5d2a6974656d70726f703d5b275c225d6163746f725b275c225d5b5e3e5d2a3e2e2a3f3c7370616e5b5e3e5d2a3e282e2a3f293c2f7370616e3e').decode('utf-8'), page, re.S) if _clean(SPlQUuFktUGOcIipLrTiIqyKaxNTPQJfzkSufdkJeVAiNpHqVkJXMGranAlNhAPynUbyZOiBkcQaeEC21))))
    K18 = bytes.fromhex('2c20').decode('utf-8').join(dict.fromkeys((_clean(SPlQUuFktUGOcIipLrTiIqyKaxNTPQJfzkSufdkJeVAiNpHqVkJXMGranAlNhAPynUbyZOiBkcQaeEC21) for SPlQUuFktUGOcIipLrTiIqyKaxNTPQJfzkSufdkJeVAiNpHqVkJXMGranAlNhAPynUbyZOiBkcQaeEC21 in re.findall(bytes.fromhex('3c615c625b5e3e5d2a687265663d5b275c225d5b5e275c225d2a66696c6d2d7475722f5b5e275c225d2a5b275c225d5b5e3e5d2a3e282e2a3f293c2f613e').decode('utf-8'), page, re.S) if _clean(SPlQUuFktUGOcIipLrTiIqyKaxNTPQJfzkSufdkJeVAiNpHqVkJXMGranAlNhAPynUbyZOiBkcQaeEC21))))
    FFFFFFFFFFFFFFFFFFF = _youtube_from_page(page)
    llIIlllIIllIIIIl = []
    for tag in re.findall(bytes.fromhex('3c6469765c625b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c62616c7465726e617465735c625b5e225c275d2a5b225c275d5b5e3e5d2a3e2e2a3f3c2f6469763e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
        for R9 in re.findall(bytes.fromhex('3c615c625b5e3e5d2a687265663d5b225c275d5b5e225c275d2b5b225c275d5b5e3e5d2a3e2e2a3f3c2f613e').decode('utf-8'), tag, re.S | re.I):
            mmmmm = _attr(R9, bytes.fromhex('68726566').decode('utf-8'))
            label = _clean(R9) or bytes.fromhex('506c6179').decode('utf-8')
            if mmmmm and bytes.fromhex('667261676d616e').decode('utf-8') not in label.lower():
                llIIlllIIllIIIIl.append({bytes.fromhex('6c6162656c').decode('utf-8'): label, bytes.fromhex('75726c').decode('utf-8'): fix_url(mmmmm, base_url)})
    sources = []
    if FFFFFFFFFFFFFFFFFFF:
        sources.append({bytes.fromhex('6c6162656c').decode('utf-8'): bytes.fromhex('467261676d616e').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): FFFFFFFFFFFFFFFFFFF, bytes.fromhex('72656665726572').decode('utf-8'): url, bytes.fromhex('69735f747261696c6572').decode('utf-8'): True})
    return {bytes.fromhex('7469746c65').decode('utf-8'): title or kk, bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('696d616765').decode('utf-8'): oooooooooooo, bytes.fromhex('6261636b64726f70').decode('utf-8'): z4 or oooooooooooo, bytes.fromhex('706c6f74').decode('utf-8'): i11, bytes.fromhex('726174696e67').decode('utf-8'): YAKSpzJwYmkCvEoenJZJaPARwWBtGkxfpycQomicCRgYHfDnZfvqzdeOuErCljAxUwTbpoxWZozHosL14, bytes.fromhex('79656172').decode('utf-8'): aAaaAaAaAaaaaAAAaaAaaA, bytes.fromhex('6163746f7273').decode('utf-8'): q, bytes.fromhex('74616773').decode('utf-8'): K18, bytes.fromhex('736f7572636573').decode('utf-8'): sources, bytes.fromhex('736f757263655f7061676573').decode('utf-8'): llIIlllIIllIIIIl}

def parse_video_config(page):
    video_id = _first(bytes.fromhex('7661725c732b766964656f49645c732a3d5c732a5b275c225d285b5e275c225d2a29').decode('utf-8'), page)
    cccccccccccccccccccc = _first(bytes.fromhex('7661725c732b766964656f547970655c732a3d5c732a5b275c225d285b5e275c225d2a29').decode('utf-8'), page)
    return (video_id, cccccccccccccccccccc)

def parse_source_response(payload, label, base_url, referer=None):
    try:
        data = json.loads(payload)
    except Exception:
        data = {}
    subtitle = fix_url(data.get(bytes.fromhex('7375627469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8'), base_url)
    sources = []
    for QQQQQQQ in data.get(bytes.fromhex('736f7572636573').decode('utf-8'), []) if isinstance(data, dict) else []:
        zMIeMiQByulzqQLXzkzrZpILeJzdpNCASDjKhcDthTDnmmdfGoiTNQPkfuFzFWCELyIKbJfCijJVqcL17 = QQQQQQQ.get(bytes.fromhex('737263').decode('utf-8')) or QQQQQQQ.get(bytes.fromhex('66696c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        aAaAaAaAAaAaA = QQQQQQQ.get(bytes.fromhex('6c6162656c').decode('utf-8')) or QQQQQQQ.get(bytes.fromhex('7175616c697479').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        if not zMIeMiQByulzqQLXzkzrZpILeJzdpNCASDjKhcDthTDnmmdfGoiTNQPkfuFzFWCELyIKbJfCijJVqcL17:
            continue
        name = bytes.fromhex('207c20').decode('utf-8').join((SPlQUuFktUGOcIipLrTiIqyKaxNTPQJfzkSufdkJeVAiNpHqVkJXMGranAlNhAPynUbyZOiBkcQaeEC21 for SPlQUuFktUGOcIipLrTiIqyKaxNTPQJfzkSufdkJeVAiNpHqVkJXMGranAlNhAPynUbyZOiBkcQaeEC21 in (label, aAaAaAaAAaAaA) if SPlQUuFktUGOcIipLrTiIqyKaxNTPQJfzkSufdkJeVAiNpHqVkJXMGranAlNhAPynUbyZOiBkcQaeEC21))
        sources.append({bytes.fromhex('6c6162656c').decode('utf-8'): name or label, bytes.fromhex('75726c').decode('utf-8'): fix_url(zMIeMiQByulzqQLXzkzrZpILeJzdpNCASDjKhcDthTDnmmdfGoiTNQPkfuFzFWCELyIKbJfCijJVqcL17, base_url), bytes.fromhex('72656665726572').decode('utf-8'): referer or base_url, bytes.fromhex('7375627469746c65').decode('utf-8'): subtitle, bytes.fromhex('69735f747261696c6572').decode('utf-8'): False})
    return sources

def fix_url(url, base_url):
    if not url:
        return bytes.fromhex('').decode('utf-8')
    value = urljoin(base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8'), html.unescape(url).strip())
    return value.replace(bytes.fromhex('68747470733a2f2f7777772e66696c6d6d6f64752e6f6e65').decode('utf-8'), base_url.rstrip(bytes.fromhex('2f').decode('utf-8'))).replace(bytes.fromhex('687474703a2f2f7777772e66696c6d6d6f64752e6f6e65').decode('utf-8'), base_url.rstrip(bytes.fromhex('2f').decode('utf-8')))

def _poster_from(block, base_url):
    anereWnUWbsszzyblCAoqjQZLCAPDPQTbsximVdKYpysdPNcbBGTVVkRVypoyUrZALkyIBsWDMNFzBN6 = _first(bytes.fromhex('3c706963747572655c625b5e3e5d2a3e2e2a3f3c696d675c625b5e3e5d2a3e').decode('utf-8'), block or bytes.fromhex('').decode('utf-8'), re.S) or _first(bytes.fromhex('3c696d675c625b5e3e5d2a3e').decode('utf-8'), block or bytes.fromhex('').decode('utf-8'), re.S)
    oooooooooooo = _attr(anereWnUWbsszzyblCAoqjQZLCAPDPQTbsximVdKYpysdPNcbBGTVVkRVypoyUrZALkyIBsWDMNFzBN6, bytes.fromhex('646174612d737263').decode('utf-8')) or _attr(anereWnUWbsszzyblCAoqjQZLCAPDPQTbsximVdKYpysdPNcbBGTVVkRVypoyUrZALkyIBsWDMNFzBN6, bytes.fromhex('737263').decode('utf-8'))
    if oooooooooooo and (not oooooooooooo.lower().startswith(bytes.fromhex('646174613a696d616765').decode('utf-8'))):
        return fix_url(oooooooooooo, base_url)
    return bytes.fromhex('').decode('utf-8')

def _youtube_from_page(page):
    for pattern in (bytes.fromhex('283f3a796f75747562655c2e636f6d2f656d6265642f7c796f75747562655c2e636f6d2f77617463685c3f763d7c796f7574755c2e62652f29285b412d5a612d7a302d395f2d5d7b362c7d29').decode('utf-8'), bytes.fromhex('646174612d747261696c65723d5b275c225d285b412d5a612d7a302d395f2d5d7b362c7d29').decode('utf-8')):
        R657781401070910 = re.search(pattern, page or bytes.fromhex('').decode('utf-8'), re.I)
        if R657781401070910:
            return bytes.fromhex('68747470733a2f2f796f75747562652e636f6d2f656d6265642f').decode('utf-8') + R657781401070910.group(1)
    return bytes.fromhex('').decode('utf-8')

def _clean_title(value):
    return re.sub(bytes.fromhex('5c732b697a6c655c732a24').decode('utf-8'), bytes.fromhex('').decode('utf-8'), _clean(value), flags=re.I).strip()

def _attr(tag, name):
    if not tag:
        return bytes.fromhex('').decode('utf-8')
    R657781401070910 = re.search(bytes.fromhex('5c627b307d3d5b225c275d285b5e225c275d2b295b225c275d').decode('utf-8').format(re.escape(name)), tag, re.I)
    return html.unescape(R657781401070910.group(1)) if R657781401070910 else bytes.fromhex('').decode('utf-8')

def _first(pattern, text, flags=0):
    R657781401070910 = re.search(pattern, text or bytes.fromhex('').decode('utf-8'), flags | re.I)
    if not R657781401070910:
        return bytes.fromhex('').decode('utf-8')
    return R657781401070910.group(1) if R657781401070910.lastindex else R657781401070910.group(0)

def _clean(text):
    text = re.sub(bytes.fromhex('3c7376672e2a3f3c2f7376673e').decode('utf-8'), bytes.fromhex('20').decode('utf-8'), text or bytes.fromhex('').decode('utf-8'), flags=re.S | re.I)
    text = re.sub(bytes.fromhex('3c5b5e3e5d2b3e').decode('utf-8'), bytes.fromhex('20').decode('utf-8'), text)
    text = html.unescape(text)
    return re.sub(bytes.fromhex('5c732b').decode('utf-8'), bytes.fromhex('20').decode('utf-8'), text).strip()
