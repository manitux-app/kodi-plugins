from __future__ import absolute_import, unicode_literals
import manituxhttp
try:
    from urllib.parse import quote_plus
except ImportError:
    from urllib import quote_plus
from . import parsers

class FilmModuSite(object):
    CLIENT_IDENTIFIERS = (bytes.fromhex('636c6f756473637261706572').decode('utf-8'), bytes.fromhex('6368726f6d655f313434').decode('utf-8'))

    def __init__(self, base_url, user_agent):
        self.base_url = base_url.rstrip(bytes.fromhex('2f').decode('utf-8'))
        self.user_agent = user_agent
        self.session = manituxhttp.Session(client_identifier=self.CLIENT_IDENTIFIERS[0])

    def headers(self, referer=None):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): self.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('746578742f68746d6c2c6170706c69636174696f6e2f7868746d6c2b786d6c2c6170706c69636174696f6e2f786d6c3b713d302e392c2a2f2a3b713d302e38').decode('utf-8'), bytes.fromhex('557067726164652d496e7365637572652d5265717565737473').decode('utf-8'): bytes.fromhex('31').decode('utf-8')}
        if referer:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        return headers

    def categories(self):
        return parsers.categories(self.base_url)

    def get_page_items(self, category_url, page_number=1, title=bytes.fromhex('').decode('utf-8')):
        page = self.get(parsers.page_url(category_url, page_number), referer=category_url)
        return parsers.parse_page_items(page, self.base_url, title)

    def search(self, query):
        page = self.get(self.base_url + bytes.fromhex('2f3f733d').decode('utf-8') + quote_plus(query), referer=self.base_url + bytes.fromhex('2f').decode('utf-8'))
        return parsers.parse_page_items(page, self.base_url, bytes.fromhex('4172616d61').decode('utf-8'))

    def get(self, url, referer=None):
        return self._get(self.absolute(url), self.headers(referer)).text

    def parse_detail(self, page, url):
        S73100502884703 = parsers.parse_media_info(page, url, self.base_url)
        S73100502884703[bytes.fromhex('736f7572636573').decode('utf-8')] = S73100502884703.get(bytes.fromhex('736f7572636573').decode('utf-8'), []) + self.resolve_sources(S73100502884703.get(bytes.fromhex('736f757263655f7061676573').decode('utf-8'), []), url)
        return S73100502884703

    def resolve_sources(self, source_pages, referer):
        sources = []
        for ZCfdiNZTUHpOFLgIymlHkkHuvTEjmoqsQAWxOcNMVgjdklXwxhnqRLsLFviFKlkaPIzurniryyAkGzq4 in source_pages:
            U1 = self.get(ZCfdiNZTUHpOFLgIymlHkkHuvTEjmoqsQAWxOcNMVgjdklXwxhnqRLsLFviFKlkaPIzurniryyAkGzq4[bytes.fromhex('75726c').decode('utf-8')], referer=referer)
            video_id, W8 = parsers.parse_video_config(U1)
            if not video_id or not W8:
                continue
            AAAaAa = self.get(self.base_url + bytes.fromhex('2f6765742d736f757263653f6d6f7669655f69643d7b307d26747970653d7b317d').decode('utf-8').format(video_id, W8), referer=ZCfdiNZTUHpOFLgIymlHkkHuvTEjmoqsQAWxOcNMVgjdklXwxhnqRLsLFviFKlkaPIzurniryyAkGzq4[bytes.fromhex('75726c').decode('utf-8')])
            sources.extend(parsers.parse_source_response(AAAaAa, ZCfdiNZTUHpOFLgIymlHkkHuvTEjmoqsQAWxOcNMVgjdklXwxhnqRLsLFviFKlkaPIzurniryyAkGzq4[bytes.fromhex('6c6162656c').decode('utf-8')], self.base_url, ZCfdiNZTUHpOFLgIymlHkkHuvTEjmoqsQAWxOcNMVgjdklXwxhnqRLsLFviFKlkaPIzurniryyAkGzq4[bytes.fromhex('75726c').decode('utf-8')]))
        return sources

    def absolute(self, url):
        return parsers.fix_url(url, self.base_url)

    def _get(self, url, headers):
        lIIlI = None
        for NN in self.CLIENT_IDENTIFIERS:
            if self.session.client_identifier != NN:
                self.session = manituxhttp.Session(client_identifier=NN)
            try:
                kvRFzqGcaihMlkToBvXmbickrRkgSVoZzMsTkCEslKdMzPSKqHrkudvQuLmSkRWevVfRjtRcsnIIxTw7 = self.session.get(url, headers=headers, timeout=25, allow_redirects=True, tls_client_identifier=NN)
                if kvRFzqGcaihMlkToBvXmbickrRkgSVoZzMsTkCEslKdMzPSKqHrkudvQuLmSkRWevVfRjtRcsnIIxTw7.status_code in (403, 429) and NN != self.CLIENT_IDENTIFIERS[-1]:
                    lIIlI = manituxhttp.HTTPError(kvRFzqGcaihMlkToBvXmbickrRkgSVoZzMsTkCEslKdMzPSKqHrkudvQuLmSkRWevVfRjtRcsnIIxTw7)
                    continue
                kvRFzqGcaihMlkToBvXmbickrRkgSVoZzMsTkCEslKdMzPSKqHrkudvQuLmSkRWevVfRjtRcsnIIxTw7.raise_for_status()
                return kvRFzqGcaihMlkToBvXmbickrRkgSVoZzMsTkCEslKdMzPSKqHrkudvQuLmSkRWevVfRjtRcsnIIxTw7
            except (manituxhttp.HTTPError, manituxhttp.RequestError) as exc:
                lIIlI = exc
                if NN == self.CLIENT_IDENTIFIERS[-1]:
                    raise
        raise lIIlI
