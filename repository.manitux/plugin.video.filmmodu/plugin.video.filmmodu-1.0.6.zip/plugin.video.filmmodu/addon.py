from __future__ import absolute_import, unicode_literals
import re
import sys
import time
import os
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
try:
    from urllib.parse import parse_qsl, quote, urlencode
except ImportError:
    from urlparse import parse_qsl
    from urllib import quote, urlencode
from resources.lib.site import FilmModuSite
I = os.path.join(xbmcaddon.Addon(id=bytes.fromhex('7363726970742e6d6f64756c652e6d616e697475787569').decode('utf-8')).getAddonInfo(bytes.fromhex('70617468').decode('utf-8')), bytes.fromhex('6c6962').decode('utf-8'))
if I not in sys.path:
    sys.path.insert(0, I)
from manituxui import CategoryLoadTimeout, DetailWindow, ManituxUI, format_time, get_continue_items, get_favorites, load_category, open_browser, play_and_track, reset_plugin_selection
ADDON_ID = bytes.fromhex('706c7567696e2e766964656f2e66696c6d6d6f6475').decode('utf-8')
l = ADDON_ID + bytes.fromhex('2e736b69705f6775695f756e74696c').decode('utf-8')
ADDON = xbmcaddon.Addon(id=ADDON_ID)
HANDLE = int(sys.argv[1])
BASE_URL = ADDON.getSetting(bytes.fromhex('626173655f75726c').decode('utf-8')) or bytes.fromhex('68747470733a2f2f66696c6d6d6f64752e6f6e65').decode('utf-8')
UA = ADDON.getSetting(bytes.fromhex('757365725f6167656e74').decode('utf-8')) or bytes.fromhex('4d6f7a696c6c612f352e3020285831313b204c696e7578207838365f363429204170706c655765624b69742f3533372e333620284b48544d4c2c206c696b65204765636b6f29204368726f6d652f3132342e30205361666172692f3533372e3336').decode('utf-8')
site = FilmModuSite(BASE_URL, UA)

class FilmModuUI(ManituxUI):
    title = bytes.fromhex('46696c6d4d6f6475').decode('utf-8')
    favorite_owner = ADDON_ID

    def categories(llII):
        categories = [{bytes.fromhex('7469746c65').decode('utf-8'): bytes.fromhex('417261').decode('utf-8'), bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('736561726368').decode('utf-8')}]
        for title, url in site.categories():
            categories.append({bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url})
        return categories

    def videos(llII, category, page=1):
        if category.get(bytes.fromhex('616374696f6e').decode('utf-8')) == bytes.fromhex('736561726368').decode('utf-8'):
            query = xbmcgui.Dialog().input(bytes.fromhex('46696c6d4d6f647520417261').decode('utf-8'))
            return [llII._art_item(item) for item in site.search(query)] if query else []
        return [llII._art_item(item) for item in site.get_page_items(category[bytes.fromhex('75726c').decode('utf-8')], page)]

    def _art_item(llII, item):
        IIl = dict(item)
        IIl[bytes.fromhex('696d616765').decode('utf-8')] = art_url(IIl.get(bytes.fromhex('696d616765').decode('utf-8'), bytes.fromhex('').decode('utf-8')), IIl.get(bytes.fromhex('75726c').decode('utf-8')) or BASE_URL + bytes.fromhex('2f').decode('utf-8'))
        return IIl

    def detail(llII, video):
        page_url = video[bytes.fromhex('75726c').decode('utf-8')]
        try:
            page = site.get(page_url)
        except Exception:
            xbmcgui.Dialog().notification(bytes.fromhex('46696c6d4d6f6475').decode('utf-8'), bytes.fromhex('44657461792073617966617369206163696c616d616469').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
            return video
        llI = site.parse_detail(page, page_url)
        image = art_url(llI.get(bytes.fromhex('696d616765').decode('utf-8')) or video.get(bytes.fromhex('696d616765').decode('utf-8'), bytes.fromhex('').decode('utf-8')), page_url)
        plot = llI.get(bytes.fromhex('706c6f74').decode('utf-8')) or video.get(bytes.fromhex('706c6f74').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
        sources = []
        for source in llI.get(bytes.fromhex('736f7572636573').decode('utf-8'), []):
            sources.append({bytes.fromhex('6c6162656c').decode('utf-8'): source.get(bytes.fromhex('6c6162656c').decode('utf-8')) or bytes.fromhex('4f796e6174').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('72656665726572').decode('utf-8'): source.get(bytes.fromhex('72656665726572').decode('utf-8')) or page_url, bytes.fromhex('7375627469746c65').decode('utf-8'): source.get(bytes.fromhex('7375627469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8'), bytes.fromhex('69735f747261696c6572').decode('utf-8'): source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8'), False)})
        return {bytes.fromhex('7469746c65').decode('utf-8'): llI.get(bytes.fromhex('7469746c65').decode('utf-8')) or video.get(bytes.fromhex('7469746c65').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('75726c').decode('utf-8'): page_url, bytes.fromhex('696d616765').decode('utf-8'): image, bytes.fromhex('6261636b64726f70').decode('utf-8'): llI.get(bytes.fromhex('6261636b64726f70').decode('utf-8')) or llI.get(bytes.fromhex('66616e617274').decode('utf-8')) or image, bytes.fromhex('706c6f74').decode('utf-8'): plot, bytes.fromhex('79656172').decode('utf-8'): llI.get(bytes.fromhex('79656172').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('636f756e747279').decode('utf-8'): llI.get(bytes.fromhex('636f756e747279').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('6475726174696f6e').decode('utf-8'): llI.get(bytes.fromhex('6475726174696f6e').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('726174696e67').decode('utf-8'): llI.get(bytes.fromhex('726174696e67').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('74616773').decode('utf-8'): llI.get(bytes.fromhex('74616773').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('6163746f7273').decode('utf-8'): llI.get(bytes.fromhex('6163746f7273').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('657069736f646573').decode('utf-8'): [llII._art_episode(episode, image, page_url) for episode in llI.get(bytes.fromhex('657069736f646573').decode('utf-8'), [])], bytes.fromhex('736f7572636573').decode('utf-8'): sources}

    def _art_episode(llII, episode, lIl, referer):
        IIl = dict(episode)
        IIl[bytes.fromhex('696d616765').decode('utf-8')] = art_url(IIl.get(bytes.fromhex('696d616765').decode('utf-8')) or lIl, IIl.get(bytes.fromhex('75726c').decode('utf-8')) or referer)
        return IIl

    def play(llII, source, video=None):
        if source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8')):
            play_youtube_gui(source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
        else:
            play_source_gui(source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), source.get(bytes.fromhex('72656665726572').decode('utf-8')), source.get(bytes.fromhex('7375627469746c65').decode('utf-8'), bytes.fromhex('').decode('utf-8')), video, source)

    def resume(llII, source, video, lIlI):
        play_source_gui(source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), source.get(bytes.fromhex('72656665726572').decode('utf-8')), source.get(bytes.fromhex('7375627469746c65').decode('utf-8'), bytes.fromhex('').decode('utf-8')), video, source, lIlI)

def build_url(query):
    return sys.argv[0] + bytes.fromhex('3f').decode('utf-8') + urlencode(query)

def art_url(url, referer=None):
    if not url or bytes.fromhex('7c').decode('utf-8') in url or (not url.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8')))):
        return url
    return url + kodi_headers(referer or BASE_URL + bytes.fromhex('2f').decode('utf-8'))

def add_directory(title, action, url=bytes.fromhex('').decode('utf-8'), image=bytes.fromhex('').decode('utf-8'), plot=bytes.fromhex('').decode('utf-8')):
    IIIl = xbmcgui.ListItem(label=title)
    image = art_url(image, url or BASE_URL + bytes.fromhex('2f').decode('utf-8'))
    IIIl.setArt({bytes.fromhex('7468756d62').decode('utf-8'): image, bytes.fromhex('69636f6e').decode('utf-8'): image, bytes.fromhex('706f73746572').decode('utf-8'): image, bytes.fromhex('66616e617274').decode('utf-8'): image})
    IIIl.setInfo(bytes.fromhex('766964656f').decode('utf-8'), {bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('706c6f74').decode('utf-8'): plot})
    xbmcplugin.addDirectoryItem(HANDLE, build_url({bytes.fromhex('616374696f6e').decode('utf-8'): action, bytes.fromhex('75726c').decode('utf-8'): url}), IIIl, True)

def add_video(title, action, url, image=bytes.fromhex('').decode('utf-8'), plot=bytes.fromhex('').decode('utf-8'), lII=None):
    query = {bytes.fromhex('616374696f6e').decode('utf-8'): action, bytes.fromhex('75726c').decode('utf-8'): url}
    if lII:
        query.update(lII)
    IIIl = xbmcgui.ListItem(label=title)
    image = art_url(image, lII.get(bytes.fromhex('72656665726572').decode('utf-8')) if lII else url or BASE_URL + bytes.fromhex('2f').decode('utf-8'))
    IIIl.setArt({bytes.fromhex('7468756d62').decode('utf-8'): image, bytes.fromhex('69636f6e').decode('utf-8'): image, bytes.fromhex('706f73746572').decode('utf-8'): image, bytes.fromhex('66616e617274').decode('utf-8'): image})
    IIIl.setInfo(bytes.fromhex('766964656f').decode('utf-8'), {bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('706c6f74').decode('utf-8'): plot})
    IIIl.setProperty(bytes.fromhex('4973506c617961626c65').decode('utf-8'), bytes.fromhex('74727565').decode('utf-8'))
    xbmcplugin.addDirectoryItem(HANDLE, build_url(query), IIIl, False)

def main_menu():
    add_directory(bytes.fromhex('417261').decode('utf-8'), bytes.fromhex('736561726368').decode('utf-8'))
    for title, url in site.categories():
        add_directory(title, bytes.fromhex('6c697374').decode('utf-8'), url)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('766964656f73').decode('utf-8'))

def manitux_skin_categories():
    for category in FilmModuUI().categories():
        if category.get(bytes.fromhex('616374696f6e').decode('utf-8')) == bytes.fromhex('736561726368').decode('utf-8') or not category.get(bytes.fromhex('75726c').decode('utf-8')):
            continue
        IIIl = xbmcgui.ListItem(label=category.get(bytes.fromhex('7469746c65').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
        IIIl.setArt({bytes.fromhex('69636f6e').decode('utf-8'): ADDON.getAddonInfo(bytes.fromhex('69636f6e').decode('utf-8')), bytes.fromhex('7468756d62').decode('utf-8'): ADDON.getAddonInfo(bytes.fromhex('69636f6e').decode('utf-8'))})
        path = build_url({bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('6d616e697475785f736b696e5f6974656d73').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): category[bytes.fromhex('75726c').decode('utf-8')], bytes.fromhex('70616765').decode('utf-8'): bytes.fromhex('31').decode('utf-8')})
        xbmcplugin.addDirectoryItem(HANDLE, path, IIIl, True)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('766964656f73').decode('utf-8'))

def manitux_skin_items(url, page_number=1):
    page_number = max(1, int(page_number))
    adapter = FilmModuUI()
    try:
        items = load_category(lambda: adapter.videos({bytes.fromhex('75726c').decode('utf-8'): url}, page_number))
    except CategoryLoadTimeout:
        reset_plugin_selection()
        items = []
    if page_number > 1:
        add_manitux_page_card(url, 1, bytes.fromhex('c4b06c6b205361796661').decode('utf-8'))
    if page_number > 2:
        add_manitux_page_card(url, page_number - 1, bytes.fromhex('c3966e63656b69205361796661').decode('utf-8'))
    IlIl = (1 if page_number > 1 else 0) + (1 if page_number > 2 else 0)
    for lll, item in enumerate(items, IlIl):
        add_manitux_detail_card(item, lll)
    if items:
        add_manitux_page_card(url, page_number + 1, bytes.fromhex('536f6e72616b69205361796661').decode('utf-8'))
    xbmcplugin.setContent(HANDLE, bytes.fromhex('6d6f76696573').decode('utf-8'))

def manitux_skin_search(query):
    for lll, item in enumerate(site.search(query) if query else []):
        add_manitux_detail_card(FilmModuUI()._art_item(item), lll)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('6d6f76696573').decode('utf-8'))

def manitux_skin_favorites():
    for lll, item in enumerate(get_favorites()):
        add_manitux_detail_card(item, lll)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('6d6f76696573').decode('utf-8'))

def manitux_skin_continue():
    for lll, item in enumerate(get_continue_items()):
        Il = dict(item)
        III = item.get(bytes.fromhex('636f6e74657874').decode('utf-8')) or {}
        Il[bytes.fromhex('79656172').decode('utf-8')] = item.get(bytes.fromhex('79656172').decode('utf-8')) or III.get(bytes.fromhex('79656172').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
        Il[bytes.fromhex('726174696e67').decode('utf-8')] = item.get(bytes.fromhex('726174696e67').decode('utf-8')) or III.get(bytes.fromhex('726174696e67').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
        Il[bytes.fromhex('7469746c65').decode('utf-8')] = bytes.fromhex('7b7d2020e280a220207b7d').decode('utf-8').format(item.get(bytes.fromhex('7469746c65').decode('utf-8'), bytes.fromhex('566964656f').decode('utf-8')), format_time(item.get(bytes.fromhex('706f736974696f6e').decode('utf-8'))))
        add_manitux_detail_card(Il, lll)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('6d6f76696573').decode('utf-8'))

def add_manitux_detail_card(item, lll):
    title = item.get(bytes.fromhex('7469746c65').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
    image = item.get(bytes.fromhex('696d616765').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
    plot = item.get(bytes.fromhex('706c6f74').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
    IIIl = xbmcgui.ListItem(label=title)
    IIIl.setArt({bytes.fromhex('7468756d62').decode('utf-8'): image, bytes.fromhex('69636f6e').decode('utf-8'): image, bytes.fromhex('706f73746572').decode('utf-8'): image, bytes.fromhex('66616e617274').decode('utf-8'): image})
    IIIl.setInfo(bytes.fromhex('766964656f').decode('utf-8'), {bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('706c6f74').decode('utf-8'): plot})
    IIIl.setProperty(bytes.fromhex('79656172').decode('utf-8'), str(item.get(bytes.fromhex('79656172').decode('utf-8')) or bytes.fromhex('').decode('utf-8')))
    IIIl.setProperty(bytes.fromhex('726174696e67').decode('utf-8'), str(item.get(bytes.fromhex('726174696e67').decode('utf-8')) or bytes.fromhex('').decode('utf-8')))
    IIIl.setProperty(bytes.fromhex('4973506c617961626c65').decode('utf-8'), bytes.fromhex('74727565').decode('utf-8'))
    query = {bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('6d616e697475785f736b696e5f64657461696c').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): item.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('696d616765').decode('utf-8'): image, bytes.fromhex('706c6f74').decode('utf-8'): plot, bytes.fromhex('6974656d5f696e646578').decode('utf-8'): str(lll)}
    IlII = item.get(bytes.fromhex('6f776e6572').decode('utf-8')) or ADDON_ID
    path = bytes.fromhex('706c7567696e3a2f2f7b307d2f3f7b317d').decode('utf-8').format(IlII, urlencode(query))
    xbmcplugin.addDirectoryItem(HANDLE, path, IIIl, False)

def add_manitux_page_card(url, page_number, II):
    IIIl = xbmcgui.ListItem(label=str(page_number))
    IIIl.setProperty(bytes.fromhex('6d616e697475785f706167655f63617264').decode('utf-8'), bytes.fromhex('74727565').decode('utf-8'))
    IIIl.setProperty(bytes.fromhex('6d616e697475785f706167655f63617074696f6e').decode('utf-8'), II)
    IIIl.setProperty(bytes.fromhex('4973506c617961626c65').decode('utf-8'), bytes.fromhex('74727565').decode('utf-8'))
    path = build_url({bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('6d616e697475785f736b696e5f70616765').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('70616765').decode('utf-8'): str(page_number)})
    xbmcplugin.addDirectoryItem(HANDLE, path, IIIl, False)

def set_skin_string(IIll, IIIII):
    IIIII = (IIIII or bytes.fromhex('').decode('utf-8')).replace(bytes.fromhex('5c').decode('utf-8'), bytes.fromhex('5c5c').decode('utf-8')).replace(bytes.fromhex('2c').decode('utf-8'), bytes.fromhex('5c2c').decode('utf-8')).replace(bytes.fromhex('29').decode('utf-8'), bytes.fromhex('5c29').decode('utf-8'))
    xbmc.executebuiltin(bytes.fromhex('536b696e2e536574537472696e67287b307d2c7b317d29').decode('utf-8').format(IIll, IIIII))

def manitux_skin_page(url, page_number):
    page_number = max(1, int(page_number))
    lI = build_url({bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('6d616e697475785f736b696e5f6974656d73').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('70616765').decode('utf-8'): str(page_number)})
    set_skin_string(bytes.fromhex('4d616e697475782e4c6f6164696e67').decode('utf-8'), bytes.fromhex('74727565').decode('utf-8'))
    set_skin_string(bytes.fromhex('4d616e697475782e43757272656e74506c7567696e43617465676f727950617468').decode('utf-8'), lI)
    set_skin_string(bytes.fromhex('4d616e697475782e43757272656e74506c7567696e43617465676f727950616765').decode('utf-8'), str(page_number))
    set_skin_string(bytes.fromhex('4d616e697475782e43757272656e74506c7567696e50726576696f757350616765').decode('utf-8'), str(max(1, page_number - 1)))
    set_skin_string(bytes.fromhex('4d616e697475782e43757272656e74506c7567696e4e65787450616765').decode('utf-8'), str(page_number + 1))
    xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
    xbmc.executebuiltin(bytes.fromhex('436f6e7461696e65722e52656672657368').decode('utf-8'))
    xbmc.sleep(150)
    xbmc.executebuiltin(bytes.fromhex('536574466f637573283330302c3029').decode('utf-8'))

def manitux_skin_detail(url, title, image, plot, lll=0):
    xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
    Ill = DetailWindow(bytes.fromhex('6d616e6974757875695f64657461696c2e786d6c').decode('utf-8'), xbmcaddon.Addon(id=bytes.fromhex('7363726970742e6d6f64756c652e6d616e697475787569').decode('utf-8')).getAddonInfo(bytes.fromhex('70617468').decode('utf-8')), bytes.fromhex('44656661756c74').decode('utf-8'), bytes.fromhex('3130383069').decode('utf-8'), adapter=FilmModuUI(), video={bytes.fromhex('6661766f726974655f6f776e6572').decode('utf-8'): ADDON_ID, bytes.fromhex('7469746c65').decode('utf-8'): title or bytes.fromhex('').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): url or bytes.fromhex('').decode('utf-8'), bytes.fromhex('696d616765').decode('utf-8'): image or bytes.fromhex('').decode('utf-8'), bytes.fromhex('6261636b64726f70').decode('utf-8'): image or bytes.fromhex('').decode('utf-8'), bytes.fromhex('706c6f74').decode('utf-8'): plot or bytes.fromhex('').decode('utf-8')})
    Ill.doModal()
    del Ill
    IlI = xbmc.getInfoLabel(bytes.fromhex('536b696e2e537472696e67284d616e697475782e43757272656e74506c7567696e43617465676f72795061746829').decode('utf-8'))
    if bytes.fromhex('616374696f6e3d6d616e697475785f736b696e5f6661766f7269746573').decode('utf-8') in IlI or bytes.fromhex('616374696f6e3d6d616e697475785f736b696e5f636f6e74696e7565').decode('utf-8') in IlI:
        xbmc.executebuiltin(bytes.fromhex('436f6e7461696e65722e52656672657368').decode('utf-8'))
    xbmc.sleep(100)
    xbmc.executebuiltin(bytes.fromhex('536574466f637573283330302c7b307d2c6162736f6c75746529').decode('utf-8').format(max(0, int(lll))))

def list_page(url, page_number=1):
    items = site.get_page_items(url, page_number)
    for item in items:
        add_directory(item[bytes.fromhex('7469746c65').decode('utf-8')], bytes.fromhex('64657461696c').decode('utf-8'), item[bytes.fromhex('75726c').decode('utf-8')], item[bytes.fromhex('696d616765').decode('utf-8')], item[bytes.fromhex('706c6f74').decode('utf-8')])
    if items:
        xbmcplugin.addDirectoryItem(HANDLE, build_url({bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('6c697374').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('70616765').decode('utf-8'): str(int(page_number) + 1)}), xbmcgui.ListItem(label=bytes.fromhex('536f6e72616b69205361796661').decode('utf-8')), True)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('6d6f76696573').decode('utf-8'))

def search():
    query = xbmcgui.Dialog().input(bytes.fromhex('46696c6d4d6f647520417261').decode('utf-8'))
    if query:
        for item in site.search(query):
            add_directory(item[bytes.fromhex('7469746c65').decode('utf-8')], bytes.fromhex('64657461696c').decode('utf-8'), item[bytes.fromhex('75726c').decode('utf-8')], item[bytes.fromhex('696d616765').decode('utf-8')], item.get(bytes.fromhex('706c6f74').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
        xbmcplugin.setContent(HANDLE, bytes.fromhex('6d6f76696573').decode('utf-8'))

def detail(url):
    try:
        page = site.get(url)
    except Exception:
        xbmcgui.Dialog().notification(bytes.fromhex('46696c6d4d6f6475').decode('utf-8'), bytes.fromhex('44657461792073617966617369206163696c616d616469').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    llI = site.parse_detail(page, url)
    for source in llI.get(bytes.fromhex('736f7572636573').decode('utf-8'), []):
        add_video(source[bytes.fromhex('6c6162656c').decode('utf-8')], bytes.fromhex('706c61795f796f7574756265').decode('utf-8') if source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8')) else bytes.fromhex('706c61795f736f75726365').decode('utf-8'), source[bytes.fromhex('75726c').decode('utf-8')], llI[bytes.fromhex('696d616765').decode('utf-8')], llI[bytes.fromhex('706c6f74').decode('utf-8')], {bytes.fromhex('72656665726572').decode('utf-8'): source.get(bytes.fromhex('72656665726572').decode('utf-8')) or url, bytes.fromhex('7375627469746c65').decode('utf-8'): source.get(bytes.fromhex('7375627469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')})
    if not llI.get(bytes.fromhex('736f7572636573').decode('utf-8')):
        xbmcgui.Dialog().notification(bytes.fromhex('46696c6d4d6f6475').decode('utf-8'), bytes.fromhex('566964656f206b61796e6167692062756c756e616d616469').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)

def youtube_plugin_url(url):
    IIIIl = bytes.fromhex('').decode('utf-8')
    for Illl in (bytes.fromhex('283f3a796f75747562655c2e636f6d2f656d6265642f7c796f75747562655c2e636f6d2f77617463685c3f763d7c796f7574755c2e62652f29285b412d5a612d7a302d395f2d5d7b362c7d29').decode('utf-8'), bytes.fromhex('5b3f265d763d285b412d5a612d7a302d395f2d5d7b362c7d29').decode('utf-8')):
        IIlI = re.search(Illl, url or bytes.fromhex('').decode('utf-8'), re.I)
        if IIlI:
            IIIIl = IIlI.group(1)
            break
    return bytes.fromhex('706c7567696e3a2f2f706c7567696e2e766964656f2e796f75747562652f706c61792f3f766964656f5f69643d').decode('utf-8') + IIIIl if IIIIl else bytes.fromhex('').decode('utf-8')

def play_youtube(url):
    lIIl = youtube_plugin_url(url)
    if not lIIl:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    try:
        xbmcaddon.Addon(id=bytes.fromhex('706c7567696e2e766964656f2e796f7574756265').decode('utf-8'))
    except Exception:
        xbmcgui.Dialog().notification(bytes.fromhex('596f7554756265').decode('utf-8'), bytes.fromhex('706c7567696e2e766964656f2e796f757475626520676572656b6c69').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=lIIl))

def play_youtube_gui(url):
    lIIl = youtube_plugin_url(url)
    if not lIIl:
        return False
    try:
        xbmcaddon.Addon(id=bytes.fromhex('706c7567696e2e766964656f2e796f7574756265').decode('utf-8'))
    except Exception:
        xbmcgui.Dialog().notification(bytes.fromhex('596f7554756265').decode('utf-8'), bytes.fromhex('706c7567696e2e766964656f2e796f757475626520676572656b6c69').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
        return False
    xbmc.Player().play(lIIl)
    return True

def play_source(url, referer=None, llll=bytes.fromhex('').decode('utf-8')):
    lllI = url + kodi_headers(referer)
    IIIl = xbmcgui.ListItem(path=lllI)
    if is_hls(url):
        IIIl.setMimeType(bytes.fromhex('6170706c69636174696f6e2f766e642e6170706c652e6d70656775726c').decode('utf-8'))
        IIIl.setContentLookup(False)
    elif is_extensionless(url):
        IIIl.setMimeType(bytes.fromhex('766964656f2f6d7034').decode('utf-8'))
        IIIl.setContentLookup(False)
    if llll:
        IIIl.setSubtitles([llll + kodi_headers(referer)])
    xbmcplugin.setResolvedUrl(HANDLE, True, IIIl)

def play_source_gui(url, referer=None, llll=bytes.fromhex('').decode('utf-8'), lIII=None, source=None, lIll=0):
    lllI = url + kodi_headers(referer)
    IIIl = xbmcgui.ListItem(path=lllI)
    if is_hls(url):
        IIIl.setMimeType(bytes.fromhex('6170706c69636174696f6e2f766e642e6170706c652e6d70656775726c').decode('utf-8'))
        IIIl.setContentLookup(False)
    elif is_extensionless(url):
        IIIl.setMimeType(bytes.fromhex('766964656f2f6d7034').decode('utf-8'))
        IIIl.setContentLookup(False)
    if llll:
        IIIl.setSubtitles([llll + kodi_headers(referer)])
    if lIII:
        play_and_track(lllI, IIIl, ADDON_ID, lIII, source or {}, lIll)
    else:
        xbmc.Player().play(lllI, IIIl)

def kodi_headers(referer=None):
    headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): UA}
    if referer:
        headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
    return bytes.fromhex('7c').decode('utf-8') + bytes.fromhex('26').decode('utf-8').join((bytes.fromhex('7b307d3d7b317d').decode('utf-8').format(IIII, quote(IIIII)) for IIII, IIIII in headers.items() if IIIII))

def is_hls(url):
    return bytes.fromhex('2e6d337538').decode('utf-8') in (url or bytes.fromhex('').decode('utf-8')).split(bytes.fromhex('7c').decode('utf-8'), 1)[0].lower()

def is_extensionless(url):
    ll = (url or bytes.fromhex('').decode('utf-8')).split(bytes.fromhex('7c').decode('utf-8'), 1)[0].split(bytes.fromhex('3f').decode('utf-8'), 1)[0].rstrip(bytes.fromhex('2f').decode('utf-8'))
    return bool(ll) and bytes.fromhex('2e').decode('utf-8') not in ll.rsplit(bytes.fromhex('2f').decode('utf-8'), 1)[-1]

def run():
    IllI = dict(parse_qsl(sys.argv[2][1:]))
    action = IllI.get(bytes.fromhex('616374696f6e').decode('utf-8'))
    url = IllI.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
    page_number = int(IllI.get(bytes.fromhex('70616765').decode('utf-8'), bytes.fromhex('31').decode('utf-8')))
    if not action:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
        IIIlI = xbmcgui.Window(10000)
        try:
            llIl = float(IIIlI.getProperty(l) or bytes.fromhex('30').decode('utf-8'))
        except ValueError:
            llIl = 0
        if time.time() < llIl:
            return
        IIIlI.clearProperty(l)
        xbmc.executebuiltin(bytes.fromhex('52756e506c7567696e287b307d29').decode('utf-8').format(build_url({bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('677569').decode('utf-8')})))
        return
    elif action == bytes.fromhex('677569').decode('utf-8'):
        open_browser(FilmModuUI())
        xbmcgui.Window(10000).setProperty(l, str(time.time() + 4))
        xbmc.executebuiltin(bytes.fromhex('416374697661746557696e646f7728486f6d6529').decode('utf-8'))
        return
    elif action == bytes.fromhex('636c6173736963').decode('utf-8'):
        main_menu()
    elif action == bytes.fromhex('6d616e697475785f736b696e5f63617465676f72696573').decode('utf-8'):
        manitux_skin_categories()
    elif action == bytes.fromhex('6d616e697475785f736b696e5f6974656d73').decode('utf-8'):
        manitux_skin_items(url, page_number)
    elif action == bytes.fromhex('6d616e697475785f736b696e5f736561726368').decode('utf-8'):
        manitux_skin_search(IllI.get(bytes.fromhex('7175657279').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
    elif action == bytes.fromhex('6d616e697475785f736b696e5f6661766f7269746573').decode('utf-8'):
        manitux_skin_favorites()
    elif action == bytes.fromhex('6d616e697475785f736b696e5f636f6e74696e7565').decode('utf-8'):
        manitux_skin_continue()
    elif action == bytes.fromhex('6d616e697475785f736b696e5f70616765').decode('utf-8'):
        manitux_skin_page(url, page_number)
        return
    elif action == bytes.fromhex('6d616e697475785f736b696e5f64657461696c').decode('utf-8'):
        manitux_skin_detail(url, IllI.get(bytes.fromhex('7469746c65').decode('utf-8'), bytes.fromhex('').decode('utf-8')), IllI.get(bytes.fromhex('696d616765').decode('utf-8'), bytes.fromhex('').decode('utf-8')), IllI.get(bytes.fromhex('706c6f74').decode('utf-8'), bytes.fromhex('').decode('utf-8')), IllI.get(bytes.fromhex('6974656d5f696e646578').decode('utf-8'), bytes.fromhex('30').decode('utf-8')))
        return
    elif action == bytes.fromhex('6c697374').decode('utf-8'):
        list_page(url, page_number)
    elif action == bytes.fromhex('736561726368').decode('utf-8'):
        search()
    elif action == bytes.fromhex('64657461696c').decode('utf-8'):
        detail(url)
    elif action == bytes.fromhex('706c61795f736f75726365').decode('utf-8'):
        play_source(url, IllI.get(bytes.fromhex('72656665726572').decode('utf-8')), IllI.get(bytes.fromhex('7375627469746c65').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
    elif action == bytes.fromhex('706c61795f796f7574756265').decode('utf-8'):
        play_youtube(url)
    xbmcplugin.endOfDirectory(HANDLE)
if __name__ == bytes.fromhex('5f5f6d61696e5f5f').decode('utf-8'):
    run()
