from __future__ import absolute_import, unicode_literals
import html
import json
import re
try:
    from urllib.parse import urljoin
except ImportError:
    from urlparse import urljoin

def categories(base_url):
    base_url = base_url.rstrip(bytes.fromhex('2f').decode('utf-8'))
    return [(bytes.fromhex('344b').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f346b2d66696c6d2d697a6c653f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('41696c65').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f61696c652d66696c6d6c6572693f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('416b7369796f6e').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f616b7369796f6e3f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('416e696d6173796f6e').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f616e696d6173796f6e3f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('42656c676573656c').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f62656c676573656c6c65723f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('42696c696d2d4b75726775').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f62696c696d2d6b757267752d66696c6d6c6572693f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('4472616d').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f6472616d2d66696c6d6c6572693f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('46616e74617374696b').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f66616e74617374696b2d66696c6d6c65723f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('476572696c696d').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f676572696c696d3f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('47697a656d').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f67697a656d2d66696c6d6c6572693f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('48696e742046696c6d6c657269').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f68642d68696e742d66696c6d6c6572693f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('4bc4b173612046696c6d').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f6b6973612d66696c6d3f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('4b6f6d656469').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f68642d6b6f6d6564692d66696c6d6c6572693f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('4b6f726b75').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f6b6f726b752d66696c6d6c6572693f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('4bc3bc6c742046696c6d6c6572').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f6b756c742d66696c6d6c65722d697a6c653f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('4d6163657261').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f6d61636572612d66696c6d6c6572693f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('4dc3bc7a696b').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f6d757a696b3f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('4f7363617220c39664c3bc6c6cc3bc2046696c6d6c6572').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f6f64756c6c752d66696c6d6c65722d697a6c653f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('526f6d616e74696b').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f726f6d616e74696b2d66696c6d6c65723f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('53617661c59f').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f73617661732d66696c6d6c6572693f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('5374616e64205570').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f7374616e642d75703f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('5375c3a7').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f7375632d66696c6d6c6572693f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('5461726968').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f74617269683f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('546176736979652046696c6d6c6572').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f746176736979652d66696c6d6c65723f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('54562066696c6d').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f74762d66696c6d3f706167653d5b706167654e756d6265725d').decode('utf-8')), (bytes.fromhex('566168c59f6920426174c4b1').decode('utf-8'), base_url + bytes.fromhex('2f66696c6d2d7475722f76616873692d626174692d66696c6d6c6572693f706167653d5b706167654e756d6265725d').decode('utf-8'))]

def page_url(lIl, page_number):
    return lIl.replace(bytes.fromhex('5b706167654e756d6265725d').decode('utf-8'), str(page_number))

def parse_page_items(page, base_url, lII=bytes.fromhex('').decode('utf-8')):
    IIIl = []
    lIIl = set()
    for Ill in re.findall(bytes.fromhex('3c6469765c625b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c626d6f7669655c625b5e225c275d2a5b225c275d5b5e3e5d2a3e2e2a3f283f3d3c6469765c625b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c626d6f7669655c627c2429').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
        IlI = Il(bytes.fromhex('3c615c625b5e3e5d2a687265663d5b275c225d5b5e275c225d2b5b275c225d5b5e3e5d2a3e').decode('utf-8'), Ill, re.S)
        lll = I(IlI, bytes.fromhex('68726566').decode('utf-8'))
        title = l(IlI) or I(IlI, bytes.fromhex('7469746c65').decode('utf-8')) or I(Il(bytes.fromhex('3c696d675c625b5e3e5d2a3e').decode('utf-8'), Ill, re.S), bytes.fromhex('616c74').decode('utf-8'))
        Illl = lI(Ill, base_url)
        if not title or not lll:
            continue
        url = fix_url(lll, base_url)
        if url in lIIl:
            continue
        lIIl.add(url)
        IIIl.append({bytes.fromhex('63617465676f7279').decode('utf-8'): lII, bytes.fromhex('7469746c65').decode('utf-8'): II(title), bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('696d616765').decode('utf-8'): Illl, bytes.fromhex('706c6f74').decode('utf-8'): bytes.fromhex('').decode('utf-8')})
    return IIIl

def parse_media_info(page, url, base_url):
    title = l(Il(bytes.fromhex('3c6469765b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c627469746c65735c625b5e225c275d2a5b225c275d5b5e3e5d2a3e2e2a3f3c68315b5e3e5d2a3e282e2a3f293c2f68313e').decode('utf-8'), page, re.S))
    IIl = l(Il(bytes.fromhex('3c6469765b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c627469746c65735c625b5e225c275d2a5b225c275d5b5e3e5d2a3e2e2a3f3c68325b5e3e5d2a3e282e2a3f293c2f68323e').decode('utf-8'), page, re.S))
    Illl = fix_url(I(Il(bytes.fromhex('3c696d675c625b5e3e5d2a636c6173733d5b275c225d5b5e275c225d2a5c62696d672d726573706f6e736976655c625b5e275c225d2a5b275c225d5b5e3e5d2a3e').decode('utf-8'), page, re.S), bytes.fromhex('737263').decode('utf-8')), base_url)
    backdrop = fix_url(I(Il(bytes.fromhex('3c6469765b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c62656d6265642d726573706f6e736976655c625b5e225c275d2a5b225c275d5b5e3e5d2a3e2e2a3f3c6469765c625b5e3e5d2a706f737465723d5b225c275d5b5e225c275d2b5b225c275d5b5e3e5d2a3e').decode('utf-8'), page, re.S), bytes.fromhex('706f73746572').decode('utf-8')), base_url)
    plot = l(Il(bytes.fromhex('3c705c625b5e3e5d2a6974656d70726f703d5b275c225d6465736372697074696f6e5b275c225d5b5e3e5d2a3e282e2a3f293c2f703e').decode('utf-8'), page, re.S))
    rating = l(Il(bytes.fromhex('3c7370616e5c625b5e3e5d2a6974656d70726f703d5b275c225d726174696e6756616c75655b275c225d5b5e3e5d2a3e282e2a3f293c2f7370616e3e').decode('utf-8'), page, re.S))
    year = Il(bytes.fromhex('5c62285c647b347d295c62').decode('utf-8'), l(Il(bytes.fromhex('3c7370616e5c625b5e3e5d2a6974656d70726f703d5b275c225d64617465437265617465645b275c225d5b5e3e5d2a3e282e2a3f293c2f7370616e3e').decode('utf-8'), page, re.S)))
    III = bytes.fromhex('2c20').decode('utf-8').join(dict.fromkeys((l(IIIll) for IIIll in re.findall(bytes.fromhex('3c615c625b5e3e5d2a6974656d70726f703d5b275c225d6163746f725b275c225d5b5e3e5d2a3e2e2a3f3c7370616e5b5e3e5d2a3e282e2a3f293c2f7370616e3e').decode('utf-8'), page, re.S) if l(IIIll))))
    tags = bytes.fromhex('2c20').decode('utf-8').join(dict.fromkeys((l(IIIll) for IIIll in re.findall(bytes.fromhex('3c615c625b5e3e5d2a687265663d5b275c225d5b5e275c225d2a66696c6d2d7475722f5b5e275c225d2a5b275c225d5b5e3e5d2a3e282e2a3f293c2f613e').decode('utf-8'), page, re.S) if l(IIIll))))
    llll = ll(page)
    lIlI = []
    for llIl in re.findall(bytes.fromhex('3c6469765c625b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c62616c7465726e617465735c625b5e225c275d2a5b225c275d5b5e3e5d2a3e2e2a3f3c2f6469763e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
        for IIlI in re.findall(bytes.fromhex('3c615c625b5e3e5d2a687265663d5b225c275d5b5e225c275d2b5b225c275d5b5e3e5d2a3e2e2a3f3c2f613e').decode('utf-8'), llIl, re.S | re.I):
            lll = I(IIlI, bytes.fromhex('68726566').decode('utf-8'))
            label = l(IIlI) or bytes.fromhex('506c6179').decode('utf-8')
            if lll and bytes.fromhex('667261676d616e').decode('utf-8') not in label.lower():
                lIlI.append({bytes.fromhex('6c6162656c').decode('utf-8'): label, bytes.fromhex('75726c').decode('utf-8'): fix_url(lll, base_url)})
    sources = []
    if llll:
        sources.append({bytes.fromhex('6c6162656c').decode('utf-8'): bytes.fromhex('467261676d616e').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): llll, bytes.fromhex('72656665726572').decode('utf-8'): url, bytes.fromhex('69735f747261696c6572').decode('utf-8'): True})
    return {bytes.fromhex('7469746c65').decode('utf-8'): title or IIl, bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('696d616765').decode('utf-8'): Illl, bytes.fromhex('6261636b64726f70').decode('utf-8'): backdrop or Illl, bytes.fromhex('706c6f74').decode('utf-8'): plot, bytes.fromhex('726174696e67').decode('utf-8'): rating, bytes.fromhex('79656172').decode('utf-8'): year, bytes.fromhex('6163746f7273').decode('utf-8'): III, bytes.fromhex('74616773').decode('utf-8'): tags, bytes.fromhex('736f7572636573').decode('utf-8'): sources, bytes.fromhex('736f757263655f7061676573').decode('utf-8'): lIlI}

def parse_video_config(page):
    IIIIl = Il(bytes.fromhex('7661725c732b766964656f49645c732a3d5c732a5b275c225d285b5e275c225d2a29').decode('utf-8'), page)
    IIIlI = Il(bytes.fromhex('7661725c732b766964656f547970655c732a3d5c732a5b275c225d285b5e275c225d2a29').decode('utf-8'), page)
    return (IIIIl, IIIlI)

def parse_source_response(IllI, label, base_url, referer=None):
    try:
        llI = json.loads(IllI)
    except Exception:
        llI = {}
    llII = fix_url(llI.get(bytes.fromhex('7375627469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8'), base_url)
    sources = []
    for item in llI.get(bytes.fromhex('736f7572636573').decode('utf-8'), []) if isinstance(llI, dict) else []:
        lIll = item.get(bytes.fromhex('737263').decode('utf-8')) or item.get(bytes.fromhex('66696c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        lIII = item.get(bytes.fromhex('6c6162656c').decode('utf-8')) or item.get(bytes.fromhex('7175616c697479').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        if not lIll:
            continue
        IlII = bytes.fromhex('207c20').decode('utf-8').join((IIIll for IIIll in (label, lIII) if IIIll))
        sources.append({bytes.fromhex('6c6162656c').decode('utf-8'): IlII or label, bytes.fromhex('75726c').decode('utf-8'): fix_url(lIll, base_url), bytes.fromhex('72656665726572').decode('utf-8'): referer or base_url, bytes.fromhex('7375627469746c65').decode('utf-8'): llII, bytes.fromhex('69735f747261696c6572').decode('utf-8'): False})
    return sources

def fix_url(url, base_url):
    if not url:
        return bytes.fromhex('').decode('utf-8')
    IIIII = urljoin(base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8'), html.unescape(url).strip())
    return IIIII.replace(bytes.fromhex('68747470733a2f2f7777772e66696c6d6d6f64752e6f6e65').decode('utf-8'), base_url.rstrip(bytes.fromhex('2f').decode('utf-8'))).replace(bytes.fromhex('687474703a2f2f7777772e66696c6d6d6f64752e6f6e65').decode('utf-8'), base_url.rstrip(bytes.fromhex('2f').decode('utf-8')))

def lI(Ill, base_url):
    IIII = Il(bytes.fromhex('3c706963747572655c625b5e3e5d2a3e2e2a3f3c696d675c625b5e3e5d2a3e').decode('utf-8'), Ill or bytes.fromhex('').decode('utf-8'), re.S) or Il(bytes.fromhex('3c696d675c625b5e3e5d2a3e').decode('utf-8'), Ill or bytes.fromhex('').decode('utf-8'), re.S)
    Illl = I(IIII, bytes.fromhex('646174612d737263').decode('utf-8')) or I(IIII, bytes.fromhex('737263').decode('utf-8'))
    if Illl and (not Illl.lower().startswith(bytes.fromhex('646174613a696d616765').decode('utf-8'))):
        return fix_url(Illl, base_url)
    return bytes.fromhex('').decode('utf-8')

def ll(page):
    for IlIl in (bytes.fromhex('283f3a796f75747562655c2e636f6d2f656d6265642f7c796f75747562655c2e636f6d2f77617463685c3f763d7c796f7574755c2e62652f29285b412d5a612d7a302d395f2d5d7b362c7d29').decode('utf-8'), bytes.fromhex('646174612d747261696c65723d5b275c225d285b412d5a612d7a302d395f2d5d7b362c7d29').decode('utf-8')):
        IIll = re.search(IlIl, page or bytes.fromhex('').decode('utf-8'), re.I)
        if IIll:
            return bytes.fromhex('68747470733a2f2f796f75747562652e636f6d2f656d6265642f').decode('utf-8') + IIll.group(1)
    return bytes.fromhex('').decode('utf-8')

def II(IIIII):
    return re.sub(bytes.fromhex('5c732b697a6c655c732a24').decode('utf-8'), bytes.fromhex('').decode('utf-8'), l(IIIII), flags=re.I).strip()

def I(llIl, IlII):
    if not llIl:
        return bytes.fromhex('').decode('utf-8')
    IIll = re.search(bytes.fromhex('5c627b307d3d5b225c275d285b5e225c275d2b295b225c275d').decode('utf-8').format(re.escape(IlII)), llIl, re.I)
    return html.unescape(IIll.group(1)) if IIll else bytes.fromhex('').decode('utf-8')

def Il(IlIl, lllI, flags=0):
    IIll = re.search(IlIl, lllI or bytes.fromhex('').decode('utf-8'), flags | re.I)
    if not IIll:
        return bytes.fromhex('').decode('utf-8')
    return IIll.group(1) if IIll.lastindex else IIll.group(0)

def l(lllI):
    lllI = re.sub(bytes.fromhex('3c7376672e2a3f3c2f7376673e').decode('utf-8'), bytes.fromhex('20').decode('utf-8'), lllI or bytes.fromhex('').decode('utf-8'), flags=re.S | re.I)
    lllI = re.sub(bytes.fromhex('3c5b5e3e5d2b3e').decode('utf-8'), bytes.fromhex('20').decode('utf-8'), lllI)
    lllI = html.unescape(lllI)
    return re.sub(bytes.fromhex('5c732b').decode('utf-8'), bytes.fromhex('20').decode('utf-8'), lllI).strip()
