from __future__ import absolute_import, unicode_literals
import manituxhttp
try:
    from urllib.parse import quote_plus
except ImportError:
    from urllib import quote_plus
from . import parsers

class FilmModuSite(object):
    CLIENT_IDENTIFIERS = (bytes.fromhex('636c6f756473637261706572').decode('utf-8'), bytes.fromhex('6368726f6d655f313434').decode('utf-8'))

    def __init__(IIl, base_url, user_agent):
        IIl.base_url = base_url.rstrip(bytes.fromhex('2f').decode('utf-8'))
        IIl.user_agent = user_agent
        IIl.session = manituxhttp.Session(client_identifier=IIl.CLIENT_IDENTIFIERS[0])

    def headers(IIl, referer=None):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): IIl.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('746578742f68746d6c2c6170706c69636174696f6e2f7868746d6c2b786d6c2c6170706c69636174696f6e2f786d6c3b713d302e392c2a2f2a3b713d302e38').decode('utf-8'), bytes.fromhex('557067726164652d496e7365637572652d5265717565737473').decode('utf-8'): bytes.fromhex('31').decode('utf-8')}
        if referer:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        return headers

    def categories(IIl):
        return parsers.categories(IIl.base_url)

    def get_page_items(IIl, l, page_number=1, title=bytes.fromhex('').decode('utf-8')):
        page = IIl.get(parsers.page_url(l, page_number), referer=l)
        return parsers.parse_page_items(page, IIl.base_url, title)

    def search(IIl, query):
        page = IIl.get(IIl.base_url + bytes.fromhex('2f3f733d').decode('utf-8') + quote_plus(query), referer=IIl.base_url + bytes.fromhex('2f').decode('utf-8'))
        return parsers.parse_page_items(page, IIl.base_url, bytes.fromhex('4172616d61').decode('utf-8'))

    def get(IIl, url, referer=None):
        return IIl._get(IIl.absolute(url), IIl.headers(referer)).text

    def parse_detail(IIl, page, url):
        Il = parsers.parse_media_info(page, url, IIl.base_url)
        Il[bytes.fromhex('736f7572636573').decode('utf-8')] = Il.get(bytes.fromhex('736f7572636573').decode('utf-8'), []) + IIl.resolve_sources(Il.get(bytes.fromhex('736f757263655f7061676573').decode('utf-8'), []), url)
        return Il

    def resolve_sources(IIl, IlI, referer):
        sources = []
        for item in IlI:
            I = IIl.get(item[bytes.fromhex('75726c').decode('utf-8')], referer=referer)
            Ill, lII = parsers.parse_video_config(I)
            if not Ill or not lII:
                continue
            ll = IIl.get(IIl.base_url + bytes.fromhex('2f6765742d736f757263653f6d6f7669655f69643d7b307d26747970653d7b317d').decode('utf-8').format(Ill, lII), referer=item[bytes.fromhex('75726c').decode('utf-8')])
            sources.extend(parsers.parse_source_response(ll, item[bytes.fromhex('6c6162656c').decode('utf-8')], IIl.base_url, item[bytes.fromhex('75726c').decode('utf-8')]))
        return sources

    def absolute(IIl, url):
        return parsers.fix_url(url, IIl.base_url)

    def _get(IIl, url, headers):
        lI = None
        for II in IIl.CLIENT_IDENTIFIERS:
            if IIl.session.client_identifier != II:
                IIl.session = manituxhttp.Session(client_identifier=II)
            try:
                III = IIl.session.get(url, headers=headers, timeout=25, allow_redirects=True, tls_client_identifier=II)
                if III.status_code in (403, 429) and II != IIl.CLIENT_IDENTIFIERS[-1]:
                    lI = manituxhttp.HTTPError(III)
                    continue
                III.raise_for_status()
                return III
            except (manituxhttp.HTTPError, manituxhttp.RequestError) as exc:
                lI = exc
                if II == IIl.CLIENT_IDENTIFIERS[-1]:
                    raise
        raise lI
