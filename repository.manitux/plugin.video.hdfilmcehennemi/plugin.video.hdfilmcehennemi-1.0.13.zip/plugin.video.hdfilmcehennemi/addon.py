from __future__ import absolute_import, unicode_literals
import re
import sys
import time
import os
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
try:
    from urllib.parse import parse_qsl, quote, urlencode
except ImportError:
    from urlparse import parse_qsl
    from urllib import quote, urlencode
from resources.lib.extractor import VideoExtractor
from resources.lib.site import HDFilmCehennemiSite
MANITUXUI_LIB = os.path.join(xbmcaddon.Addon(id=bytes.fromhex('7363726970742e6d6f64756c652e6d616e697475787569').decode('utf-8')).getAddonInfo(bytes.fromhex('70617468').decode('utf-8')), bytes.fromhex('6c6962').decode('utf-8'))
if MANITUXUI_LIB not in sys.path:
    sys.path.insert(0, MANITUXUI_LIB)
from manituxui import ManituxUI, open_browser
ADDON_ID = bytes.fromhex('706c7567696e2e766964656f2e686466696c6d636568656e6e656d69').decode('utf-8')
SKIP_GUI_UNTIL = ADDON_ID + bytes.fromhex('2e736b69705f6775695f756e74696c').decode('utf-8')
ADDON = xbmcaddon.Addon(id=ADDON_ID)
HANDLE = int(sys.argv[1])
BASE_URL = ADDON.getSetting(bytes.fromhex('626173655f75726c').decode('utf-8')) or bytes.fromhex('68747470733a2f2f7777772e686466696c6d636568656e6e656d692e6e6c').decode('utf-8')
UA = ADDON.getSetting(bytes.fromhex('757365725f6167656e74').decode('utf-8')) or bytes.fromhex('4d6f7a696c6c612f352e3020285831313b204c696e7578207838365f363429204170706c655765624b69742f3533372e333620284b48544d4c2c206c696b65204765636b6f29204368726f6d652f3132342e30205361666172692f3533372e3336').decode('utf-8')
XFOCTvjrZjbEqeVqNrxDWNJICNjyDUccgiREIcPBUjDOUcRHTBudgJiawTLpQfecYsCTjaNDgtiUyTC13 = HDFilmCehennemiSite(BASE_URL, UA)
gg = VideoExtractor(UA)

class HDFilmCehennemiUI(ManituxUI):
    title = bytes.fromhex('484446696c6d436568656e6e656d69').decode('utf-8')

    def categories(self):
        categories = [{bytes.fromhex('7469746c65').decode('utf-8'): bytes.fromhex('417261').decode('utf-8'), bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('736561726368').decode('utf-8')}]
        for title, url in XFOCTvjrZjbEqeVqNrxDWNJICNjyDUccgiREIcPBUjDOUcRHTBudgJiawTLpQfecYsCTjaNDgtiUyTC13.categories():
            categories.append({bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url})
        return categories

    def videos(self, category, page=1):
        if category.get(bytes.fromhex('616374696f6e').decode('utf-8')) == bytes.fromhex('736561726368').decode('utf-8'):
            query = xbmcgui.Dialog().input(bytes.fromhex('484446696c6d436568656e6e656d6920417261').decode('utf-8'))
            return [self._art_item(item) for item in XFOCTvjrZjbEqeVqNrxDWNJICNjyDUccgiREIcPBUjDOUcRHTBudgJiawTLpQfecYsCTjaNDgtiUyTC13.search(query)] if query else []
        return [self._art_item(item) for item in XFOCTvjrZjbEqeVqNrxDWNJICNjyDUccgiREIcPBUjDOUcRHTBudgJiawTLpQfecYsCTjaNDgtiUyTC13.get_page_items(category[bytes.fromhex('75726c').decode('utf-8')], page)]

    def _art_item(self, item):
        J = dict(item)
        J[bytes.fromhex('696d616765').decode('utf-8')] = art_url(J.get(bytes.fromhex('696d616765').decode('utf-8'), bytes.fromhex('').decode('utf-8')), J.get(bytes.fromhex('75726c').decode('utf-8')) or BASE_URL + bytes.fromhex('2f').decode('utf-8'))
        return J

    def detail(self, video):
        page_url = video[bytes.fromhex('75726c').decode('utf-8')]
        page = XFOCTvjrZjbEqeVqNrxDWNJICNjyDUccgiREIcPBUjDOUcRHTBudgJiawTLpQfecYsCTjaNDgtiUyTC13.get(page_url)
        w11455973797235 = XFOCTvjrZjbEqeVqNrxDWNJICNjyDUccgiREIcPBUjDOUcRHTBudgJiawTLpQfecYsCTjaNDgtiUyTC13.parse_detail(page, page_url)
        image = art_url(w11455973797235.get(bytes.fromhex('696d616765').decode('utf-8')) or video.get(bytes.fromhex('696d616765').decode('utf-8'), bytes.fromhex('').decode('utf-8')), page_url)
        plot = w11455973797235.get(bytes.fromhex('706c6f74').decode('utf-8')) or video.get(bytes.fromhex('706c6f74').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
        sources = []
        for source in w11455973797235.get(bytes.fromhex('736f7572636573').decode('utf-8'), []):
            sources.append({bytes.fromhex('6c6162656c').decode('utf-8'): source.get(bytes.fromhex('6c6162656c').decode('utf-8')) or bytes.fromhex('4f796e6174').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): source.get(bytes.fromhex('75726c').decode('utf-8')) if source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8')) else page_url, bytes.fromhex('766964656f5f6964').decode('utf-8'): source.get(bytes.fromhex('766964656f5f6964').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('69735f747261696c6572').decode('utf-8'): source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8'), False), bytes.fromhex('72656665726572').decode('utf-8'): page_url})
        return {bytes.fromhex('7469746c65').decode('utf-8'): w11455973797235.get(bytes.fromhex('7469746c65').decode('utf-8')) or video.get(bytes.fromhex('7469746c65').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('75726c').decode('utf-8'): page_url, bytes.fromhex('696d616765').decode('utf-8'): image, bytes.fromhex('6261636b64726f70').decode('utf-8'): w11455973797235.get(bytes.fromhex('6261636b64726f70').decode('utf-8')) or w11455973797235.get(bytes.fromhex('66616e617274').decode('utf-8')) or image, bytes.fromhex('706c6f74').decode('utf-8'): plot, bytes.fromhex('79656172').decode('utf-8'): w11455973797235.get(bytes.fromhex('79656172').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('636f756e747279').decode('utf-8'): w11455973797235.get(bytes.fromhex('636f756e747279').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('6475726174696f6e').decode('utf-8'): w11455973797235.get(bytes.fromhex('6475726174696f6e').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('726174696e67').decode('utf-8'): w11455973797235.get(bytes.fromhex('726174696e67').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('74616773').decode('utf-8'): w11455973797235.get(bytes.fromhex('74616773').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('6163746f7273').decode('utf-8'): w11455973797235.get(bytes.fromhex('6163746f7273').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('657069736f646573').decode('utf-8'): [self._art_episode(episode, image, page_url) for episode in w11455973797235.get(bytes.fromhex('657069736f646573').decode('utf-8'), [])], bytes.fromhex('736f7572636573').decode('utf-8'): sources}

    def _art_episode(self, episode, fallback_image, referer):
        J = dict(episode)
        J[bytes.fromhex('696d616765').decode('utf-8')] = art_url(J.get(bytes.fromhex('696d616765').decode('utf-8')) or fallback_image, J.get(bytes.fromhex('75726c').decode('utf-8')) or referer)
        return J

    def play(self, source, video=None):
        if source.get(bytes.fromhex('69735f657069736f6465').decode('utf-8')):
            self._play_episode(source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
        elif source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8')):
            play_iframe_gui(source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), source.get(bytes.fromhex('72656665726572').decode('utf-8')))
        else:
            play_source_gui(source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), source.get(bytes.fromhex('766964656f5f6964').decode('utf-8'), bytes.fromhex('').decode('utf-8')))

    def _play_episode(self, episode_url):
        page = XFOCTvjrZjbEqeVqNrxDWNJICNjyDUccgiREIcPBUjDOUcRHTBudgJiawTLpQfecYsCTjaNDgtiUyTC13.get(episode_url)
        w11455973797235 = XFOCTvjrZjbEqeVqNrxDWNJICNjyDUccgiREIcPBUjDOUcRHTBudgJiawTLpQfecYsCTjaNDgtiUyTC13.parse_detail(page, episode_url)
        sources = w11455973797235.get(bytes.fromhex('736f7572636573').decode('utf-8'), [])
        if not sources:
            xbmcgui.Dialog().notification(bytes.fromhex('484446696c6d436568656e6e656d69').decode('utf-8'), bytes.fromhex('566964656f206b61796e6167692062756c756e616d616469').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
            return
        source = sources[0]
        if len(sources) > 1:
            aAAAAAa = [item.get(bytes.fromhex('6c6162656c').decode('utf-8')) or bytes.fromhex('4b61796e616b207b307d').decode('utf-8').format(tttt + 1) for tttt, item in enumerate(sources)]
            M187919552809712 = xbmcgui.Dialog().select(bytes.fromhex('4b61796e616b20536563').decode('utf-8'), aAAAAAa)
            if M187919552809712 < 0:
                return
            source = sources[M187919552809712]
        if source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8')):
            play_iframe_gui(source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), episode_url)
        else:
            play_source_gui(episode_url, source.get(bytes.fromhex('766964656f5f6964').decode('utf-8'), bytes.fromhex('').decode('utf-8')))

def build_url(query):
    return sys.argv[0] + bytes.fromhex('3f').decode('utf-8') + urlencode(query)

def art_url(url, referer=None):
    if not url or bytes.fromhex('7c').decode('utf-8') in url or (not url.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8')))):
        return url
    return url + bytes.fromhex('7c557365722d4167656e743d').decode('utf-8') + quote(UA) + bytes.fromhex('26526566657265723d').decode('utf-8') + quote(referer or BASE_URL + bytes.fromhex('2f').decode('utf-8'))

def add_directory(title, action, url=bytes.fromhex('').decode('utf-8'), image=bytes.fromhex('').decode('utf-8'), plot=bytes.fromhex('').decode('utf-8')):
    hfMvmUbpllCGGCcwvKFikyHugctSjhZXEnZbVkYeTIJCOJkmZyfTUoxCYlTcgDKLwWYwQqdlOPWOJVZ8 = xbmcgui.ListItem(label=title)
    image = art_url(image, url or BASE_URL + bytes.fromhex('2f').decode('utf-8'))
    hfMvmUbpllCGGCcwvKFikyHugctSjhZXEnZbVkYeTIJCOJkmZyfTUoxCYlTcgDKLwWYwQqdlOPWOJVZ8.setArt({bytes.fromhex('7468756d62').decode('utf-8'): image, bytes.fromhex('69636f6e').decode('utf-8'): image, bytes.fromhex('706f73746572').decode('utf-8'): image, bytes.fromhex('66616e617274').decode('utf-8'): image})
    hfMvmUbpllCGGCcwvKFikyHugctSjhZXEnZbVkYeTIJCOJkmZyfTUoxCYlTcgDKLwWYwQqdlOPWOJVZ8.setInfo(bytes.fromhex('766964656f').decode('utf-8'), {bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('706c6f74').decode('utf-8'): plot})
    xbmcplugin.addDirectoryItem(HANDLE, build_url({bytes.fromhex('616374696f6e').decode('utf-8'): action, bytes.fromhex('75726c').decode('utf-8'): url}), hfMvmUbpllCGGCcwvKFikyHugctSjhZXEnZbVkYeTIJCOJkmZyfTUoxCYlTcgDKLwWYwQqdlOPWOJVZ8, True)

def add_video(title, action, url, image=bytes.fromhex('').decode('utf-8'), plot=bytes.fromhex('').decode('utf-8'), extra=None):
    query = {bytes.fromhex('616374696f6e').decode('utf-8'): action, bytes.fromhex('75726c').decode('utf-8'): url}
    if extra:
        query.update(extra)
    hfMvmUbpllCGGCcwvKFikyHugctSjhZXEnZbVkYeTIJCOJkmZyfTUoxCYlTcgDKLwWYwQqdlOPWOJVZ8 = xbmcgui.ListItem(label=title)
    image = art_url(image, extra.get(bytes.fromhex('72656665726572').decode('utf-8')) if extra else url or BASE_URL + bytes.fromhex('2f').decode('utf-8'))
    hfMvmUbpllCGGCcwvKFikyHugctSjhZXEnZbVkYeTIJCOJkmZyfTUoxCYlTcgDKLwWYwQqdlOPWOJVZ8.setArt({bytes.fromhex('7468756d62').decode('utf-8'): image, bytes.fromhex('69636f6e').decode('utf-8'): image, bytes.fromhex('706f73746572').decode('utf-8'): image, bytes.fromhex('66616e617274').decode('utf-8'): image})
    hfMvmUbpllCGGCcwvKFikyHugctSjhZXEnZbVkYeTIJCOJkmZyfTUoxCYlTcgDKLwWYwQqdlOPWOJVZ8.setInfo(bytes.fromhex('766964656f').decode('utf-8'), {bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('706c6f74').decode('utf-8'): plot})
    hfMvmUbpllCGGCcwvKFikyHugctSjhZXEnZbVkYeTIJCOJkmZyfTUoxCYlTcgDKLwWYwQqdlOPWOJVZ8.setProperty(bytes.fromhex('4973506c617961626c65').decode('utf-8'), bytes.fromhex('74727565').decode('utf-8'))
    xbmcplugin.addDirectoryItem(HANDLE, build_url(query), hfMvmUbpllCGGCcwvKFikyHugctSjhZXEnZbVkYeTIJCOJkmZyfTUoxCYlTcgDKLwWYwQqdlOPWOJVZ8, False)

def main_menu():
    add_directory(bytes.fromhex('417261').decode('utf-8'), bytes.fromhex('736561726368').decode('utf-8'))
    for title, url in XFOCTvjrZjbEqeVqNrxDWNJICNjyDUccgiREIcPBUjDOUcRHTBudgJiawTLpQfecYsCTjaNDgtiUyTC13.categories():
        add_directory(title, bytes.fromhex('6c697374').decode('utf-8'), url)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('766964656f73').decode('utf-8'))

def list_page(url, page_number=1):
    u14946387371036 = XFOCTvjrZjbEqeVqNrxDWNJICNjyDUccgiREIcPBUjDOUcRHTBudgJiawTLpQfecYsCTjaNDgtiUyTC13.get_page_items(url, page_number)
    for item in u14946387371036:
        add_directory(item[bytes.fromhex('7469746c65').decode('utf-8')], bytes.fromhex('64657461696c').decode('utf-8'), item[bytes.fromhex('75726c').decode('utf-8')], item[bytes.fromhex('696d616765').decode('utf-8')], item[bytes.fromhex('706c6f74').decode('utf-8')])
    if u14946387371036:
        hfMvmUbpllCGGCcwvKFikyHugctSjhZXEnZbVkYeTIJCOJkmZyfTUoxCYlTcgDKLwWYwQqdlOPWOJVZ8 = xbmcgui.ListItem(label=bytes.fromhex('536f6e72616b69205361796661').decode('utf-8'))
        xbmcplugin.addDirectoryItem(HANDLE, build_url({bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('6c697374').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('70616765').decode('utf-8'): str(int(page_number) + 1)}), hfMvmUbpllCGGCcwvKFikyHugctSjhZXEnZbVkYeTIJCOJkmZyfTUoxCYlTcgDKLwWYwQqdlOPWOJVZ8, True)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('6d6f76696573').decode('utf-8'))

def search():
    query = xbmcgui.Dialog().input(bytes.fromhex('484446696c6d436568656e6e656d6920417261').decode('utf-8'))
    if query:
        for item in XFOCTvjrZjbEqeVqNrxDWNJICNjyDUccgiREIcPBUjDOUcRHTBudgJiawTLpQfecYsCTjaNDgtiUyTC13.search(query):
            add_directory(item[bytes.fromhex('7469746c65').decode('utf-8')], bytes.fromhex('64657461696c').decode('utf-8'), item[bytes.fromhex('75726c').decode('utf-8')], item[bytes.fromhex('696d616765').decode('utf-8')], item.get(bytes.fromhex('706c6f74').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
        xbmcplugin.setContent(HANDLE, bytes.fromhex('6d6f76696573').decode('utf-8'))

def detail(url):
    page = XFOCTvjrZjbEqeVqNrxDWNJICNjyDUccgiREIcPBUjDOUcRHTBudgJiawTLpQfecYsCTjaNDgtiUyTC13.get(url)
    w11455973797235 = XFOCTvjrZjbEqeVqNrxDWNJICNjyDUccgiREIcPBUjDOUcRHTBudgJiawTLpQfecYsCTjaNDgtiUyTC13.parse_detail(page, url)
    if w11455973797235[bytes.fromhex('736f7572636573').decode('utf-8')]:
        for source in w11455973797235[bytes.fromhex('736f7572636573').decode('utf-8')]:
            add_video(source[bytes.fromhex('6c6162656c').decode('utf-8')], bytes.fromhex('706c61795f696672616d65').decode('utf-8') if source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8')) else bytes.fromhex('706c61795f736f75726365').decode('utf-8'), source[bytes.fromhex('75726c').decode('utf-8')] if source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8')) else url, w11455973797235[bytes.fromhex('696d616765').decode('utf-8')], w11455973797235[bytes.fromhex('706c6f74').decode('utf-8')], {bytes.fromhex('766964656f5f6964').decode('utf-8'): source.get(bytes.fromhex('766964656f5f6964').decode('utf-8'), bytes.fromhex('').decode('utf-8'))})
    if not is_episode_url(url):
        for episode in w11455973797235.get(bytes.fromhex('657069736f646573').decode('utf-8'), []):
            add_directory(episode[bytes.fromhex('7469746c65').decode('utf-8')], bytes.fromhex('64657461696c').decode('utf-8'), episode[bytes.fromhex('75726c').decode('utf-8')], w11455973797235[bytes.fromhex('696d616765').decode('utf-8')], w11455973797235[bytes.fromhex('706c6f74').decode('utf-8')])
    if not w11455973797235[bytes.fromhex('736f7572636573').decode('utf-8')] and is_episode_url(url):
        for episode in w11455973797235.get(bytes.fromhex('657069736f646573').decode('utf-8'), []):
            add_directory(episode[bytes.fromhex('7469746c65').decode('utf-8')], bytes.fromhex('64657461696c').decode('utf-8'), episode[bytes.fromhex('75726c').decode('utf-8')], w11455973797235[bytes.fromhex('696d616765').decode('utf-8')], w11455973797235[bytes.fromhex('706c6f74').decode('utf-8')])
    if not w11455973797235[bytes.fromhex('736f7572636573').decode('utf-8')] and (not w11455973797235.get(bytes.fromhex('657069736f646573').decode('utf-8'))):
        xbmcgui.Dialog().notification(bytes.fromhex('484446696c6d436568656e6e656d69').decode('utf-8'), bytes.fromhex('566964656f206b61796e6167692062756c756e616d616469').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)

def is_episode_url(url):
    return bytes.fromhex('2f73657a6f6e2d').decode('utf-8') in (url or bytes.fromhex('').decode('utf-8')).lower() and bytes.fromhex('2f626f6c756d2d').decode('utf-8') in (url or bytes.fromhex('').decode('utf-8')).lower()

def youtube_plugin_url(url):
    video_id = bytes.fromhex('').decode('utf-8')
    for P535596938189310 in (bytes.fromhex('283f3a796f75747562655c2e636f6d2f656d6265642f7c796f75747562655c2e636f6d2f77617463685c3f763d7c796f7574755c2e62652f29285b412d5a612d7a302d395f2d5d7b362c7d29').decode('utf-8'), bytes.fromhex('5b3f265d763d285b412d5a612d7a302d395f2d5d7b362c7d29').decode('utf-8')):
        YYYYYYYYY = re.search(P535596938189310, url or bytes.fromhex('').decode('utf-8'), re.I)
        if YYYYYYYYY:
            video_id = YYYYYYYYY.group(1)
            break
    return bytes.fromhex('706c7567696e3a2f2f706c7567696e2e766964656f2e796f75747562652f706c61792f3f766964656f5f69643d').decode('utf-8') + video_id if video_id else bytes.fromhex('').decode('utf-8')

def play_youtube(url):
    X11 = youtube_plugin_url(url)
    if not X11:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    try:
        xbmcaddon.Addon(id=bytes.fromhex('706c7567696e2e766964656f2e796f7574756265').decode('utf-8'))
    except Exception:
        xbmcgui.Dialog().notification(bytes.fromhex('596f7554756265').decode('utf-8'), bytes.fromhex('706c7567696e2e766964656f2e796f757475626520676572656b6c69').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=X11))

def play_iframe(url, referer=None):
    if youtube_plugin_url(url):
        play_youtube(url)
        return
    stream, subtitles = gg.resolve(url, referer)
    if not stream:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    hfMvmUbpllCGGCcwvKFikyHugctSjhZXEnZbVkYeTIJCOJkmZyfTUoxCYlTcgDKLwWYwQqdlOPWOJVZ8 = xbmcgui.ListItem(path=stream)
    if subtitles:
        hfMvmUbpllCGGCcwvKFikyHugctSjhZXEnZbVkYeTIJCOJkmZyfTUoxCYlTcgDKLwWYwQqdlOPWOJVZ8.setSubtitles(subtitles)
    xbmcplugin.setResolvedUrl(HANDLE, True, hfMvmUbpllCGGCcwvKFikyHugctSjhZXEnZbVkYeTIJCOJkmZyfTUoxCYlTcgDKLwWYwQqdlOPWOJVZ8)

def play_youtube_gui(url):
    X11 = youtube_plugin_url(url)
    if not X11:
        return False
    try:
        xbmcaddon.Addon(id=bytes.fromhex('706c7567696e2e766964656f2e796f7574756265').decode('utf-8'))
    except Exception:
        xbmcgui.Dialog().notification(bytes.fromhex('596f7554756265').decode('utf-8'), bytes.fromhex('706c7567696e2e766964656f2e796f757475626520676572656b6c69').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
        return False
    xbmc.Player().play(X11)
    return True

def play_iframe_gui(url, referer=None):
    if youtube_plugin_url(url):
        play_youtube_gui(url)
        return
    stream, subtitles = gg.resolve(url, referer)
    play_stream_gui(stream, subtitles)

def play_source_gui(page_url, video_id):
    try:
        IlI = XFOCTvjrZjbEqeVqNrxDWNJICNjyDUccgiREIcPBUjDOUcRHTBudgJiawTLpQfecYsCTjaNDgtiUyTC13.fetch_source_iframe(video_id, page_url)
    except Exception:
        page = XFOCTvjrZjbEqeVqNrxDWNJICNjyDUccgiREIcPBUjDOUcRHTBudgJiawTLpQfecYsCTjaNDgtiUyTC13.get(page_url)
        IlI = XFOCTvjrZjbEqeVqNrxDWNJICNjyDUccgiREIcPBUjDOUcRHTBudgJiawTLpQfecYsCTjaNDgtiUyTC13.parse_detail(page, page_url).get(bytes.fromhex('696672616d65').decode('utf-8'))
    play_iframe_gui(IlI, page_url)

def play_stream_gui(stream, subtitles=None):
    if not stream:
        xbmcgui.Dialog().notification(bytes.fromhex('484446696c6d436568656e6e656d69').decode('utf-8'), bytes.fromhex('4b61796e616b20c3a7c3b67ac3bc6c6d656469').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    hfMvmUbpllCGGCcwvKFikyHugctSjhZXEnZbVkYeTIJCOJkmZyfTUoxCYlTcgDKLwWYwQqdlOPWOJVZ8 = xbmcgui.ListItem(path=stream)
    if bytes.fromhex('2e6d337538').decode('utf-8') in (stream or bytes.fromhex('').decode('utf-8')).split(bytes.fromhex('7c').decode('utf-8'), 1)[0].lower():
        hfMvmUbpllCGGCcwvKFikyHugctSjhZXEnZbVkYeTIJCOJkmZyfTUoxCYlTcgDKLwWYwQqdlOPWOJVZ8.setMimeType(bytes.fromhex('6170706c69636174696f6e2f766e642e6170706c652e6d70656775726c').decode('utf-8'))
        hfMvmUbpllCGGCcwvKFikyHugctSjhZXEnZbVkYeTIJCOJkmZyfTUoxCYlTcgDKLwWYwQqdlOPWOJVZ8.setContentLookup(False)
    if subtitles:
        hfMvmUbpllCGGCcwvKFikyHugctSjhZXEnZbVkYeTIJCOJkmZyfTUoxCYlTcgDKLwWYwQqdlOPWOJVZ8.setSubtitles(subtitles)
    xbmc.Player().play(stream, hfMvmUbpllCGGCcwvKFikyHugctSjhZXEnZbVkYeTIJCOJkmZyfTUoxCYlTcgDKLwWYwQqdlOPWOJVZ8)

def play_source(page_url, video_id):
    try:
        IlI = XFOCTvjrZjbEqeVqNrxDWNJICNjyDUccgiREIcPBUjDOUcRHTBudgJiawTLpQfecYsCTjaNDgtiUyTC13.fetch_source_iframe(video_id, page_url)
    except Exception:
        page = XFOCTvjrZjbEqeVqNrxDWNJICNjyDUccgiREIcPBUjDOUcRHTBudgJiawTLpQfecYsCTjaNDgtiUyTC13.get(page_url)
        IlI = XFOCTvjrZjbEqeVqNrxDWNJICNjyDUccgiREIcPBUjDOUcRHTBudgJiawTLpQfecYsCTjaNDgtiUyTC13.parse_detail(page, page_url).get(bytes.fromhex('696672616d65').decode('utf-8'))
    play_iframe(IlI, page_url)

def run():
    params = dict(parse_qsl(sys.argv[2][1:]))
    action = params.get(bytes.fromhex('616374696f6e').decode('utf-8'))
    url = params.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
    page_number = int(params.get(bytes.fromhex('70616765').decode('utf-8'), bytes.fromhex('31').decode('utf-8')))
    if not action:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
        F329566654669315 = xbmcgui.Window(10000)
        try:
            llIIIllIllIlIl = float(F329566654669315.getProperty(SKIP_GUI_UNTIL) or bytes.fromhex('30').decode('utf-8'))
        except ValueError:
            llIIIllIllIlIl = 0
        if time.time() < llIIIllIllIlIl:
            return
        F329566654669315.clearProperty(SKIP_GUI_UNTIL)
        xbmc.executebuiltin(bytes.fromhex('52756e506c7567696e287b307d29').decode('utf-8').format(build_url({bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('677569').decode('utf-8')})))
        return
    elif action == bytes.fromhex('677569').decode('utf-8'):
        open_browser(HDFilmCehennemiUI())
        xbmcgui.Window(10000).setProperty(SKIP_GUI_UNTIL, str(time.time() + 4))
        xbmc.executebuiltin(bytes.fromhex('416374697661746557696e646f7728486f6d6529').decode('utf-8'))
        return
    elif action == bytes.fromhex('636c6173736963').decode('utf-8'):
        main_menu()
    elif action == bytes.fromhex('6c697374').decode('utf-8'):
        list_page(url, page_number)
    elif action == bytes.fromhex('736561726368').decode('utf-8'):
        search()
    elif action == bytes.fromhex('64657461696c').decode('utf-8'):
        detail(url)
    elif action == bytes.fromhex('706c61795f696672616d65').decode('utf-8'):
        play_iframe(url, params.get(bytes.fromhex('72656665726572').decode('utf-8')))
    elif action == bytes.fromhex('706c61795f736f75726365').decode('utf-8'):
        play_source(url, params.get(bytes.fromhex('766964656f5f6964').decode('utf-8')))
    xbmcplugin.endOfDirectory(HANDLE)
if __name__ == bytes.fromhex('5f5f6d61696e5f5f').decode('utf-8'):
    run()
