from __future__ import absolute_import, unicode_literals
import base64
import binascii
import json
import re
import string
import manituxhttp
try:
    from urllib.parse import quote, urlparse, urlunparse
except ImportError:
    from urllib import quote
    from urlparse import urlparse, urlunparse

class VideoExtractor(object):

    def __init__(self, user_agent):
        self.user_agent = user_agent
        self.session = manituxhttp.Session()

    def headers(self, referer=None):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): self.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('746578742f68746d6c2c6170706c69636174696f6e2f7868746d6c2b786d6c2c6170706c69636174696f6e2f786d6c3b713d302e392c2a2f2a3b713d302e38').decode('utf-8'), bytes.fromhex('436f6e74656e742d54797065').decode('utf-8'): bytes.fromhex('6170706c69636174696f6e2f6a736f6e').decode('utf-8'), bytes.fromhex('582d5265717565737465642d57697468').decode('utf-8'): bytes.fromhex('584d4c4874747052657175657374').decode('utf-8')}
        if referer:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        return headers

    def hdfilmcehennemi_extractor(self, url, referer=None):
        url = self.normalize_url(url)
        referer = referer or url
        page = self.fetch(url, referer)
        guyyDEjHZrWHzcARwmSBwLuyXjuwgReeFGeebVQaSFbEjzRuWdiaflHagoCYwxkvRVqePrYRaTQzInf16 = self.origin(url)
        R232128297874542 = []
        source = self._extract_obfuscated_video_link(page)
        f46 = self._unpack_first_eval(page)
        if f46:
            if not source:
                source = self._extract_obfuscated_video_link(f46)
            if not source:
                source = self._first(bytes.fromhex('736f75726365735c732a3a5c732a5c5b5c732a5c7b5c732a66696c655c732a3a5c732a5b275c225d285b5e275c225d2b29').decode('utf-8'), f46, re.S)
            if not source:
                v4 = self._first(bytes.fromhex('5b225c275d2861485230635b5e225c275d2b295b225c275d').decode('utf-8'), f46)
                if v4:
                    source = base64.b64decode(v4).decode(bytes.fromhex('7574662d38').decode('utf-8'), bytes.fromhex('7265706c616365').decode('utf-8'))
            R232128297874542 = self._extract_subtitles(page + bytes.fromhex('0a').decode('utf-8') + f46, guyyDEjHZrWHzcARwmSBwLuyXjuwgReeFGeebVQaSFbEjzRuWdiaflHagoCYwxkvRVqePrYRaTQzInf16)
        else:
            source = self._first(bytes.fromhex('22636f6e74656e7455726c225c732a3a5c732a22285b5e225d2b2922').decode('utf-8'), page)
            if not source:
                source = self._first(bytes.fromhex('283f3a2266696c65227c66696c65295c732a3a5c732a5b225c275d285b5e225c275d2b29').decode('utf-8'), page)
            R232128297874542 = self._extract_subtitles(page, guyyDEjHZrWHzcARwmSBwLuyXjuwgReeFGeebVQaSFbEjzRuWdiaflHagoCYwxkvRVqePrYRaTQzInf16)
        if not source:
            IlIllllIlIlIllllIllIlI = self._first(bytes.fromhex('3c696672616d655b5e3e5d2b283f3a7372637c646174612d737263293d5b225c275d285b5e225c275d2b29').decode('utf-8'), page)
            if IlIllllIlIlIllllIllIlI and IlIllllIlIlIllllIllIlI != url:
                return self.resolve(IlIllllIlIlIllllIllIlI.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')), url)
            return (None, R232128297874542)
        source = source.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')).replace(bytes.fromhex('5c7530303236').decode('utf-8'), bytes.fromhex('26').decode('utf-8'))
        return (source + self.kodi_headers(guyyDEjHZrWHzcARwmSBwLuyXjuwgReeFGeebVQaSFbEjzRuWdiaflHagoCYwxkvRVqePrYRaTQzInf16), R232128297874542)

    def resolve(self, url, referer=None):
        if not url:
            return (None, [])
        url = self.normalize_url(url)
        if self.is_hdfilm_url(url):
            return self.hdfilmcehennemi_extractor(url, referer)
        if bytes.fromhex('7669646d6f6c79').decode('utf-8') in url or bytes.fromhex('666c6d706c61796572').decode('utf-8') in url:
            return self.resolve_vidmoly(url)
        if bytes.fromhex('6f646e6f6b6c6173736e696b69').decode('utf-8') in url or bytes.fromhex('6f6b2e7275').decode('utf-8') in url:
            return self.resolve_okru(url)
        return (url + self.kodi_headers(referer), [])

    def resolve_hdfilm_embed(self, url, referer=None):
        return self.hdfilmcehennemi_extractor(url, referer)

    def resolve_vidmoly(self, url):
        url = self.normalize_url(url).replace(bytes.fromhex('2e746f70').decode('utf-8'), bytes.fromhex('2e746f').decode('utf-8'))
        page = self.fetch(url, bytes.fromhex('68747470733a2f2f7669646d6f6c792e746f2f').decode('utf-8'))
        llllIlIIlIlllIIlIIllIIIlIIllIlIIIIll = self._first(bytes.fromhex('77696e646f775c2e6c6f636174696f6e5c732a3d5c732a27285b5e275d2b2927').decode('utf-8'), page)
        if llllIlIIlIlllIIlIIllIIIlIIllIlIIIIll:
            page = self.fetch(url.replace(bytes.fromhex('656d6265642d').decode('utf-8'), llllIlIIlIlllIIlIIllIIIlIIllIlIIIIll), url)
        source = self._first(bytes.fromhex('285b5e275c225c735d2b5c2e6d3375385b5e275c225c735d2a29').decode('utf-8'), page)
        q43 = re.findall(bytes.fromhex('66696c655c732a3a5c732a27285b5e275d2b2f7372745b5e275d2a2927').decode('utf-8'), page)
        return (source + self.kodi_headers(bytes.fromhex('68747470733a2f2f7669646d6f6c792e746f2f').decode('utf-8')), q43)

    def resolve_okru(self, url):
        url = self.normalize_url(url)
        video_id = self._first(bytes.fromhex('283f3a766964656f656d6265642f7c6d69643d29285c642b29').decode('utf-8'), url)
        if not video_id:
            return (url + self.kodi_headers(bytes.fromhex('68747470733a2f2f6f6b2e72752f').decode('utf-8')), [])
        lllllIIIlllIlIllllllllIllIlIllIIllIIIl = self.session.post(bytes.fromhex('68747470733a2f2f7777772e6f6b2e72752f646b').decode('utf-8'), data={bytes.fromhex('636d64').decode('utf-8'): bytes.fromhex('766964656f506c617965724d65746164617461').decode('utf-8'), bytes.fromhex('6d6964').decode('utf-8'): video_id}, headers=self.headers(bytes.fromhex('68747470733a2f2f6f6b2e72752f').decode('utf-8')), timeout=25)
        lllllIIIlllIlIllllllllIllIlIllIIllIIIl.raise_for_status()
        data = lllllIIIlllIlIllllllllIllIlIllIIllIIIl.text
        source = self._first(bytes.fromhex('283f3a756c7472617c717561647c66756c6c7c68647c73647c6c6f777c6c6f7765737429222c2275726c223a22282e2a3f2922').decode('utf-8'), data)
        return (source.replace(bytes.fromhex('5c7530303236').decode('utf-8'), bytes.fromhex('26').decode('utf-8')) + self.kodi_headers(bytes.fromhex('68747470733a2f2f6f6b2e72752f').decode('utf-8')), [])

    def fetch(self, url, referer=None):
        lllllIIIlllIlIllllllllIllIlIllIIllIIIl = self.session.get(url, headers=self.headers(referer), timeout=25, allow_redirects=True)
        lllllIIIlllIlIllllllllIllIlIllIIllIIIl.raise_for_status()
        return lllllIIIlllIlIllllllllIllIlIllIIllIIIl.text

    def normalize_url(self, url):
        if url.startswith(bytes.fromhex('2f2f').decode('utf-8')):
            url = bytes.fromhex('68747470733a').decode('utf-8') + url
        elif url.startswith(bytes.fromhex('7777772e').decode('utf-8')):
            url = bytes.fromhex('68747470733a2f2f').decode('utf-8') + url
        elif not url.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8'))):
            url = bytes.fromhex('68747470733a2f2f').decode('utf-8') + url
        XWUnwpbvuHVRhiwvNtKBpjwzAqbcdlrjKlnpAIehUcEMlXFhhZMpAUgJxJTUwotMNWgQTQOsxjMQbJd29 = urlparse(url)
        return urlunparse(XWUnwpbvuHVRhiwvNtKBpjwzAqbcdlrjKlnpAIehUcEMlXFhhZMpAUgJxJTUwotMNWgQTQOsxjMQbJd29._replace(scheme=bytes.fromhex('6874747073').decode('utf-8')))

    def kodi_headers(self, referer=None):
        zzzzz = [bytes.fromhex('557365722d4167656e743d').decode('utf-8') + quote(self.user_agent)]
        if referer:
            zzzzz.append(bytes.fromhex('526566657265723d').decode('utf-8') + quote(referer))
        return bytes.fromhex('7c').decode('utf-8') + bytes.fromhex('26').decode('utf-8').join(zzzzz)

    def is_hdfilm_url(self, url):
        aaaAAAAAaAAaAAAAaAAa = urlparse(url).netloc.lower()
        return bytes.fromhex('686466696c6d636568656e6e656d69').decode('utf-8') in aaaAAAAAaAAaAAAAaAAa or bytes.fromhex('64697a69636568656e6e656d69').decode('utf-8') in aaaAAAAAaAAaAAAAaAAa or bytes.fromhex('706c61796d6978').decode('utf-8') in aaaAAAAAaAAaAAAAaAAa or (bytes.fromhex('726170696472616d65').decode('utf-8') in aaaAAAAAaAAaAAAAaAAa)

    def origin(self, url):
        XWUnwpbvuHVRhiwvNtKBpjwzAqbcdlrjKlnpAIehUcEMlXFhhZMpAUgJxJTUwotMNWgQTQOsxjMQbJd29 = urlparse(url)
        return XWUnwpbvuHVRhiwvNtKBpjwzAqbcdlrjKlnpAIehUcEMlXFhhZMpAUgJxJTUwotMNWgQTQOsxjMQbJd29.scheme + bytes.fromhex('3a2f2f').decode('utf-8') + XWUnwpbvuHVRhiwvNtKBpjwzAqbcdlrjKlnpAIehUcEMlXFhhZMpAUgJxJTUwotMNWgQTQOsxjMQbJd29.netloc

    def _extract_subtitles(self, page, origin):
        q43 = []
        for subtitle in re.findall(bytes.fromhex('2266696c65225c732a3a5c732a22285b5e225d2b29225b5e7b7d5d2a226b696e64225c732a3a5c732a2263617074696f6e7322').decode('utf-8'), page, re.S):
            q43.append(self._absolute_url(subtitle.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')), origin))
        for yfkNPdMXyFPhGByRXOPyNMLeCxuDGCiWdAqxOcurqfDHrCUiqjLrANjVGVzRCjYnvnkJyPhfIYOHpZH45 in re.findall(bytes.fromhex('747261636b735c732a3a5c732a285c5b2e2a3f5c5d295c732a2c').decode('utf-8'), page, re.S):
            for subtitle in re.findall(bytes.fromhex('2266696c65225c732a3a5c732a22285b5e225d2b2922').decode('utf-8'), yfkNPdMXyFPhGByRXOPyNMLeCxuDGCiWdAqxOcurqfDHrCUiqjLrANjVGVzRCjYnvnkJyPhfIYOHpZH45):
                q43.append(self._absolute_url(subtitle.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')), origin))
        for subtitle in re.findall(bytes.fromhex('747261636b5c732b7372633d5b275c225d285b5e275c225d2b29').decode('utf-8'), page, re.S | re.I):
            q43.append(self._absolute_url(subtitle.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')), origin))
        return list(dict.fromkeys(q43))

    def _absolute_url(self, url, origin):
        if url.startswith(bytes.fromhex('2f2f').decode('utf-8')):
            return bytes.fromhex('68747470733a').decode('utf-8') + url
        if url.startswith(bytes.fromhex('2f').decode('utf-8')):
            return origin.rstrip(bytes.fromhex('2f').decode('utf-8')) + url
        return url

    def _unpack_first_eval(self, page):
        IlIllIlIlIllIllllllIIIIll = re.search(bytes.fromhex('6576616c5c2866756e6374696f6e5c28702c612c632c6b2c652c645c292e2a3f5c7d5c28283f503c7061796c6f61643e5b275c225d2e2a3f5b275c225d295c732a2c5c732a283f503c626173653e5c642b295c732a2c5c732a283f503c636f756e743e5c642b295c732a2c5c732a283f503c73796d626f6c733e5b275c225d2e2a3f5b275c225d295c2e73706c69745c285b275c225d5c7c5b275c225d5c29').decode('utf-8'), page, re.S)
        if not IlIllIlIlIllIllllllIIIIll:
            return bytes.fromhex('').decode('utf-8')
        NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN = self._js_string(IlIllIlIlIllIllllllIIIIll.group(bytes.fromhex('7061796c6f6164').decode('utf-8')))
        base = int(IlIllIlIlIllIllllllIIIIll.group(bytes.fromhex('62617365').decode('utf-8')))
        a763618262999012 = int(IlIllIlIlIllIllllllIIIIll.group(bytes.fromhex('636f756e74').decode('utf-8')))
        l44 = self._js_string(IlIllIlIlIllIllllllIIIIll.group(bytes.fromhex('73796d626f6c73').decode('utf-8'))).split(bytes.fromhex('7c').decode('utf-8'))
        if a763618262999012 > len(l44):
            l44.extend([bytes.fromhex('').decode('utf-8')] * (a763618262999012 - len(l44)))
        for lllIIlIIlIlIIIIIIIlllll in range(a763618262999012 - 1, -1, -1):
            q440731759920547 = self._base_n(lllIIlIIlIlIIIIIIIlllll, base)
            if l44[lllIIlIIlIlIIIIIIIlllll]:
                NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN = re.sub(bytes.fromhex('5c62').decode('utf-8') + re.escape(q440731759920547) + bytes.fromhex('5c62').decode('utf-8'), l44[lllIIlIIlIlIIIIIIIlllll], NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN)
        return NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN

    def _js_string(self, value):
        D35 = value[0]
        if value[-1] == D35:
            value = value[1:-1]
        return bytes(value, bytes.fromhex('7574662d38').decode('utf-8')).decode(bytes.fromhex('756e69636f64655f657363617065').decode('utf-8'))

    def _base_n(self, number, base):
        I = string.digits + string.ascii_lowercase + string.ascii_uppercase
        if number == 0:
            return bytes.fromhex('30').decode('utf-8')
        Z39 = bytes.fromhex('').decode('utf-8')
        while number:
            number, pZBnRogCCMMoiHqbEIFjsOXTkQEjGYkwTGnPDQizptzxepCBRtqhMoflelJBLBvvGxjgnjgwDCSwCHq37 = divmod(number, base)
            Z39 = I[pZBnRogCCMMoiHqbEIFjsOXTkQEjGYkwTGnPDQizptzxepCBRtqhMoflelJBLBvvGxjgnjgwDCSwCHq37] + Z39
        return Z39

    def _decode_obfuscated_source(self, page):
        IlIllIlIlIllIllllllIIIIll = re.search(bytes.fromhex('7661725c732b28735f5b412d5a612d7a302d395f5d2b295c732a3d5c732a2864635f5b412d5a612d7a302d395f5d2b295c28285c5b2e2a3f5c5d295c29').decode('utf-8'), page, re.S)
        if not IlIllIlIlIllIllllllIIIIll:
            return bytes.fromhex('').decode('utf-8')
        Q32 = json.loads(IlIllIlIlIllIllllllIIIIll.group(3).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')))
        value = bytes.fromhex('').decode('utf-8').join(Q32)
        value = self._rot13(value)[::-1]
        aAaAaAAAAaAAA = base64.b64decode(value).decode(bytes.fromhex('6c6174696e2d31').decode('utf-8'))
        a259974533948710 = []
        for k212335036710221, yyyyyyyy in enumerate(aAaAaAAAAaAAA):
            lllllllllll = (ord(yyyyyyyy) - 399756995 % (k212335036710221 + 5) + 256) % 256
            a259974533948710.append(chr(lllllllllll))
        return bytes.fromhex('').decode('utf-8').join(a259974533948710)

    @staticmethod
    def _rot13(value):
        IllllIlIlIllIIlIlllIIIIllIIl = []
        for yyyyyyyy in value:
            lllllllllll = ord(yyyyyyyy)
            if 65 <= lllllllllll <= 90:
                IllllIlIlIllIIlIlllIIIIllIIl.append(chr((lllllllllll - 65 + 13) % 26 + 65))
            elif 97 <= lllllllllll <= 122:
                IllllIlIlIllIIlIlllIIIIllIIl.append(chr((lllllllllll - 97 + 13) % 26 + 97))
            else:
                IllllIlIlIllIIlIlllIIIIllIIl.append(yyyyyyyy)
        return bytes.fromhex('').decode('utf-8').join(IllllIlIlIllIIlIlllIIIIllIIl)

    def _extract_obfuscated_video_link(self, html):
        for TTTTTTT in self._get_base64_candidates_from_html(html):
            source = self._try_decrypt_candidate(TTTTTTT)
            if source:
                return source
        source = self._decode_obfuscated_source(html)
        if source:
            return self._get_url(source)
        return self._direct_video_link(html)

    def _try_decrypt_candidate(self, value):
        aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa = (lambda syJuIJaaHDNmsbsHzLbHregzvuoiECXXKfihxMaIenFZtLUWGpgbsgeSuekZxpVdbKyQcLGPnTeoDlU48: self._unmix(self._rot13(self._base64_decode_js(syJuIJaaHDNmsbsHzLbHregzvuoiECXXKfihxMaIenFZtLUWGpgbsgeSuekZxpVdbKyQcLGPnTeoDlU48[::-1]))), lambda syJuIJaaHDNmsbsHzLbHregzvuoiECXXKfihxMaIenFZtLUWGpgbsgeSuekZxpVdbKyQcLGPnTeoDlU48: self._unmix(self._base64_decode_js(self._rot13(syJuIJaaHDNmsbsHzLbHregzvuoiECXXKfihxMaIenFZtLUWGpgbsgeSuekZxpVdbKyQcLGPnTeoDlU48))[::-1]), lambda syJuIJaaHDNmsbsHzLbHregzvuoiECXXKfihxMaIenFZtLUWGpgbsgeSuekZxpVdbKyQcLGPnTeoDlU48: self._unmix(self._rot13(self._base64_decode_js(syJuIJaaHDNmsbsHzLbHregzvuoiECXXKfihxMaIenFZtLUWGpgbsgeSuekZxpVdbKyQcLGPnTeoDlU48))[::-1]), lambda syJuIJaaHDNmsbsHzLbHregzvuoiECXXKfihxMaIenFZtLUWGpgbsgeSuekZxpVdbKyQcLGPnTeoDlU48: self._unmix(self._base64_decode_js(self._base64_decode_js(syJuIJaaHDNmsbsHzLbHregzvuoiECXXKfihxMaIenFZtLUWGpgbsgeSuekZxpVdbKyQcLGPnTeoDlU48[::-1]))), lambda syJuIJaaHDNmsbsHzLbHregzvuoiECXXKfihxMaIenFZtLUWGpgbsgeSuekZxpVdbKyQcLGPnTeoDlU48: self._unmix(self._base64_decode_js(self._rot13(syJuIJaaHDNmsbsHzLbHregzvuoiECXXKfihxMaIenFZtLUWGpgbsgeSuekZxpVdbKyQcLGPnTeoDlU48)[::-1])), self._decrypt_rot13_base64_reverse_unmix, self._decrypt_reversed_double_base64_unmix, self._decrypt_text_base64_rot13_reverse_unmix, self._decrypt_rot13_reversed_base64_unmix)
        for uuuuuuuuuuuuuu in aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:
            try:
                aAaAaAAAAaAAA = uuuuuuuuuuuuuu(value)
            except Exception:
                aAaAaAAAAaAAA = None
            source = self._get_url(aAaAaAAAAaAAA)
            if source:
                return source
        return None

    def _decrypt_rot13_base64_reverse_unmix(self, value):
        aAaAaAAAAaAAA = self._base64_decode_js(self._rot13(value))
        if not aAaAaAAAAaAAA:
            return None
        return self._get_url(self._unmix(aAaAaAAAAaAAA[::-1]))

    def _decrypt_reversed_double_base64_unmix(self, value):
        s896082265662019 = self._base64_decode_js(value[::-1])
        if not s896082265662019:
            return None
        AaaAAAaAaAaAaaAAaAAAaaAAAAaAaaaAAaAaAAAa = self._base64_decode_js(s896082265662019)
        if not AaaAAAaAaAaAaaAAaAAAaaAAAAaAaaaAAaAaAAAa:
            return None
        return self._get_url(self._unmix(AaaAAAaAaAaAaaAAaAAAaaAAAAaAaaaAAaAaAAAa))

    def _decrypt_text_base64_rot13_reverse_unmix(self, value):
        aAaAaAAAAaAAA = self._base64_decode_js(value)
        if not aAaAaAAAAaAAA or self._printable_ratio(aAaAaAAAAaAAA) <= 0.75:
            return None
        return self._get_url(self._unmix(self._rot13(aAaAaAAAAaAAA)[::-1]))

    def _decrypt_rot13_reversed_base64_unmix(self, value):
        aAaAaAAAAaAAA = self._base64_decode_js(self._rot13(value)[::-1])
        if not aAaAaAAAAaAAA or self._printable_ratio(aAaAaAAAAaAAA) <= 0.75:
            return None
        return self._get_url(self._unmix(aAaAaAAAAaAAA))

    def _get_base64_candidates_from_html(self, html):
        candidates = []
        self._add_direct_array_values(html, candidates)
        self._add_quoted_base64_values(html, candidates)
        f46 = self._unpack_first_eval(html)
        if f46:
            self._add_direct_array_values(f46, candidates)
            self._add_quoted_base64_values(f46, candidates)
        self._add_packed_array_values(html, candidates)
        Z39 = []
        for TTTTTTT in candidates:
            TTTTTTT = (TTTTTTT or bytes.fromhex('').decode('utf-8')).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')).strip()
            if self._is_likely_encrypted_payload(TTTTTTT) and TTTTTTT not in Z39:
                Z39.append(TTTTTTT)
        return Z39

    def _add_direct_array_values(self, html, candidates):
        Ill = re.compile(bytes.fromhex('5c625c772b5c732a5c285c732a285c5b5c732a283f3a5c225b5e5c225d2a5c227c275b5e275d2a27295c732a283f3a2c5c732a283f3a5c225b5e5c225d2a5c227c275b5e275d2a27295c732a292a5c5d295c732a5c29').decode('utf-8'), re.S)
        for IlIllIlIlIllIllllllIIIIll in Ill.finditer(html or bytes.fromhex('').decode('utf-8')):
            array_text = IlIllIlIlIllIllllllIIIIll.group(1)
            XWUnwpbvuHVRhiwvNtKBpjwzAqbcdlrjKlnpAIehUcEMlXFhhZMpAUgJxJTUwotMNWgQTQOsxjMQbJd29 = self._parse_string_array(array_text)
            if XWUnwpbvuHVRhiwvNtKBpjwzAqbcdlrjKlnpAIehUcEMlXFhhZMpAUgJxJTUwotMNWgQTQOsxjMQbJd29:
                candidates.append(XWUnwpbvuHVRhiwvNtKBpjwzAqbcdlrjKlnpAIehUcEMlXFhhZMpAUgJxJTUwotMNWgQTQOsxjMQbJd29)
            else:
                Q32 = re.findall(bytes.fromhex('5b22275d285b5e22275d2b295b22275d').decode('utf-8'), array_text)
                candidates.append(bytes.fromhex('').decode('utf-8').join(Q32))

    def _add_quoted_base64_values(self, html, candidates):
        pattern = re.compile(bytes.fromhex('5b22275d283f503c76616c75653e283f3a3d7b302c327d295b412d5a612d7a302d392b2f5d7b38302c7d3d7b302c327d295b22275d').decode('utf-8'), re.S)
        for IlIllIlIlIllIllllllIIIIll in pattern.finditer(html or bytes.fromhex('').decode('utf-8')):
            candidates.append(IlIllIlIlIllIllllllIIIIll.group(bytes.fromhex('76616c7565').decode('utf-8')))

    def _add_packed_array_values(self, html, candidates):
        S124197868183018 = re.compile(bytes.fromhex('6576616c5c2866756e6374696f6e5c28702c612c632c6b2c652c645c292e2a3f5c2e73706c69745c285b275c225d5c7c5b275c225d5c292c5c642b2c5c7b5c7d5c295c29').decode('utf-8'), re.S)
        for j17 in S124197868183018.finditer(html or bytes.fromhex('').decode('utf-8')):
            aAaAAa = j17.group(0)
            AaaaaAaAaAAAaAA = re.search(bytes.fromhex('5b27225d285b5e27225d2a295b27225d5c2e73706c6974').decode('utf-8'), aAaAAa, re.S)
            if not AaaaaAaAaAAAaAA:
                continue
            dictionary = AaaaaAaAaAAAaAA.group(1).split(bytes.fromhex('7c').decode('utf-8'))
            lookup = string.digits + string.ascii_lowercase + string.ascii_uppercase
            for n27541422170352 in re.finditer(bytes.fromhex('5c5b5c732a285b22275d2e2a3f5b22275d5c732a2c3f5c732a292b5c732a5c5d').decode('utf-8'), aAaAAa, re.S):
                Q32 = []
                for K31 in re.finditer(bytes.fromhex('5b22275d283f503c76616c3e2e2a3f295b22275d').decode('utf-8'), n27541422170352.group(0), re.S):
                    QiGlbOwyXLhEDfwkigLGYWWtXyXApnwEeCrKlOKEcBpUjDCsKVUpdkNqdyrEUcRBgbNcPZfMYotvtSC30 = re.sub(bytes.fromhex('5c772b').decode('utf-8'), lambda llllllllllllllllllllllll: self._base62_lookup(llllllllllllllllllllllll.group(0), lookup, dictionary), K31.group(bytes.fromhex('76616c').decode('utf-8')))
                    Q32.append(QiGlbOwyXLhEDfwkigLGYWWtXyXApnwEeCrKlOKEcBpUjDCsKVUpdkNqdyrEUcRBgbNcPZfMYotvtSC30)
                candidates.append(bytes.fromhex('').decode('utf-8').join(Q32))

    def _parse_string_array(self, array_text):
        ZZZZZZZZZZZZZZZZZZZZZZZZZZZ = re.sub(bytes.fromhex('27285b5e275c5c5d2a283f3a5c5c2e5b5e275c5c5d2a292a2927').decode('utf-8'), lambda llllllllllllllllllllllll: json.dumps(llllllllllllllllllllllll.group(1)), array_text)
        try:
            return bytes.fromhex('').decode('utf-8').join(json.loads(ZZZZZZZZZZZZZZZZZZZZZZZZZZZ))
        except (TypeError, ValueError):
            return bytes.fromhex('').decode('utf-8')

    def _base62_lookup(self, value, lookup, dictionary):
        lllIIlIIlIlIIIIIIIlllll = 0
        AaAaAaaaAaaaaAaAaaaaaAaAaA = 1
        for yyyyyyyy in reversed(value):
            AAAaaAaAa = lookup.find(yyyyyyyy)
            if AAAaaAaAa == -1:
                return value
            lllIIlIIlIlIIIIIIIlllll += AAAaaAaAa * AaAaAaaaAaaaaAaAaaaaaAaAaA
            AaAaAaaaAaaaaAaAaaaaaAaAaA *= 62
        if lllIIlIIlIlIIIIIIIlllll < len(dictionary) and dictionary[lllIIlIIlIlIIIIIIIlllll]:
            return dictionary[lllIIlIIlIlIIIIIIIlllll]
        return value

    def _base64_decode_js(self, value):
        if not value:
            return bytes.fromhex('').decode('utf-8')
        try:
            if not isinstance(value, bytes):
                value = value.encode(bytes.fromhex('6c6174696e2d31').decode('utf-8'))
            value += b'=' * ((4 - len(value) % 4) % 4)
            return base64.b64decode(value).decode(bytes.fromhex('6c6174696e2d31').decode('utf-8'))
        except (TypeError, binascii.Error, UnicodeError):
            return bytes.fromhex('').decode('utf-8')

    def _is_likely_encrypted_payload(self, value):
        if len(value) < 40:
            return False
        a763618262999012 = sum((1 for yyyyyyyy in value if yyyyyyyy.isalnum() or yyyyyyyy in bytes.fromhex('2b2f3d').decode('utf-8')))
        return float(a763618262999012) / len(value) > 0.85

    def _unmix(self, value):
        a259974533948710 = []
        for k212335036710221, yyyyyyyy in enumerate(value):
            lllllllllll = (ord(yyyyyyyy) - 399756995 % (k212335036710221 + 5) + 256) % 256
            a259974533948710.append(chr(lllllllllll))
        return bytes.fromhex('').decode('utf-8').join(a259974533948710)

    def _printable_ratio(self, value):
        if not value:
            return 0
        A34 = sum((1 for yyyyyyyy in value if yyyyyyyy in bytes.fromhex('0d0a09').decode('utf-8') or bytes.fromhex('20').decode('utf-8') <= yyyyyyyy <= bytes.fromhex('7e').decode('utf-8')))
        return float(A34) / len(value)

    def _get_url(self, value):
        value = (value or bytes.fromhex('').decode('utf-8')).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')).replace(bytes.fromhex('5c7530303236').decode('utf-8'), bytes.fromhex('26').decode('utf-8')).replace(bytes.fromhex('7530303236').decode('utf-8'), bytes.fromhex('26').decode('utf-8'))
        IlIllIlIlIllIllllllIIIIll = re.search(bytes.fromhex('68747470733f3a2f2f5b5e5c7322277c3c3e5d2b').decode('utf-8'), value)
        return IlIllIlIlIllIllllllIIIIll.group(0) if IlIllIlIlIllIllllllIIIIll else None

    def _direct_video_link(self, html):
        f46 = self._unpack_first_eval(html)
        for source in (f46, html):
            IlIllIlIlIllIllllllIIIIll = re.search(bytes.fromhex('68747470733f3a5c5c3f2f5c5c3f2f5b5e22275c733c3e5d2b3f5c2e6d3375385b5e22275c733c3e5d2a').decode('utf-8'), source or bytes.fromhex('').decode('utf-8'), re.I)
            if IlIllIlIlIllIllllllIIIIll:
                return IlIllIlIlIllIllllllIIIIll.group(0).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'))
        return None

    @staticmethod
    def _first(pattern, text, flags=0):
        IlIllIlIlIllIllllllIIIIll = re.search(pattern, text or bytes.fromhex('').decode('utf-8'), flags | re.I)
        return IlIllIlIlIllIllllllIIIIll.group(1) if IlIllIlIlIllIllllllIIIIll else bytes.fromhex('').decode('utf-8')
