from __future__ import absolute_import, unicode_literals
import manituxhttp
try:
    import urllib.parse as urlparse
except ImportError:
    import urlparse
from . import parsers

class HDFilmCehennemiSite(object):

    def __init__(self, base_url, user_agent):
        self.base_url = base_url.rstrip(bytes.fromhex('2f').decode('utf-8'))
        self.user_agent = user_agent
        self.session = manituxhttp.Session()

    def headers(self, referer=None, ajax=False):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): self.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('746578742f68746d6c2c6170706c69636174696f6e2f7868746d6c2b786d6c2c6170706c69636174696f6e2f786d6c3b713d302e392c696d6167652f617669662c696d6167652f776562702c696d6167652f61706e672c2a2f2a3b713d302e38').decode('utf-8'), bytes.fromhex('4163636570742d4c616e6775616765').decode('utf-8'): bytes.fromhex('74722d54522c74723b713d302e392c656e2d55533b713d302e382c656e3b713d302e37').decode('utf-8'), bytes.fromhex('436f6e6e656374696f6e').decode('utf-8'): bytes.fromhex('6b6565702d616c697665').decode('utf-8'), bytes.fromhex('557067726164652d496e7365637572652d5265717565737473').decode('utf-8'): bytes.fromhex('31').decode('utf-8')}
        if referer:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        else:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = self.base_url + bytes.fromhex('2f').decode('utf-8')
        if ajax:
            headers[bytes.fromhex('582d5265717565737465642d57697468').decode('utf-8')] = bytes.fromhex('6665746368').decode('utf-8')
        return headers

    def get_headers(self, referer=None, ajax=False):
        MRBWzwqfCeCupMQVsealtHKaChuLqZJuhSLhaBZFCngAreOIqvHRdGoWymNBBUYSZQKiPhFNVVxZiQB5 = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): self.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('746578742f68746d6c2c6170706c69636174696f6e2f7868746d6c2b786d6c2c6170706c69636174696f6e2f786d6c3b713d302e392c696d6167652f617669662c696d6167652f776562702c696d6167652f61706e672c2a2f2a3b713d302e38').decode('utf-8'), bytes.fromhex('4163636570742d4c616e6775616765').decode('utf-8'): bytes.fromhex('74722d54522c74723b713d302e392c656e2d55533b713d302e382c656e3b713d302e37').decode('utf-8'), bytes.fromhex('557067726164652d496e7365637572652d5265717565737473').decode('utf-8'): bytes.fromhex('31').decode('utf-8'), bytes.fromhex('436f6e6e656374696f6e').decode('utf-8'): bytes.fromhex('6b6565702d616c697665').decode('utf-8')}
        if referer:
            MRBWzwqfCeCupMQVsealtHKaChuLqZJuhSLhaBZFCngAreOIqvHRdGoWymNBBUYSZQKiPhFNVVxZiQB5[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        if ajax:
            MRBWzwqfCeCupMQVsealtHKaChuLqZJuhSLhaBZFCngAreOIqvHRdGoWymNBBUYSZQKiPhFNVVxZiQB5[bytes.fromhex('416363657074').decode('utf-8')] = bytes.fromhex('2a2f2a').decode('utf-8')
            MRBWzwqfCeCupMQVsealtHKaChuLqZJuhSLhaBZFCngAreOIqvHRdGoWymNBBUYSZQKiPhFNVVxZiQB5[bytes.fromhex('582d5265717565737465642d57697468').decode('utf-8')] = bytes.fromhex('584d4c4874747052657175657374').decode('utf-8')
            MRBWzwqfCeCupMQVsealtHKaChuLqZJuhSLhaBZFCngAreOIqvHRdGoWymNBBUYSZQKiPhFNVVxZiQB5[bytes.fromhex('5365632d46657463682d44657374').decode('utf-8')] = bytes.fromhex('656d707479').decode('utf-8')
            MRBWzwqfCeCupMQVsealtHKaChuLqZJuhSLhaBZFCngAreOIqvHRdGoWymNBBUYSZQKiPhFNVVxZiQB5[bytes.fromhex('5365632d46657463682d4d6f6465').decode('utf-8')] = bytes.fromhex('636f7273').decode('utf-8')
            MRBWzwqfCeCupMQVsealtHKaChuLqZJuhSLhaBZFCngAreOIqvHRdGoWymNBBUYSZQKiPhFNVVxZiQB5[bytes.fromhex('5365632d46657463682d53697465').decode('utf-8')] = bytes.fromhex('73616d652d6f726967696e').decode('utf-8')
            if bytes.fromhex('557067726164652d496e7365637572652d5265717565737473').decode('utf-8') in MRBWzwqfCeCupMQVsealtHKaChuLqZJuhSLhaBZFCngAreOIqvHRdGoWymNBBUYSZQKiPhFNVVxZiQB5:
                del MRBWzwqfCeCupMQVsealtHKaChuLqZJuhSLhaBZFCngAreOIqvHRdGoWymNBBUYSZQKiPhFNVVxZiQB5[bytes.fromhex('557067726164652d496e7365637572652d5265717565737473').decode('utf-8')]
        return MRBWzwqfCeCupMQVsealtHKaChuLqZJuhSLhaBZFCngAreOIqvHRdGoWymNBBUYSZQKiPhFNVVxZiQB5

    def get(self, url, referer=None, ajax=False):
        url = self.absolute(url)
        return self._get(url, headers=self.headers(referer, ajax=ajax)).text

    def categories(self):
        return parsers.categories(self.base_url)

    def page_url(self, category_url, page_number):
        return parsers.page_api_url(category_url, page_number)

    def get_page_items(self, category_url, page_number=1, title=bytes.fromhex('').decode('utf-8')):
        api_url = self.page_url(category_url, page_number)
        try:
            page = self.get_ajax(api_url)
        except manituxhttp.HTTPError as exc:
            if getattr(exc.response, bytes.fromhex('7374617475735f636f6465').decode('utf-8'), None) != 403:
                raise
            MiRnFdaIqjfEzUphssoWOFIuNHbIteKQKLHKQeFbeKapEJhSiDClcDcFYJyTYfYwiTYGghakSduOZhC3 = self.page_fallback_url(api_url, category_url, page_number)
            if not MiRnFdaIqjfEzUphssoWOFIuNHbIteKQKLHKQeFbeKapEJhSiDClcDcFYJyTYfYwiTYGghakSduOZhC3:
                raise
            page = self.get(MiRnFdaIqjfEzUphssoWOFIuNHbIteKQKLHKQeFbeKapEJhSiDClcDcFYJyTYfYwiTYGghakSduOZhC3)
        N50692434465037 = parsers.html_from_load_response(page)
        return parsers.parse_page_items(N50692434465037, self.base_url, title)

    def absolute(self, url):
        return parsers.fix_url(url, self.base_url)

    def search_url(self, query):
        return self.base_url + bytes.fromhex('2f7365617263682f3f713d').decode('utf-8') + urlparse.quote_plus(query)

    def search(self, query):
        AaAAAAAaAA = self._get(self.search_url(query), headers=self.headers(referer=self.base_url + bytes.fromhex('2f').decode('utf-8'), ajax=True))
        return parsers.parse_search_results(AaAAAAAaAA.text, self.base_url)

    def parse_movies(self, page):
        return parsers.parse_page_items(page, self.base_url)

    def parse_next_page(self, page, current_url):
        return None

    def parse_detail(self, page, url):
        return parsers.parse_media_info(page, url, self.base_url)

    def fetch_source_iframe(self, video_id, referer):
        page = self.get_ajax(self.base_url + bytes.fromhex('2f766964656f2f7b307d2f').decode('utf-8').format(video_id), referer=referer)
        return parsers.parse_iframe_from_video_response(page)

    def get_ajax(self, url, referer=None):
        url = self.absolute(url)
        aAAaAAaa = None
        for headers in self.ajax_header_variants(referer):
            try:
                return self._get(url, headers=headers).text
            except manituxhttp.HTTPError as exc:
                if getattr(exc.response, bytes.fromhex('7374617475735f636f6465').decode('utf-8'), None) != 403:
                    raise
                aAAaAAaa = exc
                self._prime_session()
        raise aAAaAAaa

    def page_fallback_url(self, api_url, category_url, page_number):
        if int(page_number) != 1:
            return bytes.fromhex('').decode('utf-8')
        path = urlparse.urlparse(api_url).path.rstrip(bytes.fromhex('2f').decode('utf-8'))
        if path == bytes.fromhex('2f6c6f61642f706167652f312f686f6d65').decode('utf-8'):
            return self.base_url + bytes.fromhex('2f').decode('utf-8')
        if bytes.fromhex('2f7475722f').decode('utf-8') in category_url:
            return self.absolute(category_url)
        return bytes.fromhex('').decode('utf-8')

    def ajax_header_variants(self, referer=None):
        K1 = referer or self.base_url + bytes.fromhex('2f').decode('utf-8')
        headers = self.headers(K1, ajax=True)
        llIIllllIll = [headers]
        I4 = headers.copy()
        I4[bytes.fromhex('416363657074').decode('utf-8')] = bytes.fromhex('2a2f2a').decode('utf-8')
        I4[bytes.fromhex('4f726967696e').decode('utf-8')] = self.base_url
        I4[bytes.fromhex('5365632d46657463682d44657374').decode('utf-8')] = bytes.fromhex('656d707479').decode('utf-8')
        I4[bytes.fromhex('5365632d46657463682d4d6f6465').decode('utf-8')] = bytes.fromhex('636f7273').decode('utf-8')
        I4[bytes.fromhex('5365632d46657463682d53697465').decode('utf-8')] = bytes.fromhex('73616d652d6f726967696e').decode('utf-8')
        I4.pop(bytes.fromhex('557067726164652d496e7365637572652d5265717565737473').decode('utf-8'), None)
        llIIllllIll.append(I4)
        pBFOgzNFRkMlInFBTnvqlwnaXkCONygfXGtuQuteRLHxjlDOWrVWUfpSvPgFkVyXoPlIKlplwyKJPXW2 = headers.copy()
        pBFOgzNFRkMlInFBTnvqlwnaXkCONygfXGtuQuteRLHxjlDOWrVWUfpSvPgFkVyXoPlIKlplwyKJPXW2[bytes.fromhex('4f726967696e').decode('utf-8')] = self.base_url
        pBFOgzNFRkMlInFBTnvqlwnaXkCONygfXGtuQuteRLHxjlDOWrVWUfpSvPgFkVyXoPlIKlplwyKJPXW2[bytes.fromhex('5365632d46657463682d44657374').decode('utf-8')] = bytes.fromhex('656d707479').decode('utf-8')
        pBFOgzNFRkMlInFBTnvqlwnaXkCONygfXGtuQuteRLHxjlDOWrVWUfpSvPgFkVyXoPlIKlplwyKJPXW2[bytes.fromhex('5365632d46657463682d4d6f6465').decode('utf-8')] = bytes.fromhex('636f7273').decode('utf-8')
        pBFOgzNFRkMlInFBTnvqlwnaXkCONygfXGtuQuteRLHxjlDOWrVWUfpSvPgFkVyXoPlIKlplwyKJPXW2[bytes.fromhex('5365632d46657463682d53697465').decode('utf-8')] = bytes.fromhex('73616d652d6f726967696e').decode('utf-8')
        llIIllllIll.append(pBFOgzNFRkMlInFBTnvqlwnaXkCONygfXGtuQuteRLHxjlDOWrVWUfpSvPgFkVyXoPlIKlplwyKJPXW2)
        return llIIllllIll

    def _prime_session(self):
        try:
            self._get(self.base_url + bytes.fromhex('2f').decode('utf-8'), headers=self.headers(self.base_url + bytes.fromhex('2f').decode('utf-8')))
        except Exception:
            pass

    def _get(self, url, headers):
        AaAAAAAaAA = self.session.get(url, headers=headers, timeout=25)
        AaAAAAAaAA.raise_for_status()
        return AaAAAAAaAA

    def url_to_host(self, url):
        if not url.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8'))):
            url = bytes.fromhex('68747470733a2f2f').decode('utf-8') + url
        IIlIIllll = urlparse(url)
        h6 = IIlIIllll.netloc
        if bytes.fromhex('3a').decode('utf-8') in h6 and (not h6.split(bytes.fromhex('3a').decode('utf-8'))[-1].isdigit()):
            h6 = h6.split(bytes.fromhex('3a').decode('utf-8'))[0]
        return h6
