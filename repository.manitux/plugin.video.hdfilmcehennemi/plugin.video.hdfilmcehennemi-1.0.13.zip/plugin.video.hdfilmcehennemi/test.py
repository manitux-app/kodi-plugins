from __future__ import absolute_import, print_function, unicode_literals
import argparse
import json
import os
import sys
try:
    from urllib.parse import urlparse
except ImportError:
    from urlparse import urlparse
ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), bytes.fromhex('2e2e').decode('utf-8')))
HTTP_LIB = os.path.join(ROOT_DIR, bytes.fromhex('7363726970742e6d6f64756c652e6d616e6974757868747470').decode('utf-8'), bytes.fromhex('6c6962').decode('utf-8'))
if HTTP_LIB not in sys.path:
    sys.path.insert(0, HTTP_LIB)
ADDON_DIR = os.path.dirname(__file__)
if ADDON_DIR not in sys.path:
    sys.path.insert(0, ADDON_DIR)
from resources.lib.extractor import VideoExtractor
from resources.lib.site import HDFilmCehennemiSite
DEFAULT_USER_AGENT = bytes.fromhex('4d6f7a696c6c612f352e3020285831313b204c696e7578207838365f363429204170706c655765624b69742f3533372e333620284b48544d4c2c206c696b65204765636b6f29204368726f6d652f3132342e30205361666172692f3533372e3336').decode('utf-8')

def base_url_from(url):
    K11 = urlparse(url)
    if not K11.scheme or not K11.netloc:
        return bytes.fromhex('68747470733a2f2f7777772e686466696c6d636568656e6e656d692e6e6c').decode('utf-8')
    return K11.scheme + bytes.fromhex('3a2f2f').decode('utf-8') + K11.netloc

def public_media_info(info):
    R9 = (bytes.fromhex('7469746c65').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('696d616765').decode('utf-8'), bytes.fromhex('6261636b64726f70').decode('utf-8'), bytes.fromhex('706c6f74').decode('utf-8'), bytes.fromhex('74616773').decode('utf-8'), bytes.fromhex('726174696e67').decode('utf-8'), bytes.fromhex('79656172').decode('utf-8'), bytes.fromhex('636f756e747279').decode('utf-8'), bytes.fromhex('6163746f7273').decode('utf-8'), bytes.fromhex('6475726174696f6e').decode('utf-8'))
    return dict(((vvvvvvvv, info.get(vvvvvvvv, bytes.fromhex('').decode('utf-8'))) for vvvvvvvv in R9))

def resolve_source(site, extractor, page_url, source):
    llIIIIIllIIIl = {bytes.fromhex('6c6162656c').decode('utf-8'): source.get(bytes.fromhex('6c6162656c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('766964656f5f6964').decode('utf-8'): source.get(bytes.fromhex('766964656f5f6964').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('706c61795f75726c').decode('utf-8'): source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('69735f747261696c6572').decode('utf-8'): bool(source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8'))), bytes.fromhex('696672616d65').decode('utf-8'): bytes.fromhex('').decode('utf-8'), bytes.fromhex('73747265616d').decode('utf-8'): bytes.fromhex('').decode('utf-8'), bytes.fromhex('7375627469746c6573').decode('utf-8'): [], bytes.fromhex('6572726f72').decode('utf-8'): bytes.fromhex('').decode('utf-8')}
    try:
        if source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8')):
            I14, lllllllllllllll = extractor.resolve(source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), page_url)
            llIIIIIllIIIl[bytes.fromhex('73747265616d').decode('utf-8')] = I14 or bytes.fromhex('').decode('utf-8')
            llIIIIIllIIIl[bytes.fromhex('7375627469746c6573').decode('utf-8')] = lllllllllllllll or []
            return llIIIIIllIIIl
        j7 = site.fetch_source_iframe(source.get(bytes.fromhex('766964656f5f6964').decode('utf-8'), bytes.fromhex('').decode('utf-8')), page_url)
        llIIIIIllIIIl[bytes.fromhex('696672616d65').decode('utf-8')] = j7 or bytes.fromhex('').decode('utf-8')
        if j7:
            I14, lllllllllllllll = extractor.resolve(j7, page_url)
            llIIIIIllIIIl[bytes.fromhex('73747265616d').decode('utf-8')] = I14 or bytes.fromhex('').decode('utf-8')
            llIIIIIllIIIl[bytes.fromhex('7375627469746c6573').decode('utf-8')] = lllllllllllllll or []
    except Exception as exc:
        llIIIIIllIIIl[bytes.fromhex('6572726f72').decode('utf-8')] = repr(exc)
    return llIIIIIllIIIl

def inspect_url(url, user_agent):
    site = HDFilmCehennemiSite(base_url_from(url), user_agent)
    extractor = VideoExtractor(user_agent)
    page = site.get(url, ajax=True)
    print(page)
    info = site.parse_detail(page, url)
    G5 = info.get(bytes.fromhex('657069736f646573').decode('utf-8')) or []
    sources = info.get(bytes.fromhex('736f7572636573').decode('utf-8')) or []
    Y10 = {bytes.fromhex('696e7075745f75726c').decode('utf-8'): url, bytes.fromhex('626173655f75726c').decode('utf-8'): site.base_url, bytes.fromhex('74797065').decode('utf-8'): bytes.fromhex('736572696573').decode('utf-8') if G5 else bytes.fromhex('6d6f7669655f6f725f657069736f6465').decode('utf-8'), bytes.fromhex('6d656469615f696e666f').decode('utf-8'): public_media_info(info), bytes.fromhex('657069736f646573').decode('utf-8'): G5, bytes.fromhex('706c61795f6c696e6b73').decode('utf-8'): sources, bytes.fromhex('7265736f6c7665645f736f7572636573').decode('utf-8'): []}
    if G5:
        aAAAaA = G5[0]
        JWIeEdbMeJPjUNpVSEPCHIycLJvBfjpFMgOIzdoSGUgcmLLPdABgrimqolDdWxLKyHmmopVshZfNgml3 = site.get(aAAAaA[bytes.fromhex('75726c').decode('utf-8')])
        II = site.parse_detail(JWIeEdbMeJPjUNpVSEPCHIycLJvBfjpFMgOIzdoSGUgcmLLPdABgrimqolDdWxLKyHmmopVshZfNgml3, aAAAaA[bytes.fromhex('75726c').decode('utf-8')])
        CCCC = II.get(bytes.fromhex('736f7572636573').decode('utf-8')) or []
        Y10[bytes.fromhex('66697273745f657069736f6465').decode('utf-8')] = {bytes.fromhex('6d656469615f696e666f').decode('utf-8'): public_media_info(II), bytes.fromhex('657069736f6465').decode('utf-8'): aAAAaA, bytes.fromhex('706c61795f6c696e6b73').decode('utf-8'): CCCC, bytes.fromhex('7265736f6c7665645f736f7572636573').decode('utf-8'): [resolve_source(site, extractor, aAAAaA[bytes.fromhex('75726c').decode('utf-8')], source) for source in CCCC if not source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8'))]}
    else:
        Y10[bytes.fromhex('7265736f6c7665645f736f7572636573').decode('utf-8')] = [resolve_source(site, extractor, url, source) for source in sources if not source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8'))]
    return Y10

def page_items(url, user_agent):
    site = HDFilmCehennemiSite(base_url_from(url), user_agent)
    page = site.get_page_items(url)
    print(page)

def main(argv=None):
    AAAAAAAAAAAA = argparse.ArgumentParser(description=bytes.fromhex('484446696c6d436568656e6e656d69206d6564696120696e666f2c20706c6179206c696e6b2076652067657263656b20766964656f206b61796e616b6c6172696e69207465737420656465722e').decode('utf-8'))
    AAAAAAAAAAAA.add_argument(bytes.fromhex('75726c').decode('utf-8'), help=bytes.fromhex('46696c6d2c2064697a69207665796120626f6c756d2055524c277369').decode('utf-8'))
    AAAAAAAAAAAA.add_argument(bytes.fromhex('2d2d757365722d6167656e74').decode('utf-8'), default=DEFAULT_USER_AGENT, help=bytes.fromhex('497374656b6c65726465206b756c6c616e696c6163616b20557365722d4167656e74').decode('utf-8'))
    oNzrUvDdWnSADHRVdQgaPIkGSkXDSgPscVBRNYUqggWFloFKHHDXWmUcyRwdrusgdjrKuipYnEAzkha1 = AAAAAAAAAAAA.parse_args(argv)
    page_items(oNzrUvDdWnSADHRVdQgaPIkGSkXDSgPscVBRNYUqggWFloFKHHDXWmUcyRwdrusgdjrKuipYnEAzkha1.url, oNzrUvDdWnSADHRVdQgaPIkGSkXDSgPscVBRNYUqggWFloFKHHDXWmUcyRwdrusgdjrKuipYnEAzkha1.user_agent)
if __name__ == bytes.fromhex('5f5f6d61696e5f5f').decode('utf-8'):
    main()
