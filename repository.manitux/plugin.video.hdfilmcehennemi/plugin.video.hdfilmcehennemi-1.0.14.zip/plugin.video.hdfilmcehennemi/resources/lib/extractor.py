from __future__ import absolute_import, unicode_literals
import base64
import binascii
import json
import re
import string
import manituxhttp
try:
    from urllib.parse import quote, urlparse, urlunparse
except ImportError:
    from urllib import quote
    from urlparse import urlparse, urlunparse

class VideoExtractor(object):

    def __init__(lIlIl, user_agent):
        lIlIl.user_agent = user_agent
        lIlIl.session = manituxhttp.Session()

    def headers(lIlIl, referer=None):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): lIlIl.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('746578742f68746d6c2c6170706c69636174696f6e2f7868746d6c2b786d6c2c6170706c69636174696f6e2f786d6c3b713d302e392c2a2f2a3b713d302e38').decode('utf-8'), bytes.fromhex('436f6e74656e742d54797065').decode('utf-8'): bytes.fromhex('6170706c69636174696f6e2f6a736f6e').decode('utf-8'), bytes.fromhex('582d5265717565737465642d57697468').decode('utf-8'): bytes.fromhex('584d4c4874747052657175657374').decode('utf-8')}
        if referer:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        return headers

    def hdfilmcehennemi_extractor(lIlIl, url, referer=None):
        url = lIlIl.normalize_url(url)
        referer = referer or url
        page = lIlIl.fetch(url, referer)
        IlIl = lIlIl.origin(url)
        lIlll = []
        source = lIlIl._extract_obfuscated_video_link(page)
        lllII = lIlIl._unpack_first_eval(page)
        if lllII:
            if not source:
                source = lIlIl._extract_obfuscated_video_link(lllII)
            if not source:
                source = lIlIl._first(bytes.fromhex('736f75726365735c732a3a5c732a5c5b5c732a5c7b5c732a66696c655c732a3a5c732a5b275c225d285b5e275c225d2b29').decode('utf-8'), lllII, re.S)
            if not source:
                lI = lIlIl._first(bytes.fromhex('5b225c275d2861485230635b5e225c275d2b295b225c275d').decode('utf-8'), lllII)
                if lI:
                    source = base64.b64decode(lI).decode(bytes.fromhex('7574662d38').decode('utf-8'), bytes.fromhex('7265706c616365').decode('utf-8'))
            lIlll = lIlIl._extract_subtitles(page + bytes.fromhex('0a').decode('utf-8') + lllII, IlIl)
        else:
            source = lIlIl._first(bytes.fromhex('22636f6e74656e7455726c225c732a3a5c732a22285b5e225d2b2922').decode('utf-8'), page)
            if not source:
                source = lIlIl._first(bytes.fromhex('283f3a2266696c65227c66696c65295c732a3a5c732a5b225c275d285b5e225c275d2b29').decode('utf-8'), page)
            lIlll = lIlIl._extract_subtitles(page, IlIl)
        if not source:
            llIl = lIlIl._first(bytes.fromhex('3c696672616d655b5e3e5d2b283f3a7372637c646174612d737263293d5b225c275d285b5e225c275d2b29').decode('utf-8'), page)
            if llIl and llIl != url:
                return lIlIl.resolve(llIl.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')), url)
            IlllI = lIlIl._first(bytes.fromhex('5b3f265d726170696472616d655f69643d285b612d7a302d395d2b29').decode('utf-8'), url)
            if IlllI and referer:
                Illll = lIlIl.origin(referer).rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f72706c617965722f7b307d2f').decode('utf-8').format(IlllI)
                return lIlIl.resolve(Illll, referer)
            return (None, lIlll)
        source = source.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')).replace(bytes.fromhex('5c7530303236').decode('utf-8'), bytes.fromhex('26').decode('utf-8'))
        return (source + lIlIl.kodi_headers(IlIl), lIlll)

    def resolve(lIlIl, url, referer=None):
        if not url:
            return (None, [])
        url = lIlIl.normalize_url(url)
        if lIlIl.is_hdfilm_url(url):
            return lIlIl.hdfilmcehennemi_extractor(url, referer)
        if bytes.fromhex('7669646d6f6c79').decode('utf-8') in url or bytes.fromhex('666c6d706c61796572').decode('utf-8') in url:
            return lIlIl.resolve_vidmoly(url)
        if bytes.fromhex('6f646e6f6b6c6173736e696b69').decode('utf-8') in url or bytes.fromhex('6f6b2e7275').decode('utf-8') in url:
            return lIlIl.resolve_okru(url)
        return (url + lIlIl.kodi_headers(referer), [])

    def resolve_hdfilm_embed(lIlIl, url, referer=None):
        return lIlIl.hdfilmcehennemi_extractor(url, referer)

    def resolve_vidmoly(lIlIl, url):
        url = lIlIl.normalize_url(url).replace(bytes.fromhex('2e746f70').decode('utf-8'), bytes.fromhex('2e746f').decode('utf-8'))
        page = lIlIl.fetch(url, bytes.fromhex('68747470733a2f2f7669646d6f6c792e746f2f').decode('utf-8'))
        lIIII = lIlIl._first(bytes.fromhex('77696e646f775c2e6c6f636174696f6e5c732a3d5c732a27285b5e275d2b2927').decode('utf-8'), page)
        if lIIII:
            page = lIlIl.fetch(url.replace(bytes.fromhex('656d6265642d').decode('utf-8'), lIIII), url)
        source = lIlIl._first(bytes.fromhex('285b5e275c225c735d2b5c2e6d3375385b5e275c225c735d2a29').decode('utf-8'), page)
        llIIl = re.findall(bytes.fromhex('66696c655c732a3a5c732a27285b5e275d2b2f7372745b5e275d2a2927').decode('utf-8'), page)
        return (source + lIlIl.kodi_headers(bytes.fromhex('68747470733a2f2f7669646d6f6c792e746f2f').decode('utf-8')), llIIl)

    def resolve_okru(lIlIl, url):
        url = lIlIl.normalize_url(url)
        llllI = lIlIl._first(bytes.fromhex('283f3a766964656f656d6265642f7c6d69643d29285c642b29').decode('utf-8'), url)
        if not llllI:
            return (url + lIlIl.kodi_headers(bytes.fromhex('68747470733a2f2f6f6b2e72752f').decode('utf-8')), [])
        lIIlI = lIlIl.session.post(bytes.fromhex('68747470733a2f2f7777772e6f6b2e72752f646b').decode('utf-8'), data={bytes.fromhex('636d64').decode('utf-8'): bytes.fromhex('766964656f506c617965724d65746164617461').decode('utf-8'), bytes.fromhex('6d6964').decode('utf-8'): llllI}, headers=lIlIl.headers(bytes.fromhex('68747470733a2f2f6f6b2e72752f').decode('utf-8')), timeout=25)
        lIIlI.raise_for_status()
        data = lIIlI.text
        source = lIlIl._first(bytes.fromhex('283f3a756c7472617c717561647c66756c6c7c68647c73647c6c6f777c6c6f7765737429222c2275726c223a22282e2a3f2922').decode('utf-8'), data)
        return (source.replace(bytes.fromhex('5c7530303236').decode('utf-8'), bytes.fromhex('26').decode('utf-8')) + lIlIl.kodi_headers(bytes.fromhex('68747470733a2f2f6f6b2e72752f').decode('utf-8')), [])

    def fetch(lIlIl, url, referer=None):
        lIIlI = lIlIl.session.get(url, headers=lIlIl.headers(referer), timeout=25, allow_redirects=True)
        lIIlI.raise_for_status()
        return lIIlI.text

    def normalize_url(lIlIl, url):
        if url.startswith(bytes.fromhex('2f2f').decode('utf-8')):
            url = bytes.fromhex('68747470733a').decode('utf-8') + url
        elif url.startswith(bytes.fromhex('7777772e').decode('utf-8')):
            url = bytes.fromhex('68747470733a2f2f').decode('utf-8') + url
        elif not url.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8'))):
            url = bytes.fromhex('68747470733a2f2f').decode('utf-8') + url
        IIllI = urlparse(url)
        return urlunparse(IIllI._replace(scheme=bytes.fromhex('6874747073').decode('utf-8')))

    def kodi_headers(lIlIl, referer=None):
        III = [bytes.fromhex('557365722d4167656e743d').decode('utf-8') + quote(lIlIl.user_agent)]
        if referer:
            III.append(bytes.fromhex('526566657265723d').decode('utf-8') + quote(referer))
        return bytes.fromhex('7c').decode('utf-8') + bytes.fromhex('26').decode('utf-8').join(III)

    def is_hdfilm_url(lIlIl, url):
        lIlI = urlparse(url).netloc.lower()
        return bytes.fromhex('686466696c6d636568656e6e656d69').decode('utf-8') in lIlI or bytes.fromhex('64697a69636568656e6e656d69').decode('utf-8') in lIlI or bytes.fromhex('706c61796d6978').decode('utf-8') in lIlI or (bytes.fromhex('726170696472616d65').decode('utf-8') in lIlI)

    def origin(lIlIl, url):
        IIllI = urlparse(url)
        return IIllI.scheme + bytes.fromhex('3a2f2f').decode('utf-8') + IIllI.netloc

    def _extract_subtitles(lIlIl, page, origin):
        llIIl = []
        for llIII in re.findall(bytes.fromhex('2266696c65225c732a3a5c732a22285b5e225d2b29225b5e7b7d5d2a226b696e64225c732a3a5c732a2263617074696f6e7322').decode('utf-8'), page, re.S):
            llIIl.append(lIlIl._absolute_url(llIII.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')), origin))
        for llIll in re.findall(bytes.fromhex('747261636b735c732a3a5c732a285c5b2e2a3f5c5d295c732a2c').decode('utf-8'), page, re.S):
            for llIII in re.findall(bytes.fromhex('2266696c65225c732a3a5c732a22285b5e225d2b2922').decode('utf-8'), llIll):
                llIIl.append(lIlIl._absolute_url(llIII.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')), origin))
        for llIII in re.findall(bytes.fromhex('747261636b5c732b7372633d5b275c225d285b5e275c225d2b29').decode('utf-8'), page, re.S | re.I):
            llIIl.append(lIlIl._absolute_url(llIII.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')), origin))
        return list(dict.fromkeys(llIIl))

    def _absolute_url(lIlIl, url, origin):
        if url.startswith(bytes.fromhex('2f2f').decode('utf-8')):
            return bytes.fromhex('68747470733a').decode('utf-8') + url
        if url.startswith(bytes.fromhex('2f').decode('utf-8')):
            return origin.rstrip(bytes.fromhex('2f').decode('utf-8')) + url
        return url

    def _unpack_first_eval(lIlIl, page):
        IIIIl = re.search(bytes.fromhex('6576616c5c2866756e6374696f6e5c28702c612c632c6b2c652c645c292e2a3f5c7d5c28283f503c7061796c6f61643e5b275c225d2e2a3f5b275c225d295c732a2c5c732a283f503c626173653e5c642b295c732a2c5c732a283f503c636f756e743e5c642b295c732a2c5c732a283f503c73796d626f6c733e5b275c225d2e2a3f5b275c225d295c2e73706c69745c285b275c225d5c7c5b275c225d5c29').decode('utf-8'), page, re.S)
        if not IIIIl:
            return bytes.fromhex('').decode('utf-8')
        IlIll = lIlIl._js_string(IIIIl.group(bytes.fromhex('7061796c6f6164').decode('utf-8')))
        ll = int(IIIIl.group(bytes.fromhex('62617365').decode('utf-8')))
        IIII = int(IIIIl.group(bytes.fromhex('636f756e74').decode('utf-8')))
        llIlI = lIlIl._js_string(IIIIl.group(bytes.fromhex('73796d626f6c73').decode('utf-8'))).split(bytes.fromhex('7c').decode('utf-8'))
        if IIII > len(llIlI):
            llIlI.extend([bytes.fromhex('').decode('utf-8')] * (IIII - len(llIlI)))
        for lllI in range(IIII - 1, -1, -1):
            lllll = lIlIl._base_n(lllI, ll)
            if llIlI[lllI]:
                IlIll = re.sub(bytes.fromhex('5c62').decode('utf-8') + re.escape(lllll) + bytes.fromhex('5c62').decode('utf-8'), llIlI[lllI], IlIll)
        return IlIll

    def _js_string(lIlIl, lllIl):
        IllIl = lllIl[0]
        if lllIl[-1] == IllIl:
            lllIl = lllIl[1:-1]
        return bytes(lllIl, bytes.fromhex('7574662d38').decode('utf-8')).decode(bytes.fromhex('756e69636f64655f657363617065').decode('utf-8'))

    def _base_n(lIlIl, IIlII, ll):
        I = string.digits + string.ascii_lowercase + string.ascii_uppercase
        if IIlII == 0:
            return bytes.fromhex('30').decode('utf-8')
        lIIll = bytes.fromhex('').decode('utf-8')
        while IIlII:
            IIlII, lIIIl = divmod(IIlII, ll)
            lIIll = I[lIIIl] + lIIll
        return lIIll

    def _decode_obfuscated_source(lIlIl, page):
        IIIIl = re.search(bytes.fromhex('7661725c732b28735f5b412d5a612d7a302d395f5d2b295c732a3d5c732a2864635f5b412d5a612d7a302d395f5d2b295c28285c5b2e2a3f5c5d295c29').decode('utf-8'), page, re.S)
        if not IIIIl:
            return bytes.fromhex('').decode('utf-8')
        IlIIl = json.loads(IIIIl.group(3).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')))
        lllIl = bytes.fromhex('').decode('utf-8').join(IlIIl)
        lllIl = lIlIl._rot13(lllIl)[::-1]
        IIIl = base64.b64decode(lllIl).decode(bytes.fromhex('6c6174696e2d31').decode('utf-8'))
        llI = []
        for llII, lII in enumerate(IIIl):
            lll = (ord(lII) - 399756995 % (llII + 5) + 256) % 256
            llI.append(chr(lll))
        return bytes.fromhex('').decode('utf-8').join(llI)

    @staticmethod
    def _rot13(lllIl):
        IIlIl = []
        for lII in lllIl:
            lll = ord(lII)
            if 65 <= lll <= 90:
                IIlIl.append(chr((lll - 65 + 13) % 26 + 65))
            elif 97 <= lll <= 122:
                IIlIl.append(chr((lll - 97 + 13) % 26 + 97))
            else:
                IIlIl.append(lII)
        return bytes.fromhex('').decode('utf-8').join(IIlIl)

    def _extract_obfuscated_video_link(lIlIl, lIll):
        for IlI in lIlIl._get_base64_candidates_from_html(lIll):
            source = lIlIl._try_decrypt_candidate(IlI)
            if source:
                return source
        source = lIlIl._decode_obfuscated_source(lIll)
        if source:
            return lIlIl._get_url(source)
        return lIlIl._direct_video_link(lIll)

    def _try_decrypt_candidate(lIlIl, lllIl):
        lIllI = (lambda IIIIII: lIlIl._unmix(lIlIl._rot13(lIlIl._base64_decode_js(IIIIII[::-1]))), lambda IIIIII: lIlIl._unmix(lIlIl._base64_decode_js(lIlIl._rot13(IIIIII))[::-1]), lambda IIIIII: lIlIl._unmix(lIlIl._rot13(lIlIl._base64_decode_js(IIIIII))[::-1]), lambda IIIIII: lIlIl._unmix(lIlIl._base64_decode_js(lIlIl._base64_decode_js(IIIIII[::-1]))), lambda IIIIII: lIlIl._unmix(lIlIl._base64_decode_js(lIlIl._rot13(IIIIII)[::-1])), lIlIl._decrypt_rot13_base64_reverse_unmix, lIlIl._decrypt_reversed_double_base64_unmix, lIlIl._decrypt_text_base64_rot13_reverse_unmix, lIlIl._decrypt_rot13_reversed_base64_unmix)
        for IIlI in lIllI:
            try:
                IIIl = IIlI(lllIl)
            except Exception:
                IIIl = None
            source = lIlIl._get_url(IIIl)
            if source:
                return source
        return None

    def _decrypt_rot13_base64_reverse_unmix(lIlIl, lllIl):
        IIIl = lIlIl._base64_decode_js(lIlIl._rot13(lllIl))
        if not IIIl:
            return None
        return lIlIl._get_url(lIlIl._unmix(IIIl[::-1]))

    def _decrypt_reversed_double_base64_unmix(lIlIl, lllIl):
        lIII = lIlIl._base64_decode_js(lllIl[::-1])
        if not lIII:
            return None
        lIlII = lIlIl._base64_decode_js(lIII)
        if not lIlII:
            return None
        return lIlIl._get_url(lIlIl._unmix(lIlII))

    def _decrypt_text_base64_rot13_reverse_unmix(lIlIl, lllIl):
        IIIl = lIlIl._base64_decode_js(lllIl)
        if not IIIl or lIlIl._printable_ratio(IIIl) <= 0.75:
            return None
        return lIlIl._get_url(lIlIl._unmix(lIlIl._rot13(IIIl)[::-1]))

    def _decrypt_rot13_reversed_base64_unmix(lIlIl, lllIl):
        IIIl = lIlIl._base64_decode_js(lIlIl._rot13(lllIl)[::-1])
        if not IIIl or lIlIl._printable_ratio(IIIl) <= 0.75:
            return None
        return lIlIl._get_url(lIlIl._unmix(IIIl))

    def _get_base64_candidates_from_html(lIlIl, lIll):
        Ill = []
        lIlIl._add_direct_array_values(lIll, Ill)
        lIlIl._add_quoted_base64_values(lIll, Ill)
        lllII = lIlIl._unpack_first_eval(lIll)
        if lllII:
            lIlIl._add_direct_array_values(lllII, Ill)
            lIlIl._add_quoted_base64_values(lllII, Ill)
        lIlIl._add_packed_array_values(lIll, Ill)
        lIIll = []
        for IlI in Ill:
            IlI = (IlI or bytes.fromhex('').decode('utf-8')).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')).strip()
            if lIlIl._is_likely_encrypted_payload(IlI) and IlI not in lIIll:
                lIIll.append(IlI)
        return lIIll

    def _add_direct_array_values(lIlIl, lIll, Ill):
        II = re.compile(bytes.fromhex('5c625c772b5c732a5c285c732a285c5b5c732a283f3a5c225b5e5c225d2a5c227c275b5e275d2a27295c732a283f3a2c5c732a283f3a5c225b5e5c225d2a5c227c275b5e275d2a27295c732a292a5c5d295c732a5c29').decode('utf-8'), re.S)
        for IIIIl in II.finditer(lIll or bytes.fromhex('').decode('utf-8')):
            Il = IIIIl.group(1)
            IIllI = lIlIl._parse_string_array(Il)
            if IIllI:
                Ill.append(IIllI)
            else:
                IlIIl = re.findall(bytes.fromhex('5b22275d285b5e22275d2b295b22275d').decode('utf-8'), Il)
                Ill.append(bytes.fromhex('').decode('utf-8').join(IlIIl))

    def _add_quoted_base64_values(lIlIl, lIll, Ill):
        IlIlI = re.compile(bytes.fromhex('5b22275d283f503c76616c75653e283f3a3d7b302c327d295b412d5a612d7a302d392b2f5d7b38302c7d3d7b302c327d295b22275d').decode('utf-8'), re.S)
        for IIIIl in IlIlI.finditer(lIll or bytes.fromhex('').decode('utf-8')):
            Ill.append(IIIIl.group(bytes.fromhex('76616c7565').decode('utf-8')))

    def _add_packed_array_values(lIlIl, lIll, Ill):
        Illl = re.compile(bytes.fromhex('6576616c5c2866756e6374696f6e5c28702c612c632c6b2c652c645c292e2a3f5c2e73706c69745c285b275c225d5c7c5b275c225d5c292c5c642b2c5c7b5c7d5c295c29').decode('utf-8'), re.S)
        for IllI in Illl.finditer(lIll or bytes.fromhex('').decode('utf-8')):
            IIl = IllI.group(0)
            IIll = re.search(bytes.fromhex('5b27225d285b5e27225d2a295b27225d5c2e73706c6974').decode('utf-8'), IIl, re.S)
            if not IIll:
                continue
            IlII = IIll.group(1).split(bytes.fromhex('7c').decode('utf-8'))
            llll = string.digits + string.ascii_lowercase + string.ascii_uppercase
            for l in re.finditer(bytes.fromhex('5c5b5c732a285b22275d2e2a3f5b22275d5c732a2c3f5c732a292b5c732a5c5d').decode('utf-8'), IIl, re.S):
                IlIIl = []
                for IlIII in re.finditer(bytes.fromhex('5b22275d283f503c76616c3e2e2a3f295b22275d').decode('utf-8'), l.group(0), re.S):
                    IIlll = re.sub(bytes.fromhex('5c772b').decode('utf-8'), lambda IIIII: lIlIl._base62_lookup(IIIII.group(0), llll, IlII), IlIII.group(bytes.fromhex('76616c').decode('utf-8')))
                    IlIIl.append(IIlll)
                Ill.append(bytes.fromhex('').decode('utf-8').join(IlIIl))

    def _parse_string_array(lIlIl, Il):
        IIIll = re.sub(bytes.fromhex('27285b5e275c5c5d2a283f3a5c5c2e5b5e275c5c5d2a292a2927').decode('utf-8'), lambda IIIII: json.dumps(IIIII.group(1)), Il)
        try:
            return bytes.fromhex('').decode('utf-8').join(json.loads(IIIll))
        except (TypeError, ValueError):
            return bytes.fromhex('').decode('utf-8')

    def _base62_lookup(lIlIl, lllIl, llll, IlII):
        lllI = 0
        IIIlI = 1
        for lII in reversed(lllIl):
            lIl = llll.find(lII)
            if lIl == -1:
                return lllIl
            lllI += lIl * IIIlI
            IIIlI *= 62
        if lllI < len(IlII) and IlII[lllI]:
            return IlII[lllI]
        return lllIl

    def _base64_decode_js(lIlIl, lllIl):
        if not lllIl:
            return bytes.fromhex('').decode('utf-8')
        try:
            if not isinstance(lllIl, bytes):
                lllIl = lllIl.encode(bytes.fromhex('6c6174696e2d31').decode('utf-8'))
            lllIl += b'=' * ((4 - len(lllIl) % 4) % 4)
            return base64.b64decode(lllIl).decode(bytes.fromhex('6c6174696e2d31').decode('utf-8'))
        except (TypeError, binascii.Error, UnicodeError):
            return bytes.fromhex('').decode('utf-8')

    def _is_likely_encrypted_payload(lIlIl, lllIl):
        if len(lllIl) < 40:
            return False
        IIII = sum((1 for lII in lllIl if lII.isalnum() or lII in bytes.fromhex('2b2f3d').decode('utf-8')))
        return float(IIII) / len(lllIl) > 0.85

    def _unmix(lIlIl, lllIl):
        llI = []
        for llII, lII in enumerate(lllIl):
            lll = (ord(lII) - 399756995 % (llII + 5) + 256) % 256
            llI.append(chr(lll))
        return bytes.fromhex('').decode('utf-8').join(llI)

    def _printable_ratio(lIlIl, lllIl):
        if not lllIl:
            return 0
        IllII = sum((1 for lII in lllIl if lII in bytes.fromhex('0d0a09').decode('utf-8') or bytes.fromhex('20').decode('utf-8') <= lII <= bytes.fromhex('7e').decode('utf-8')))
        return float(IllII) / len(lllIl)

    def _get_url(lIlIl, lllIl):
        lllIl = (lllIl or bytes.fromhex('').decode('utf-8')).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')).replace(bytes.fromhex('5c7530303236').decode('utf-8'), bytes.fromhex('26').decode('utf-8')).replace(bytes.fromhex('7530303236').decode('utf-8'), bytes.fromhex('26').decode('utf-8'))
        IIIIl = re.search(bytes.fromhex('68747470733f3a2f2f5b5e5c7322277c3c3e5d2b').decode('utf-8'), lllIl)
        return IIIIl.group(0) if IIIIl else None

    def _direct_video_link(lIlIl, lIll):
        lllII = lIlIl._unpack_first_eval(lIll)
        for source in (lllII, lIll):
            IIIIl = re.search(bytes.fromhex('68747470733f3a5c5c3f2f5c5c3f2f5b5e22275c733c3e5d2b3f5c2e6d3375385b5e22275c733c3e5d2a').decode('utf-8'), source or bytes.fromhex('').decode('utf-8'), re.I)
            if IIIIl:
                return IIIIl.group(0).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'))
        return None

    @staticmethod
    def _first(IlIlI, text, lIIl=0):
        IIIIl = re.search(IlIlI, text or bytes.fromhex('').decode('utf-8'), lIIl | re.I)
        return IIIIl.group(1) if IIIIl else bytes.fromhex('').decode('utf-8')
