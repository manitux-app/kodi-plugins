from __future__ import absolute_import, unicode_literals
import html
import json
import re
try:
    from urllib.parse import urljoin
except ImportError:
    from urlparse import urljoin

def categories(base_url):
    base_url = base_url.rstrip(bytes.fromhex('2f').decode('utf-8'))
    return [(bytes.fromhex('59656e6920456b6c656e656e2046696c6d6c6572').decode('utf-8'), base_url + bytes.fromhex('2f6c6f61642f706167652f5b706167654e756d6265725d2f686f6d652f').decode('utf-8')), (bytes.fromhex('59656e6920456b6c656e656e2044697a696c6572').decode('utf-8'), base_url + bytes.fromhex('2f6c6f61642f706167652f5b706167654e756d6265725d2f686f6d652d7365726965732f').decode('utf-8')), (bytes.fromhex('54c3bc726bc3a765204475626c616a2046696c6d6c6572').decode('utf-8'), base_url + bytes.fromhex('2f6c6f61642f706167652f5b706167654e756d6265725d2f6c616e6775616765732f7475726b63652d6475626c616a6c692d66696c6d2d697a6c6579696e2d352f').decode('utf-8')), (bytes.fromhex('54c3bc726bc3a76520416c7479617ac4b16cc4b12046696c6d6c6572').decode('utf-8'), base_url + bytes.fromhex('2f6c6f61642f706167652f5b706167654e756d6265725d2f6c616e6775616765732f7475726b63652d616c7479617a696c692d66696c6d6c6572692d697a6c656d652d7369746573692d332f').decode('utf-8')), (bytes.fromhex('41696c652046696c6d6c657269').decode('utf-8'), base_url + bytes.fromhex('2f7475722f61696c652d66696c6d6c6572692d697a6c6579696e2d37').decode('utf-8')), (bytes.fromhex('416b7369796f6e2046696c6d6c657269').decode('utf-8'), base_url + bytes.fromhex('2f7475722f616b7369796f6e2d66696c6d6c6572692d697a6c6579696e2d37').decode('utf-8')), (bytes.fromhex('416e696d6173796f6e2046696c6d6c657269').decode('utf-8'), base_url + bytes.fromhex('2f7475722f616e696d6173796f6e2d66696c6d6c6572696e692d697a6c6579696e2d35').decode('utf-8')), (bytes.fromhex('42656c676573656c2046696c6d6c657269').decode('utf-8'), base_url + bytes.fromhex('2f7475722f62656c676573656c2d66696c6d6c6572696e692d697a6c652d32').decode('utf-8')), (bytes.fromhex('42696c696d204b757267752046696c6d6c657269').decode('utf-8'), base_url + bytes.fromhex('2f7475722f62696c696d2d6b757267752d66696c6d6c6572696e692d697a6c6579696e2d35').decode('utf-8')), (bytes.fromhex('4269796f67726166692046696c6d6c657269').decode('utf-8'), base_url + bytes.fromhex('2f7475722f6269796f67726166692d66696c6d6c6572692d697a6c652d33').decode('utf-8')), (bytes.fromhex('4472616d2046696c6d6c657269').decode('utf-8'), base_url + bytes.fromhex('2f7475722f6472616d2d66696c6d6c6572696e692d697a6c652d32').decode('utf-8')), (bytes.fromhex('46616e74617374696b2046696c6d6c657269').decode('utf-8'), base_url + bytes.fromhex('2f7475722f66616e74617374696b2d66696c6d6c6572696e692d697a6c6579696e2d33').decode('utf-8')), (bytes.fromhex('476572696c696d2046696c6d6c657269').decode('utf-8'), base_url + bytes.fromhex('2f7475722f676572696c696d2d66696c6d6c6572696e692d697a6c652d32').decode('utf-8')), (bytes.fromhex('47697a656d2046696c6d6c657269').decode('utf-8'), base_url + bytes.fromhex('2f7475722f67697a656d2d66696c6d6c6572692d697a6c652d33').decode('utf-8')), (bytes.fromhex('4b6f6d6564692046696c6d6c657269').decode('utf-8'), base_url + bytes.fromhex('2f7475722f6b6f6d6564692d66696c6d6c6572696e692d697a6c6579696e2d32').decode('utf-8')), (bytes.fromhex('4b6f726b752046696c6d6c657269').decode('utf-8'), base_url + bytes.fromhex('2f7475722f6b6f726b752d66696c6d6c6572696e692d697a6c652d35').decode('utf-8')), (bytes.fromhex('4d61636572612046696c6d6c657269').decode('utf-8'), base_url + bytes.fromhex('2f7475722f6d61636572612d66696c6d6c6572696e692d697a6c6579696e2d34').decode('utf-8')), (bytes.fromhex('526f6d616e74696b2046696c6d6c657269').decode('utf-8'), base_url + bytes.fromhex('2f7475722f726f6d616e74696b2d66696c6d6c6572692d697a6c652d33').decode('utf-8')), (bytes.fromhex('53617661c59f2046696c6d6c657269').decode('utf-8'), base_url + bytes.fromhex('2f7475722f73617661732d66696c6d6c6572692d697a6c652d35').decode('utf-8')), (bytes.fromhex('53706f722046696c6d6c657269').decode('utf-8'), base_url + bytes.fromhex('2f7475722f73706f722d66696c6d6c6572692d697a6c652d33').decode('utf-8')), (bytes.fromhex('5375c3a72046696c6d6c657269').decode('utf-8'), base_url + bytes.fromhex('2f7475722f7375632d66696c6d6c6572692d697a6c652d33').decode('utf-8')), (bytes.fromhex('54617269682046696c6d6c657269').decode('utf-8'), base_url + bytes.fromhex('2f7475722f74617269682d66696c6d6c6572692d697a6c652d35').decode('utf-8')), (bytes.fromhex('5765737465726e2046696c6d6c657269').decode('utf-8'), base_url + bytes.fromhex('2f7475722f7765737465726e2d66696c6d6c6572692d697a6c652d33').decode('utf-8'))]

def page_api_url(IIII, page_number):
    url = IIII
    if bytes.fromhex('2f7475722f').decode('utf-8') in url:
        url = url.replace(bytes.fromhex('2f7475722f').decode('utf-8'), bytes.fromhex('2f6c6f61642f706167652f5b706167654e756d6265725d2f67656e7265732f').decode('utf-8'))
    return url.replace(bytes.fromhex('5b706167654e756d6265725d').decode('utf-8'), str(page_number))

def html_from_load_response(IIIlI):
    try:
        IIIl = json.loads(IIIlI)
    except Exception:
        return IIIlI
    return IIIl.get(bytes.fromhex('68746d6c').decode('utf-8'), bytes.fromhex('').decode('utf-8')) if isinstance(IIIl, dict) else bytes.fromhex('').decode('utf-8')

def parse_page_items(IIlI, base_url, lll=bytes.fromhex('').decode('utf-8')):
    lIII = []
    IlIll = set()
    for lIl in III(IIlI):
        IIll = I(lIl, bytes.fromhex('68726566').decode('utf-8'))
        title = l(lI(bytes.fromhex('3c7374726f6e675b5e3e5d2a636c6173733d225b5e225d2a5c62706f737465722d7469746c655c625b5e225d2a225b5e3e5d2a3e282e2a3f293c2f7374726f6e673e').decode('utf-8'), lIl, re.S))
        IIlII = I(lI(bytes.fromhex('3c696d675c625b5e3e5d2a3e').decode('utf-8'), lIl, re.S), bytes.fromhex('646174612d737263').decode('utf-8')) or I(lI(bytes.fromhex('3c696d675c625b5e3e5d2a3e').decode('utf-8'), lIl, re.S), bytes.fromhex('737263').decode('utf-8'))
        year = l(lI(bytes.fromhex('3c6469765b5e3e5d2a636c6173733d225b5e225d2a5c62706f737465722d696e666f5c625b5e225d2a225b5e3e5d2a3e2e2a3f3c7370616e5b5e3e5d2a3e282e2a3f293c2f7370616e3e').decode('utf-8'), lIl, re.S))
        rating = l(lI(bytes.fromhex('3c7370616e5b5e3e5d2a636c6173733d225b5e225d2a5c62696d64625c625b5e225d2a225b5e3e5d2a3e282e2a3f293c2f7370616e3e').decode('utf-8'), lIl, re.S))
        if not title or not IIll:
            continue
        url = fix_url(IIll, base_url)
        if url in IlIll:
            continue
        IlIll.add(url)
        lIII.append({bytes.fromhex('63617465676f7279').decode('utf-8'): lll, bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('696d616765').decode('utf-8'): fix_url(IIlII, base_url) if IIlII else bytes.fromhex('').decode('utf-8'), bytes.fromhex('726174696e67').decode('utf-8'): rating, bytes.fromhex('79656172').decode('utf-8'): year, bytes.fromhex('706c6f74').decode('utf-8'): bytes.fromhex('20').decode('utf-8').join((lIIll for lIIll in [year, rating] if lIIll))})
    return lIII

def parse_search_results(IIIlI, base_url):
    lIII = []
    try:
        IIIl = json.loads(IIIlI)
    except Exception:
        IIIl = {}
    for IlIII in IIIl.get(bytes.fromhex('726573756c7473').decode('utf-8'), []) if isinstance(IIIl, dict) else []:
        title = l(lI(bytes.fromhex('3c68345b5e3e5d2a636c6173733d225b5e225d2a5c627469746c655c625b5e225d2a225b5e3e5d2a3e282e2a3f293c2f68343e').decode('utf-8'), IlIII, re.S))
        Ill = lI(bytes.fromhex('3c615c625b5e3e5d2a3e').decode('utf-8'), IlIII, re.S)
        IIll = I(Ill, bytes.fromhex('68726566').decode('utf-8'))
        IllI = lI(bytes.fromhex('3c696d675c625b5e3e5d2a3e').decode('utf-8'), IlIII, re.S)
        IIlII = I(IllI, bytes.fromhex('646174612d737263').decode('utf-8')) or I(IllI, bytes.fromhex('737263').decode('utf-8'))
        if title and IIll:
            image = fix_url(IIlII, base_url).replace(bytes.fromhex('2f7468756d622f').decode('utf-8'), bytes.fromhex('2f6c6973742f').decode('utf-8')) if IIlII else bytes.fromhex('').decode('utf-8')
            lIII.append({bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): fix_url(IIll, base_url), bytes.fromhex('696d616765').decode('utf-8'): image, bytes.fromhex('706c6f74').decode('utf-8'): bytes.fromhex('').decode('utf-8')})
    return lIII

def parse_media_info(page, url, base_url):
    title = l(lI(bytes.fromhex('3c68315b5e3e5d2a636c6173733d225b5e225d2a5c6273656374696f6e2d7469746c655c625b5e225d2a225b5e3e5d2a3e282e2a3f293c2f68313e').decode('utf-8'), page, re.S))
    IIlIl = lI(bytes.fromhex('3c61736964655b5e3e5d2a636c6173733d225b5e225d2a5c62706f73742d696e666f2d706f737465725c625b5e225d2a225b5e3e5d2a3e2e2a3f3c2f61736964653e').decode('utf-8'), page, re.S)
    IIllI = lI(bytes.fromhex('3c696d675c625b5e3e5d2a3e').decode('utf-8'), IIlIl, re.S)
    IIlII = I(IIllI, bytes.fromhex('646174612d737263').decode('utf-8')) or I(IIllI, bytes.fromhex('737263').decode('utf-8'))
    backdrop = Il(page)
    plot = l(lI(bytes.fromhex('3c61727469636c655b5e3e5d2a636c6173733d225b5e225d2a5c62706f73742d696e666f2d636f6e74656e745c625b5e225d2a225b5e3e5d2a3e5c732a3c705b5e3e5d2a3e282e2a3f293c2f703e').decode('utf-8'), page, re.S))
    tags = bytes.fromhex('2c20').decode('utf-8').join((l(lIIll) for lIIll in re.findall(bytes.fromhex('3c6469765b5e3e5d2a636c6173733d225b5e225d2a5c62706f73742d696e666f2d67656e7265735c625b5e225d2a225b5e3e5d2a3e2e2a3f3c615b5e3e5d2a3e282e2a3f293c2f613e').decode('utf-8'), page, re.S)))
    rating = l(lI(bytes.fromhex('3c6469765b5e3e5d2a636c6173733d225b5e225d2a5c62706f73742d696e666f2d696d64622d726174696e675c625b5e225d2a225b5e3e5d2a3e2e2a3f3c7370616e5b5e3e5d2a3e282e2a3f293c2f7370616e3e').decode('utf-8'), page, re.S)).split(bytes.fromhex('28').decode('utf-8'))[0].strip()
    lIlII = lI(bytes.fromhex('3c6469765b5e3e5d2a636c6173733d225b5e225d2a5c62706f73742d696e666f2d796561722d636f756e7472795c625b5e225d2a225b5e3e5d2a3e282e2a3f293c2f6469763e').decode('utf-8'), page, re.S)
    year = l(lI(bytes.fromhex('3c615b5e3e5d2a3e282e2a3f293c2f613e').decode('utf-8'), lIlII, re.S))
    country = l(lI(bytes.fromhex('3c615b5e3e5d2a687265663d225b5e225d2a2f756c6b652f5b5e225d2a225b5e3e5d2a3e282e2a3f293c2f613e').decode('utf-8'), lIlII, re.S))
    IlI = II(page)
    duration = lI(bytes.fromhex('3c6469765b5e3e5d2a636c6173733d225b5e225d2a5c62706f73742d696e666f2d6475726174696f6e5c625b5e225d2a225b5e3e5d2a3e282e2a3f293c2f6469763e').decode('utf-8'), page, re.S)
    duration = lI(bytes.fromhex('285c642b29').decode('utf-8'), l(duration))
    episodes = parse_episodes(page, base_url)
    IlIIl = parse_related(page, base_url)
    sources = parse_video_sources(page, base_url)
    lIIII = lI(bytes.fromhex('646174612d6d6f64616c3d22747261696c65722f285b5e225d2b2922').decode('utf-8'), page)
    if lIIII and lIIII != bytes.fromhex('30').decode('utf-8'):
        sources.insert(0, {bytes.fromhex('6c6162656c').decode('utf-8'): bytes.fromhex('467261676d616e').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): bytes.fromhex('68747470733a2f2f7777772e796f75747562652e636f6d2f656d6265642f').decode('utf-8') + lIIII, bytes.fromhex('766964656f5f6964').decode('utf-8'): bytes.fromhex('').decode('utf-8'), bytes.fromhex('69735f747261696c6572').decode('utf-8'): True})
    if not backdrop or backdrop.startswith(bytes.fromhex('646174613a696d616765').decode('utf-8')):
        backdrop = IIlII
    return {bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('696d616765').decode('utf-8'): fix_url(IIlII, base_url) if IIlII else bytes.fromhex('').decode('utf-8'), bytes.fromhex('6261636b64726f70').decode('utf-8'): fix_url(backdrop, base_url) if backdrop else bytes.fromhex('').decode('utf-8'), bytes.fromhex('706c6f74').decode('utf-8'): plot, bytes.fromhex('74616773').decode('utf-8'): tags, bytes.fromhex('726174696e67').decode('utf-8'): rating, bytes.fromhex('79656172').decode('utf-8'): year, bytes.fromhex('636f756e747279').decode('utf-8'): country, bytes.fromhex('6163746f7273').decode('utf-8'): IlI, bytes.fromhex('6475726174696f6e').decode('utf-8'): duration, bytes.fromhex('736f7572636573').decode('utf-8'): sources, bytes.fromhex('657069736f646573').decode('utf-8'): episodes, bytes.fromhex('72656c61746564').decode('utf-8'): IlIIl}

def parse_episodes(page, base_url):
    episodes = []
    IlIll = set()
    for lIl in re.findall(bytes.fromhex('3c615c625b5e3e5d2a636c6173733d225b5e225d2a5c626d696e692d706f737465725c625b5e225d2a225b5e3e5d2a3e2e2a3f3c2f613e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
        title = l(lI(bytes.fromhex('3c68345b5e3e5d2a3e282e2a3f293c2f68343e').decode('utf-8'), lIl, re.S))
        IIll = I(lIl, bytes.fromhex('68726566').decode('utf-8'))
        if not IIll or not re.search(bytes.fromhex('2f73657a6f6e2d5c642b2f626f6c756d2d5c642b2f').decode('utf-8'), IIll, re.I):
            continue
        IlIlI = lI(bytes.fromhex('285c642b295c2e3f5c732a53657a6f6e').decode('utf-8'), title, re.I) or lI(bytes.fromhex('2f73657a6f6e2d285c642b292f').decode('utf-8'), IIll, re.I) or bytes.fromhex('31').decode('utf-8')
        episode = lI(bytes.fromhex('285c642b295c2e3f5c732a425b6fc3b65d6c5b75c3bc5d6d').decode('utf-8'), title, re.I) or lI(bytes.fromhex('2f626f6c756d2d285c642b292f').decode('utf-8'), IIll, re.I) or bytes.fromhex('31').decode('utf-8')
        key = (IlIlI, episode)
        if key in IlIll:
            continue
        IlIll.add(key)
        episodes.append({bytes.fromhex('7469746c65').decode('utf-8'): title or bytes.fromhex('7b307d2e2053657a6f6e207b317d2e20426f6c756d').decode('utf-8').format(IlIlI, episode), bytes.fromhex('75726c').decode('utf-8'): fix_url(IIll, base_url), bytes.fromhex('736561736f6e').decode('utf-8'): IlIlI, bytes.fromhex('657069736f6465').decode('utf-8'): episode})
    return sorted(episodes, key=lambda item: (int(item[bytes.fromhex('736561736f6e').decode('utf-8')]), int(item[bytes.fromhex('657069736f6465').decode('utf-8')])))

def parse_related(page, base_url):
    IlIIl = []
    for lIl in re.findall(bytes.fromhex('3c6469765b5e3e5d2a636c6173733d225b5e225d2a5c62736c696465722d736c6964655c625b5e225d2a225b5e3e5d2a3e2e2a3f3c2f6469763e').decode('utf-8'), page, re.S):
        title = l(lI(bytes.fromhex('3c7374726f6e675b5e3e5d2a636c6173733d225b5e225d2a5c62706f737465722d7469746c655c625b5e225d2a225b5e3e5d2a3e282e2a3f293c2f7374726f6e673e').decode('utf-8'), lIl, re.S))
        IIll = I(lI(bytes.fromhex('3c615c625b5e3e5d2a3e').decode('utf-8'), lIl, re.S), bytes.fromhex('68726566').decode('utf-8'))
        Illl = lI(bytes.fromhex('3c696d675c625b5e3e5d2a3e').decode('utf-8'), lIl, re.S)
        IIlII = I(Illl, bytes.fromhex('646174612d737263').decode('utf-8')) or (I(Illl, bytes.fromhex('646174612d737263736574').decode('utf-8')).split(bytes.fromhex('3178').decode('utf-8'))[0].strip() if I(Illl, bytes.fromhex('646174612d737263736574').decode('utf-8')) else bytes.fromhex('').decode('utf-8')) or I(Illl, bytes.fromhex('737263').decode('utf-8'))
        if title and IIll:
            IlIIl.append({bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): fix_url(IIll, base_url), bytes.fromhex('696d616765').decode('utf-8'): fix_url(IIlII, base_url) if IIlII else bytes.fromhex('').decode('utf-8')})
    return IlIIl

def parse_video_sources(page, base_url):
    sources = []
    IllII = set()
    llII = {}
    for llI in re.findall(bytes.fromhex('3c627574746f6e5c625b5e3e5d2a636c6173733d225b5e225d2a5c626c616e67756167652d6c696e6b5c625b5e225d2a225b5e3e5d2a3e2e2a3f3c2f627574746f6e3e').decode('utf-8'), page, re.S):
        lIIl = (I(llI, bytes.fromhex('646174612d6c616e67').decode('utf-8')) or bytes.fromhex('').decode('utf-8')).lower()
        label = l(llI)
        if lIIl:
            llII[lIIl] = bytes.fromhex('4455414c').decode('utf-8') if bytes.fromhex('6475616c').decode('utf-8') in label.lower() else label
    for group in re.findall(bytes.fromhex('3c6469765c625b5e3e5d2a636c6173733d225b5e225d2a5c62616c7465726e61746976652d6c696e6b735c625b5e225d2a225b5e3e5d2a3e2e2a3f3c2f6469763e').decode('utf-8'), page, re.S):
        lIlI = (I(group, bytes.fromhex('646174612d6c616e67').decode('utf-8')) or bytes.fromhex('').decode('utf-8')).lower()
        lIll = llII.get(lIlI, lIlI.upper())
        for llI in re.findall(bytes.fromhex('3c627574746f6e5c625b5e3e5d2a636c6173733d225b5e225d2a5c62616c7465726e61746976652d6c696e6b5c625b5e225d2a225b5e3e5d2a3e2e2a3f3c2f627574746f6e3e').decode('utf-8'), group, re.S):
            lIIlI = I(llI, bytes.fromhex('646174612d766964656f').decode('utf-8'))
            IllIl = l(llI).replace(bytes.fromhex('284844726970205862657429').decode('utf-8'), bytes.fromhex('').decode('utf-8')).strip()
            label = bytes.fromhex('207c20').decode('utf-8').join((lIIll for lIIll in [lIll, IllIl] if lIIll)).strip(bytes.fromhex('207c').decode('utf-8'))
            if lIIlI and lIIlI not in IllII:
                IllII.add(lIIlI)
                sources.append({bytes.fromhex('6c6162656c').decode('utf-8'): label or lIIlI, bytes.fromhex('766964656f5f6964').decode('utf-8'): lIIlI, bytes.fromhex('75726c').decode('utf-8'): base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f766964656f2f7b307d2f').decode('utf-8').format(lIIlI), bytes.fromhex('69735f747261696c6572').decode('utf-8'): False})
    if len([lIIll for lIIll in sources if not lIIll.get(bytes.fromhex('69735f747261696c6572').decode('utf-8'))]) <= 1:
        sources = sources[:1] if sources and sources[0].get(bytes.fromhex('69735f747261696c6572').decode('utf-8')) else []
        IllII = set()
        for llIl in re.finditer(bytes.fromhex('3c627574746f6e5c625b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c62616c7465726e61746976652d6c696e6b5c625b5e225c275d2a5b225c275d5b5e3e5d2a3e2e2a3f3c2f627574746f6e3e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
            llI = llIl.group(0)
            lIIlI = I(llI, bytes.fromhex('646174612d766964656f').decode('utf-8'))
            if not lIIlI or lIIlI in IllII:
                continue
            IllII.add(lIIlI)
            lIlI = ll(page, llIl.start())
            lIll = llII.get(lIlI, lIlI.upper())
            IllIl = l(llI).replace(bytes.fromhex('284844726970205862657429').decode('utf-8'), bytes.fromhex('').decode('utf-8')).strip()
            label = bytes.fromhex('207c20').decode('utf-8').join((lIIll for lIIll in [lIll, IllIl] if lIIll)).strip(bytes.fromhex('207c').decode('utf-8'))
            sources.append({bytes.fromhex('6c6162656c').decode('utf-8'): label or lIIlI, bytes.fromhex('766964656f5f6964').decode('utf-8'): lIIlI, bytes.fromhex('75726c').decode('utf-8'): base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f766964656f2f7b307d2f').decode('utf-8').format(lIIlI), bytes.fromhex('69735f747261696c6572').decode('utf-8'): False})
    return sources

def ll(page, IIIll):
    lII = (page or bytes.fromhex('').decode('utf-8'))[:IIIll]
    lllI = list(re.finditer(bytes.fromhex('3c6469765c625b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c62616c7465726e61746976652d6c696e6b735c625b5e225c275d2a5b225c275d5b5e3e5d2a5c62646174612d6c616e673d5b225c275d285b5e225c275d2b295b225c275d').decode('utf-8'), lII, re.I))
    return lllI[-1].group(1).lower() if lllI else bytes.fromhex('').decode('utf-8')

def parse_iframe_from_video_response(IIIlI):
    try:
        IIIl = json.loads(IIIlI)
        IlII = IIIl.get(bytes.fromhex('64617461').decode('utf-8'), {}).get(bytes.fromhex('68746d6c').decode('utf-8'), bytes.fromhex('').decode('utf-8')) if isinstance(IIIl, dict) else bytes.fromhex('').decode('utf-8')
    except Exception:
        IlII = IIIlI or bytes.fromhex('').decode('utf-8')
    IlIl = lI(bytes.fromhex('3c696672616d655b5e3e5d2b283f3a646174612d7372637c737263293d22285b5e225d2b2922').decode('utf-8'), IlII)
    return IlIl.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')) if IlIl else bytes.fromhex('').decode('utf-8')

def fix_url(url, base_url):
    if not url:
        return bytes.fromhex('').decode('utf-8')
    return urljoin(base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8'), html.unescape(url).strip())

def III(IIlI):
    return re.findall(bytes.fromhex('3c615c732b5b5e3e5d2a636c6173733d225b5e225d2a5c62706f737465725c625b5e225d2a225b5e3e5d2a3e2e2a3f3c2f613e').decode('utf-8'), IIlI or bytes.fromhex('').decode('utf-8'), re.S | re.I)

def Il(page):
    lIl = lI(bytes.fromhex('3c6469765b5e3e5d2a636c6173733d225b5e225d2a5c62706c61792d746861742d766964656f5c625b5e225d2a225b5e3e5d2a3e2e2a3f3c2f6469763e').decode('utf-8'), page, re.S)
    Illl = lI(bytes.fromhex('3c696d675c625b5e3e5d2a3e').decode('utf-8'), lIl, re.S)
    lIIIl = I(Illl, bytes.fromhex('646174612d737263').decode('utf-8')) or I(Illl, bytes.fromhex('737263736574').decode('utf-8')) or I(Illl, bytes.fromhex('737263').decode('utf-8'))
    if bytes.fromhex('31782c').decode('utf-8') in lIIIl:
        llIl = re.search(bytes.fromhex('31782c5c732a2868747470733f3a2f2f5c532b29').decode('utf-8'), lIIIl)
        if llIl:
            lIIIl = llIl.group(1)
    return lIIIl

def II(page):
    IIIII = []
    for IIlll in re.findall(bytes.fromhex('3c7363726970745b5e3e5d2a747970653d5b225c275d6170706c69636174696f6e2f6c645c2b6a736f6e5b225c275d5b5e3e5d2a3e282e2a3f293c2f7363726970743e').decode('utf-8'), page or bytes.fromhex('').decode('utf-8'), re.S | re.I):
        try:
            IIIl = json.loads(IIlll)
        except Exception:
            continue
        for IIl in IIIl.get(bytes.fromhex('6163746f72').decode('utf-8'), []) if isinstance(IIIl, dict) else []:
            if isinstance(IIl, dict):
                IIIII.append(l(IIl.get(bytes.fromhex('6e616d65').decode('utf-8'), bytes.fromhex('').decode('utf-8'))))
    if not IIIII:
        lIl = lI(bytes.fromhex('3c6469765b5e3e5d2a636c6173733d5b225c275d5b5e225c275d2a5c62706f73742d696e666f2d636173745c625b5e225c275d2a5b225c275d5b5e3e5d2a3e282e2a3f293c2f6469763e5c732a3c2f6469763e').decode('utf-8'), page, re.S)
        IIIII.extend((l(lIIll) for lIIll in re.findall(bytes.fromhex('3c7374726f6e675b5e3e5d2a3e282e2a3f293c2f7374726f6e673e').decode('utf-8'), lIl, re.S | re.I)))
    IlI = []
    IlIll = set()
    for llll in IIIII:
        key = llll.lower()
        if llll and key not in IlIll:
            IlIll.add(key)
            IlI.append(llll)
    return bytes.fromhex('2c20').decode('utf-8').join(IlI)

def I(IlllI, llll):
    if not IlllI:
        return bytes.fromhex('').decode('utf-8')
    llIl = re.search(bytes.fromhex('5c627b307d3d5b225c275d285b5e225c275d2b295b225c275d').decode('utf-8').format(re.escape(llll)), IlllI, re.I)
    return html.unescape(llIl.group(1)) if llIl else bytes.fromhex('').decode('utf-8')

def lI(IIIIl, Illll, flags=0):
    llIl = re.search(IIIIl, Illll or bytes.fromhex('').decode('utf-8'), flags | re.I)
    if not llIl:
        return bytes.fromhex('').decode('utf-8')
    return llIl.group(1) if llIl.lastindex else llIl.group(0)

def l(Illll):
    Illll = re.sub(bytes.fromhex('3c7376672e2a3f3c2f7376673e').decode('utf-8'), bytes.fromhex('20').decode('utf-8'), Illll or bytes.fromhex('').decode('utf-8'), flags=re.S | re.I)
    Illll = re.sub(bytes.fromhex('3c5b5e3e5d2b3e').decode('utf-8'), bytes.fromhex('20').decode('utf-8'), Illll)
    Illll = html.unescape(Illll)
    return re.sub(bytes.fromhex('5c732b').decode('utf-8'), bytes.fromhex('20').decode('utf-8'), Illll).strip()
