from __future__ import absolute_import, unicode_literals
import manituxhttp
try:
    import urllib.parse as urlparse
except ImportError:
    import urlparse
from . import parsers

class HDFilmCehennemiSite(object):

    def __init__(lll, base_url, user_agent):
        lll.base_url = base_url.rstrip(bytes.fromhex('2f').decode('utf-8'))
        lll.user_agent = user_agent
        lll.session = manituxhttp.Session()

    def headers(lll, referer=None, ajax=False):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): lll.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('746578742f68746d6c2c6170706c69636174696f6e2f7868746d6c2b786d6c2c6170706c69636174696f6e2f786d6c3b713d302e392c696d6167652f617669662c696d6167652f776562702c696d6167652f61706e672c2a2f2a3b713d302e38').decode('utf-8'), bytes.fromhex('4163636570742d4c616e6775616765').decode('utf-8'): bytes.fromhex('74722d54522c74723b713d302e392c656e2d55533b713d302e382c656e3b713d302e37').decode('utf-8'), bytes.fromhex('436f6e6e656374696f6e').decode('utf-8'): bytes.fromhex('6b6565702d616c697665').decode('utf-8'), bytes.fromhex('557067726164652d496e7365637572652d5265717565737473').decode('utf-8'): bytes.fromhex('31').decode('utf-8')}
        if referer:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        else:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = lll.base_url + bytes.fromhex('2f').decode('utf-8')
        if ajax:
            headers[bytes.fromhex('582d5265717565737465642d57697468').decode('utf-8')] = bytes.fromhex('6665746368').decode('utf-8')
        return headers

    def get_headers(lll, referer=None, ajax=False):
        IIl = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): lll.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('746578742f68746d6c2c6170706c69636174696f6e2f7868746d6c2b786d6c2c6170706c69636174696f6e2f786d6c3b713d302e392c696d6167652f617669662c696d6167652f776562702c696d6167652f61706e672c2a2f2a3b713d302e38').decode('utf-8'), bytes.fromhex('4163636570742d4c616e6775616765').decode('utf-8'): bytes.fromhex('74722d54522c74723b713d302e392c656e2d55533b713d302e382c656e3b713d302e37').decode('utf-8'), bytes.fromhex('557067726164652d496e7365637572652d5265717565737473').decode('utf-8'): bytes.fromhex('31').decode('utf-8'), bytes.fromhex('436f6e6e656374696f6e').decode('utf-8'): bytes.fromhex('6b6565702d616c697665').decode('utf-8')}
        if referer:
            IIl[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        if ajax:
            IIl[bytes.fromhex('416363657074').decode('utf-8')] = bytes.fromhex('2a2f2a').decode('utf-8')
            IIl[bytes.fromhex('582d5265717565737465642d57697468').decode('utf-8')] = bytes.fromhex('584d4c4874747052657175657374').decode('utf-8')
            IIl[bytes.fromhex('5365632d46657463682d44657374').decode('utf-8')] = bytes.fromhex('656d707479').decode('utf-8')
            IIl[bytes.fromhex('5365632d46657463682d4d6f6465').decode('utf-8')] = bytes.fromhex('636f7273').decode('utf-8')
            IIl[bytes.fromhex('5365632d46657463682d53697465').decode('utf-8')] = bytes.fromhex('73616d652d6f726967696e').decode('utf-8')
            if bytes.fromhex('557067726164652d496e7365637572652d5265717565737473').decode('utf-8') in IIl:
                del IIl[bytes.fromhex('557067726164652d496e7365637572652d5265717565737473').decode('utf-8')]
        return IIl

    def get(lll, url, referer=None, ajax=False):
        url = lll.absolute(url)
        return lll._get(url, headers=lll.headers(referer, ajax=ajax)).text

    def categories(lll):
        return parsers.categories(lll.base_url)

    def page_url(lll, Il, page_number):
        return parsers.page_api_url(Il, page_number)

    def get_page_items(lll, Il, page_number=1, title=bytes.fromhex('').decode('utf-8')):
        I = lll.page_url(Il, page_number)
        try:
            page = lll.get_ajax(I)
        except manituxhttp.HTTPError as exc:
            if getattr(exc.response, bytes.fromhex('7374617475735f636f6465').decode('utf-8'), None) != 403:
                raise
            ll = lll.page_fallback_url(I, Il, page_number)
            if not ll:
                raise
            page = lll.get(ll)
        Ill = parsers.html_from_load_response(page)
        return parsers.parse_page_items(Ill, lll.base_url, title)

    def absolute(lll, url):
        return parsers.fix_url(url, lll.base_url)

    def search_url(lll, query):
        return lll.base_url + bytes.fromhex('2f7365617263682f3f713d').decode('utf-8') + urlparse.quote_plus(query)

    def search(lll, query):
        llI = lll._get(lll.search_url(query), headers=lll.headers(referer=lll.base_url + bytes.fromhex('2f').decode('utf-8'), ajax=True))
        return parsers.parse_search_results(llI.text, lll.base_url)

    def parse_movies(lll, page):
        return parsers.parse_page_items(page, lll.base_url)

    def parse_next_page(lll, page, lI):
        return None

    def parse_detail(lll, page, url):
        return parsers.parse_media_info(page, url, lll.base_url)

    def fetch_source_iframe(lll, IIIl, referer):
        page = lll.get_ajax(lll.base_url + bytes.fromhex('2f766964656f2f7b307d2f').decode('utf-8').format(IIIl), referer=referer)
        return parsers.parse_iframe_from_video_response(page)

    def get_ajax(lll, url, referer=None):
        url = lll.absolute(url)
        lII = None
        for headers in lll.ajax_header_variants(referer):
            try:
                return lll._get(url, headers=headers).text
            except manituxhttp.HTTPError as exc:
                if getattr(exc.response, bytes.fromhex('7374617475735f636f6465').decode('utf-8'), None) != 403:
                    raise
                lII = exc
                lll._prime_session()
        raise lII

    def page_fallback_url(lll, I, Il, page_number):
        if int(page_number) != 1:
            return bytes.fromhex('').decode('utf-8')
        path = urlparse.urlparse(I).path.rstrip(bytes.fromhex('2f').decode('utf-8'))
        if path == bytes.fromhex('2f6c6f61642f706167652f312f686f6d65').decode('utf-8'):
            return lll.base_url + bytes.fromhex('2f').decode('utf-8')
        if bytes.fromhex('2f7475722f').decode('utf-8') in Il:
            return lll.absolute(Il)
        return bytes.fromhex('').decode('utf-8')

    def ajax_header_variants(lll, referer=None):
        l = referer or lll.base_url + bytes.fromhex('2f').decode('utf-8')
        headers = lll.headers(l, ajax=True)
        IIII = [headers]
        III = headers.copy()
        III[bytes.fromhex('416363657074').decode('utf-8')] = bytes.fromhex('2a2f2a').decode('utf-8')
        III[bytes.fromhex('4f726967696e').decode('utf-8')] = lll.base_url
        III[bytes.fromhex('5365632d46657463682d44657374').decode('utf-8')] = bytes.fromhex('656d707479').decode('utf-8')
        III[bytes.fromhex('5365632d46657463682d4d6f6465').decode('utf-8')] = bytes.fromhex('636f7273').decode('utf-8')
        III[bytes.fromhex('5365632d46657463682d53697465').decode('utf-8')] = bytes.fromhex('73616d652d6f726967696e').decode('utf-8')
        III.pop(bytes.fromhex('557067726164652d496e7365637572652d5265717565737473').decode('utf-8'), None)
        IIII.append(III)
        II = headers.copy()
        II[bytes.fromhex('4f726967696e').decode('utf-8')] = lll.base_url
        II[bytes.fromhex('5365632d46657463682d44657374').decode('utf-8')] = bytes.fromhex('656d707479').decode('utf-8')
        II[bytes.fromhex('5365632d46657463682d4d6f6465').decode('utf-8')] = bytes.fromhex('636f7273').decode('utf-8')
        II[bytes.fromhex('5365632d46657463682d53697465').decode('utf-8')] = bytes.fromhex('73616d652d6f726967696e').decode('utf-8')
        IIII.append(II)
        return IIII

    def _prime_session(lll):
        try:
            lll._get(lll.base_url + bytes.fromhex('2f').decode('utf-8'), headers=lll.headers(lll.base_url + bytes.fromhex('2f').decode('utf-8')))
        except Exception:
            pass

    def _get(lll, url, headers):
        llI = lll.session.get(url, headers=headers, timeout=25)
        llI.raise_for_status()
        return llI

    def url_to_host(lll, url):
        if not url.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8'))):
            url = bytes.fromhex('68747470733a2f2f').decode('utf-8') + url
        lIl = urlparse(url)
        IlI = lIl.netloc
        if bytes.fromhex('3a').decode('utf-8') in IlI and (not IlI.split(bytes.fromhex('3a').decode('utf-8'))[-1].isdigit()):
            IlI = IlI.split(bytes.fromhex('3a').decode('utf-8'))[0]
        return IlI
