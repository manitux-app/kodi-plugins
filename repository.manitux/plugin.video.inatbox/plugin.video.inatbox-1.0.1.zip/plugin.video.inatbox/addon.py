from __future__ import absolute_import, unicode_literals
import base64
import json
import sys
import time
import os
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
try:
    from urllib.parse import parse_qsl, quote, urlencode
except ImportError:
    from urlparse import parse_qsl
    from urllib import quote, urlencode
from resources.lib.site import InatBoxSite
MANITUXUI_LIB = os.path.join(xbmcaddon.Addon(id=bytes.fromhex('7363726970742e6d6f64756c652e6d616e697475787569').decode('utf-8')).getAddonInfo(bytes.fromhex('70617468').decode('utf-8')), bytes.fromhex('6c6962').decode('utf-8'))
if MANITUXUI_LIB not in sys.path:
    sys.path.insert(0, MANITUXUI_LIB)
from manituxui import ManituxUI, open_browser
ADDON_ID = bytes.fromhex('706c7567696e2e766964656f2e696e6174626f78').decode('utf-8')
SKIP_GUI_UNTIL = ADDON_ID + bytes.fromhex('2e736b69705f6775695f756e74696c').decode('utf-8')
ADDON = xbmcaddon.Addon(id=ADDON_ID)
HANDLE = int(sys.argv[1])
BASE_URL = ADDON.getSetting(bytes.fromhex('626173655f75726c').decode('utf-8'))
UA = ADDON.getSetting(bytes.fromhex('757365725f6167656e74').decode('utf-8')) or bytes.fromhex('737065656472657374617069').decode('utf-8')
YwNfgMAJagMASiBhYNfUldOIgjoDowgkbvKAznRdknsoLcOeEzmWFLXDeQfvxqMDQlDrNhbeTHjvAFT9 = InatBoxSite(BASE_URL, UA)

class InatBoxUI(ManituxUI):
    title = bytes.fromhex('496e6174426f78').decode('utf-8')

    def categories(self):
        categories = [{bytes.fromhex('7469746c65').decode('utf-8'): bytes.fromhex('417261').decode('utf-8'), bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('736561726368').decode('utf-8')}]
        try:
            for category in YwNfgMAJagMASiBhYNfUldOIgjoDowgkbvKAznRdknsoLcOeEzmWFLXDeQfvxqMDQlDrNhbeTHjvAFT9.categories():
                a = dict(category)
                a[bytes.fromhex('7469746c65').decode('utf-8')] = YwNfgMAJagMASiBhYNfUldOIgjoDowgkbvKAznRdknsoLcOeEzmWFLXDeQfvxqMDQlDrNhbeTHjvAFT9.item_title(a)
                a[bytes.fromhex('696d616765').decode('utf-8')] = art_url(YwNfgMAJagMASiBhYNfUldOIgjoDowgkbvKAznRdknsoLcOeEzmWFLXDeQfvxqMDQlDrNhbeTHjvAFT9.item_image(a))
                categories.append(a)
        except Exception:
            xbmcgui.Dialog().notification(bytes.fromhex('496e6174426f78').decode('utf-8'), bytes.fromhex('416e61206c6973746520616c696e616d616469').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
        return categories

    def videos(self, category, page=1):
        if category.get(bytes.fromhex('616374696f6e').decode('utf-8')) == bytes.fromhex('736561726368').decode('utf-8'):
            query = xbmcgui.Dialog().input(bytes.fromhex('496e6174426f7820417261').decode('utf-8'))
            if not query:
                return []
            JJJJ = []
            for G75462161475648 in YwNfgMAJagMASiBhYNfUldOIgjoDowgkbvKAznRdknsoLcOeEzmWFLXDeQfvxqMDQlDrNhbeTHjvAFT9.search(query):
                item = dict(G75462161475648.get(bytes.fromhex('6974656d').decode('utf-8')) or {})
                item[bytes.fromhex('69735f63617465676f7279').decode('utf-8')] = G75462161475648.get(bytes.fromhex('6b696e64').decode('utf-8')) == bytes.fromhex('63617465676f7279').decode('utf-8')
                JJJJ.append(self._decorate_item(item))
            return JJJJ
        try:
            return [self._decorate_item(item) for item in YwNfgMAJagMASiBhYNfUldOIgjoDowgkbvKAznRdknsoLcOeEzmWFLXDeQfvxqMDQlDrNhbeTHjvAFT9.category_items(category)]
        except Exception:
            xbmcgui.Dialog().notification(bytes.fromhex('496e6174426f78').decode('utf-8'), bytes.fromhex('4c6973746520616c696e616d616469').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
            return []

    def has_next_page(self, category, page=1, videos=None):
        return False

    def _decorate_item(self, item):
        a = dict(item)
        a[bytes.fromhex('7469746c65').decode('utf-8')] = YwNfgMAJagMASiBhYNfUldOIgjoDowgkbvKAznRdknsoLcOeEzmWFLXDeQfvxqMDQlDrNhbeTHjvAFT9.item_title(a)
        a[bytes.fromhex('696d616765').decode('utf-8')] = art_url(YwNfgMAJagMASiBhYNfUldOIgjoDowgkbvKAznRdknsoLcOeEzmWFLXDeQfvxqMDQlDrNhbeTHjvAFT9.item_image(a))
        a[bytes.fromhex('706c6f74').decode('utf-8')] = YwNfgMAJagMASiBhYNfUldOIgjoDowgkbvKAznRdknsoLcOeEzmWFLXDeQfvxqMDQlDrNhbeTHjvAFT9.item_plot(a)
        return a

    def detail(self, video):
        image = art_url(video.get(bytes.fromhex('696d616765').decode('utf-8')) or YwNfgMAJagMASiBhYNfUldOIgjoDowgkbvKAznRdknsoLcOeEzmWFLXDeQfvxqMDQlDrNhbeTHjvAFT9.item_image(video))
        if video.get(bytes.fromhex('69735f63617465676f7279').decode('utf-8')):
            return {bytes.fromhex('7469746c65').decode('utf-8'): video.get(bytes.fromhex('7469746c65').decode('utf-8')) or YwNfgMAJagMASiBhYNfUldOIgjoDowgkbvKAznRdknsoLcOeEzmWFLXDeQfvxqMDQlDrNhbeTHjvAFT9.item_title(video), bytes.fromhex('696d616765').decode('utf-8'): image, bytes.fromhex('706c6f74').decode('utf-8'): video.get(bytes.fromhex('706c6f74').decode('utf-8')) or YwNfgMAJagMASiBhYNfUldOIgjoDowgkbvKAznRdknsoLcOeEzmWFLXDeQfvxqMDQlDrNhbeTHjvAFT9.item_plot(video), bytes.fromhex('657069736f646573').decode('utf-8'): self.videos(video), bytes.fromhex('736f7572636573').decode('utf-8'): []}
        plot = video.get(bytes.fromhex('706c6f74').decode('utf-8')) or YwNfgMAJagMASiBhYNfUldOIgjoDowgkbvKAznRdknsoLcOeEzmWFLXDeQfvxqMDQlDrNhbeTHjvAFT9.item_plot(video)
        try:
            sources = YwNfgMAJagMASiBhYNfUldOIgjoDowgkbvKAznRdknsoLcOeEzmWFLXDeQfvxqMDQlDrNhbeTHjvAFT9.sources_from_item(video)
        except Exception:
            sources = []
        return {bytes.fromhex('7469746c65').decode('utf-8'): video.get(bytes.fromhex('7469746c65').decode('utf-8')) or YwNfgMAJagMASiBhYNfUldOIgjoDowgkbvKAznRdknsoLcOeEzmWFLXDeQfvxqMDQlDrNhbeTHjvAFT9.item_title(video), bytes.fromhex('75726c').decode('utf-8'): video.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('696d616765').decode('utf-8'): image, bytes.fromhex('6261636b64726f70').decode('utf-8'): art_url(video.get(bytes.fromhex('6261636b64726f70').decode('utf-8')) or video.get(bytes.fromhex('66616e617274').decode('utf-8')) or image), bytes.fromhex('706c6f74').decode('utf-8'): plot, bytes.fromhex('736f7572636573').decode('utf-8'): [dict(source, label=source.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('4b61796e616b207b307d').decode('utf-8').format(LLL + 1)) for LLL, source in enumerate(sources)]}

    def episode_detail(self, episode, video=None):
        return self.detail(episode)

    def play(self, source, video=None):
        resolve_stream_gui(YwNfgMAJagMASiBhYNfUldOIgjoDowgkbvKAznRdknsoLcOeEzmWFLXDeQfvxqMDQlDrNhbeTHjvAFT9.stream_url(source))

def build_url(query):
    return sys.argv[0] + bytes.fromhex('3f').decode('utf-8') + urlencode(query)

def encode_data(value):
    G84145285590856 = json.dumps(value or {}, ensure_ascii=False, separators=(bytes.fromhex('2c').decode('utf-8'), bytes.fromhex('3a').decode('utf-8'))).encode(bytes.fromhex('7574662d38').decode('utf-8'))
    return base64.urlsafe_b64encode(G84145285590856).decode(bytes.fromhex('6173636969').decode('utf-8'))

def decode_data(value):
    if not value:
        return {}
    IIIIl = bytes.fromhex('3d').decode('utf-8') * (-len(value) % 4)
    return json.loads(base64.urlsafe_b64decode((value + IIIIl).encode(bytes.fromhex('6173636969').decode('utf-8'))).decode(bytes.fromhex('7574662d38').decode('utf-8')))

def art_url(url):
    if not url or bytes.fromhex('7c').decode('utf-8') in url or (not url.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8')))):
        return url
    return url + bytes.fromhex('7c557365722d4167656e743d').decode('utf-8') + quote(UA)

def set_art(li, image):
    image = art_url(image)
    li.setArt({bytes.fromhex('7468756d62').decode('utf-8'): image, bytes.fromhex('69636f6e').decode('utf-8'): image, bytes.fromhex('706f73746572').decode('utf-8'): image, bytes.fromhex('66616e617274').decode('utf-8'): image})

def add_directory(title, action, data=bytes.fromhex('').decode('utf-8'), image=bytes.fromhex('').decode('utf-8'), plot=bytes.fromhex('').decode('utf-8')):
    query = {bytes.fromhex('616374696f6e').decode('utf-8'): action}
    if data:
        query[bytes.fromhex('64617461').decode('utf-8')] = data
    li = xbmcgui.ListItem(label=title)
    set_art(li, image)
    li.setInfo(bytes.fromhex('766964656f').decode('utf-8'), {bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('706c6f74').decode('utf-8'): plot})
    xbmcplugin.addDirectoryItem(HANDLE, build_url(query), li, True)

def add_video(title, data, image=bytes.fromhex('').decode('utf-8'), plot=bytes.fromhex('').decode('utf-8')):
    li = xbmcgui.ListItem(label=title)
    set_art(li, image)
    li.setInfo(bytes.fromhex('766964656f').decode('utf-8'), {bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('706c6f74').decode('utf-8'): plot})
    li.setProperty(bytes.fromhex('4973506c617961626c65').decode('utf-8'), bytes.fromhex('74727565').decode('utf-8'))
    xbmcplugin.addDirectoryItem(HANDLE, build_url({bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('706c6179').decode('utf-8'), bytes.fromhex('64617461').decode('utf-8'): data}), li, False)

def main_menu():
    add_directory(bytes.fromhex('417261').decode('utf-8'), bytes.fromhex('736561726368').decode('utf-8'))
    try:
        categories = YwNfgMAJagMASiBhYNfUldOIgjoDowgkbvKAznRdknsoLcOeEzmWFLXDeQfvxqMDQlDrNhbeTHjvAFT9.categories()
    except Exception:
        categories = []
        xbmcgui.Dialog().notification(bytes.fromhex('496e6174426f78').decode('utf-8'), bytes.fromhex('416e61206c6973746520616c696e616d616469').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
    for category in categories:
        add_directory(YwNfgMAJagMASiBhYNfUldOIgjoDowgkbvKAznRdknsoLcOeEzmWFLXDeQfvxqMDQlDrNhbeTHjvAFT9.item_title(category), bytes.fromhex('6c697374').decode('utf-8'), encode_data(category), YwNfgMAJagMASiBhYNfUldOIgjoDowgkbvKAznRdknsoLcOeEzmWFLXDeQfvxqMDQlDrNhbeTHjvAFT9.item_image(category))
    xbmcplugin.setContent(HANDLE, bytes.fromhex('766964656f73').decode('utf-8'))

def list_category(data):
    category = decode_data(data)
    try:
        JJJJ = YwNfgMAJagMASiBhYNfUldOIgjoDowgkbvKAznRdknsoLcOeEzmWFLXDeQfvxqMDQlDrNhbeTHjvAFT9.category_items(category)
    except Exception:
        JJJJ = []
        xbmcgui.Dialog().notification(bytes.fromhex('496e6174426f78').decode('utf-8'), bytes.fromhex('4c6973746520616c696e616d616469').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
    for item in JJJJ:
        title = YwNfgMAJagMASiBhYNfUldOIgjoDowgkbvKAznRdknsoLcOeEzmWFLXDeQfvxqMDQlDrNhbeTHjvAFT9.item_title(item)
        image = YwNfgMAJagMASiBhYNfUldOIgjoDowgkbvKAznRdknsoLcOeEzmWFLXDeQfvxqMDQlDrNhbeTHjvAFT9.item_image(item)
        plot = YwNfgMAJagMASiBhYNfUldOIgjoDowgkbvKAznRdknsoLcOeEzmWFLXDeQfvxqMDQlDrNhbeTHjvAFT9.item_plot(item)
        add_directory(title, bytes.fromhex('736f7572636573').decode('utf-8'), encode_data(item), image, plot)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('766964656f73').decode('utf-8'))

def search():
    query = xbmcgui.Dialog().input(bytes.fromhex('496e6174426f7820417261').decode('utf-8'))
    if not query:
        return
    for G75462161475648 in YwNfgMAJagMASiBhYNfUldOIgjoDowgkbvKAznRdknsoLcOeEzmWFLXDeQfvxqMDQlDrNhbeTHjvAFT9.search(query):
        item = G75462161475648.get(bytes.fromhex('6974656d').decode('utf-8')) or {}
        action = bytes.fromhex('6c697374').decode('utf-8') if G75462161475648.get(bytes.fromhex('6b696e64').decode('utf-8')) == bytes.fromhex('63617465676f7279').decode('utf-8') else bytes.fromhex('736f7572636573').decode('utf-8')
        add_directory(YwNfgMAJagMASiBhYNfUldOIgjoDowgkbvKAznRdknsoLcOeEzmWFLXDeQfvxqMDQlDrNhbeTHjvAFT9.item_title(item), action, encode_data(item), YwNfgMAJagMASiBhYNfUldOIgjoDowgkbvKAznRdknsoLcOeEzmWFLXDeQfvxqMDQlDrNhbeTHjvAFT9.item_image(item), YwNfgMAJagMASiBhYNfUldOIgjoDowgkbvKAznRdknsoLcOeEzmWFLXDeQfvxqMDQlDrNhbeTHjvAFT9.item_plot(item))
    xbmcplugin.setContent(HANDLE, bytes.fromhex('766964656f73').decode('utf-8'))

def sources(data):
    item = decode_data(data)
    image = YwNfgMAJagMASiBhYNfUldOIgjoDowgkbvKAznRdknsoLcOeEzmWFLXDeQfvxqMDQlDrNhbeTHjvAFT9.item_image(item)
    plot = YwNfgMAJagMASiBhYNfUldOIgjoDowgkbvKAznRdknsoLcOeEzmWFLXDeQfvxqMDQlDrNhbeTHjvAFT9.item_plot(item)
    try:
        fffffff = YwNfgMAJagMASiBhYNfUldOIgjoDowgkbvKAznRdknsoLcOeEzmWFLXDeQfvxqMDQlDrNhbeTHjvAFT9.sources_from_item(item)
    except Exception:
        fffffff = []
    for LLL, source in enumerate(fffffff, 1):
        label = source.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('4b61796e616b207b307d').decode('utf-8').format(LLL)
        add_video(label, encode_data(source), image, plot)
    if not fffffff:
        xbmcgui.Dialog().notification(bytes.fromhex('496e6174426f78').decode('utf-8'), bytes.fromhex('4b61796e616b2062756c756e616d616469').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('766964656f73').decode('utf-8'))

def play(data):
    stream = YwNfgMAJagMASiBhYNfUldOIgjoDowgkbvKAznRdknsoLcOeEzmWFLXDeQfvxqMDQlDrNhbeTHjvAFT9.stream_url(decode_data(data))
    if not stream:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    li = xbmcgui.ListItem(path=stream)
    if is_hls_stream(stream):
        li.setMimeType(bytes.fromhex('6170706c69636174696f6e2f766e642e6170706c652e6d70656775726c').decode('utf-8'))
        li.setContentLookup(False)
        if has_addon(bytes.fromhex('696e70757473747265616d2e6164617074697665').decode('utf-8')):
            ll = stream.split(bytes.fromhex('7c').decode('utf-8'), 1)[1] if bytes.fromhex('7c').decode('utf-8') in stream else bytes.fromhex('').decode('utf-8')
            li.setProperty(bytes.fromhex('696e70757473747265616d').decode('utf-8'), bytes.fromhex('696e70757473747265616d2e6164617074697665').decode('utf-8'))
            li.setProperty(bytes.fromhex('696e70757473747265616d2e61646170746976652e73747265616d5f68656164657273').decode('utf-8'), ll)
            li.setProperty(bytes.fromhex('696e70757473747265616d2e61646170746976652e6d616e69666573745f68656164657273').decode('utf-8'), ll)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)

def resolve_stream_gui(stream):
    if not stream:
        xbmcgui.Dialog().notification(bytes.fromhex('496e6174426f78').decode('utf-8'), bytes.fromhex('4b61796e616b2062756c756e616d616469').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    li = xbmcgui.ListItem(path=stream)
    if is_hls_stream(stream):
        li.setMimeType(bytes.fromhex('6170706c69636174696f6e2f766e642e6170706c652e6d70656775726c').decode('utf-8'))
        li.setContentLookup(False)
        if has_addon(bytes.fromhex('696e70757473747265616d2e6164617074697665').decode('utf-8')):
            ll = stream.split(bytes.fromhex('7c').decode('utf-8'), 1)[1] if bytes.fromhex('7c').decode('utf-8') in stream else bytes.fromhex('').decode('utf-8')
            li.setProperty(bytes.fromhex('696e70757473747265616d').decode('utf-8'), bytes.fromhex('696e70757473747265616d2e6164617074697665').decode('utf-8'))
            li.setProperty(bytes.fromhex('696e70757473747265616d2e61646170746976652e73747265616d5f68656164657273').decode('utf-8'), ll)
            li.setProperty(bytes.fromhex('696e70757473747265616d2e61646170746976652e6d616e69666573745f68656164657273').decode('utf-8'), ll)
    xbmc.Player().play(stream, li)

def is_hls_stream(url):
    return bytes.fromhex('2e6d337538').decode('utf-8') in (url or bytes.fromhex('').decode('utf-8')).split(bytes.fromhex('7c').decode('utf-8'), 1)[0].lower()

def has_addon(addon_id):
    return bool(xbmc.getCondVisibility(bytes.fromhex('53797374656d2e4861734164646f6e287b307d29').decode('utf-8').format(addon_id)))

def run():
    params = dict(parse_qsl(sys.argv[2][1:]))
    action = params.get(bytes.fromhex('616374696f6e').decode('utf-8'))
    if not action:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
        lIllIllIIlI = xbmcgui.Window(10000)
        try:
            n776266751696810 = float(lIllIllIIlI.getProperty(SKIP_GUI_UNTIL) or bytes.fromhex('30').decode('utf-8'))
        except ValueError:
            n776266751696810 = 0
        if time.time() < n776266751696810:
            return
        lIllIllIIlI.clearProperty(SKIP_GUI_UNTIL)
        xbmc.executebuiltin(bytes.fromhex('52756e506c7567696e287b307d29').decode('utf-8').format(build_url({bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('677569').decode('utf-8')})))
        return
    elif action == bytes.fromhex('677569').decode('utf-8'):
        open_browser(InatBoxUI())
        xbmcgui.Window(10000).setProperty(SKIP_GUI_UNTIL, str(time.time() + 4))
        xbmc.executebuiltin(bytes.fromhex('416374697661746557696e646f7728486f6d6529').decode('utf-8'))
        return
    elif action == bytes.fromhex('636c6173736963').decode('utf-8'):
        main_menu()
    elif action == bytes.fromhex('6c697374').decode('utf-8'):
        list_category(params.get(bytes.fromhex('64617461').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
    elif action == bytes.fromhex('736561726368').decode('utf-8'):
        search()
    elif action == bytes.fromhex('736f7572636573').decode('utf-8'):
        sources(params.get(bytes.fromhex('64617461').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
    elif action == bytes.fromhex('706c6179').decode('utf-8'):
        play(params.get(bytes.fromhex('64617461').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
    xbmcplugin.endOfDirectory(HANDLE)
if __name__ == bytes.fromhex('5f5f6d61696e5f5f').decode('utf-8'):
    run()
