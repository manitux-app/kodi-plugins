from __future__ import absolute_import, unicode_literals
import base64
import json
import re
import manituxhttp
try:
    from Crypto.Cipher import AES
    from Crypto.Util.Padding import unpad
except ImportError:
    try:
        from Cryptodome.Cipher import AES
        from Cryptodome.Util.Padding import unpad
    except ImportError:
        AES = None
        unpad = None
try:
    from urllib.parse import quote, urljoin
except ImportError:
    from urllib import quote
    from urlparse import urljoin

class InatBoxSite(object):
    HASH_URL = bytes.fromhex('68747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f6d746c73686173682f636572742f6d61696e2f68617368').decode('utf-8')
    FALLBACK_URL = bytes.fromhex('68747470733a2f2f7374617469632e737461746963736176652e636f6d2f666173742f63742e6a73').decode('utf-8')
    AES_KEY = bytes.fromhex('7977657671746a7275726b777471677a').decode('utf-8')
    CLIENT_IDENTIFIERS = (bytes.fromhex('6368726f6d655f313434').decode('utf-8'), bytes.fromhex('636c6f756473637261706572').decode('utf-8'))
    WORKING_CATEGORY_NAMES = (bytes.fromhex('4c697374652033202d205452').decode('utf-8'), bytes.fromhex('53706f72').decode('utf-8'), bytes.fromhex('544f44').decode('utf-8'))
    HEADER_KEYS = {bytes.fromhex('557365724167656e74').decode('utf-8'): bytes.fromhex('557365722d4167656e74').decode('utf-8'), bytes.fromhex('557365722d4167656e74').decode('utf-8'): bytes.fromhex('557365722d4167656e74').decode('utf-8'), bytes.fromhex('52656665726572').decode('utf-8'): bytes.fromhex('52656665726572').decode('utf-8'), bytes.fromhex('4f726967696e').decode('utf-8'): bytes.fromhex('4f726967696e').decode('utf-8'), bytes.fromhex('5852657175657374656457697468').decode('utf-8'): bytes.fromhex('582d5265717565737465642d57697468').decode('utf-8'), bytes.fromhex('582d5265717565737465642d57697468').decode('utf-8'): bytes.fromhex('582d5265717565737465642d57697468').decode('utf-8'), bytes.fromhex('436f6f6b6965').decode('utf-8'): bytes.fromhex('436f6f6b6965').decode('utf-8'), bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('416363657074').decode('utf-8')}

    def __init__(self, base_url=bytes.fromhex('').decode('utf-8'), user_agent=bytes.fromhex('737065656472657374617069').decode('utf-8')):
        self.user_agent = user_agent or bytes.fromhex('737065656472657374617069').decode('utf-8')
        self.session = manituxhttp.Session(client_identifier=self.CLIENT_IDENTIFIERS[0])
        self.base_url = (base_url or self.remote_base_url() or self.FALLBACK_URL).strip()

    def categories(self):
        items = self.fetch_json(self.base_url)
        if not isinstance(items, list):
            return []
        return [item for item in items if self.content_allowed(item, bytes.fromhex('6361744e616d65').decode('utf-8'), bytes.fromhex('63617454797065').decode('utf-8')) and (item.get(bytes.fromhex('6361744e616d65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')) in self.WORKING_CATEGORY_NAMES]

    def category_items(self, category):
        AaAAAaAAaaaaaAAAAaAaAaAAaAaAAAAaAAAa = self.fetch_json(category.get(bytes.fromhex('63617455726c').decode('utf-8')) or bytes.fromhex('').decode('utf-8'), category.get(bytes.fromhex('6361744461746154797065').decode('utf-8')) or bytes.fromhex('').decode('utf-8'))
        if isinstance(AaAAAaAAaaaaaAAAAaAaAaAAaAaAAAAaAAAa, list):
            return [item for item in AaAAAaAAaaaaaAAAAaAaAaAAaAaAAAAaAAAa if self.content_allowed(item, bytes.fromhex('63684e616d65').decode('utf-8'), bytes.fromhex('636854797065').decode('utf-8'))]
        if isinstance(AaAAAaAAaaaaaAAAAaAaAaAAaAaAAAAaAAAa, dict):
            if isinstance(AaAAAaAAaaaaaAAAAaAaAaAAaAaAAAAaAAAa.get(bytes.fromhex('43617465676f72696573').decode('utf-8')), list):
                nTepSAGIAkNxexXXSWTDKyQVmYTPIvlVaRLEelrUoMpJIjANncuPrihBDDnRroiNhFyOodndjhbsgGV44 = []
                for group in AaAAAaAAaaaaaAAAAaAaAaAAaAaAAAAaAAAa.get(bytes.fromhex('43617465676f72696573').decode('utf-8')) or []:
                    nTepSAGIAkNxexXXSWTDKyQVmYTPIvlVaRLEelrUoMpJIjANncuPrihBDDnRroiNhFyOodndjhbsgGV44.extend(group.get(bytes.fromhex('436f6e74656e7473').decode('utf-8')) or [])
                return nTepSAGIAkNxexXXSWTDKyQVmYTPIvlVaRLEelrUoMpJIjANncuPrihBDDnRroiNhFyOodndjhbsgGV44
            if isinstance(AaAAAaAAaaaaaAAAAaAaAaAAaAaAAAAaAAAa.get(bytes.fromhex('436f6e74656e7473').decode('utf-8')), list):
                return AaAAAaAAaaaaaAAAAaAaAaAAaAaAAAAaAAAa.get(bytes.fromhex('436f6e74656e7473').decode('utf-8')) or []
        return []

    def search(self, query):
        query = (query or bytes.fromhex('').decode('utf-8')).lower()
        FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF = []
        for category in self.categories():
            if query in (category.get(bytes.fromhex('6361744e616d65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')).lower():
                FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF.append({bytes.fromhex('6b696e64').decode('utf-8'): bytes.fromhex('63617465676f7279').decode('utf-8'), bytes.fromhex('6974656d').decode('utf-8'): category})
                continue
            try:
                for item in self.category_items(category):
                    title = self.item_title(item).lower()
                    if query in title:
                        FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF.append({bytes.fromhex('6b696e64').decode('utf-8'): bytes.fromhex('6974656d').decode('utf-8'), bytes.fromhex('6974656d').decode('utf-8'): item})
            except Exception:
                continue
        return FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

    def sources_from_item(self, item):
        if item.get(bytes.fromhex('63684e616d65').decode('utf-8')):
            return self.resolve_ch_content(item)
        nnnnnnnnnnnnnnnnnnnnnnnnnnnnn = item.get(bytes.fromhex('4d6564696173').decode('utf-8')) or []
        sources = []
        for media in nnnnnnnnnnnnnnnnnnnnnnnnnnnnn:
            url = media.get(bytes.fromhex('55524c').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
            if url:
                sources.append({bytes.fromhex('7469746c65').decode('utf-8'): self.media_label(media), bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('68656164657273').decode('utf-8'): {}})
        return sources

    def resolve_ch_content(self, item):
        url = self.vk_source_fix(item.get(bytes.fromhex('636855726c').decode('utf-8')) or bytes.fromhex('').decode('utf-8'))
        headers = self.parse_headers(item.get(bytes.fromhex('636848656164657273').decode('utf-8')))
        if self.is_direct_stream(url):
            return self.resolve_direct_stream(item.get(bytes.fromhex('63684e616d65').decode('utf-8')) or bytes.fromhex('4b61796e616b').decode('utf-8'), url, headers)
        data = self.fetch_text(url, headers=headers)
        nRZJGQwkOXWgRQZvsopUjxhmGfXrAWLgUjbwffMmhenKCHKOOBgByRJIEQCNWHZCskTemqWLaspuhso43 = self.try_decrypt_response(data, item.get(bytes.fromhex('6368526567').decode('utf-8')))
        try:
            AaAAAaAAaaaaaAAAAaAaAaAAaAaAAAAaAAAa = json.loads(nRZJGQwkOXWgRQZvsopUjxhmGfXrAWLgUjbwffMmhenKCHKOOBgByRJIEQCNWHZCskTemqWLaspuhso43)
        except Exception:
            AaAAAaAAaaaaaAAAAaAaAaAAaAaAAAAaAAAa = None
        if isinstance(AaAAAaAAaaaaaAAAAaAaAaAAaAaAAAAaAAAa, dict):
            AaAaaaaAaaaAAAAaaaAAaaaAAaAAaaaaaaAaaAaAAaAAaaa = AaAAAaAAaaaaaAAAAaAaAaAAaAaAAAAaAAAa.get(bytes.fromhex('636855726c').decode('utf-8')) or AaAAAaAAaaaaaAAAAaAaAaAAaAaAAAAaAAAa.get(bytes.fromhex('75726c').decode('utf-8')) or AaAAAaAAaaaaaAAAAaAaAaAAaAaAAAAaAAAa.get(bytes.fromhex('706c617955726c').decode('utf-8')) or AaAAAaAAaaaaaAAAAaAaAaAAaAaAAAAaAAAa.get(bytes.fromhex('73747265616d55726c').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
            headers.update(self.parse_headers(AaAAAaAAaaaaaAAAAaAaAaAAaAaAAAAaAAAa.get(bytes.fromhex('68656164657273').decode('utf-8')) or AaAAAaAAaaaaaAAAAaAaAaAAaAaAAAAaAAAa.get(bytes.fromhex('636848656164657273').decode('utf-8'))))
            if AaAaaaaAaaaAAAAaaaAAaaaAAaAAaaaaaaAaaAaAAaAAaaa:
                return self.resolve_direct_stream(item.get(bytes.fromhex('63684e616d65').decode('utf-8')) or bytes.fromhex('4b61796e616b').decode('utf-8'), AaAaaaaAaaaAAAAaaaAAaaaAAaAAaaaaaaAaaAaAAaAAaaa, headers)
        return self.extract_direct_urls(nRZJGQwkOXWgRQZvsopUjxhmGfXrAWLgUjbwffMmhenKCHKOOBgByRJIEQCNWHZCskTemqWLaspuhso43, headers, item.get(bytes.fromhex('63684e616d65').decode('utf-8')) or bytes.fromhex('4b61796e616b').decode('utf-8'))

    def resolve_direct_stream(self, title, url, headers):
        if bytes.fromhex('2e6d337538').decode('utf-8') not in (url or bytes.fromhex('').decode('utf-8')).lower():
            return [{bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('68656164657273').decode('utf-8'): headers}]
        try:
            playlist = self.fetch_text(url, headers=headers)
        except Exception:
            return []
        if bytes.fromhex('234558544d3355').decode('utf-8') not in playlist:
            return []
        jcwEVvwfGCoyIDaJgjTtOHGyvDpjpFIkhkHOaJUlQpMSPdjylGzzhUInfqzjqRQEbJKvAwVnIcGzpft52 = self.best_hls_variant(url, playlist)
        return [{bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): jcwEVvwfGCoyIDaJgjTtOHGyvDpjpFIkhkHOaJUlQpMSPdjylGzzhUInfqzjqRQEbJKvAwVnIcGzpft52 or url, bytes.fromhex('68656164657273').decode('utf-8'): headers}]

    @staticmethod
    def best_hls_variant(base_url, playlist):
        llIIlIIll = None
        L725939274194037 = None
        for y40 in (playlist or bytes.fromhex('').decode('utf-8')).splitlines():
            line = y40.strip()
            if not line:
                continue
            if line.startswith(bytes.fromhex('234558542d582d53545245414d2d494e46').decode('utf-8')):
                L725939274194037 = InatBoxSite.variant_score(line)
            elif L725939274194037 is not None and (not line.startswith(bytes.fromhex('23').decode('utf-8'))):
                url = urljoin(base_url, line)
                if llIIlIIll is None or L725939274194037 > llIIlIIll[0]:
                    llIIlIIll = (L725939274194037, url)
                L725939274194037 = None
        return llIIlIIll[1] if llIIlIIll else bytes.fromhex('').decode('utf-8')

    @staticmethod
    def variant_score(line):
        y32967316569378 = 0
        UUUUUUUUUUUUUUUUUUUUUUU = 0
        S28 = re.search(bytes.fromhex('42414e4457494454483d285c642b29').decode('utf-8'), line)
        if S28:
            y32967316569378 = int(S28.group(1))
        S28 = re.search(bytes.fromhex('5245534f4c5554494f4e3d5c642b78285c642b29').decode('utf-8'), line)
        if S28:
            UUUUUUUUUUUUUUUUUUUUUUU = int(S28.group(1))
        return y32967316569378 + UUUUUUUUUUUUUUUUUUUUUUU * 1000000000

    def stream_url(self, source):
        url = (source or {}).get(bytes.fromhex('75726c').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        if not url:
            return bytes.fromhex('').decode('utf-8')
        return url + self.kodi_headers((source or {}).get(bytes.fromhex('68656164657273').decode('utf-8')) or {})

    def remote_base_url(self):
        try:
            AaAAAaAAaaaaaAAAAaAaAaAAaAaAAAAaAAAa = self.fetch_json(self.HASH_URL, use_base=False)
            if isinstance(AaAAAaAAaaaaaAAAAaAaAaAAaAaAAAAaAAAa, dict):
                return AaAAAaAAaaaaaAAAAaAaAaAAaAaAAAAaAAAa.get(bytes.fromhex('44433130').decode('utf-8')) or AaAAAaAAaaaaaAAAAaAaAaAAaAaAAAAaAAAa.get(bytes.fromhex('444332').decode('utf-8')) or AaAAAaAAaaaaaAAAAaAaAaAAaAaAAAAaAAAa.get(bytes.fromhex('444331').decode('utf-8'))
        except Exception:
            return self.FALLBACK_URL
        return self.FALLBACK_URL

    def fetch_json(self, url, custom_key=None, use_base=True):
        text = self.fetch_text(url, use_base=use_base)
        bbbbbbbbbbbbbbb = self.try_decrypt_response(text, custom_key)
        return json.loads(bbbbbbbbbbbbbbb)

    def fetch_text(self, url, headers=None, use_base=True):
        if not url:
            return bytes.fromhex('').decode('utf-8')
        headers = dict(headers or {})
        headers.setdefault(bytes.fromhex('557365722d4167656e74').decode('utf-8'), self.user_agent)
        if use_base and (not url.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8')))):
            url = self.base_url.rstrip(bytes.fromhex('2f').decode('utf-8')) + bytes.fromhex('2f').decode('utf-8') + url.lstrip(bytes.fromhex('2f').decode('utf-8'))
        return self._request(bytes.fromhex('474554').decode('utf-8'), url, headers=headers).text

    def try_decrypt_response(self, response, custom_key=None):
        TTTTTTTTTTTTTT = (response or bytes.fromhex('').decode('utf-8')).strip()
        aAAAaAAAAaAaAaAa = custom_key if isinstance(custom_key, str) and custom_key else self.AES_KEY
        for l in range(4):
            D776487880343348 = TTTTTTTTTTTTTT.lstrip()
            if D776487880343348.startswith((bytes.fromhex('7b').decode('utf-8'), bytes.fromhex('5b').decode('utf-8'))):
                return TTTTTTTTTTTTTT
            if bytes.fromhex('3a').decode('utf-8') not in TTTTTTTTTTTTTT:
                return TTTTTTTTTTTTTT
            cipher_text, key = TTTTTTTTTTTTTT.split(bytes.fromhex('3a').decode('utf-8'), 1)
            try:
                TTTTTTTTTTTTTT = self.decrypt_aes(cipher_text.strip(), key.strip() or aAAAaAAAAaAaAaAa)
            except Exception:
                return TTTTTTTTTTTTTT
        return TTTTTTTTTTTTTT

    @staticmethod
    def decrypt_aes(cipher_text, aes_key):
        key = base64.b64decode(aes_key)
        llIIIIlIlIIIIlIll = base64.b64decode(cipher_text)
        if AES is not None:
            IlllllllIIIl = AES.new(key, AES.MODE_CBC, iv=key)
            return unpad(IlllllllIIIl.decrypt(llIIIIlIlIIIIlIll), AES.block_size).decode(bytes.fromhex('7574662d38').decode('utf-8'))
        return aes_cbc_decrypt(llIIIIlIlIIIIlIll, key, key).decode(bytes.fromhex('7574662d38').decode('utf-8'))

    def _request(self, method, url, headers=None, data=None):
        AaAaaAaAaaaAaAaaaAAAaaaAaaA = None
        for sssssssssssssssssssssssss in self.CLIENT_IDENTIFIERS:
            if self.session.client_identifier != sssssssssssssssssssssssss:
                self.session = manituxhttp.Session(client_identifier=sssssssssssssssssssssssss)
            try:
                if method == bytes.fromhex('504f5354').decode('utf-8'):
                    QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ = self.session.post(url, data=data, headers=headers, timeout=25, allow_redirects=True, tls_client_identifier=sssssssssssssssssssssssss)
                else:
                    QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ = self.session.get(url, headers=headers, timeout=25, allow_redirects=True, tls_client_identifier=sssssssssssssssssssssssss)
                if QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ.status_code in (403, 429) and sssssssssssssssssssssssss != self.CLIENT_IDENTIFIERS[-1]:
                    AaAaaAaAaaaAaAaaaAAAaaaAaaA = manituxhttp.HTTPError(QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ)
                    continue
                QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ.raise_for_status()
                return QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ
            except (manituxhttp.HTTPError, manituxhttp.RequestError) as exc:
                AaAaaAaAaaaAaAaaaAAAaaaAaaA = exc
                if sssssssssssssssssssssssss == self.CLIENT_IDENTIFIERS[-1]:
                    raise
        raise AaAaaAaAaaaAaAaaaAAAaaaAaaA

    def parse_headers(self, value):
        if not value or value == bytes.fromhex('6e756c6c').decode('utf-8'):
            return {}
        if isinstance(value, list):
            value = value[0] if value else {}
        if isinstance(value, str):
            try:
                value = json.loads(value)
            except Exception:
                return {}
            if isinstance(value, list):
                value = value[0] if value else {}
        nTepSAGIAkNxexXXSWTDKyQVmYTPIvlVaRLEelrUoMpJIjANncuPrihBDDnRroiNhFyOodndjhbsgGV44 = {}
        if isinstance(value, dict):
            for key, S22 in self.HEADER_KEYS.items():
                I996669009020951 = value.get(key)
                if I996669009020951 and I996669009020951 != bytes.fromhex('6e756c6c').decode('utf-8'):
                    nTepSAGIAkNxexXXSWTDKyQVmYTPIvlVaRLEelrUoMpJIjANncuPrihBDDnRroiNhFyOodndjhbsgGV44[S22] = I996669009020951
        return nTepSAGIAkNxexXXSWTDKyQVmYTPIvlVaRLEelrUoMpJIjANncuPrihBDDnRroiNhFyOodndjhbsgGV44

    def extract_direct_urls(self, text, headers, title):
        KKKKKKKKKKKKKKKKKK = []
        for S28 in re.finditer(bytes.fromhex('68747470733f3a2f2f5b5e5c735c22273c3e5d2b3f283f3a5c2e6d3375387c5c2e6d70647c5c2e6d70347c5c2e7765626d29283f3a5b5e5c735c22273c3e5d2a293f').decode('utf-8'), text or bytes.fromhex('').decode('utf-8'), re.I):
            url = S28.group(0).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'))
            if url not in [item[bytes.fromhex('75726c').decode('utf-8')] for item in KKKKKKKKKKKKKKKKKK]:
                KKKKKKKKKKKKKKKKKK.append({bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('68656164657273').decode('utf-8'): headers})
        return KKKKKKKKKKKKKKKKKK

    @staticmethod
    def content_allowed(item, name_key, type_key):
        IIIlllIllIIlIlIIlIIIIIIlIIIllIlIIlIIIIlllIIIIIIlll = (item.get(type_key) or bytes.fromhex('').decode('utf-8')).lower()
        HVReciyKPeyTHRSVvygvBgUyuGSMyMVWKPjUinvxKwRieizWdEsaJEvngSIvRFMGMMCCvFfZgRliXuw30 = (item.get(name_key) or bytes.fromhex('').decode('utf-8')).lower()
        e11 = (bytes.fromhex('6c696e6b').decode('utf-8'), bytes.fromhex('776562').decode('utf-8'), bytes.fromhex('64657374656b').decode('utf-8'), bytes.fromhex('796f6b').decode('utf-8'))
        tttttttttt = (bytes.fromhex('696e61747476').decode('utf-8'), bytes.fromhex('40').decode('utf-8'), bytes.fromhex('686174612062696c646972').decode('utf-8'), bytes.fromhex('74656c656772616d').decode('utf-8'))
        return not any((NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN in IIIlllIllIIlIlIIlIIIIIIlIIIllIlIIlIIIIlllIIIIIIlll for NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN in e11)) and (not any((NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN in HVReciyKPeyTHRSVvygvBgUyuGSMyMVWKPjUinvxKwRieizWdEsaJEvngSIvRFMGMMCCvFfZgRliXuw30 for NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN in tttttttttt)))

    @staticmethod
    def item_title(item):
        return item.get(bytes.fromhex('63684e616d65').decode('utf-8')) or item.get(bytes.fromhex('5469746c65').decode('utf-8')) or item.get(bytes.fromhex('6361744e616d65').decode('utf-8')) or bytes.fromhex('4261736c696b').decode('utf-8')

    @staticmethod
    def item_image(item):
        nnnnnnnnnnnnnnnnnnnnnnnnnnnnn = item.get(bytes.fromhex('4d6564696173').decode('utf-8')) or []
        for media in nnnnnnnnnnnnnnnnnnnnnnnnnnnnn:
            if media.get(bytes.fromhex('54797065').decode('utf-8')) in (1, 2) and media.get(bytes.fromhex('55524c').decode('utf-8')):
                return media.get(bytes.fromhex('55524c').decode('utf-8'))
        return item.get(bytes.fromhex('6368496d67').decode('utf-8')) or item.get(bytes.fromhex('636174496d67').decode('utf-8')) or bytes.fromhex('').decode('utf-8')

    @staticmethod
    def item_plot(item):
        w21 = item.get(bytes.fromhex('47656e7265').decode('utf-8')) or []
        llIlIlllIllllIllllll = bytes.fromhex('2c20').decode('utf-8').join([j715943444092219.get(bytes.fromhex('5469746c65').decode('utf-8')) or j715943444092219.get(bytes.fromhex('4e616d65').decode('utf-8')) or bytes.fromhex('').decode('utf-8') for j715943444092219 in w21 if isinstance(j715943444092219, dict)])
        aaAaAaAAAaAAaaAaaAAAaaAAaaAaaaAAAAA = [item.get(bytes.fromhex('4465736372697074696f6e').decode('utf-8')) or bytes.fromhex('').decode('utf-8'), item.get(bytes.fromhex('54616773').decode('utf-8')) or bytes.fromhex('').decode('utf-8'), llIlIlllIllllIllllll]
        return bytes.fromhex('0a').decode('utf-8').join([NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN for NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN in aaAaAaAAAaAAaaAaaAAAaaAAaaAaaaAAAAA if NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN])

    @staticmethod
    def media_label(media):
        if media.get(bytes.fromhex('54797065').decode('utf-8')):
            return bytes.fromhex('4b61796e616b207b307d').decode('utf-8').format(media.get(bytes.fromhex('54797065').decode('utf-8')))
        return media.get(bytes.fromhex('46696c65554944').decode('utf-8')) or bytes.fromhex('4b61796e616b').decode('utf-8')

    @staticmethod
    def vk_source_fix(url):
        if (url or bytes.fromhex('').decode('utf-8')).startswith(bytes.fromhex('616374').decode('utf-8')):
            return bytes.fromhex('68747470733a2f2f766b2e636f6d2f616c5f766964656f2e7068703f').decode('utf-8') + url
        return url

    @staticmethod
    def is_direct_stream(url):
        lower = (url or bytes.fromhex('').decode('utf-8')).lower()
        return bytes.fromhex('2e6d337538').decode('utf-8') in lower or bytes.fromhex('2e6d7064').decode('utf-8') in lower or bytes.fromhex('2e6d7034').decode('utf-8') in lower or (bytes.fromhex('2e7765626d').decode('utf-8') in lower)

    @staticmethod
    def kodi_headers(headers):
        if not headers:
            return bytes.fromhex('').decode('utf-8')
        aaAaAaAAAaAAaaAaaAAAaaAAaaAaaaAAAAA = []
        for key in sorted(headers):
            if headers[key]:
                aaAaAaAAAaAAaaAaaAAAaaAAaaAaaaAAAAA.append(bytes.fromhex('7b307d3d7b317d').decode('utf-8').format(key, quote(headers[key])))
        return bytes.fromhex('7c').decode('utf-8') + bytes.fromhex('26').decode('utf-8').join(aaAaAaAAAaAAaaAaaAAAaaAAaaAaaaAAAAA) if aaAaAaAAAaAAaaAaaAAAaaAAaaAaaaAAAAA else bytes.fromhex('').decode('utf-8')

def aes_cbc_decrypt(data, key, iv):
    if len(key) != 16 or len(iv) != 16 or len(data) % 16:
        raise ValueError(bytes.fromhex('4145532d3132382d434243206461746120697320696e76616c6964').decode('utf-8'))
    round_keys = aes_expand_key(key)
    ddddddddddddddddddddddddddddddddddddddd = iv
    K32 = []
    for llIIlIlIIIIlIlIIIIIIIIIIlIIIIIl in range(0, len(data), 16):
        block = aes_decrypt_block(data[llIIlIlIIIIlIlIIIIIIIIIIlIIIIIl:llIIlIlIIIIlIlIIIIIIIIIIlIIIIIl + 16], round_keys)
        K32.append(bytes([block[IlIllIlIIIlllIIlIIIIllII] ^ ddddddddddddddddddddddddddddddddddddddd[IlIllIlIIIlllIIlIIIIllII] for IlIllIlIIIlllIIlIIIIllII in range(16)]))
        ddddddddddddddddddddddddddddddddddddddd = data[llIIlIlIIIIlIlIIIIIIIIIIlIIIIIl:llIIlIlIIIIlIlIIIIIIIIIIlIIIIIl + 16]
    tttttttttttttttttttttttttttttttttttttt = b''.join(K32)
    W351434290310433 = tttttttttttttttttttttttttttttttttttttt[-1]
    if W351434290310433 < 1 or W351434290310433 > 16 or tttttttttttttttttttttttttttttttttttttt[-W351434290310433:] != bytes([W351434290310433]) * W351434290310433:
        raise ValueError(bytes.fromhex('4145532070616464696e6720697320696e76616c6964').decode('utf-8'))
    return tttttttttttttttttttttttttttttttttttttt[:-W351434290310433]

def aes_decrypt_block(block, round_keys):
    state = list(block)
    add_round_key(state, round_keys[10])
    for VSWqSrcnwULRYevQCqwyIMcfyXxRBOLERWnDxkiPIsqbvmiAtWeBsJVFlFZgWemxwIPynkkuzfWOXpl46 in range(9, 0, -1):
        inv_shift_rows(state)
        inv_sub_bytes(state)
        add_round_key(state, round_keys[VSWqSrcnwULRYevQCqwyIMcfyXxRBOLERWnDxkiPIsqbvmiAtWeBsJVFlFZgWemxwIPynkkuzfWOXpl46])
        inv_mix_columns(state)
    inv_shift_rows(state)
    inv_sub_bytes(state)
    add_round_key(state, round_keys[0])
    return state

def aes_expand_key(key):
    OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO = [list(key[IlIllIlIIIlllIIlIIIIllII:IlIllIlIIIlllIIlIIIIllII + 4]) for IlIllIlIIIlllIIlIIIIllII in range(0, 16, 4)]
    llIllIIlIlIIIlIlIlIIlIlllllllllIIIIlIlIlI = 1
    while len(OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO) < 44:
        lIIllIIIlIIIllIllIllllIllllIIllIllIllIIIIlllIIIII = OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO[-1][:]
        if len(OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO) % 4 == 0:
            lIIllIIIlIIIllIllIllllIllllIIllIllIllIIIIlllIIIII = [SBOX[lIIllIIIlIIIllIllIllllIllllIIllIllIllIIIIlllIIIII[1]], SBOX[lIIllIIIlIIIllIllIllllIllllIIllIllIllIIIIlllIIIII[2]], SBOX[lIIllIIIlIIIllIllIllllIllllIIllIllIllIIIIlllIIIII[3]], SBOX[lIIllIIIlIIIllIllIllllIllllIIllIllIllIIIIlllIIIII[0]]]
            lIIllIIIlIIIllIllIllllIllllIIllIllIllIIIIlllIIIII[0] ^= llIllIIlIlIIIlIlIlIIlIlllllllllIIIIlIlIlI
            llIllIIlIlIIIlIlIlIIlIlllllllllIIIIlIlIlI = xtime(llIllIIlIlIIIlIlIlIIlIlllllllllIIIIlIlIlI)
        OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO.append([OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO[-4][IlIllIlIIIlllIIlIIIIllII] ^ lIIllIIIlIIIllIllIllllIllllIIllIllIllIIIIlllIIIII[IlIllIlIIIlllIIlIIIIllII] for IlIllIlIIIlllIIlIIIIllII in range(4)])
    aAaAaAaAaaAAaaAaAaaAaaaAaa = []
    for IlIllIlIIIlllIIlIIIIllII in range(0, 44, 4):
        aAaAaAaAaaAAaaAaAaaAaaaAaa.append(OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO[IlIllIlIIIlllIIlIIIIllII] + OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO[IlIllIlIIIlllIIlIIIIllII + 1] + OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO[IlIllIlIIIlllIIlIIIIllII + 2] + OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO[IlIllIlIIIlllIIlIIIIllII + 3])
    return aAaAaAaAaaAAaaAaAaaAaaaAaa

def add_round_key(state, key):
    for IlIllIlIIIlllIIlIIIIllII in range(16):
        state[IlIllIlIIIlllIIlIIIIllII] ^= key[IlIllIlIIIlllIIlIIIIllII]

def inv_sub_bytes(state):
    for IlIllIlIIIlllIIlIIIIllII in range(16):
        state[IlIllIlIIIlllIIlIIIIllII] = INV_SBOX[state[IlIllIlIIIlllIIlIIIIllII]]

def inv_shift_rows(state):
    state[1], state[5], state[9], state[13] = (state[13], state[1], state[5], state[9])
    state[2], state[6], state[10], state[14] = (state[10], state[14], state[2], state[6])
    state[3], state[7], state[11], state[15] = (state[7], state[11], state[15], state[3])

def inv_mix_columns(state):
    for sssssssssssss in range(4):
        IlIllIlIIIlllIIlIIIIllII = sssssssssssss * 4
        EEEE, k5, IIlIII, lIIIIll = state[IlIllIlIIIlllIIlIIIIllII:IlIllIlIIIlllIIlIIIIllII + 4]
        state[IlIllIlIIIlllIIlIIIIllII] = gf_mul(EEEE, 14) ^ gf_mul(k5, 11) ^ gf_mul(IIlIII, 13) ^ gf_mul(lIIIIll, 9)
        state[IlIllIlIIIlllIIlIIIIllII + 1] = gf_mul(EEEE, 9) ^ gf_mul(k5, 14) ^ gf_mul(IIlIII, 11) ^ gf_mul(lIIIIll, 13)
        state[IlIllIlIIIlllIIlIIIIllII + 2] = gf_mul(EEEE, 13) ^ gf_mul(k5, 9) ^ gf_mul(IIlIII, 14) ^ gf_mul(lIIIIll, 11)
        state[IlIllIlIIIlllIIlIIIIllII + 3] = gf_mul(EEEE, 11) ^ gf_mul(k5, 13) ^ gf_mul(IIlIII, 9) ^ gf_mul(lIIIIll, 14)

def xtime(value):
    return (value << 1 ^ 27) & 255 if value & 128 else value << 1

def gf_mul(a, b):
    nTepSAGIAkNxexXXSWTDKyQVmYTPIvlVaRLEelrUoMpJIjANncuPrihBDDnRroiNhFyOodndjhbsgGV44 = 0
    while b:
        if b & 1:
            nTepSAGIAkNxexXXSWTDKyQVmYTPIvlVaRLEelrUoMpJIjANncuPrihBDDnRroiNhFyOodndjhbsgGV44 ^= a
        a = xtime(a)
        b >>= 1
    return nTepSAGIAkNxexXXSWTDKyQVmYTPIvlVaRLEelrUoMpJIjANncuPrihBDDnRroiNhFyOodndjhbsgGV44
SBOX = (99, 124, 119, 123, 242, 107, 111, 197, 48, 1, 103, 43, 254, 215, 171, 118, 202, 130, 201, 125, 250, 89, 71, 240, 173, 212, 162, 175, 156, 164, 114, 192, 183, 253, 147, 38, 54, 63, 247, 204, 52, 165, 229, 241, 113, 216, 49, 21, 4, 199, 35, 195, 24, 150, 5, 154, 7, 18, 128, 226, 235, 39, 178, 117, 9, 131, 44, 26, 27, 110, 90, 160, 82, 59, 214, 179, 41, 227, 47, 132, 83, 209, 0, 237, 32, 252, 177, 91, 106, 203, 190, 57, 74, 76, 88, 207, 208, 239, 170, 251, 67, 77, 51, 133, 69, 249, 2, 127, 80, 60, 159, 168, 81, 163, 64, 143, 146, 157, 56, 245, 188, 182, 218, 33, 16, 255, 243, 210, 205, 12, 19, 236, 95, 151, 68, 23, 196, 167, 126, 61, 100, 93, 25, 115, 96, 129, 79, 220, 34, 42, 144, 136, 70, 238, 184, 20, 222, 94, 11, 219, 224, 50, 58, 10, 73, 6, 36, 92, 194, 211, 172, 98, 145, 149, 228, 121, 231, 200, 55, 109, 141, 213, 78, 169, 108, 86, 244, 234, 101, 122, 174, 8, 186, 120, 37, 46, 28, 166, 180, 198, 232, 221, 116, 31, 75, 189, 139, 138, 112, 62, 181, 102, 72, 3, 246, 14, 97, 53, 87, 185, 134, 193, 29, 158, 225, 248, 152, 17, 105, 217, 142, 148, 155, 30, 135, 233, 206, 85, 40, 223, 140, 161, 137, 13, 191, 230, 66, 104, 65, 153, 45, 15, 176, 84, 187, 22)
INV_SBOX = [0] * 256
for QQ, q3 in enumerate(SBOX):
    INV_SBOX[q3] = QQ
INV_SBOX = tuple(INV_SBOX)
