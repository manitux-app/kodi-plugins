# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals
FFFFFFFF = None
if False:
    FFFFFFFF.PatronUI
    FFFFFFFF.categories
    FFFFFFFF.category
    FFFFFFFF.detail
    FFFFFFFF.has_next_page
    FFFFFFFF.page
    FFFFFFFF.play
    FFFFFFFF.source
    FFFFFFFF.title
    FFFFFFFF.video
    FFFFFFFF.videos
import sys
import time
import os
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
try:
    from urllib.parse import parse_qsl, quote, urlencode
except ImportError:
    from urlparse import parse_qsl
    from urllib import quote, urlencode
from manituxui import ManituxUI, open_browser
from resources.lib.site import PatronSite
ll = bytes.fromhex('706c7567696e2e766964656f2e706174726f6e').decode('utf-8')
ANwqfVeJVqdoCkojStEvUfRQdkPOXmyARJACAZpqWpgQVkWuAOcIOGOODHKezpNyXbgavXJsihcStfD6 = ll + bytes.fromhex('2e736b69705f6775695f756e74696c').decode('utf-8')
A = xbmcaddon.Addon(id=ll)
l65941991035874 = int(sys.argv[1])
IlIll = 20
KKKKKKK = bytes.fromhex('4d6f7a696c6c612f352e30202857696e646f7773204e542031302e303b2057696e36343b2078363429204170706c655765624b69742f3533372e333620284b48544d4c2c206c696b65204765636b6f29204368726f6d652f3132302e302e302e30205361666172692f3533372e3336').decode('utf-8')
CCC = os.path.join(xbmcaddon.Addon(id=bytes.fromhex('7363726970742e6d6f64756c652e6d616e697475787569').decode('utf-8')).getAddonInfo(bytes.fromhex('70617468').decode('utf-8')), bytes.fromhex('7265736f7572636573').decode('utf-8'), bytes.fromhex('736b696e73').decode('utf-8'), bytes.fromhex('44656661756c74').decode('utf-8'), bytes.fromhex('6d65646961').decode('utf-8'), bytes.fromhex('63617465676f72795f706f737465722e706e67').decode('utf-8'))
O144386095566533 = PatronSite(user_agent=KKKKKKK)

class PatronUI(ManituxUI):
    title = bytes.fromhex('70617472306e').decode('utf-8')

    def __init__(x707206464401332):
        x707206464401332.search_query = bytes.fromhex('').decode('utf-8')
        x707206464401332.search_results = []

    def categories(x707206464401332):
        categories = [{bytes.fromhex('7469746c65').decode('utf-8'): bytes.fromhex('417261').decode('utf-8'), bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('736561726368').decode('utf-8')}]
        for qAhVGhoBMwwyItUcKJPgdAOfMlsZnLlUFjOFWuIGXMHNTnFAciDNwBPBSWBRHXjbDapzrwgGMGIaMGd28 in O144386095566533.playlists():
            categories.append({bytes.fromhex('7469746c65').decode('utf-8'): qAhVGhoBMwwyItUcKJPgdAOfMlsZnLlUFjOFWuIGXMHNTnFAciDNwBPBSWBRHXjbDapzrwgGMGIaMGd28.get(bytes.fromhex('7469746c65').decode('utf-8')) or qAhVGhoBMwwyItUcKJPgdAOfMlsZnLlUFjOFWuIGXMHNTnFAciDNwBPBSWBRHXjbDapzrwgGMGIaMGd28.get(bytes.fromhex('6e616d65').decode('utf-8')) or bytes.fromhex('4c69737465').decode('utf-8'), bytes.fromhex('6d6f6465').decode('utf-8'): bytes.fromhex('67726f757073').decode('utf-8'), bytes.fromhex('706c61796c697374').decode('utf-8'): qAhVGhoBMwwyItUcKJPgdAOfMlsZnLlUFjOFWuIGXMHNTnFAciDNwBPBSWBRHXjbDapzrwgGMGIaMGd28})
        return categories

    def videos(x707206464401332, category, page=1):
        if category.get(bytes.fromhex('616374696f6e').decode('utf-8')) == bytes.fromhex('736561726368').decode('utf-8'):
            if page <= 1 or not x707206464401332.search_query:
                XTmrVulkVqbzUtFjwahxvgxDVJhSvyCosuUqoObJqiocttyNTqHxbBEGRELRtHAQBveObmWLvBGZWzc30 = xbmcgui.Dialog().input(bytes.fromhex('506174726f6e20417261').decode('utf-8'))
                x707206464401332.search_query = XTmrVulkVqbzUtFjwahxvgxDVJhSvyCosuUqoObJqiocttyNTqHxbBEGRELRtHAQBveObmWLvBGZWzc30 or bytes.fromhex('').decode('utf-8')
                x707206464401332.search_results = O144386095566533.search(XTmrVulkVqbzUtFjwahxvgxDVJhSvyCosuUqoObJqiocttyNTqHxbBEGRELRtHAQBveObmWLvBGZWzc30) if XTmrVulkVqbzUtFjwahxvgxDVJhSvyCosuUqoObJqiocttyNTqHxbBEGRELRtHAQBveObmWLvBGZWzc30 else []
            return x707206464401332._page(x707206464401332.search_results, page)
        qAhVGhoBMwwyItUcKJPgdAOfMlsZnLlUFjOFWuIGXMHNTnFAciDNwBPBSWBRHXjbDapzrwgGMGIaMGd28 = category.get(bytes.fromhex('706c61796c697374').decode('utf-8')) or {}
        if category.get(bytes.fromhex('6d6f6465').decode('utf-8')) == bytes.fromhex('67726f75705f6974656d73').decode('utf-8'):
            items = O144386095566533.items(qAhVGhoBMwwyItUcKJPgdAOfMlsZnLlUFjOFWuIGXMHNTnFAciDNwBPBSWBRHXjbDapzrwgGMGIaMGd28, group=category.get(bytes.fromhex('67726f7570').decode('utf-8')) or bytes.fromhex('').decode('utf-8'))
            return x707206464401332._page(items, page)
        if category.get(bytes.fromhex('6d6f6465').decode('utf-8')) == bytes.fromhex('67726f757073').decode('utf-8'):
            return x707206464401332._page(x707206464401332._group_cards(qAhVGhoBMwwyItUcKJPgdAOfMlsZnLlUFjOFWuIGXMHNTnFAciDNwBPBSWBRHXjbDapzrwgGMGIaMGd28), page)
        items = O144386095566533.items(qAhVGhoBMwwyItUcKJPgdAOfMlsZnLlUFjOFWuIGXMHNTnFAciDNwBPBSWBRHXjbDapzrwgGMGIaMGd28)
        return x707206464401332._page(items, page)

    def has_next_page(x707206464401332, category, page=1, videos=None):
        if category.get(bytes.fromhex('616374696f6e').decode('utf-8')) == bytes.fromhex('736561726368').decode('utf-8'):
            return int(page) * IlIll < len(x707206464401332.search_results)
        qAhVGhoBMwwyItUcKJPgdAOfMlsZnLlUFjOFWuIGXMHNTnFAciDNwBPBSWBRHXjbDapzrwgGMGIaMGd28 = category.get(bytes.fromhex('706c61796c697374').decode('utf-8')) or {}
        if category.get(bytes.fromhex('6d6f6465').decode('utf-8')) == bytes.fromhex('67726f757073').decode('utf-8'):
            return False
        if category.get(bytes.fromhex('6d6f6465').decode('utf-8')) == bytes.fromhex('67726f75705f6974656d73').decode('utf-8'):
            AaaAAAaAaaaaaAAAAAAAAAAAAaaaAAaAaaaAA = len(O144386095566533.items(qAhVGhoBMwwyItUcKJPgdAOfMlsZnLlUFjOFWuIGXMHNTnFAciDNwBPBSWBRHXjbDapzrwgGMGIaMGd28, group=category.get(bytes.fromhex('67726f7570').decode('utf-8')) or bytes.fromhex('').decode('utf-8')))
            return int(page) * IlIll < AaaAAAaAaaaaaAAAAAAAAAAAAaaaAAaAaaaAA
        AaaAAAaAaaaaaAAAAAAAAAAAAaaaAAaAaaaAA = len(O144386095566533.items(qAhVGhoBMwwyItUcKJPgdAOfMlsZnLlUFjOFWuIGXMHNTnFAciDNwBPBSWBRHXjbDapzrwgGMGIaMGd28))
        return int(page) * IlIll < AaaAAAaAaaaaaAAAAAAAAAAAAaaaAAaAaaaAA

    def detail(x707206464401332, video):
        if video.get(bytes.fromhex('6e617669676174655f63617465676f7279').decode('utf-8')):
            return video
        aaAAAaAAaaAaAAAAaaaa = video.get(bytes.fromhex('6c6f676f').decode('utf-8')) or video.get(bytes.fromhex('696d616765').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        EEEEEEEEEEEEEEEEE = video.get(bytes.fromhex('67726f7570').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        qAhVGhoBMwwyItUcKJPgdAOfMlsZnLlUFjOFWuIGXMHNTnFAciDNwBPBSWBRHXjbDapzrwgGMGIaMGd28 = video.get(bytes.fromhex('706c61796c6973745f7469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        URLQYvlUaKxikMXBNidZaOSEEdbhcbZuWUdcuHFgqgaKfUJxLgCDRUWpdRLLUTUtxcSDVJsMhpOurdi29 = [J27 for J27 in (qAhVGhoBMwwyItUcKJPgdAOfMlsZnLlUFjOFWuIGXMHNTnFAciDNwBPBSWBRHXjbDapzrwgGMGIaMGd28, EEEEEEEEEEEEEEEEE) if J27]
        return {bytes.fromhex('7469746c65').decode('utf-8'): video.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('566964656f').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): video.get(bytes.fromhex('75726c').decode('utf-8')) or bytes.fromhex('').decode('utf-8'), bytes.fromhex('696d616765').decode('utf-8'): aaAAAaAAaaAaAAAAaaaa, bytes.fromhex('6261636b64726f70').decode('utf-8'): aaAAAaAAaaAaAAAAaaaa, bytes.fromhex('706c6f74').decode('utf-8'): bytes.fromhex('202f20').decode('utf-8').join(URLQYvlUaKxikMXBNidZaOSEEdbhcbZuWUdcuHFgqgaKfUJxLgCDRUWpdRLLUTUtxcSDVJsMhpOurdi29), bytes.fromhex('74616773').decode('utf-8'): EEEEEEEEEEEEEEEEE, bytes.fromhex('736f7572636573').decode('utf-8'): [{bytes.fromhex('6c6162656c').decode('utf-8'): bytes.fromhex('4f796e6174').decode('utf-8'), bytes.fromhex('6974656d').decode('utf-8'): video}]}

    def play(x707206464401332, source, video=None):
        aAAaaaaAaaAAaAAaaAaaaa = source.get(bytes.fromhex('6974656d').decode('utf-8')) or video or {}
        u102150003416236 = O144386095566533.stream_url(aAAaaaaAaaAAaAAaaAaaaa)
        if not u102150003416236:
            xbmcgui.Dialog().notification(bytes.fromhex('506174726f6e').decode('utf-8'), bytes.fromhex('4b61796e616b2062756c756e616d6164c4b1').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
            return
        NvVQgDNMMWQmnVwvblaFjPtcRTbZgwqXqSMjXQMMtrGCQbbrvrsaIXNwqPQBRAugjaOwMuCtTGSUXKX24 = xbmcgui.ListItem(path=u102150003416236)
        NvVQgDNMMWQmnVwvblaFjPtcRTbZgwqXqSMjXQMMtrGCQbbrvrsaIXNwqPQBRAugjaOwMuCtTGSUXKX24.setInfo(bytes.fromhex('766964656f').decode('utf-8'), {bytes.fromhex('7469746c65').decode('utf-8'): aAAaaaaAaaAAaAAaaAaaaa.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('566964656f').decode('utf-8'), bytes.fromhex('67656e7265').decode('utf-8'): aAAaaaaAaaAAaAAaaAaaaa.get(bytes.fromhex('67726f7570').decode('utf-8')) or bytes.fromhex('').decode('utf-8')})
        aaAAAaAAaaAaAAAAaaaa = aAAaaaaAaaAAaAAaaAaaaa.get(bytes.fromhex('6c6f676f').decode('utf-8')) or aAAaaaaAaaAAaAAaaAaaaa.get(bytes.fromhex('696d616765').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        if aaAAAaAAaaAaAAAAaaaa:
            NvVQgDNMMWQmnVwvblaFjPtcRTbZgwqXqSMjXQMMtrGCQbbrvrsaIXNwqPQBRAugjaOwMuCtTGSUXKX24.setArt({bytes.fromhex('7468756d62').decode('utf-8'): aaAAAaAAaaAaAAAAaaaa, bytes.fromhex('69636f6e').decode('utf-8'): aaAAAaAAaaAaAAAAaaaa, bytes.fromhex('706f73746572').decode('utf-8'): aaAAAaAAaaAaAAAAaaaa, bytes.fromhex('66616e617274').decode('utf-8'): aaAAAaAAaaAaAAAAaaaa})
        if mmmmmmmmmmmmmmmmmmmmm(u102150003416236):
            NvVQgDNMMWQmnVwvblaFjPtcRTbZgwqXqSMjXQMMtrGCQbbrvrsaIXNwqPQBRAugjaOwMuCtTGSUXKX24.setMimeType(bytes.fromhex('6170706c69636174696f6e2f766e642e6170706c652e6d70656775726c').decode('utf-8'))
            NvVQgDNMMWQmnVwvblaFjPtcRTbZgwqXqSMjXQMMtrGCQbbrvrsaIXNwqPQBRAugjaOwMuCtTGSUXKX24.setContentLookup(False)
            if llllIllIIlIIIIlIll(bytes.fromhex('696e70757473747265616d2e6164617074697665').decode('utf-8')):
                b19 = u102150003416236.split(bytes.fromhex('7c').decode('utf-8'), 1)[1] if bytes.fromhex('7c').decode('utf-8') in u102150003416236 else bytes.fromhex('').decode('utf-8')
                NvVQgDNMMWQmnVwvblaFjPtcRTbZgwqXqSMjXQMMtrGCQbbrvrsaIXNwqPQBRAugjaOwMuCtTGSUXKX24.setProperty(bytes.fromhex('696e70757473747265616d').decode('utf-8'), bytes.fromhex('696e70757473747265616d2e6164617074697665').decode('utf-8'))
                NvVQgDNMMWQmnVwvblaFjPtcRTbZgwqXqSMjXQMMtrGCQbbrvrsaIXNwqPQBRAugjaOwMuCtTGSUXKX24.setProperty(bytes.fromhex('696e70757473747265616d2e61646170746976652e73747265616d5f68656164657273').decode('utf-8'), b19)
                NvVQgDNMMWQmnVwvblaFjPtcRTbZgwqXqSMjXQMMtrGCQbbrvrsaIXNwqPQBRAugjaOwMuCtTGSUXKX24.setProperty(bytes.fromhex('696e70757473747265616d2e61646170746976652e6d616e69666573745f68656164657273').decode('utf-8'), b19)
        for mmmmmmmmmmmmmmmmmmmmmmm, aaAaAaaAAAAAAAAAAaaaaAaAAAaAAAAaAaAaaAa in (aAAaaaaAaaAAaAAaaAaaaa.get(bytes.fromhex('6b6f64695f70726f7073').decode('utf-8')) or {}).items():
            if mmmmmmmmmmmmmmmmmmmmmmm and aaAaAaaAAAAAAAAAAaaaaAaAAAaAAAAaAaAaaAa:
                NvVQgDNMMWQmnVwvblaFjPtcRTbZgwqXqSMjXQMMtrGCQbbrvrsaIXNwqPQBRAugjaOwMuCtTGSUXKX24.setProperty(mmmmmmmmmmmmmmmmmmmmmmm, aaAaAaaAAAAAAAAAAaaaaAaAAAaAAAAaAaAaaAa)
        xbmc.Player().play(u102150003416236, NvVQgDNMMWQmnVwvblaFjPtcRTbZgwqXqSMjXQMMtrGCQbbrvrsaIXNwqPQBRAugjaOwMuCtTGSUXKX24)

    def _page(x707206464401332, items, page):
        aAAaaAaaaAaAAaaAaAaaAAaAAAAAAaAAaAa = max(int(page) - 1, 0) * IlIll
        return [x707206464401332._video_item(aAAaaaaAaaAAaAAaaAaaaa) for aAAaaaaAaaAAaAAaaAaaaa in list(items or [])[aAAaaAaaaAaAAaaAaAaaAAaAAAAAAaAAaAa:aAAaaAaaaAaAAaaAaAaaAAaAAAAAAaAAaAa + IlIll]]

    def _group_cards(x707206464401332, qAhVGhoBMwwyItUcKJPgdAOfMlsZnLlUFjOFWuIGXMHNTnFAciDNwBPBSWBRHXjbDapzrwgGMGIaMGd28):
        AAAaaAaaAaaaaaAA = {}
        aAaaaAaAaAAAaaAAaaaAaaAAa = []
        for aAAaaaaAaaAAaAAaaAaaaa in O144386095566533.items(qAhVGhoBMwwyItUcKJPgdAOfMlsZnLlUFjOFWuIGXMHNTnFAciDNwBPBSWBRHXjbDapzrwgGMGIaMGd28):
            EEEEEEEEEEEEEEEEE = aAAaaaaAaaAAaAAaaAaaaa.get(bytes.fromhex('67726f7570').decode('utf-8')) or bytes.fromhex('4469676572').decode('utf-8')
            if EEEEEEEEEEEEEEEEE not in AAAaaAaaAaaaaaAA:
                AAAaaAaaAaaaaaAA[EEEEEEEEEEEEEEEEE] = 0
                aAaaaAaAaAAAaaAAaaaAaaAAa.append(EEEEEEEEEEEEEEEEE)
            AAAaaAaaAaaaaaAA[EEEEEEEEEEEEEEEEE] += 1
        aAaaaaaaaaAaA = []
        for EEEEEEEEEEEEEEEEE in aAaaaAaAaAAAaaAAaaaAaaAAa:
            aAaAaaAAaaAaAaa = AAAaaAaaAaaaaaAA.get(EEEEEEEEEEEEEEEEE, 0)
            aAaaaaaaaaAaA.append({bytes.fromhex('7469746c65').decode('utf-8'): EEEEEEEEEEEEEEEEE, bytes.fromhex('696d616765').decode('utf-8'): CCC, bytes.fromhex('706f73746572').decode('utf-8'): CCC, bytes.fromhex('7468756d62').decode('utf-8'): CCC, bytes.fromhex('6261636b64726f70').decode('utf-8'): CCC, bytes.fromhex('706c6f74').decode('utf-8'): bytes.fromhex('7b307d2069c3a76572696b').decode('utf-8').format(aAaAaaAAaaAaAaa), bytes.fromhex('6e617669676174655f63617465676f7279').decode('utf-8'): {bytes.fromhex('7469746c65').decode('utf-8'): EEEEEEEEEEEEEEEEE, bytes.fromhex('6d6f6465').decode('utf-8'): bytes.fromhex('67726f75705f6974656d73').decode('utf-8'), bytes.fromhex('706c61796c697374').decode('utf-8'): qAhVGhoBMwwyItUcKJPgdAOfMlsZnLlUFjOFWuIGXMHNTnFAciDNwBPBSWBRHXjbDapzrwgGMGIaMGd28, bytes.fromhex('67726f7570').decode('utf-8'): EEEEEEEEEEEEEEEEE}})
        return aAaaaaaaaaAaA

    def _video_item(x707206464401332, aAAaaaaAaaAAaAAaaAaaaa):
        aAAaaaaAaaAAaAAaaAaaaa = dict(aAAaaaaAaaAAaAAaaAaaaa or {})
        aaAAAaAAaaAaAAAAaaaa = aAAaaaaAaaAAaAAaaAaaaa.get(bytes.fromhex('696d616765').decode('utf-8')) or aAAaaaaAaaAAaAAaaAaaaa.get(bytes.fromhex('6c6f676f').decode('utf-8')) or aAAaaaaAaaAAaAAaaAaaaa.get(bytes.fromhex('706f73746572').decode('utf-8')) or aAAaaaaAaaAAaAAaaAaaaa.get(bytes.fromhex('7468756d62').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        aaAAAaAAaaAaAAAAaaaa = V212558132687811(aaAAAaAAaaAaAAAAaaaa)
        aAAaaaaAaaAAaAAaaAaaaa[bytes.fromhex('696d616765').decode('utf-8')] = aaAAAaAAaaAaAAAAaaaa
        aAAaaaaAaaAAaAAaaAaaaa[bytes.fromhex('706f73746572').decode('utf-8')] = aaAAAaAAaaAaAAAAaaaa
        aAAaaaaAaaAAaAAaaAaaaa[bytes.fromhex('7468756d62').decode('utf-8')] = aaAAAaAAaaAaAAAAaaaa
        aAAaaaaAaaAAaAAaaAaaaa[bytes.fromhex('6261636b64726f70').decode('utf-8')] = V212558132687811(aAAaaaaAaaAAaAAaaAaaaa.get(bytes.fromhex('6261636b64726f70').decode('utf-8')) or aaAAAaAAaaAaAAAAaaaa)
        return aAAaaaaAaaAAaAAaaAaaaa

def FFFFFFFFFFFF(XTmrVulkVqbzUtFjwahxvgxDVJhSvyCosuUqoObJqiocttyNTqHxbBEGRELRtHAQBveObmWLvBGZWzc30):
    return sys.argv[0] + bytes.fromhex('3f').decode('utf-8') + urlencode(XTmrVulkVqbzUtFjwahxvgxDVJhSvyCosuUqoObJqiocttyNTqHxbBEGRELRtHAQBveObmWLvBGZWzc30)

def V212558132687811(llIIIIIIIllIIlllIIIIllIllIIlIIlIlIIllI):
    if not llIIIIIIIllIIlllIIIIllIllIIlIIlIlIIllI or bytes.fromhex('7c').decode('utf-8') in llIIIIIIIllIIlllIIIIllIllIIlIIlIlIIllI or (not llIIIIIIIllIIlllIIIIllIllIIlIIlIlIIllI.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8')))):
        return llIIIIIIIllIIlllIIIIllIllIIlIIlIlIIllI
    return llIIIIIIIllIIlllIIIIllIllIIlIIlIlIIllI + bytes.fromhex('7c557365722d4167656e743d').decode('utf-8') + quote(KKKKKKK)

def mmmmmmmmmmmmmmmmmmmmm(llIIIIIIIllIIlllIIIIllIllIIlIIlIlIIllI):
    A679330488878214 = (llIIIIIIIllIIlllIIIIllIllIIlIIlIlIIllI or bytes.fromhex('').decode('utf-8')).split(bytes.fromhex('7c').decode('utf-8'), 1)[0].lower()
    return bytes.fromhex('2e6d337538').decode('utf-8') in A679330488878214 or A679330488878214.endswith(bytes.fromhex('2f6d61737465722e747874').decode('utf-8')) or A679330488878214.endswith(bytes.fromhex('2f7478742f6d61737465722e747874').decode('utf-8'))

def llllIllIIlIIIIlIll(IIIllIIlll):
    return bool(xbmc.getCondVisibility(bytes.fromhex('53797374656d2e4861734164646f6e287b307d29').decode('utf-8').format(IIIllIIlll)))

def bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb():
    BBBBBBBBBBBBBBBBBBBBBBBBBB = dict(parse_qsl(sys.argv[2][1:]))
    C9 = BBBBBBBBBBBBBBBBBBBBBBBBBB.get(bytes.fromhex('616374696f6e').decode('utf-8'))
    if not C9:
        xbmcplugin.endOfDirectory(l65941991035874, succeeded=True, cacheToDisc=False)
        Y40 = xbmcgui.Window(10000)
        try:
            aAAAAaaaAaAAaaaaaAaAaAaAAaaaaAaaaa = float(Y40.getProperty(ANwqfVeJVqdoCkojStEvUfRQdkPOXmyARJACAZpqWpgQVkWuAOcIOGOODHKezpNyXbgavXJsihcStfD6) or bytes.fromhex('30').decode('utf-8'))
        except ValueError:
            aAAAAaaaAaAAaaaaaAaAaAaAAaaaaAaaaa = 0
        if time.time() < aAAAAaaaAaAAaaaaaAaAaAaAAaaaaAaaaa:
            return
        Y40.clearProperty(ANwqfVeJVqdoCkojStEvUfRQdkPOXmyARJACAZpqWpgQVkWuAOcIOGOODHKezpNyXbgavXJsihcStfD6)
        xbmc.executebuiltin(bytes.fromhex('52756e506c7567696e287b307d29').decode('utf-8').format(FFFFFFFFFFFF({bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('677569').decode('utf-8')})))
        return
    if C9 == bytes.fromhex('677569').decode('utf-8'):
        open_browser(PatronUI())
        xbmcgui.Window(10000).setProperty(ANwqfVeJVqdoCkojStEvUfRQdkPOXmyARJACAZpqWpgQVkWuAOcIOGOODHKezpNyXbgavXJsihcStfD6, str(time.time() + 4))
        xbmc.executebuiltin(bytes.fromhex('416374697661746557696e646f7728486f6d6529').decode('utf-8'))
        return
    xbmcplugin.endOfDirectory(l65941991035874)
if __name__ == bytes.fromhex('5f5f6d61696e5f5f').decode('utf-8'):
    bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb()
