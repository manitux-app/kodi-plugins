# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals
l = None
if False:
    l.PatronSite
    l.get
    l.group
    l.groups
    l.item
    l.items
    l.line
    l.name
    l.parse_extinf
    l.parse_m3u
    l.playlist
    l.playlists
    l.query
    l.search
    l.split_option
    l.stream_url
    l.text
    l.title_from_name
    l.url
    l.value
    l.vlc_header_name
import json
import re
import manituxhttp
try:
    from urllib.parse import quote
except ImportError:
    from urllib import quote

class PatronSite(object):
    API_URL = bytes.fromhex('68747470733a2f2f6170692e6769746875622e636f6d2f7265706f732f70617472306e712f666c6d532f636f6e74656e7473').decode('utf-8')
    RAW_BASE = bytes.fromhex('68747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f70617472306e712f666c6d532f6d61696e2f').decode('utf-8')
    FALLBACK_PLAYLISTS = ((bytes.fromhex('66696c6d6d616b696e6573695f74756d2e6d3375').decode('utf-8'), bytes.fromhex('46696c6d6d616b696e657369').decode('utf-8')), (bytes.fromhex('66696c6d6d6f64755f74756d2e6d3375').decode('utf-8'), bytes.fromhex('46696c6d6d6f6475').decode('utf-8')), (bytes.fromhex('686466696c6d5f6c6973746573692e6d3375').decode('utf-8'), bytes.fromhex('484446696c6d').decode('utf-8')), (bytes.fromhex('6a657466696c6d5f74756d2e6d3375').decode('utf-8'), bytes.fromhex('4a657446696c6d').decode('utf-8')))
    ATTR_RE = re.compile(bytes.fromhex('285b5c772d5d2b293d22285b5e225d2a2922').decode('utf-8'))

    def __init__(HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20, user_agent):
        HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20.user_agent = user_agent
        HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20.session = manituxhttp.Session(client_identifier=bytes.fromhex('6368726f6d655f313434').decode('utf-8'))
        HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20._playlist_cache = {}

    def playlists(HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20):
        caRBEAmWTEMNmFNiYVndAbMfMNAdgfGHNpHfnWDMOrVimIIddLIyFKApjrwccwNLTSqMhMPgibUSpDd17 = []
        try:
            vvvvvvvvvvvvv = json.loads(HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20.get(HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20.API_URL))
            for item in vvvvvvvvvvvvv or []:
                name = item.get(bytes.fromhex('6e616d65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
                if not name.lower().endswith((bytes.fromhex('2e6d3375').decode('utf-8'), bytes.fromhex('2e6d337538').decode('utf-8'))):
                    continue
                caRBEAmWTEMNmFNiYVndAbMfMNAdgfGHNpHfnWDMOrVimIIddLIyFKApjrwccwNLTSqMhMPgibUSpDd17.append({bytes.fromhex('6e616d65').decode('utf-8'): name, bytes.fromhex('7469746c65').decode('utf-8'): HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20.title_from_name(name), bytes.fromhex('75726c').decode('utf-8'): item.get(bytes.fromhex('646f776e6c6f61645f75726c').decode('utf-8')) or HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20.RAW_BASE + name})
        except Exception:
            caRBEAmWTEMNmFNiYVndAbMfMNAdgfGHNpHfnWDMOrVimIIddLIyFKApjrwccwNLTSqMhMPgibUSpDd17 = []
        if caRBEAmWTEMNmFNiYVndAbMfMNAdgfGHNpHfnWDMOrVimIIddLIyFKApjrwccwNLTSqMhMPgibUSpDd17:
            return sorted(caRBEAmWTEMNmFNiYVndAbMfMNAdgfGHNpHfnWDMOrVimIIddLIyFKApjrwccwNLTSqMhMPgibUSpDd17, key=lambda item: item.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8'))
        return [{bytes.fromhex('6e616d65').decode('utf-8'): name, bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20.RAW_BASE + name} for name, title in HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20.FALLBACK_PLAYLISTS]

    def groups(HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20, playlist):
        groups = []
        aAaaaaAAaAAAaAAAAAa = set()
        for item in HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20.items(playlist):
            group = item.get(bytes.fromhex('67726f7570').decode('utf-8')) or bytes.fromhex('4469676572').decode('utf-8')
            t9 = group.lower()
            if t9 in aAaaaaAAaAAAaAAAAAa:
                continue
            aAaaaaAAaAAAaAAAAAa.add(t9)
            groups.append(group)
        return groups

    def items(HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20, playlist, group=bytes.fromhex('').decode('utf-8')):
        url = playlist.get(bytes.fromhex('75726c').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        BuLCwJhQvTGgkprPsmvWIiLFBBRPxbEtZhifAIItlQKCRIwNQUknDKbmZLuWLneCLhpPHESrhhSidnh4 = url or playlist.get(bytes.fromhex('6e616d65').decode('utf-8')) or playlist.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        if BuLCwJhQvTGgkprPsmvWIiLFBBRPxbEtZhifAIItlQKCRIwNQUknDKbmZLuWLneCLhpPHESrhhSidnh4 in HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20._playlist_cache:
            items = HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20._playlist_cache[BuLCwJhQvTGgkprPsmvWIiLFBBRPxbEtZhifAIItlQKCRIwNQUknDKbmZLuWLneCLhpPHESrhhSidnh4]
        else:
            items = HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20.parse_m3u(HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20.get(url))
            lBWLlufucmhNbpIULfeHNcsCceWyYEcSySglIoUYzkSbRsERhSxEjREdNoqSrdtljCmnSJeTGvEIHnM14 = playlist.get(bytes.fromhex('7469746c65').decode('utf-8')) or playlist.get(bytes.fromhex('6e616d65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
            for item in items:
                item[bytes.fromhex('706c61796c6973745f7469746c65').decode('utf-8')] = lBWLlufucmhNbpIULfeHNcsCceWyYEcSySglIoUYzkSbRsERhSxEjREdNoqSrdtljCmnSJeTGvEIHnM14
            HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20._playlist_cache[BuLCwJhQvTGgkprPsmvWIiLFBBRPxbEtZhifAIItlQKCRIwNQUknDKbmZLuWLneCLhpPHESrhhSidnh4] = items
        if group:
            return [item for item in items if (item.get(bytes.fromhex('67726f7570').decode('utf-8')) or bytes.fromhex('4469676572').decode('utf-8')) == group]
        return items

    def search(HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20, query):
        AoXtgpHRxoqHWrwwVrzuLIDyTQEqwCuKqDanznVTeosgNebLvsGQrCDgWULxNAJNBYjmorubQZkCDWS11 = (query or bytes.fromhex('').decode('utf-8')).lower()
        G18 = []
        for playlist in HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20.playlists():
            for item in HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20.items(playlist):
                ffffff = bytes.fromhex('20').decode('utf-8').join((item.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8'), item.get(bytes.fromhex('67726f7570').decode('utf-8')) or bytes.fromhex('').decode('utf-8'), playlist.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8'))).lower()
                if AoXtgpHRxoqHWrwwVrzuLIDyTQEqwCuKqDanznVTeosgNebLvsGQrCDgWULxNAJNBYjmorubQZkCDWS11 in ffffff:
                    item = dict(item)
                    item[bytes.fromhex('7469746c65').decode('utf-8')] = bytes.fromhex('5b7b307d5d207b317d').decode('utf-8').format(playlist.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('4c69737465').decode('utf-8'), item.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('566964656f').decode('utf-8'))
                    G18.append(item)
        return G18

    def stream_url(HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20, item):
        url = (item or {}).get(bytes.fromhex('75726c').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        if not url:
            return bytes.fromhex('').decode('utf-8')
        IlIIIIIl = dict((item or {}).get(bytes.fromhex('68656164657273').decode('utf-8')) or {})
        if bytes.fromhex('557365722d4167656e74').decode('utf-8') not in IlIIIIIl:
            IlIIIIIl[bytes.fromhex('557365722d4167656e74').decode('utf-8')] = HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20.user_agent
        if not IlIIIIIl:
            return url
        return url + bytes.fromhex('7c').decode('utf-8') + bytes.fromhex('26').decode('utf-8').join((bytes.fromhex('7b307d3d7b317d').decode('utf-8').format(t9, quote(value)) for t9, value in sorted(IlIIIIIl.items()) if value))

    def get(HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20, url):
        IlIIIIIl = {bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('2a2f2a').decode('utf-8'), bytes.fromhex('557365722d4167656e74').decode('utf-8'): HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20.user_agent}
        v16 = HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20.session.get(url, headers=IlIIIIIl, timeout=30, allow_redirects=True)
        v16.raise_for_status()
        if (url or bytes.fromhex('').decode('utf-8')).startswith(HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20.RAW_BASE):
            return v16.content.decode(bytes.fromhex('7574662d38').decode('utf-8'), bytes.fromhex('7265706c616365').decode('utf-8'))
        return v16.text

    def parse_m3u(HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20, text):
        items = []
        Aaaaa = None
        IlIIIIIl = {}
        pHUxJbZjaceJnDCgWZkRJdjcbKKVQcsMlIiANnxEQKlFYEveCRQThgcUDZJomMoSsidTPwIlwJYFURY10 = {}
        for AaaaaaAaaaaaAAa in (text or bytes.fromhex('').decode('utf-8')).splitlines():
            line = AaaaaaAaaaaaAAa.strip()
            if not line:
                continue
            if line.startswith(bytes.fromhex('23455854494e46').decode('utf-8')):
                LiArcskjHlkQZmjjWQtNIlMKRiBwGYHAtCXBUCWoplTpUoBKhHqJfpdAfLUnXoAPPdZqrhZklFWYJLa3, title = HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20.parse_extinf(line)
                Aaaaa = {bytes.fromhex('7469746c65').decode('utf-8'): title or LiArcskjHlkQZmjjWQtNIlMKRiBwGYHAtCXBUCWoplTpUoBKhHqJfpdAfLUnXoAPPdZqrhZklFWYJLa3.get(bytes.fromhex('7476672d6e616d65').decode('utf-8')) or bytes.fromhex('566964656f').decode('utf-8'), bytes.fromhex('6c6f676f').decode('utf-8'): LiArcskjHlkQZmjjWQtNIlMKRiBwGYHAtCXBUCWoplTpUoBKhHqJfpdAfLUnXoAPPdZqrhZklFWYJLa3.get(bytes.fromhex('7476672d6c6f676f').decode('utf-8')) or bytes.fromhex('').decode('utf-8'), bytes.fromhex('67726f7570').decode('utf-8'): LiArcskjHlkQZmjjWQtNIlMKRiBwGYHAtCXBUCWoplTpUoBKhHqJfpdAfLUnXoAPPdZqrhZklFWYJLa3.get(bytes.fromhex('67726f75702d7469746c65').decode('utf-8')) or bytes.fromhex('4469676572').decode('utf-8'), bytes.fromhex('68656164657273').decode('utf-8'): {}, bytes.fromhex('6b6f64695f70726f7073').decode('utf-8'): {}}
                IlIIIIIl = {}
                pHUxJbZjaceJnDCgWZkRJdjcbKKVQcsMlIiANnxEQKlFYEveCRQThgcUDZJomMoSsidTPwIlwJYFURY10 = {}
            elif line.startswith(bytes.fromhex('23455854564c434f50543a').decode('utf-8')):
                name, value = HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20.split_option(line[len(bytes.fromhex('23455854564c434f50543a').decode('utf-8')):])
                aaaAaaa = HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20.vlc_header_name(name)
                if aaaAaaa and value:
                    IlIIIIIl[aaaAaaa] = value
            elif line.startswith(bytes.fromhex('234b4f444950524f503a').decode('utf-8')):
                name, value = HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20.split_option(line[len(bytes.fromhex('234b4f444950524f503a').decode('utf-8')):])
                if name and value:
                    pHUxJbZjaceJnDCgWZkRJdjcbKKVQcsMlIiANnxEQKlFYEveCRQThgcUDZJomMoSsidTPwIlwJYFURY10[name] = value
            elif line.startswith(bytes.fromhex('23').decode('utf-8')):
                continue
            elif Aaaaa:
                Aaaaa[bytes.fromhex('75726c').decode('utf-8')] = line
                Aaaaa[bytes.fromhex('68656164657273').decode('utf-8')] = IlIIIIIl
                Aaaaa[bytes.fromhex('6b6f64695f70726f7073').decode('utf-8')] = pHUxJbZjaceJnDCgWZkRJdjcbKKVQcsMlIiANnxEQKlFYEveCRQThgcUDZJomMoSsidTPwIlwJYFURY10
                items.append(Aaaaa)
                Aaaaa = None
                IlIIIIIl = {}
                pHUxJbZjaceJnDCgWZkRJdjcbKKVQcsMlIiANnxEQKlFYEveCRQThgcUDZJomMoSsidTPwIlwJYFURY10 = {}
        return items

    def parse_extinf(HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20, line):
        LiArcskjHlkQZmjjWQtNIlMKRiBwGYHAtCXBUCWoplTpUoBKhHqJfpdAfLUnXoAPPdZqrhZklFWYJLa3 = dict(HHIumsNvVatlUpxebdZZiiiZCuOIFyvEmCpXnlPlbnUcurxQevrkUJdApCxtFdgCkLCfcmCNiCznStr20.ATTR_RE.findall(line))
        title = bytes.fromhex('').decode('utf-8')
        if bytes.fromhex('2c').decode('utf-8') in line:
            title = line.rsplit(bytes.fromhex('2c').decode('utf-8'), 1)[-1].strip()
        return (LiArcskjHlkQZmjjWQtNIlMKRiBwGYHAtCXBUCWoplTpUoBKhHqJfpdAfLUnXoAPPdZqrhZklFWYJLa3, title)

    @staticmethod
    def split_option(value):
        if bytes.fromhex('3d').decode('utf-8') not in value:
            return (value.strip(), bytes.fromhex('').decode('utf-8'))
        name, IlIllllIIlIl = value.split(bytes.fromhex('3d').decode('utf-8'), 1)
        return (name.strip(), IlIllllIIlIl.strip())

    @staticmethod
    def vlc_header_name(name):
        Y93196119147922 = {bytes.fromhex('687474702d7265666572726572').decode('utf-8'): bytes.fromhex('52656665726572').decode('utf-8'), bytes.fromhex('687474702d72656665726572').decode('utf-8'): bytes.fromhex('52656665726572').decode('utf-8'), bytes.fromhex('687474702d757365722d6167656e74').decode('utf-8'): bytes.fromhex('557365722d4167656e74').decode('utf-8'), bytes.fromhex('687474702d6f726967696e').decode('utf-8'): bytes.fromhex('4f726967696e').decode('utf-8')}
        return Y93196119147922.get((name or bytes.fromhex('').decode('utf-8')).lower(), bytes.fromhex('').decode('utf-8'))

    @staticmethod
    def title_from_name(name):
        title = (name or bytes.fromhex('').decode('utf-8')).rsplit(bytes.fromhex('2e').decode('utf-8'), 1)[0].replace(bytes.fromhex('5f74756d').decode('utf-8'), bytes.fromhex('').decode('utf-8')).replace(bytes.fromhex('5f6c697374657369').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
        return title.replace(bytes.fromhex('5f').decode('utf-8'), bytes.fromhex('20').decode('utf-8')).replace(bytes.fromhex('2d').decode('utf-8'), bytes.fromhex('20').decode('utf-8')).title()
