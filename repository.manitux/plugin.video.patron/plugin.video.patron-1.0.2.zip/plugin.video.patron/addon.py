from __future__ import absolute_import, unicode_literals
import sys
import time
import os
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
try:
    from urllib.parse import parse_qsl, quote, urlencode
except ImportError:
    from urlparse import parse_qsl
    from urllib import quote, urlencode
from manituxui import ManituxUI, open_browser
from resources.lib.site import PatronSite
ADDON_ID = bytes.fromhex('706c7567696e2e766964656f2e706174726f6e').decode('utf-8')
SKIP_GUI_UNTIL = ADDON_ID + bytes.fromhex('2e736b69705f6775695f756e74696c').decode('utf-8')
ADDON = xbmcaddon.Addon(id=ADDON_ID)
HANDLE = int(sys.argv[1])
PAGE_SIZE = 20
UA = bytes.fromhex('4d6f7a696c6c612f352e30202857696e646f7773204e542031302e303b2057696e36343b2078363429204170706c655765624b69742f3533372e333620284b48544d4c2c206c696b65204765636b6f29204368726f6d652f3132302e302e302e30205361666172692f3533372e3336').decode('utf-8')
CATEGORY_ICON = os.path.join(xbmcaddon.Addon(id=bytes.fromhex('7363726970742e6d6f64756c652e6d616e697475787569').decode('utf-8')).getAddonInfo(bytes.fromhex('70617468').decode('utf-8')), bytes.fromhex('7265736f7572636573').decode('utf-8'), bytes.fromhex('736b696e73').decode('utf-8'), bytes.fromhex('44656661756c74').decode('utf-8'), bytes.fromhex('6d65646961').decode('utf-8'), bytes.fromhex('63617465676f72795f706f737465722e706e67').decode('utf-8'))
IlIlIIIIlIIll = PatronSite(user_agent=UA)

class PatronUI(ManituxUI):
    title = bytes.fromhex('70617472306e').decode('utf-8')

    def __init__(self):
        self.search_query = bytes.fromhex('').decode('utf-8')
        self.search_results = []

    def categories(self):
        categories = [{bytes.fromhex('7469746c65').decode('utf-8'): bytes.fromhex('417261').decode('utf-8'), bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('736561726368').decode('utf-8')}]
        for playlist in IlIlIIIIlIIll.playlists():
            categories.append({bytes.fromhex('7469746c65').decode('utf-8'): playlist.get(bytes.fromhex('7469746c65').decode('utf-8')) or playlist.get(bytes.fromhex('6e616d65').decode('utf-8')) or bytes.fromhex('4c69737465').decode('utf-8'), bytes.fromhex('6d6f6465').decode('utf-8'): bytes.fromhex('67726f757073').decode('utf-8'), bytes.fromhex('706c61796c697374').decode('utf-8'): playlist})
        return categories

    def videos(self, category, page=1):
        if category.get(bytes.fromhex('616374696f6e').decode('utf-8')) == bytes.fromhex('736561726368').decode('utf-8'):
            if page <= 1 or not self.search_query:
                query = xbmcgui.Dialog().input(bytes.fromhex('506174726f6e20417261').decode('utf-8'))
                self.search_query = query or bytes.fromhex('').decode('utf-8')
                self.search_results = IlIlIIIIlIIll.search(query) if query else []
            return self._page(self.search_results, page)
        playlist = category.get(bytes.fromhex('706c61796c697374').decode('utf-8')) or {}
        if category.get(bytes.fromhex('6d6f6465').decode('utf-8')) == bytes.fromhex('67726f75705f6974656d73').decode('utf-8'):
            items = IlIlIIIIlIIll.items(playlist, group=category.get(bytes.fromhex('67726f7570').decode('utf-8')) or bytes.fromhex('').decode('utf-8'))
            return self._page(items, page)
        if category.get(bytes.fromhex('6d6f6465').decode('utf-8')) == bytes.fromhex('67726f757073').decode('utf-8'):
            return self._page(self._group_cards(playlist), page)
        items = IlIlIIIIlIIll.items(playlist)
        return self._page(items, page)

    def has_next_page(self, category, page=1, videos=None):
        if category.get(bytes.fromhex('616374696f6e').decode('utf-8')) == bytes.fromhex('736561726368').decode('utf-8'):
            return int(page) * PAGE_SIZE < len(self.search_results)
        playlist = category.get(bytes.fromhex('706c61796c697374').decode('utf-8')) or {}
        if category.get(bytes.fromhex('6d6f6465').decode('utf-8')) == bytes.fromhex('67726f757073').decode('utf-8'):
            return False
        if category.get(bytes.fromhex('6d6f6465').decode('utf-8')) == bytes.fromhex('67726f75705f6974656d73').decode('utf-8'):
            I17 = len(IlIlIIIIlIIll.items(playlist, group=category.get(bytes.fromhex('67726f7570').decode('utf-8')) or bytes.fromhex('').decode('utf-8')))
            return int(page) * PAGE_SIZE < I17
        I17 = len(IlIlIIIIlIIll.items(playlist))
        return int(page) * PAGE_SIZE < I17

    def detail(self, video):
        if video.get(bytes.fromhex('6e617669676174655f63617465676f7279').decode('utf-8')):
            return video
        n7 = art_url(video.get(bytes.fromhex('6c6f676f').decode('utf-8')) or video.get(bytes.fromhex('696d616765').decode('utf-8')) or bytes.fromhex('').decode('utf-8'))
        group = video.get(bytes.fromhex('67726f7570').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        playlist = video.get(bytes.fromhex('706c61796c6973745f7469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        w12 = [H628622261684011 for H628622261684011 in (playlist, group) if H628622261684011]
        return {bytes.fromhex('7469746c65').decode('utf-8'): video.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('566964656f').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): video.get(bytes.fromhex('75726c').decode('utf-8')) or bytes.fromhex('').decode('utf-8'), bytes.fromhex('696d616765').decode('utf-8'): n7, bytes.fromhex('6261636b64726f70').decode('utf-8'): n7, bytes.fromhex('706c6f74').decode('utf-8'): bytes.fromhex('202f20').decode('utf-8').join(w12), bytes.fromhex('74616773').decode('utf-8'): group, bytes.fromhex('736f7572636573').decode('utf-8'): [{bytes.fromhex('6c6162656c').decode('utf-8'): bytes.fromhex('4f796e6174').decode('utf-8'), bytes.fromhex('6974656d').decode('utf-8'): video}]}

    def play(self, source, video=None):
        item = source.get(bytes.fromhex('6974656d').decode('utf-8')) or video or {}
        IIllIllIlIlIIIlI = IlIlIIIIlIIll.stream_url(item)
        if not IIllIllIlIlIIIlI:
            xbmcgui.Dialog().notification(bytes.fromhex('506174726f6e').decode('utf-8'), bytes.fromhex('4b61796e616b2062756c756e616d6164c4b1').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
            return
        aAAAAaAAA = xbmcgui.ListItem(path=IIllIllIlIlIIIlI)
        aAAAAaAAA.setInfo(bytes.fromhex('766964656f').decode('utf-8'), {bytes.fromhex('7469746c65').decode('utf-8'): item.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('566964656f').decode('utf-8'), bytes.fromhex('67656e7265').decode('utf-8'): item.get(bytes.fromhex('67726f7570').decode('utf-8')) or bytes.fromhex('').decode('utf-8')})
        n7 = art_url(item.get(bytes.fromhex('6c6f676f').decode('utf-8')) or item.get(bytes.fromhex('696d616765').decode('utf-8')) or bytes.fromhex('').decode('utf-8'))
        if n7:
            aAAAAaAAA.setArt({bytes.fromhex('7468756d62').decode('utf-8'): n7, bytes.fromhex('69636f6e').decode('utf-8'): n7, bytes.fromhex('706f73746572').decode('utf-8'): n7, bytes.fromhex('66616e617274').decode('utf-8'): n7})
        if is_hls_stream(IIllIllIlIlIIIlI):
            aAAAAaAAA.setMimeType(bytes.fromhex('6170706c69636174696f6e2f766e642e6170706c652e6d70656775726c').decode('utf-8'))
            aAAAAaAAA.setContentLookup(False)
            if has_addon(bytes.fromhex('696e70757473747265616d2e6164617074697665').decode('utf-8')):
                IlllIl = IIllIllIlIlIIIlI.split(bytes.fromhex('7c').decode('utf-8'), 1)[1] if bytes.fromhex('7c').decode('utf-8') in IIllIllIlIlIIIlI else bytes.fromhex('').decode('utf-8')
                aAAAAaAAA.setProperty(bytes.fromhex('696e70757473747265616d').decode('utf-8'), bytes.fromhex('696e70757473747265616d2e6164617074697665').decode('utf-8'))
                aAAAAaAAA.setProperty(bytes.fromhex('696e70757473747265616d2e61646170746976652e73747265616d5f68656164657273').decode('utf-8'), IlllIl)
                aAAAAaAAA.setProperty(bytes.fromhex('696e70757473747265616d2e61646170746976652e6d616e69666573745f68656164657273').decode('utf-8'), IlllIl)
        for tttttttt, V18 in (item.get(bytes.fromhex('6b6f64695f70726f7073').decode('utf-8')) or {}).items():
            if tttttttt and V18:
                aAAAAaAAA.setProperty(tttttttt, V18)
        xbmc.Player().play(IIllIllIlIlIIIlI, aAAAAaAAA)

    def _page(self, items, page):
        u415391480263715 = max(int(page) - 1, 0) * PAGE_SIZE
        return [self._video_item(item) for item in list(items or [])[u415391480263715:u415391480263715 + PAGE_SIZE]]

    def _group_cards(self, playlist):
        v5 = {}
        bWZuJBWoFTpBnGIValdKvvqbdwGismdbFtvuoJfvpbgTseVrxkKibLosSmWrMyCKsEUedenouDYCRWB10 = []
        for item in IlIlIIIIlIIll.items(playlist):
            group = item.get(bytes.fromhex('67726f7570').decode('utf-8')) or bytes.fromhex('4469676572').decode('utf-8')
            if group not in v5:
                v5[group] = 0
                bWZuJBWoFTpBnGIValdKvvqbdwGismdbFtvuoJfvpbgTseVrxkKibLosSmWrMyCKsEUedenouDYCRWB10.append(group)
            v5[group] += 1
        f2 = []
        for group in bWZuJBWoFTpBnGIValdKvvqbdwGismdbFtvuoJfvpbgTseVrxkKibLosSmWrMyCKsEUedenouDYCRWB10:
            aAAA = v5.get(group, 0)
            f2.append({bytes.fromhex('7469746c65').decode('utf-8'): group, bytes.fromhex('696d616765').decode('utf-8'): CATEGORY_ICON, bytes.fromhex('706f73746572').decode('utf-8'): CATEGORY_ICON, bytes.fromhex('7468756d62').decode('utf-8'): CATEGORY_ICON, bytes.fromhex('6261636b64726f70').decode('utf-8'): CATEGORY_ICON, bytes.fromhex('706c6f74').decode('utf-8'): bytes.fromhex('7b307d2069c3a76572696b').decode('utf-8').format(aAAA), bytes.fromhex('6e617669676174655f63617465676f7279').decode('utf-8'): {bytes.fromhex('7469746c65').decode('utf-8'): group, bytes.fromhex('6d6f6465').decode('utf-8'): bytes.fromhex('67726f75705f6974656d73').decode('utf-8'), bytes.fromhex('706c61796c697374').decode('utf-8'): playlist, bytes.fromhex('67726f7570').decode('utf-8'): group}})
        return f2

    def _video_item(self, item):
        item = dict(item or {})
        n7 = item.get(bytes.fromhex('696d616765').decode('utf-8')) or item.get(bytes.fromhex('6c6f676f').decode('utf-8')) or item.get(bytes.fromhex('706f73746572').decode('utf-8')) or item.get(bytes.fromhex('7468756d62').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        n7 = art_url(n7)
        item[bytes.fromhex('696d616765').decode('utf-8')] = n7
        item[bytes.fromhex('706f73746572').decode('utf-8')] = n7
        item[bytes.fromhex('7468756d62').decode('utf-8')] = n7
        item[bytes.fromhex('6261636b64726f70').decode('utf-8')] = art_url(item.get(bytes.fromhex('6261636b64726f70').decode('utf-8')) or n7)
        return item

def build_url(query):
    return sys.argv[0] + bytes.fromhex('3f').decode('utf-8') + urlencode(query)

def art_url(url):
    if not url or bytes.fromhex('7c').decode('utf-8') in url or (not url.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8')))):
        return url
    return url + bytes.fromhex('7c557365722d4167656e743d').decode('utf-8') + quote(UA)

def is_hls_stream(url):
    YYY = (url or bytes.fromhex('').decode('utf-8')).split(bytes.fromhex('7c').decode('utf-8'), 1)[0].lower()
    return bytes.fromhex('2e6d337538').decode('utf-8') in YYY or YYY.endswith(bytes.fromhex('2f6d61737465722e747874').decode('utf-8')) or YYY.endswith(bytes.fromhex('2f7478742f6d61737465722e747874').decode('utf-8'))

def has_addon(addon_id):
    return bool(xbmc.getCondVisibility(bytes.fromhex('53797374656d2e4861734164646f6e287b307d29').decode('utf-8').format(addon_id)))

def run():
    params = dict(parse_qsl(sys.argv[2][1:]))
    w = params.get(bytes.fromhex('616374696f6e').decode('utf-8'))
    if not w:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
        f19 = xbmcgui.Window(10000)
        try:
            qqqqqqqqqqqqqq = float(f19.getProperty(SKIP_GUI_UNTIL) or bytes.fromhex('30').decode('utf-8'))
        except ValueError:
            qqqqqqqqqqqqqq = 0
        if time.time() < qqqqqqqqqqqqqq:
            return
        f19.clearProperty(SKIP_GUI_UNTIL)
        xbmc.executebuiltin(bytes.fromhex('52756e506c7567696e287b307d29').decode('utf-8').format(build_url({bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('677569').decode('utf-8')})))
        return
    if w == bytes.fromhex('677569').decode('utf-8'):
        open_browser(PatronUI())
        xbmcgui.Window(10000).setProperty(SKIP_GUI_UNTIL, str(time.time() + 4))
        xbmc.executebuiltin(bytes.fromhex('416374697661746557696e646f7728486f6d6529').decode('utf-8'))
        return
    xbmcplugin.endOfDirectory(HANDLE)
if __name__ == bytes.fromhex('5f5f6d61696e5f5f').decode('utf-8'):
    run()
