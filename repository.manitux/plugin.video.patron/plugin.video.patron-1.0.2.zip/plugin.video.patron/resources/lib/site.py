from __future__ import absolute_import, unicode_literals
import json
import re
import manituxhttp
try:
    from urllib.parse import quote
except ImportError:
    from urllib import quote

class PatronSite(object):
    API_URL = bytes.fromhex('68747470733a2f2f6170692e6769746875622e636f6d2f7265706f732f70617472306e712f666c6d532f636f6e74656e7473').decode('utf-8')
    RAW_BASE = bytes.fromhex('68747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f70617472306e712f666c6d532f6d61696e2f').decode('utf-8')
    FALLBACK_PLAYLISTS = ((bytes.fromhex('66696c6d6d616b696e6573695f74756d2e6d3375').decode('utf-8'), bytes.fromhex('46696c6d6d616b696e657369').decode('utf-8')), (bytes.fromhex('66696c6d6d6f64755f74756d2e6d3375').decode('utf-8'), bytes.fromhex('46696c6d6d6f6475').decode('utf-8')), (bytes.fromhex('686466696c6d5f6c6973746573692e6d3375').decode('utf-8'), bytes.fromhex('484446696c6d').decode('utf-8')), (bytes.fromhex('6a657466696c6d5f74756d2e6d3375').decode('utf-8'), bytes.fromhex('4a657446696c6d').decode('utf-8')))
    ATTR_RE = re.compile(bytes.fromhex('285b5c772d5d2b293d22285b5e225d2a2922').decode('utf-8'))

    def __init__(self, user_agent):
        self.user_agent = user_agent
        self.session = manituxhttp.Session(client_identifier=bytes.fromhex('6368726f6d655f313434').decode('utf-8'))
        self._playlist_cache = {}

    def playlists(self):
        KudwfHizPVcpkgSkfvaPoAmYKYfhDPiKsNUnaymYpPhwhNstOWkrIxbcmcBmpGmfvOuHVWhoorrzRtm16 = []
        try:
            E258516137642212 = json.loads(self.get(self.API_URL))
            for item in E258516137642212 or []:
                name = item.get(bytes.fromhex('6e616d65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
                if not name.lower().endswith((bytes.fromhex('2e6d3375').decode('utf-8'), bytes.fromhex('2e6d337538').decode('utf-8'))):
                    continue
                KudwfHizPVcpkgSkfvaPoAmYKYfhDPiKsNUnaymYpPhwhNstOWkrIxbcmcBmpGmfvOuHVWhoorrzRtm16.append({bytes.fromhex('6e616d65').decode('utf-8'): name, bytes.fromhex('7469746c65').decode('utf-8'): self.title_from_name(name), bytes.fromhex('75726c').decode('utf-8'): item.get(bytes.fromhex('646f776e6c6f61645f75726c').decode('utf-8')) or self.RAW_BASE + name})
        except Exception:
            KudwfHizPVcpkgSkfvaPoAmYKYfhDPiKsNUnaymYpPhwhNstOWkrIxbcmcBmpGmfvOuHVWhoorrzRtm16 = []
        if KudwfHizPVcpkgSkfvaPoAmYKYfhDPiKsNUnaymYpPhwhNstOWkrIxbcmcBmpGmfvOuHVWhoorrzRtm16:
            return sorted(KudwfHizPVcpkgSkfvaPoAmYKYfhDPiKsNUnaymYpPhwhNstOWkrIxbcmcBmpGmfvOuHVWhoorrzRtm16, key=lambda item: item.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8'))
        return [{bytes.fromhex('6e616d65').decode('utf-8'): name, bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): self.RAW_BASE + name} for name, title in self.FALLBACK_PLAYLISTS]

    def groups(self, playlist):
        groups = []
        f18 = set()
        for item in self.items(playlist):
            group = item.get(bytes.fromhex('67726f7570').decode('utf-8')) or bytes.fromhex('4469676572').decode('utf-8')
            IlIlIIIl = group.lower()
            if IlIlIIIl in f18:
                continue
            f18.add(IlIlIIIl)
            groups.append(group)
        return groups

    def items(self, playlist, group=bytes.fromhex('').decode('utf-8')):
        url = playlist.get(bytes.fromhex('75726c').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        YnWvxVSFMBYCCRMWjCAqWDAnSUeFQxKEzUKnLwPqumJZDbVwtemTyqujLMcvuQFGNYUdqYtmofQpFOt3 = url or playlist.get(bytes.fromhex('6e616d65').decode('utf-8')) or playlist.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        if YnWvxVSFMBYCCRMWjCAqWDAnSUeFQxKEzUKnLwPqumJZDbVwtemTyqujLMcvuQFGNYUdqYtmofQpFOt3 in self._playlist_cache:
            items = self._playlist_cache[YnWvxVSFMBYCCRMWjCAqWDAnSUeFQxKEzUKnLwPqumJZDbVwtemTyqujLMcvuQFGNYUdqYtmofQpFOt3]
        else:
            items = self.parse_m3u(self.get(url))
            vzaANyXnnDLRoiELVJxfhpMZRFTfFRLrMCaomWoyDDHtBrnSQYvvHMQhnBDZdSRUJzwXvfKcXeVNJEy13 = playlist.get(bytes.fromhex('7469746c65').decode('utf-8')) or playlist.get(bytes.fromhex('6e616d65').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
            for item in items:
                item[bytes.fromhex('706c61796c6973745f7469746c65').decode('utf-8')] = vzaANyXnnDLRoiELVJxfhpMZRFTfFRLrMCaomWoyDDHtBrnSQYvvHMQhnBDZdSRUJzwXvfKcXeVNJEy13
            self._playlist_cache[YnWvxVSFMBYCCRMWjCAqWDAnSUeFQxKEzUKnLwPqumJZDbVwtemTyqujLMcvuQFGNYUdqYtmofQpFOt3] = items
        if group:
            return [item for item in items if (item.get(bytes.fromhex('67726f7570').decode('utf-8')) or bytes.fromhex('4469676572').decode('utf-8')) == group]
        return items

    def search(self, query):
        IIIIlIIlIl = (query or bytes.fromhex('').decode('utf-8')).lower()
        llIIIlIlIllIllllI = []
        for playlist in self.playlists():
            for item in self.items(playlist):
                WQgGTZmXsSfgIjDmjbZkPHXdjDZwBGHJuwTDZqLkiledicTiUlqdThcuNWEUripTlAqJDOJwViwwlzS5 = bytes.fromhex('20').decode('utf-8').join((item.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8'), item.get(bytes.fromhex('67726f7570').decode('utf-8')) or bytes.fromhex('').decode('utf-8'), playlist.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('').decode('utf-8'))).lower()
                if IIIIlIIlIl in WQgGTZmXsSfgIjDmjbZkPHXdjDZwBGHJuwTDZqLkiledicTiUlqdThcuNWEUripTlAqJDOJwViwwlzS5:
                    item = dict(item)
                    item[bytes.fromhex('7469746c65').decode('utf-8')] = bytes.fromhex('5b7b307d5d207b317d').decode('utf-8').format(playlist.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('4c69737465').decode('utf-8'), item.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('566964656f').decode('utf-8'))
                    llIIIlIlIllIllllI.append(item)
        return llIIIlIlIllIllllI

    def stream_url(self, item):
        url = (item or {}).get(bytes.fromhex('75726c').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        if not url:
            return bytes.fromhex('').decode('utf-8')
        aAAAaAA = dict((item or {}).get(bytes.fromhex('68656164657273').decode('utf-8')) or {})
        if bytes.fromhex('557365722d4167656e74').decode('utf-8') not in aAAAaAA:
            aAAAaAA[bytes.fromhex('557365722d4167656e74').decode('utf-8')] = self.user_agent
        if not aAAAaAA:
            return url
        return url + bytes.fromhex('7c').decode('utf-8') + bytes.fromhex('26').decode('utf-8').join((bytes.fromhex('7b307d3d7b317d').decode('utf-8').format(IlIlIIIl, quote(value)) for IlIlIIIl, value in sorted(aAAAaAA.items()) if value))

    def get(self, url):
        aAAAaAA = {bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('2a2f2a').decode('utf-8'), bytes.fromhex('557365722d4167656e74').decode('utf-8'): self.user_agent}
        lIlIlIIIllllIII = self.session.get(url, headers=aAAAaAA, timeout=30, allow_redirects=True)
        lIlIlIIIllllIII.raise_for_status()
        if (url or bytes.fromhex('').decode('utf-8')).startswith(self.RAW_BASE):
            return lIlIlIIIllllIII.content.decode(bytes.fromhex('7574662d38').decode('utf-8'), bytes.fromhex('7265706c616365').decode('utf-8'))
        return lIlIlIIIllllIII.text

    def parse_m3u(self, text):
        items = []
        AAaA = None
        aAAAaAA = {}
        ZwXJHyjrhOUymoNEihXXWOprgXcVYQLRzDRNrqqzAmSFPevNerbFQlZpiXecNxEMrcNcGltOsdUFbae9 = {}
        for aaaAaaaaaaAAaA in (text or bytes.fromhex('').decode('utf-8')).splitlines():
            line = aaaAaaaaaaAAaA.strip()
            if not line:
                continue
            if line.startswith(bytes.fromhex('23455854494e46').decode('utf-8')):
                cc, title = self.parse_extinf(line)
                AAaA = {bytes.fromhex('7469746c65').decode('utf-8'): title or cc.get(bytes.fromhex('7476672d6e616d65').decode('utf-8')) or bytes.fromhex('566964656f').decode('utf-8'), bytes.fromhex('6c6f676f').decode('utf-8'): cc.get(bytes.fromhex('7476672d6c6f676f').decode('utf-8')) or bytes.fromhex('').decode('utf-8'), bytes.fromhex('67726f7570').decode('utf-8'): cc.get(bytes.fromhex('67726f75702d7469746c65').decode('utf-8')) or bytes.fromhex('4469676572').decode('utf-8'), bytes.fromhex('68656164657273').decode('utf-8'): {}, bytes.fromhex('6b6f64695f70726f7073').decode('utf-8'): {}}
                aAAAaAA = {}
                ZwXJHyjrhOUymoNEihXXWOprgXcVYQLRzDRNrqqzAmSFPevNerbFQlZpiXecNxEMrcNcGltOsdUFbae9 = {}
            elif line.startswith(bytes.fromhex('23455854564c434f50543a').decode('utf-8')):
                name, value = self.split_option(line[len(bytes.fromhex('23455854564c434f50543a').decode('utf-8')):])
                ffffff = self.vlc_header_name(name)
                if ffffff and value:
                    aAAAaAA[ffffff] = value
            elif line.startswith(bytes.fromhex('234b4f444950524f503a').decode('utf-8')):
                name, value = self.split_option(line[len(bytes.fromhex('234b4f444950524f503a').decode('utf-8')):])
                if name and value:
                    ZwXJHyjrhOUymoNEihXXWOprgXcVYQLRzDRNrqqzAmSFPevNerbFQlZpiXecNxEMrcNcGltOsdUFbae9[name] = value
            elif line.startswith(bytes.fromhex('23').decode('utf-8')):
                continue
            elif AAaA:
                AAaA[bytes.fromhex('75726c').decode('utf-8')] = line
                AAaA[bytes.fromhex('68656164657273').decode('utf-8')] = aAAAaAA
                AAaA[bytes.fromhex('6b6f64695f70726f7073').decode('utf-8')] = ZwXJHyjrhOUymoNEihXXWOprgXcVYQLRzDRNrqqzAmSFPevNerbFQlZpiXecNxEMrcNcGltOsdUFbae9
                items.append(AAaA)
                AAaA = None
                aAAAaAA = {}
                ZwXJHyjrhOUymoNEihXXWOprgXcVYQLRzDRNrqqzAmSFPevNerbFQlZpiXecNxEMrcNcGltOsdUFbae9 = {}
        return items

    def parse_extinf(self, line):
        cc = dict(self.ATTR_RE.findall(line))
        title = bytes.fromhex('').decode('utf-8')
        if bytes.fromhex('2c').decode('utf-8') in line:
            title = line.rsplit(bytes.fromhex('2c').decode('utf-8'), 1)[-1].strip()
        return (cc, title)

    @staticmethod
    def split_option(value):
        if bytes.fromhex('3d').decode('utf-8') not in value:
            return (value.strip(), bytes.fromhex('').decode('utf-8'))
        name, uuuuuuuuuuu = value.split(bytes.fromhex('3d').decode('utf-8'), 1)
        return (name.strip(), uuuuuuuuuuu.strip())

    @staticmethod
    def vlc_header_name(name):
        DlzPusDjzKKuwYPFpKUVnYggxSbbRoYUwlDRCYiGzsAYGouLsPqWjKZPaEzWmBuLAGJQHgYiEUXMeQO1 = {bytes.fromhex('687474702d7265666572726572').decode('utf-8'): bytes.fromhex('52656665726572').decode('utf-8'), bytes.fromhex('687474702d72656665726572').decode('utf-8'): bytes.fromhex('52656665726572').decode('utf-8'), bytes.fromhex('687474702d757365722d6167656e74').decode('utf-8'): bytes.fromhex('557365722d4167656e74').decode('utf-8'), bytes.fromhex('687474702d6f726967696e').decode('utf-8'): bytes.fromhex('4f726967696e').decode('utf-8')}
        return DlzPusDjzKKuwYPFpKUVnYggxSbbRoYUwlDRCYiGzsAYGouLsPqWjKZPaEzWmBuLAGJQHgYiEUXMeQO1.get((name or bytes.fromhex('').decode('utf-8')).lower(), bytes.fromhex('').decode('utf-8'))

    @staticmethod
    def title_from_name(name):
        title = (name or bytes.fromhex('').decode('utf-8')).rsplit(bytes.fromhex('2e').decode('utf-8'), 1)[0].replace(bytes.fromhex('5f74756d').decode('utf-8'), bytes.fromhex('').decode('utf-8')).replace(bytes.fromhex('5f6c697374657369').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
        return title.replace(bytes.fromhex('5f').decode('utf-8'), bytes.fromhex('20').decode('utf-8')).replace(bytes.fromhex('2d').decode('utf-8'), bytes.fromhex('20').decode('utf-8')).title()
