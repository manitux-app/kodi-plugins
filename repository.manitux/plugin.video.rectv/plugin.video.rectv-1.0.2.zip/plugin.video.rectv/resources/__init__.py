exec("_rectv_obf_guard = 173\nif _rectv_obf_guard == -1:\n    _rectv_obf_shadow = bytes.fromhex('756e75736564').decode('utf-8')")
