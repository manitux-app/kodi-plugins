from __future__ import absolute_import, unicode_literals
import base64
import json
import re
import sys
import time
import os
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
try:
    from urllib.parse import parse_qsl, quote, urlencode
except ImportError:
    from urlparse import parse_qsl
    from urllib import quote, urlencode
from resources.lib.site import RecTVSite
MANITUXUI_LIB = os.path.join(xbmcaddon.Addon(id=bytes.fromhex('7363726970742e6d6f64756c652e6d616e697475787569').decode('utf-8')).getAddonInfo(bytes.fromhex('70617468').decode('utf-8')), bytes.fromhex('6c6962').decode('utf-8'))
if MANITUXUI_LIB not in sys.path:
    sys.path.insert(0, MANITUXUI_LIB)
from manituxui import ManituxUI, open_browser
ADDON_ID = bytes.fromhex('706c7567696e2e766964656f2e7265637476').decode('utf-8')
SKIP_GUI_UNTIL = ADDON_ID + bytes.fromhex('2e736b69705f6775695f756e74696c').decode('utf-8')
ADDON = xbmcaddon.Addon(id=ADDON_ID)
HANDLE = int(sys.argv[1])
BASE_URL = ADDON.getSetting(bytes.fromhex('626173655f75726c').decode('utf-8'))
UA = ADDON.getSetting(bytes.fromhex('757365725f6167656e74').decode('utf-8')) or bytes.fromhex('6f6b687474702f342e31322e30').decode('utf-8')
NAFXHwuNqCYCuerrJtkIKvUMEiURpaAfmJhapGNyrtFpAhBCUQKmRiBfWPUsGUyeiRHWMcuyptQtrLc16 = RecTVSite(BASE_URL, UA)

class RecTVUI(ManituxUI):
    title = bytes.fromhex('5265635456').decode('utf-8')

    def categories(self):
        categories = [{bytes.fromhex('7469746c65').decode('utf-8'): bytes.fromhex('417261').decode('utf-8'), bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('736561726368').decode('utf-8')}]
        for title, path in NAFXHwuNqCYCuerrJtkIKvUMEiURpaAfmJhapGNyrtFpAhBCUQKmRiBfWPUsGUyeiRHWMcuyptQtrLc16.categories():
            categories.append({bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('70617468').decode('utf-8'): path})
        return categories

    def videos(self, category, page=1):
        if category.get(bytes.fromhex('616374696f6e').decode('utf-8')) == bytes.fromhex('736561726368').decode('utf-8'):
            query = xbmcgui.Dialog().input(bytes.fromhex('526563545620417261').decode('utf-8'))
            return self._decorate_items(NAFXHwuNqCYCuerrJtkIKvUMEiURpaAfmJhapGNyrtFpAhBCUQKmRiBfWPUsGUyeiRHWMcuyptQtrLc16.search(query)) if query else []
        return self._decorate_items(NAFXHwuNqCYCuerrJtkIKvUMEiURpaAfmJhapGNyrtFpAhBCUQKmRiBfWPUsGUyeiRHWMcuyptQtrLc16.get_page_items(category.get(bytes.fromhex('70617468').decode('utf-8'), bytes.fromhex('').decode('utf-8')), page))

    def _decorate_items(self, items):
        f85537882200442 = []
        for item in items:
            R54746881105951 = dict(item)
            R54746881105951[bytes.fromhex('7469746c65').decode('utf-8')] = item_title(R54746881105951)
            R54746881105951[bytes.fromhex('696d616765').decode('utf-8')] = art_url(R54746881105951.get(bytes.fromhex('696d616765').decode('utf-8')) or R54746881105951.get(bytes.fromhex('636f766572').decode('utf-8')) or bytes.fromhex('').decode('utf-8'))
            R54746881105951[bytes.fromhex('706c6f74').decode('utf-8')] = item_plot(R54746881105951)
            f85537882200442.append(R54746881105951)
        return f85537882200442

    def detail(self, video):
        image = art_url(video.get(bytes.fromhex('696d616765').decode('utf-8')) or video.get(bytes.fromhex('636f766572').decode('utf-8')) or bytes.fromhex('').decode('utf-8'))
        plot = video.get(bytes.fromhex('706c6f74').decode('utf-8')) or item_plot(video)
        sources = []
        IlI = []
        ileMFOnMPFCsFDcATCTVnhYcKgZmGhuAdLMmbTQjIaWdtaEAwtkYKCgJHDDORolvXWDLBZWMsdCvQvm19 = video.get(bytes.fromhex('747261696c6572').decode('utf-8')) or {}
        if ileMFOnMPFCsFDcATCTVnhYcKgZmGhuAdLMmbTQjIaWdtaEAwtkYKCgJHDDORolvXWDLBZWMsdCvQvm19.get(bytes.fromhex('75726c').decode('utf-8')):
            sources.append({bytes.fromhex('6c6162656c').decode('utf-8'): bytes.fromhex('467261676d616e').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): ileMFOnMPFCsFDcATCTVnhYcKgZmGhuAdLMmbTQjIaWdtaEAwtkYKCgJHDDORolvXWDLBZWMsdCvQvm19.get(bytes.fromhex('75726c').decode('utf-8')), bytes.fromhex('69735f796f7574756265').decode('utf-8'): is_youtube(ileMFOnMPFCsFDcATCTVnhYcKgZmGhuAdLMmbTQjIaWdtaEAwtkYKCgJHDDORolvXWDLBZWMsdCvQvm19.get(bytes.fromhex('75726c').decode('utf-8'))), bytes.fromhex('69735f6469726563745f75726c').decode('utf-8'): not is_youtube(ileMFOnMPFCsFDcATCTVnhYcKgZmGhuAdLMmbTQjIaWdtaEAwtkYKCgJHDDORolvXWDLBZWMsdCvQvm19.get(bytes.fromhex('75726c').decode('utf-8')))})
        if video.get(bytes.fromhex('74797065').decode('utf-8')) == bytes.fromhex('7365726965').decode('utf-8'):
            for AaaAaaaaaaAAAaA in NAFXHwuNqCYCuerrJtkIKvUMEiURpaAfmJhapGNyrtFpAhBCUQKmRiBfWPUsGUyeiRHWMcuyptQtrLc16.seasons(video):
                for episode in AaaAaaaaaaAAAaA.get(bytes.fromhex('657069736f646573').decode('utf-8')) or []:
                    title = bytes.fromhex('7b307d202d207b317d').decode('utf-8').format(AaaAaaaaaaAAAaA.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('53657a6f6e').decode('utf-8'), episode.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('426f6c756d').decode('utf-8'))
                    IlI.append({bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('736f7572636573').decode('utf-8'): episode.get(bytes.fromhex('736f7572636573').decode('utf-8')) or [], bytes.fromhex('696d616765').decode('utf-8'): art_url(episode.get(bytes.fromhex('696d616765').decode('utf-8')) or image), bytes.fromhex('706c6f74').decode('utf-8'): plot})
        else:
            for source in NAFXHwuNqCYCuerrJtkIKvUMEiURpaAfmJhapGNyrtFpAhBCUQKmRiBfWPUsGUyeiRHWMcuyptQtrLc16.sources_from_item(video):
                sources.append(dict(source, label=source.get(bytes.fromhex('7469746c65').decode('utf-8')) or source.get(bytes.fromhex('7175616c697479').decode('utf-8')) or source.get(bytes.fromhex('74797065').decode('utf-8')) or bytes.fromhex('4b61796e616b').decode('utf-8')))
        return {bytes.fromhex('7469746c65').decode('utf-8'): video.get(bytes.fromhex('7469746c65').decode('utf-8')) or item_title(video), bytes.fromhex('75726c').decode('utf-8'): video.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('696d616765').decode('utf-8'): image, bytes.fromhex('6261636b64726f70').decode('utf-8'): video.get(bytes.fromhex('6261636b64726f70').decode('utf-8')) or video.get(bytes.fromhex('66616e617274').decode('utf-8')) or image, bytes.fromhex('706c6f74').decode('utf-8'): plot, bytes.fromhex('79656172').decode('utf-8'): video.get(bytes.fromhex('79656172').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('636f756e747279').decode('utf-8'): video.get(bytes.fromhex('636f756e747279').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('6475726174696f6e').decode('utf-8'): video.get(bytes.fromhex('6475726174696f6e').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('726174696e67').decode('utf-8'): video.get(bytes.fromhex('726174696e67').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('74616773').decode('utf-8'): bytes.fromhex('2c20').decode('utf-8').join([eeee.get(bytes.fromhex('7469746c65').decode('utf-8')) for eeee in video.get(bytes.fromhex('67656e726573').decode('utf-8')) or [] if eeee.get(bytes.fromhex('7469746c65').decode('utf-8'))]), bytes.fromhex('6163746f7273').decode('utf-8'): video.get(bytes.fromhex('6163746f7273').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('657069736f646573').decode('utf-8'): IlI, bytes.fromhex('736f7572636573').decode('utf-8'): sources}

    def episode_detail(self, episode, video=None):
        image = art_url(episode.get(bytes.fromhex('696d616765').decode('utf-8')) or (video or {}).get(bytes.fromhex('696d616765').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
        return {bytes.fromhex('7469746c65').decode('utf-8'): episode.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('42c3b66cc3bc6d').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): episode.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('696d616765').decode('utf-8'): image, bytes.fromhex('6261636b64726f70').decode('utf-8'): art_url(episode.get(bytes.fromhex('6261636b64726f70').decode('utf-8')) or image or (video or {}).get(bytes.fromhex('6261636b64726f70').decode('utf-8'), bytes.fromhex('').decode('utf-8'))), bytes.fromhex('706c6f74').decode('utf-8'): episode.get(bytes.fromhex('706c6f74').decode('utf-8')) or (video or {}).get(bytes.fromhex('706c6f74').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('736f7572636573').decode('utf-8'): [dict(source, label=source.get(bytes.fromhex('7469746c65').decode('utf-8')) or source.get(bytes.fromhex('7175616c697479').decode('utf-8')) or source.get(bytes.fromhex('74797065').decode('utf-8')) or bytes.fromhex('4b61796e616b').decode('utf-8')) for source in episode.get(bytes.fromhex('736f7572636573').decode('utf-8')) or []]}

    def play(self, source, video=None):
        if source.get(bytes.fromhex('69735f796f7574756265').decode('utf-8')):
            play_youtube_gui(source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
        elif source.get(bytes.fromhex('69735f6469726563745f75726c').decode('utf-8')):
            resolve_stream_gui(source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
        else:
            stream = NAFXHwuNqCYCuerrJtkIKvUMEiURpaAfmJhapGNyrtFpAhBCUQKmRiBfWPUsGUyeiRHWMcuyptQtrLc16.stream_url(source)
            resolve_stream_gui(stream)

def build_url(query):
    return sys.argv[0] + bytes.fromhex('3f').decode('utf-8') + urlencode(query)

def encode_data(value):
    aaaaaAaaaAAAaa = json.dumps(value or {}, ensure_ascii=False, separators=(bytes.fromhex('2c').decode('utf-8'), bytes.fromhex('3a').decode('utf-8'))).encode(bytes.fromhex('7574662d38').decode('utf-8'))
    return base64.urlsafe_b64encode(aaaaaAaaaAAAaa).decode(bytes.fromhex('6173636969').decode('utf-8'))

def decode_data(value):
    if not value:
        return {}
    mWvbEYVmXidRHnZXBuxXDqPybSKhzPGDVZXpRUSxlNCaocldruhNnnBwMwPZjttwTdhKXdBBJqIdXcV9 = bytes.fromhex('3d').decode('utf-8') * (-len(value) % 4)
    return json.loads(base64.urlsafe_b64decode((value + mWvbEYVmXidRHnZXBuxXDqPybSKhzPGDVZXpRUSxlNCaocldruhNnnBwMwPZjttwTdhKXdBBJqIdXcV9).encode(bytes.fromhex('6173636969').decode('utf-8'))).decode(bytes.fromhex('7574662d38').decode('utf-8')))

def art_url(url):
    if not url or bytes.fromhex('7c').decode('utf-8') in url or (not url.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8')))):
        return url
    return url + bytes.fromhex('7c557365722d4167656e743d').decode('utf-8') + quote(UA)

def set_art(li, image):
    image = art_url(image)
    li.setArt({bytes.fromhex('7468756d62').decode('utf-8'): image, bytes.fromhex('69636f6e').decode('utf-8'): image, bytes.fromhex('706f73746572').decode('utf-8'): image, bytes.fromhex('66616e617274').decode('utf-8'): image})

def item_title(item):
    title = item.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('4261736c696b').decode('utf-8')
    lRUHBpcxqIBeMBGKHrewvxrsIsxQAUBScdTGXkjpIpKHWxvIwKejsPaWTnCrsWjmADoAusHNrFcgsVW11 = [item.get(bytes.fromhex('6c6162656c').decode('utf-8')), item.get(bytes.fromhex('7375626c6162656c').decode('utf-8'))]
    f670673163193318 = bytes.fromhex('202f20').decode('utf-8').join([C620978152128810 for C620978152128810 in lRUHBpcxqIBeMBGKHrewvxrsIsxQAUBScdTGXkjpIpKHWxvIwKejsPaWTnCrsWjmADoAusHNrFcgsVW11 if C620978152128810])
    return title + (bytes.fromhex('205b7b307d5d').decode('utf-8').format(f670673163193318) if f670673163193318 else bytes.fromhex('').decode('utf-8'))

def item_plot(item):
    plot = item.get(bytes.fromhex('6465736372697074696f6e').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
    R5 = bytes.fromhex('2c20').decode('utf-8').join([eeee.get(bytes.fromhex('7469746c65').decode('utf-8')) for eeee in item.get(bytes.fromhex('67656e726573').decode('utf-8')) or [] if eeee.get(bytes.fromhex('7469746c65').decode('utf-8'))])
    if R5:
        plot = (plot + bytes.fromhex('0a0a').decode('utf-8') if plot else bytes.fromhex('').decode('utf-8')) + R5
    return plot

def add_directory(title, action, data=bytes.fromhex('').decode('utf-8'), image=bytes.fromhex('').decode('utf-8'), plot=bytes.fromhex('').decode('utf-8'), page_path=bytes.fromhex('').decode('utf-8')):
    query = {bytes.fromhex('616374696f6e').decode('utf-8'): action}
    if data:
        query[bytes.fromhex('64617461').decode('utf-8')] = data
    if page_path:
        query[bytes.fromhex('70617468').decode('utf-8')] = page_path
    li = xbmcgui.ListItem(label=title)
    set_art(li, image)
    li.setInfo(bytes.fromhex('766964656f').decode('utf-8'), {bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('706c6f74').decode('utf-8'): plot})
    xbmcplugin.addDirectoryItem(HANDLE, build_url(query), li, True)

def add_video(title, action, data, image=bytes.fromhex('').decode('utf-8'), plot=bytes.fromhex('').decode('utf-8')):
    li = xbmcgui.ListItem(label=title)
    set_art(li, image)
    li.setInfo(bytes.fromhex('766964656f').decode('utf-8'), {bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('706c6f74').decode('utf-8'): plot})
    li.setProperty(bytes.fromhex('4973506c617961626c65').decode('utf-8'), bytes.fromhex('74727565').decode('utf-8'))
    xbmcplugin.addDirectoryItem(HANDLE, build_url({bytes.fromhex('616374696f6e').decode('utf-8'): action, bytes.fromhex('64617461').decode('utf-8'): data}), li, False)

def main_menu():
    add_directory(bytes.fromhex('417261').decode('utf-8'), bytes.fromhex('736561726368').decode('utf-8'))
    for title, path in NAFXHwuNqCYCuerrJtkIKvUMEiURpaAfmJhapGNyrtFpAhBCUQKmRiBfWPUsGUyeiRHWMcuyptQtrLc16.categories():
        add_directory(title, bytes.fromhex('6c697374').decode('utf-8'), page_path=path)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('766964656f73').decode('utf-8'))

def list_page(path, page_number=1):
    items = NAFXHwuNqCYCuerrJtkIKvUMEiURpaAfmJhapGNyrtFpAhBCUQKmRiBfWPUsGUyeiRHWMcuyptQtrLc16.get_page_items(path, page_number)
    for item in items:
        title = item_title(item)
        image = item.get(bytes.fromhex('696d616765').decode('utf-8')) or item.get(bytes.fromhex('636f766572').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        plot = item_plot(item)
        if item.get(bytes.fromhex('74797065').decode('utf-8')) == bytes.fromhex('7365726965').decode('utf-8'):
            add_directory(title, bytes.fromhex('64657461696c').decode('utf-8'), encode_data(item), image, plot)
        else:
            add_directory(title, bytes.fromhex('736f7572636573').decode('utf-8'), encode_data(item), image, plot)
    if items:
        xbmcplugin.addDirectoryItem(HANDLE, build_url({bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('6c697374').decode('utf-8'), bytes.fromhex('70617468').decode('utf-8'): path, bytes.fromhex('70616765').decode('utf-8'): str(int(page_number) + 1)}), xbmcgui.ListItem(label=bytes.fromhex('536f6e72616b69205361796661').decode('utf-8')), True)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('766964656f73').decode('utf-8'))

def search():
    query = xbmcgui.Dialog().input(bytes.fromhex('526563545620417261').decode('utf-8'))
    if not query:
        return
    for item in NAFXHwuNqCYCuerrJtkIKvUMEiURpaAfmJhapGNyrtFpAhBCUQKmRiBfWPUsGUyeiRHWMcuyptQtrLc16.search(query):
        title = item_title(item)
        image = item.get(bytes.fromhex('696d616765').decode('utf-8')) or item.get(bytes.fromhex('636f766572').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
        plot = item_plot(item)
        action = bytes.fromhex('64657461696c').decode('utf-8') if item.get(bytes.fromhex('74797065').decode('utf-8')) == bytes.fromhex('7365726965').decode('utf-8') else bytes.fromhex('736f7572636573').decode('utf-8')
        add_directory(title, action, encode_data(item), image, plot)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('766964656f73').decode('utf-8'))

def detail(data):
    item = decode_data(data)
    image = item.get(bytes.fromhex('696d616765').decode('utf-8')) or item.get(bytes.fromhex('636f766572').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
    ileMFOnMPFCsFDcATCTVnhYcKgZmGhuAdLMmbTQjIaWdtaEAwtkYKCgJHDDORolvXWDLBZWMsdCvQvm19 = item.get(bytes.fromhex('747261696c6572').decode('utf-8')) or {}
    if ileMFOnMPFCsFDcATCTVnhYcKgZmGhuAdLMmbTQjIaWdtaEAwtkYKCgJHDDORolvXWDLBZWMsdCvQvm19.get(bytes.fromhex('75726c').decode('utf-8')):
        add_video(bytes.fromhex('467261676d616e').decode('utf-8'), bytes.fromhex('706c61795f796f7574756265').decode('utf-8') if is_youtube(ileMFOnMPFCsFDcATCTVnhYcKgZmGhuAdLMmbTQjIaWdtaEAwtkYKCgJHDDORolvXWDLBZWMsdCvQvm19.get(bytes.fromhex('75726c').decode('utf-8'))) else bytes.fromhex('706c61795f75726c').decode('utf-8'), encode_data({bytes.fromhex('75726c').decode('utf-8'): ileMFOnMPFCsFDcATCTVnhYcKgZmGhuAdLMmbTQjIaWdtaEAwtkYKCgJHDDORolvXWDLBZWMsdCvQvm19.get(bytes.fromhex('75726c').decode('utf-8'))}), image, item_plot(item))
    seasons = NAFXHwuNqCYCuerrJtkIKvUMEiURpaAfmJhapGNyrtFpAhBCUQKmRiBfWPUsGUyeiRHWMcuyptQtrLc16.seasons(item)
    for AaaAaaaaaaAAAaA in seasons:
        for episode in AaaAaaaaaaAAAaA.get(bytes.fromhex('657069736f646573').decode('utf-8')) or []:
            title = bytes.fromhex('7b307d202d207b317d').decode('utf-8').format(AaaAaaaaaaAAAaA.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('53657a6f6e').decode('utf-8'), episode.get(bytes.fromhex('7469746c65').decode('utf-8')) or bytes.fromhex('426f6c756d').decode('utf-8'))
            b13 = {bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('736f7572636573').decode('utf-8'): episode.get(bytes.fromhex('736f7572636573').decode('utf-8')) or [], bytes.fromhex('696d616765').decode('utf-8'): image, bytes.fromhex('706c6f74').decode('utf-8'): item_plot(item)}
            add_directory(title, bytes.fromhex('736f7572636573').decode('utf-8'), encode_data(b13), image, item_plot(item))
    if not seasons and (not ileMFOnMPFCsFDcATCTVnhYcKgZmGhuAdLMmbTQjIaWdtaEAwtkYKCgJHDDORolvXWDLBZWMsdCvQvm19.get(bytes.fromhex('75726c').decode('utf-8'))):
        xbmcgui.Dialog().notification(bytes.fromhex('5265635456').decode('utf-8'), bytes.fromhex('426f6c756d2062756c756e616d616469').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('657069736f646573').decode('utf-8'))

def sources(data):
    item = decode_data(data)
    image = item.get(bytes.fromhex('696d616765').decode('utf-8')) or item.get(bytes.fromhex('636f766572').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
    sources = NAFXHwuNqCYCuerrJtkIKvUMEiURpaAfmJhapGNyrtFpAhBCUQKmRiBfWPUsGUyeiRHWMcuyptQtrLc16.sources_from_item(item)
    for C28326768539367, source in enumerate(sources, 1):
        label = source.get(bytes.fromhex('7469746c65').decode('utf-8')) or source.get(bytes.fromhex('7175616c697479').decode('utf-8')) or source.get(bytes.fromhex('74797065').decode('utf-8')) or bytes.fromhex('4b61796e616b').decode('utf-8')
        if source.get(bytes.fromhex('74797065').decode('utf-8')):
            label = bytes.fromhex('7b307d202d207b317d').decode('utf-8').format(label, source.get(bytes.fromhex('74797065').decode('utf-8')))
        add_video(label or bytes.fromhex('4b61796e616b207b307d').decode('utf-8').format(C28326768539367), bytes.fromhex('706c61795f736f75726365').decode('utf-8'), encode_data(source), image, item.get(bytes.fromhex('706c6f74').decode('utf-8')) or item_plot(item))
    if not sources:
        xbmcgui.Dialog().notification(bytes.fromhex('5265635456').decode('utf-8'), bytes.fromhex('4b61796e616b2062756c756e616d616469').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('766964656f73').decode('utf-8'))

def play_source(data):
    source = decode_data(data)
    stream = NAFXHwuNqCYCuerrJtkIKvUMEiURpaAfmJhapGNyrtFpAhBCUQKmRiBfWPUsGUyeiRHWMcuyptQtrLc16.stream_url(source)
    if not stream:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    resolve_stream(stream)

def play_url(data):
    resolve_stream(decode_data(data).get(bytes.fromhex('75726c').decode('utf-8')) or bytes.fromhex('').decode('utf-8'))

def play_youtube(data):
    url = decode_data(data).get(bytes.fromhex('75726c').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
    video_id = youtube_id(url)
    if not video_id:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    try:
        xbmcaddon.Addon(id=bytes.fromhex('706c7567696e2e766964656f2e796f7574756265').decode('utf-8'))
    except Exception:
        xbmcgui.Dialog().notification(bytes.fromhex('596f7554756265').decode('utf-8'), bytes.fromhex('706c7567696e2e766964656f2e796f757475626520676572656b6c69').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=bytes.fromhex('706c7567696e3a2f2f706c7567696e2e766964656f2e796f75747562652f706c61792f3f766964656f5f69643d').decode('utf-8') + video_id))

def play_youtube_gui(url):
    video_id = youtube_id(url)
    if not video_id:
        return False
    try:
        xbmcaddon.Addon(id=bytes.fromhex('706c7567696e2e766964656f2e796f7574756265').decode('utf-8'))
    except Exception:
        xbmcgui.Dialog().notification(bytes.fromhex('596f7554756265').decode('utf-8'), bytes.fromhex('706c7567696e2e766964656f2e796f757475626520676572656b6c69').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
        return False
    xbmc.Player().play(bytes.fromhex('706c7567696e3a2f2f706c7567696e2e766964656f2e796f75747562652f706c61792f3f766964656f5f69643d').decode('utf-8') + video_id)
    return True

def resolve_stream(stream):
    li = xbmcgui.ListItem(path=stream)
    if is_hls_stream(stream):
        li.setMimeType(bytes.fromhex('6170706c69636174696f6e2f766e642e6170706c652e6d70656775726c').decode('utf-8'))
        li.setContentLookup(False)
        if has_addon(bytes.fromhex('696e70757473747265616d2e6164617074697665').decode('utf-8')):
            f6 = stream.split(bytes.fromhex('7c').decode('utf-8'), 1)[1] if bytes.fromhex('7c').decode('utf-8') in stream else bytes.fromhex('').decode('utf-8')
            li.setProperty(bytes.fromhex('696e70757473747265616d').decode('utf-8'), bytes.fromhex('696e70757473747265616d2e6164617074697665').decode('utf-8'))
            li.setProperty(bytes.fromhex('696e70757473747265616d2e61646170746976652e73747265616d5f68656164657273').decode('utf-8'), f6)
            li.setProperty(bytes.fromhex('696e70757473747265616d2e61646170746976652e6d616e69666573745f68656164657273').decode('utf-8'), f6)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)

def resolve_stream_gui(stream):
    if not stream:
        xbmcgui.Dialog().notification(bytes.fromhex('5265635456').decode('utf-8'), bytes.fromhex('4b61796e616b2062756c756e616d616469').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    li = xbmcgui.ListItem(path=stream)
    if is_hls_stream(stream):
        li.setMimeType(bytes.fromhex('6170706c69636174696f6e2f766e642e6170706c652e6d70656775726c').decode('utf-8'))
        li.setContentLookup(False)
        if has_addon(bytes.fromhex('696e70757473747265616d2e6164617074697665').decode('utf-8')):
            f6 = stream.split(bytes.fromhex('7c').decode('utf-8'), 1)[1] if bytes.fromhex('7c').decode('utf-8') in stream else bytes.fromhex('').decode('utf-8')
            li.setProperty(bytes.fromhex('696e70757473747265616d').decode('utf-8'), bytes.fromhex('696e70757473747265616d2e6164617074697665').decode('utf-8'))
            li.setProperty(bytes.fromhex('696e70757473747265616d2e61646170746976652e73747265616d5f68656164657273').decode('utf-8'), f6)
            li.setProperty(bytes.fromhex('696e70757473747265616d2e61646170746976652e6d616e69666573745f68656164657273').decode('utf-8'), f6)
    xbmc.Player().play(stream, li)

def is_hls_stream(url):
    return bytes.fromhex('2e6d337538').decode('utf-8') in (url or bytes.fromhex('').decode('utf-8')).split(bytes.fromhex('7c').decode('utf-8'), 1)[0].lower()

def is_youtube(url):
    return bytes.fromhex('796f75747562652e').decode('utf-8') in (url or bytes.fromhex('').decode('utf-8')) or bytes.fromhex('796f7574752e62652f').decode('utf-8') in (url or bytes.fromhex('').decode('utf-8'))

def youtube_id(url):
    for qqqqqqqqqqqq in (bytes.fromhex('283f3a796f75747562655c2e636f6d2f77617463685c3f763d7c796f75747562655c2e636f6d2f656d6265642f7c796f7574755c2e62652f29285b412d5a612d7a302d395f2d5d7b362c7d29').decode('utf-8'), bytes.fromhex('5b3f265d763d285b412d5a612d7a302d395f2d5d7b362c7d29').decode('utf-8')):
        x8 = re.search(qqqqqqqqqqqq, url or bytes.fromhex('').decode('utf-8'), re.I)
        if x8:
            return x8.group(1)
    return bytes.fromhex('').decode('utf-8')

def has_addon(addon_id):
    return bool(xbmc.getCondVisibility(bytes.fromhex('53797374656d2e4861734164646f6e287b307d29').decode('utf-8').format(addon_id)))

def run():
    params = dict(parse_qsl(sys.argv[2][1:]))
    action = params.get(bytes.fromhex('616374696f6e').decode('utf-8'))
    if not action:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
        R813900377706320 = xbmcgui.Window(10000)
        try:
            IllIIIlIllIlllIII = float(R813900377706320.getProperty(SKIP_GUI_UNTIL) or bytes.fromhex('30').decode('utf-8'))
        except ValueError:
            IllIIIlIllIlllIII = 0
        if time.time() < IllIIIlIllIlllIII:
            return
        R813900377706320.clearProperty(SKIP_GUI_UNTIL)
        xbmc.executebuiltin(bytes.fromhex('52756e506c7567696e287b307d29').decode('utf-8').format(build_url({bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('677569').decode('utf-8')})))
        return
    elif action == bytes.fromhex('677569').decode('utf-8'):
        open_browser(RecTVUI())
        xbmcgui.Window(10000).setProperty(SKIP_GUI_UNTIL, str(time.time() + 4))
        xbmc.executebuiltin(bytes.fromhex('416374697661746557696e646f7728486f6d6529').decode('utf-8'))
        return
    elif action == bytes.fromhex('636c6173736963').decode('utf-8'):
        main_menu()
    elif action == bytes.fromhex('6c697374').decode('utf-8'):
        list_page(params.get(bytes.fromhex('70617468').decode('utf-8'), bytes.fromhex('').decode('utf-8')), int(params.get(bytes.fromhex('70616765').decode('utf-8'), bytes.fromhex('31').decode('utf-8'))))
    elif action == bytes.fromhex('736561726368').decode('utf-8'):
        search()
    elif action == bytes.fromhex('64657461696c').decode('utf-8'):
        detail(params.get(bytes.fromhex('64617461').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
    elif action == bytes.fromhex('736f7572636573').decode('utf-8'):
        sources(params.get(bytes.fromhex('64617461').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
    elif action == bytes.fromhex('706c61795f736f75726365').decode('utf-8'):
        play_source(params.get(bytes.fromhex('64617461').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
    elif action == bytes.fromhex('706c61795f75726c').decode('utf-8'):
        play_url(params.get(bytes.fromhex('64617461').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
    elif action == bytes.fromhex('706c61795f796f7574756265').decode('utf-8'):
        play_youtube(params.get(bytes.fromhex('64617461').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
    xbmcplugin.endOfDirectory(HANDLE)
if __name__ == bytes.fromhex('5f5f6d61696e5f5f').decode('utf-8'):
    run()
