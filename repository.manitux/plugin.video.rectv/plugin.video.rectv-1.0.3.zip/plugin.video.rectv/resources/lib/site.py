from __future__ import absolute_import, unicode_literals
import hashlib
import hmac
import json
import time
import uuid
import manituxhttp
try:
    from urllib.parse import quote, quote_from_bytes, urlparse
except ImportError:
    from urllib import quote
    quote_from_bytes = quote
    from urlparse import urlparse

class RecTVSite(object):
    SW_KEY = bytes.fromhex('34463541394333443941383646413534454143454444443633353138352f63336335626431372d653337622d346239342d613934342d386133363838613330343532').decode('utf-8')
    HMAC_KEY = bytes.fromhex('36386339363735322d363732312d343833352d396236302d333138363864323730363835').decode('utf-8')
    FALLBACK_URL = bytes.fromhex('68747470733a2f2f612e70726563747637302e6c6f6c').decode('utf-8')
    REMOTE_CONFIG_URL = bytes.fromhex('68747470733a2f2f666972656261736572656d6f7465636f6e6669672e676f6f676c65617069732e636f6d2f76312f70726f6a656374732f3739313538333033313237392f6e616d657370616365732f66697265626173653a6665746368').decode('utf-8')
    CLIENT_IDENTIFIERS = (bytes.fromhex('6368726f6d655f313434').decode('utf-8'), bytes.fromhex('636c6f756473637261706572').decode('utf-8'))
    CATEGORIES = ((bytes.fromhex('43616e6c69').decode('utf-8'), bytes.fromhex('2f6170692f6368616e6e656c2f62792f66696c747265732f302f302f53415946412f').decode('utf-8') + SW_KEY + bytes.fromhex('2f').decode('utf-8')), (bytes.fromhex('536f6e2044697a696c6572').decode('utf-8'), bytes.fromhex('2f6170692f73657269652f62792f66696c747265732f302f637265617465642f53415946412f').decode('utf-8') + SW_KEY + bytes.fromhex('2f').decode('utf-8')), (bytes.fromhex('416b7369796f6e2044697a696c657269').decode('utf-8'), bytes.fromhex('2f6170692f73657269652f62792f66696c747265732f33312f637265617465642f53415946412f').decode('utf-8') + SW_KEY + bytes.fromhex('2f').decode('utf-8')), (bytes.fromhex('54762053686f77').decode('utf-8'), bytes.fromhex('2f6170692f73657269652f62792f66696c747265732f33362f637265617465642f53415946412f').decode('utf-8') + SW_KEY + bytes.fromhex('2f').decode('utf-8')), (bytes.fromhex('5765737465726e2044697a696c657269').decode('utf-8'), bytes.fromhex('2f6170692f73657269652f62792f66696c747265732f33352f637265617465642f53415946412f').decode('utf-8') + SW_KEY + bytes.fromhex('2f').decode('utf-8')), (bytes.fromhex('42696c696d204b757267752044697a696c657269').decode('utf-8'), bytes.fromhex('2f6170692f73657269652f62792f66696c747265732f32382f637265617465642f53415946412f').decode('utf-8') + SW_KEY + bytes.fromhex('2f').decode('utf-8')), (bytes.fromhex('416b7369796f6e202844697a6929').decode('utf-8'), bytes.fromhex('2f6170692f73657269652f62792f66696c747265732f312f637265617465642f53415946412f').decode('utf-8') + SW_KEY + bytes.fromhex('2f').decode('utf-8')), (bytes.fromhex('536f6e2046696c6d6c6572').decode('utf-8'), bytes.fromhex('2f6170692f6d6f7669652f62792f66696c747265732f302f637265617465642f53415946412f').decode('utf-8') + SW_KEY + bytes.fromhex('2f').decode('utf-8')), (bytes.fromhex('5475726b6365204475626c616a2046696c6d6c6572').decode('utf-8'), bytes.fromhex('2f6170692f6d6f7669652f62792f66696c747265732f32362f637265617465642f53415946412f').decode('utf-8') + SW_KEY + bytes.fromhex('2f').decode('utf-8')), (bytes.fromhex('5475726b636520416c7479617a696c692046696c6d6c6572').decode('utf-8'), bytes.fromhex('2f6170692f6d6f7669652f62792f66696c747265732f32372f637265617465642f53415946412f').decode('utf-8') + SW_KEY + bytes.fromhex('2f').decode('utf-8')), (bytes.fromhex('41696c652046696c6d6c657269').decode('utf-8'), bytes.fromhex('2f6170692f6d6f7669652f62792f66696c747265732f31342f637265617465642f53415946412f').decode('utf-8') + SW_KEY + bytes.fromhex('2f').decode('utf-8')), (bytes.fromhex('416b7369796f6e2046696c6d6c657269').decode('utf-8'), bytes.fromhex('2f6170692f6d6f7669652f62792f66696c747265732f312f637265617465642f53415946412f').decode('utf-8') + SW_KEY + bytes.fromhex('2f').decode('utf-8')), (bytes.fromhex('416e696d6173796f6e2046696c6d6c657269').decode('utf-8'), bytes.fromhex('2f6170692f6d6f7669652f62792f66696c747265732f31332f637265617465642f53415946412f').decode('utf-8') + SW_KEY + bytes.fromhex('2f').decode('utf-8')), (bytes.fromhex('42656c676573656c6c6572').decode('utf-8'), bytes.fromhex('2f6170692f6d6f7669652f62792f66696c747265732f31392f637265617465642f53415946412f').decode('utf-8') + SW_KEY + bytes.fromhex('2f').decode('utf-8')), (bytes.fromhex('42696c696d204b757267752046696c6d6c657269').decode('utf-8'), bytes.fromhex('2f6170692f6d6f7669652f62792f66696c747265732f342f637265617465642f53415946412f').decode('utf-8') + SW_KEY + bytes.fromhex('2f').decode('utf-8')), (bytes.fromhex('4472616d2046696c6d6c657269').decode('utf-8'), bytes.fromhex('2f6170692f6d6f7669652f62792f66696c747265732f322f637265617465642f53415946412f').decode('utf-8') + SW_KEY + bytes.fromhex('2f').decode('utf-8')), (bytes.fromhex('46616e74617a692046696c6d6c657269').decode('utf-8'), bytes.fromhex('2f6170692f6d6f7669652f62792f66696c747265732f31302f637265617465642f53415946412f').decode('utf-8') + SW_KEY + bytes.fromhex('2f').decode('utf-8')), (bytes.fromhex('4b6f6d6564692046696c6d6c657269').decode('utf-8'), bytes.fromhex('2f6170692f6d6f7669652f62792f66696c747265732f332f637265617465642f53415946412f').decode('utf-8') + SW_KEY + bytes.fromhex('2f').decode('utf-8')), (bytes.fromhex('4b6f726b752046696c6d6c657269').decode('utf-8'), bytes.fromhex('2f6170692f6d6f7669652f62792f66696c747265732f382f637265617465642f53415946412f').decode('utf-8') + SW_KEY + bytes.fromhex('2f').decode('utf-8')), (bytes.fromhex('4d61636572612046696c6d6c657269').decode('utf-8'), bytes.fromhex('2f6170692f6d6f7669652f62792f66696c747265732f31372f637265617465642f53415946412f').decode('utf-8') + SW_KEY + bytes.fromhex('2f').decode('utf-8')), (bytes.fromhex('526f6d616e74697a6d2046696c6d6c657269').decode('utf-8'), bytes.fromhex('2f6170692f6d6f7669652f62792f66696c747265732f352f637265617465642f53415946412f').decode('utf-8') + SW_KEY + bytes.fromhex('2f').decode('utf-8')))

    def __init__(self, base_url=bytes.fromhex('').decode('utf-8'), user_agent=bytes.fromhex('6f6b687474702f342e31322e30').decode('utf-8')):
        self.user_agent = user_agent or bytes.fromhex('6f6b687474702f342e31322e30').decode('utf-8')
        self.session = manituxhttp.Session(client_identifier=self.CLIENT_IDENTIFIERS[0])
        self.base_url = (base_url or self.remote_base_url() or self.FALLBACK_URL).rstrip(bytes.fromhex('2f').decode('utf-8'))

    def categories(self):
        return list(self.CATEGORIES)

    def get_page_items(self, path, page_number=1):
        return [self.normalize_item(item) for item in self.get_json(path.replace(bytes.fromhex('5341594641').decode('utf-8'), str(int(page_number)))) or []]

    def search(self, query):
        V51980881195349 = query.encode(bytes.fromhex('7574662d38').decode('utf-8')) if not isinstance(query, bytes) else query
        path = bytes.fromhex('2f6170692f7365617263682f7b307d2f7b317d2f').decode('utf-8').format(quote_from_bytes(V51980881195349), self.SW_KEY)
        IIlIIIII = self.get_json(path) or {}
        aAaA = []
        for item in IIlIIIII.get(bytes.fromhex('6368616e6e656c73').decode('utf-8')) or []:
            aAaA.append(self.normalize_item(item))
        for item in IIlIIIII.get(bytes.fromhex('706f7374657273').decode('utf-8')) or []:
            aAaA.append(self.normalize_item(item))
        return aAaA

    def seasons(self, item):
        path = bytes.fromhex('2f6170692f736561736f6e2f62792f73657269652f7b307d2f7b317d2f').decode('utf-8').format(item.get(bytes.fromhex('6964').decode('utf-8')), self.SW_KEY)
        return self.get_json(path) or []

    def sources_from_item(self, item):
        return self.normalize_sources(item.get(bytes.fromhex('736f7572636573').decode('utf-8')) or [])

    def sources_from_episode(self, episode):
        return self.normalize_sources(episode.get(bytes.fromhex('736f7572636573').decode('utf-8')) or [])

    def stream_url(self, source):
        url = self.fix_stream_url((source or {}).get(bytes.fromhex('75726c').decode('utf-8')) or bytes.fromhex('').decode('utf-8'))
        if not url:
            return bytes.fromhex('').decode('utf-8')
        return url + self.kodi_headers()

    def get_json(self, path):
        text = self.get(path)
        try:
            return json.loads(text)
        except Exception:
            return None

    def get(self, path):
        url = path if path.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8'))) else self.base_url + path
        headers = self.api_headers(url)
        return self._request(bytes.fromhex('474554').decode('utf-8'), url, headers=headers).text

    def api_headers(self, full_url, method=bytes.fromhex('474554').decode('utf-8'), body=None):
        k14 = str(int(time.time()))
        lIllIII = str(uuid.uuid4())
        path = urlparse(full_url).path or bytes.fromhex('2f').decode('utf-8')
        b76816006639222 = hashlib.sha256(body or b'').hexdigest()
        BBoCLFuavvlOTxuJbXAylXykvqQoiHGFTiKiCmrXglZtfueDItpIKAsPNXXosoCALuFLXGxpJMxOiQZ13 = bytes.fromhex('0a').decode('utf-8').join((method, path, k14, lIllIII, b76816006639222))
        AaAAA = self.HMAC_KEY.encode(bytes.fromhex('7574662d38').decode('utf-8'))
        t335857041392112 = hmac.new(AaAAA, BBoCLFuavvlOTxuJbXAylXykvqQoiHGFTiKiCmrXglZtfueDItpIKAsPNXXosoCALuFLXGxpJMxOiQZ13.encode(bytes.fromhex('7574662d38').decode('utf-8')), hashlib.sha256).hexdigest()
        return {bytes.fromhex('582d54696d657374616d70').decode('utf-8'): k14, bytes.fromhex('582d4e6f6e6365').decode('utf-8'): lIllIII, bytes.fromhex('582d5369676e6174757265').decode('utf-8'): t335857041392112, bytes.fromhex('582d4170702d56657273696f6e').decode('utf-8'): bytes.fromhex('313036').decode('utf-8'), bytes.fromhex('582d436c69656e742d4964').decode('utf-8'): bytes.fromhex('72656374762d616e64726f6964').decode('utf-8'), bytes.fromhex('557365722d4167656e74').decode('utf-8'): self.user_agent}

    def remote_base_url(self):
        body = json.dumps({bytes.fromhex('61707056657273696f6e').decode('utf-8'): bytes.fromhex('31392e322e32').decode('utf-8'), bytes.fromhex('617070496e7374616e63654964').decode('utf-8'): bytes.fromhex('636b34595368357354456163334a5362455779555249').decode('utf-8'), bytes.fromhex('6170704964').decode('utf-8'): bytes.fromhex('313a3739313538333033313237393a616e64726f69643a32343463336435303761623239396663616263303161').decode('utf-8')}).encode(bytes.fromhex('7574662d38').decode('utf-8'))
        headers = {bytes.fromhex('582d476f6f672d4170692d4b6579').decode('utf-8'): bytes.fromhex('41497a615379426268707a473845636f68753979417266434f357446313342514c686a4c616863').decode('utf-8'), bytes.fromhex('582d416e64726f69642d5061636b616765').decode('utf-8'): bytes.fromhex('636f6d2e72656374762e73686f74').decode('utf-8'), bytes.fromhex('557365722d4167656e74').decode('utf-8'): bytes.fromhex('44616c76696b2f322e312e3020284c696e75783b20553b20416e64726f696420313229').decode('utf-8'), bytes.fromhex('436f6e74656e742d54797065').decode('utf-8'): bytes.fromhex('6170706c69636174696f6e2f6a736f6e').decode('utf-8')}
        try:
            lllIllllll = self._request(bytes.fromhex('504f5354').decode('utf-8'), self.REMOTE_CONFIG_URL, headers=headers, data=body)
            IIlIIIII = json.loads(lllIllllll.text)
            l = (IIlIIIII.get(bytes.fromhex('656e7472696573').decode('utf-8')) or {}).get(bytes.fromhex('6170695f75726c').decode('utf-8')) or bytes.fromhex('').decode('utf-8')
            return l.replace(bytes.fromhex('2f6170692f').decode('utf-8'), bytes.fromhex('').decode('utf-8')).rstrip(bytes.fromhex('2f').decode('utf-8'))
        except Exception:
            return self.FALLBACK_URL

    def _request(self, method, url, headers=None, data=None):
        IIIIll = None
        for aaa in self.CLIENT_IDENTIFIERS:
            if self.session.client_identifier != aaa:
                self.session = manituxhttp.Session(client_identifier=aaa)
            try:
                if method == bytes.fromhex('504f5354').decode('utf-8'):
                    lllIllllll = self.session.post(url, data=data, headers=headers, timeout=25, allow_redirects=True, tls_client_identifier=aaa)
                else:
                    lllIllllll = self.session.get(url, headers=headers, timeout=25, allow_redirects=True, tls_client_identifier=aaa)
                if lllIllllll.status_code in (403, 429) and aaa != self.CLIENT_IDENTIFIERS[-1]:
                    IIIIll = manituxhttp.HTTPError(lllIllllll)
                    continue
                lllIllllll.raise_for_status()
                return lllIllllll
            except (manituxhttp.HTTPError, manituxhttp.RequestError) as exc:
                IIIIll = exc
                if aaa == self.CLIENT_IDENTIFIERS[-1]:
                    raise
        raise IIIIll

    def normalize_item(self, item):
        item = dict(item or {})
        item[bytes.fromhex('736f7572636573').decode('utf-8')] = self.normalize_sources(item.get(bytes.fromhex('736f7572636573').decode('utf-8')) or [])
        return item

    def normalize_sources(self, sources):
        AaAAAAAaAAA = []
        for source in sources or []:
            source = dict(source or {})
            if bytes.fromhex('6f746f6c696e6b6166662e636f6d2f796f6e6c652f72656374766166662f').decode('utf-8') in (source.get(bytes.fromhex('75726c').decode('utf-8')) or bytes.fromhex('').decode('utf-8')):
                continue
            AaAAAAAaAAA.append(source)
        return AaAAAAAaAAA

    @staticmethod
    def fix_stream_url(url):
        if bytes.fromhex('776f726b6572732e646576').decode('utf-8') not in (url or bytes.fromhex('').decode('utf-8')):
            return url
        path = url.split(bytes.fromhex('2e6465762f').decode('utf-8'), 1)[-1].replace(bytes.fromhex('2661643d72616e646f6d3f').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
        query = url.split(bytes.fromhex('3f').decode('utf-8'), 1)[-1] if bytes.fromhex('3f').decode('utf-8') in url else bytes.fromhex('').decode('utf-8')
        return bytes.fromhex('68747470733a2f2f666972696e6d616b696e6573692e6c6f6c2f').decode('utf-8') + path + bytes.fromhex('3f3d26').decode('utf-8') + query

    def kodi_headers(self):
        return bytes.fromhex('7c526566657265723d7b307d264f726967696e3d7b317d26557365722d4167656e743d7b327d').decode('utf-8').format(quote(bytes.fromhex('68747470733a2f2f747769747465722e636f6d2f').decode('utf-8')), quote(bytes.fromhex('68747470733a2f2f747769747465722e636f6d').decode('utf-8')), quote(bytes.fromhex('676f6f676c6575736572636f6e74656e74').decode('utf-8')))
