# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import re
import sys
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

try:
    from urllib.parse import parse_qsl, urlencode
except ImportError:
    from urlparse import parse_qsl
    from urllib import urlencode

from resources.lib.extractor import VideoExtractor
from resources.lib.site import HDFilmCehennemiSite
from manituxui import DetailWindow, ManituxUI, open_browser


ADDON_ID = "plugin.video.test"
SKIP_GUI_UNTIL = ADDON_ID + ".skip_gui_until"
ADDON = xbmcaddon.Addon(id=ADDON_ID)
HANDLE = int(sys.argv[1])
BASE_URL = ADDON.getSetting("base_url") or "https://www.hdfilmcehennemi.nl"
UA = ADDON.getSetting("user_agent") or "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"

site = HDFilmCehennemiSite(BASE_URL, UA)
extractor = VideoExtractor(UA)


class HDFilmCehennemiUI(ManituxUI):
    title = "HDFilmCehennemi"

    def categories(self):
        categories = [{"title": "Ara", "action": "search"}]
        for title, url in site.categories():
            categories.append({"title": title, "url": url})
        return categories

    def videos(self, category, page=1):
        if category.get("action") == "search":
            query = xbmcgui.Dialog().input("HDFilmCehennemi Ara")
            return site.search(query) if query else []
        return site.get_page_items(category["url"], page)

    def detail(self, video):
        page_url = video["url"]
        page = site.get(page_url)
        info = site.parse_detail(page, page_url)
        image = info.get("image") or video.get("image", "")
        plot = info.get("plot") or video.get("plot", "")
        sources = []
        for source in info.get("sources", []):
            sources.append(
                {
                    "label": source.get("label") or "Oynat",
                    "url": source.get("url") if source.get("is_trailer") else page_url,
                    "video_id": source.get("video_id", ""),
                    "is_trailer": source.get("is_trailer", False),
                    "referer": page_url,
                }
            )
        return {
            "title": info.get("title") or video.get("title", ""),
            "url": page_url,
            "image": image,
            "backdrop": info.get("backdrop") or info.get("fanart") or image,
            "plot": plot,
            "year": info.get("year", ""),
            "country": info.get("country", ""),
            "duration": info.get("duration", ""),
            "rating": info.get("rating", ""),
            "tags": info.get("tags", ""),
            "actors": info.get("actors", ""),
            "episodes": info.get("episodes", []),
            "sources": sources,
        }

    def play(self, source, video=None):
        if source.get("is_episode"):
            self._play_episode(source.get("url", ""))
        elif source.get("is_trailer"):
            play_iframe_gui(source.get("url", ""), source.get("referer"))
        else:
            play_source_gui(source.get("url", ""), source.get("video_id", ""))

    def _play_episode(self, episode_url):
        page = site.get(episode_url)
        info = site.parse_detail(page, episode_url)
        sources = info.get("sources", [])
        if not sources:
            xbmcgui.Dialog().notification("HDFilmCehennemi", "Video kaynağı bulunamadı", xbmcgui.NOTIFICATION_WARNING, 3000)
            return
        source = sources[0]
        if len(sources) > 1:
            labels = [item.get("label") or "Kaynak {0}".format(index + 1) for index, item in enumerate(sources)]
            selected = xbmcgui.Dialog().select("Kaynak Sec", labels)
            if selected < 0:
                return
            source = sources[selected]
        if source.get("is_trailer"):
            play_iframe_gui(source.get("url", ""), episode_url)
        else:
            play_source_gui(episode_url, source.get("video_id", ""))


def build_url(query):
    return sys.argv[0] + "?" + urlencode(query)


def add_directory(title, action, url="", image="", plot=""):
    li = xbmcgui.ListItem(label=title)
    li.setArt({"thumb": image, "icon": image, "poster": image, "fanart": image})
    li.setInfo("video", {"title": title, "plot": plot})
    xbmcplugin.addDirectoryItem(HANDLE, build_url({"action": action, "url": url}), li, True)


def add_video(title, action, url, image="", plot="", extra=None):
    query = {"action": action, "url": url}
    if extra:
        query.update(extra)
    li = xbmcgui.ListItem(label=title)
    li.setArt({"thumb": image, "icon": image, "poster": image, "fanart": image})
    li.setInfo("video", {"title": title, "plot": plot})
    li.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(HANDLE, build_url(query), li, False)


def main_menu():
    add_directory("Ara", "search")
    for title, url in site.categories():
        add_directory(title, "list", url)
    xbmcplugin.setContent(HANDLE, "videos")


def manitux_skin_categories():
    """Return category folders for skin.manitux without opening ManituxUI."""
    for category in HDFilmCehennemiUI().categories():
        if category.get("action") == "search" or not category.get("url"):
            continue
        li = xbmcgui.ListItem(label=category.get("title", ""))
        li.setArt({"icon": ADDON.getAddonInfo("icon"), "thumb": ADDON.getAddonInfo("icon")})
        path = build_url(
            {
                "action": "manitux_skin_items",
                "url": category["url"],
                "category": category.get("title", ""),
                "page": "1",
            }
        )
        xbmcplugin.addDirectoryItem(HANDLE, path, li, True)
    xbmcplugin.setContent(HANDLE, "videos")


def manitux_skin_items(url, page_number=1):
    """Return poster folders for a selected skin.manitux category."""
    page_number = max(1, int(page_number))
    items = HDFilmCehennemiUI().videos({"url": url}, page_number)

    if page_number > 1:
        add_manitux_page_card(url, 1, "İlk Sayfa")
    if page_number > 2:
        add_manitux_page_card(url, page_number - 1, "Önceki Sayfa")

    page_card_count = (1 if page_number > 1 else 0) + (1 if page_number > 2 else 0)
    for item_index, item in enumerate(items, page_card_count):
        add_manitux_detail_card(item, item_index)

    if items:
        add_manitux_page_card(url, page_number + 1, "Sonraki Sayfa")

    xbmcplugin.setContent(HANDLE, "movies")


def manitux_skin_search(query):
    """Return skin search results without pagination cards."""
    items = site.search(query) if query else []
    for item_index, item in enumerate(items):
        add_manitux_detail_card(item, item_index)
    xbmcplugin.setContent(HANDLE, "movies")


def add_manitux_detail_card(item, item_index):
    title = item.get("title", "")
    image = item.get("image", "")
    plot = item.get("plot", "")
    li = xbmcgui.ListItem(label=title)
    li.setArt({"thumb": image, "icon": image, "poster": image, "fanart": image})
    li.setInfo("video", {"title": title, "plot": plot})
    li.setProperty("IsPlayable", "true")
    path = build_url(
        {
            "action": "manitux_skin_detail",
            "url": item.get("url", ""),
            "title": title,
            "image": image,
            "plot": plot,
            "item_index": str(item_index),
        }
    )
    xbmcplugin.addDirectoryItem(HANDLE, path, li, False)


def add_manitux_page_card(url, page_number, caption):
    li = xbmcgui.ListItem(label=str(page_number))
    li.setProperty("manitux_page_card", "true")
    li.setProperty("manitux_page_caption", caption)
    li.setProperty("IsPlayable", "true")
    path = build_url(
        {
            "action": "manitux_skin_page",
            "url": url,
            "page": str(page_number),
        }
    )
    xbmcplugin.addDirectoryItem(HANDLE, path, li, False)


def set_skin_string(name, value):
    value = (value or "").replace("\\", "\\\\").replace(",", "\\,").replace(")", "\\)")
    xbmc.executebuiltin("Skin.SetString({0},{1})".format(name, value))


def manitux_skin_page(url, page_number):
    page_number = max(1, int(page_number))
    category_path = build_url(
        {
            "action": "manitux_skin_items",
            "url": url,
            "page": str(page_number),
        }
    )
    set_skin_string("Manitux.Loading", "true")
    set_skin_string("Manitux.CurrentPluginCategoryPath", category_path)
    set_skin_string("Manitux.CurrentPluginCategoryPage", str(page_number))
    set_skin_string("Manitux.CurrentPluginPreviousPage", str(max(1, page_number - 1)))
    set_skin_string("Manitux.CurrentPluginNextPage", str(page_number + 1))
    xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
    xbmc.executebuiltin("Container.Refresh")
    xbmc.sleep(150)
    xbmc.executebuiltin("SetFocus(300,0)")


def manitux_skin_detail(url, title, image, plot, item_index=0):
    xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
    detail_window = DetailWindow(
        "manituxui_detail.xml",
        xbmcaddon.Addon(id="script.module.manituxui").getAddonInfo("path"),
        "Default",
        "1080i",
        adapter=HDFilmCehennemiUI(),
        video={
            "title": title or "",
            "url": url or "",
            "image": image or "",
            "backdrop": image or "",
            "plot": plot or "",
        },
    )
    detail_window.doModal()
    del detail_window
    xbmc.sleep(100)
    xbmc.executebuiltin("SetFocus(300,{0},absolute)".format(max(0, int(item_index))))


def list_page(url, page_number=1):
    items = site.get_page_items(url, page_number)
    for item in items:
        add_directory(item["title"], "detail", item["url"], item["image"], item["plot"])
    if items:
        li = xbmcgui.ListItem(label="Sonraki Sayfa")
        xbmcplugin.addDirectoryItem(
            HANDLE,
            build_url({"action": "list", "url": url, "page": str(int(page_number) + 1)}),
            li,
            True,
        )
    xbmcplugin.setContent(HANDLE, "movies")


def search():
    query = xbmcgui.Dialog().input("HDFilmCehennemi Ara")
    if query:
        for item in site.search(query):
            add_directory(item["title"], "detail", item["url"], item["image"], item.get("plot", ""))
        xbmcplugin.setContent(HANDLE, "movies")


def detail(url):
    page = site.get(url)
    info = site.parse_detail(page, url)
    if info["sources"]:
        for source in info["sources"]:
            add_video(
                source["label"],
                "play_iframe" if source.get("is_trailer") else "play_source",
                source["url"] if source.get("is_trailer") else url,
                info["image"],
                info["plot"],
                {"video_id": source.get("video_id", "")},
            )
    if not is_episode_url(url):
        for episode in info.get("episodes", []):
            add_directory(episode["title"], "detail", episode["url"], info["image"], info["plot"])
    if not info["sources"] and is_episode_url(url):
        for episode in info.get("episodes", []):
            add_directory(episode["title"], "detail", episode["url"], info["image"], info["plot"])
    if not info["sources"] and not info.get("episodes"):
        xbmcgui.Dialog().notification("HDFilmCehennemi", "Video kaynağı bulunamadı", xbmcgui.NOTIFICATION_WARNING, 3000)


def is_episode_url(url):
    return "/sezon-" in (url or "").lower() and "/bolum-" in (url or "").lower()


def youtube_plugin_url(url):
    video_id = ""
    for pattern in (
        r"(?:youtube\.com/embed/|youtube\.com/watch\?v=|youtu\.be/)([A-Za-z0-9_-]{6,})",
        r"[?&]v=([A-Za-z0-9_-]{6,})",
    ):
        match = re.search(pattern, url or "", re.I)
        if match:
            video_id = match.group(1)
            break
    return "plugin://plugin.video.youtube/play/?video_id=" + video_id if video_id else ""


def play_youtube(url):
    plugin_url = youtube_plugin_url(url)
    if not plugin_url:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    try:
        xbmcaddon.Addon(id="plugin.video.youtube")
    except Exception:
        xbmcgui.Dialog().notification("YouTube", "plugin.video.youtube gerekli", xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=plugin_url))


def play_iframe(url, referer=None):
    if youtube_plugin_url(url):
        play_youtube(url)
        return
    stream, subtitles = extractor.resolve(url, referer)
    if not stream:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    li = xbmcgui.ListItem(path=stream)
    if subtitles:
        li.setSubtitles(subtitles)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def play_youtube_gui(url):
    plugin_url = youtube_plugin_url(url)
    if not plugin_url:
        return False
    try:
        xbmcaddon.Addon(id="plugin.video.youtube")
    except Exception:
        xbmcgui.Dialog().notification("YouTube", "plugin.video.youtube gerekli", xbmcgui.NOTIFICATION_WARNING, 3000)
        return False
    xbmc.Player().play(plugin_url)
    return True


def play_iframe_gui(url, referer=None):
    if youtube_plugin_url(url):
        play_youtube_gui(url)
        return
    stream, subtitles = extractor.resolve(url, referer)
    play_stream_gui(stream, subtitles)


def play_source_gui(page_url, video_id):
    try:
        iframe = site.fetch_source_iframe(video_id, page_url)
    except Exception:
        page = site.get(page_url)
        iframe = site.parse_detail(page, page_url).get("iframe")
    play_iframe_gui(iframe, page_url)


def play_stream_gui(stream, subtitles=None):
    if not stream:
        xbmcgui.Dialog().notification("HDFilmCehennemi", "Kaynak çözülmedi", xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    li = xbmcgui.ListItem(path=stream)
    if ".m3u8" in (stream or "").split("|", 1)[0].lower():
        li.setMimeType("application/vnd.apple.mpegurl")
        li.setContentLookup(False)
    if subtitles:
        li.setSubtitles(subtitles)
    xbmc.Player().play(stream, li)


def play_source(page_url, video_id):
    try:
        iframe = site.fetch_source_iframe(video_id, page_url)
    except Exception:
        page = site.get(page_url)
        iframe = site.parse_detail(page, page_url).get("iframe")
    play_iframe(iframe, page_url)


def run():
    params = dict(parse_qsl(sys.argv[2][1:]))
    action = params.get("action")
    url = params.get("url", "")
    page_number = int(params.get("page", "1"))
    if not action:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
        window = xbmcgui.Window(10000)
        try:
            skip_until = float(window.getProperty(SKIP_GUI_UNTIL) or "0")
        except ValueError:
            skip_until = 0
        if time.time() < skip_until:
            return
        window.clearProperty(SKIP_GUI_UNTIL)
        xbmc.executebuiltin("RunPlugin({0})".format(build_url({"action": "gui"})))
        return
    elif action == "gui":
        open_browser(HDFilmCehennemiUI())
        xbmcgui.Window(10000).setProperty(SKIP_GUI_UNTIL, str(time.time() + 4))
        xbmc.executebuiltin("ActivateWindow(Home)")
        return
    elif action == "classic":
        main_menu()
    elif action == "manitux_skin_categories":
        manitux_skin_categories()
    elif action == "manitux_skin_items":
        manitux_skin_items(url, page_number)
    elif action == "manitux_skin_search":
        manitux_skin_search(params.get("query", ""))
    elif action == "manitux_skin_page":
        manitux_skin_page(url, page_number)
        return
    elif action == "manitux_skin_detail":
        manitux_skin_detail(
            url,
            params.get("title", ""),
            params.get("image", ""),
            params.get("plot", ""),
            params.get("item_index", "0"),
        )
        return
    elif action == "list":
        list_page(url, page_number)
    elif action == "search":
        search()
    elif action == "detail":
        detail(url)
    elif action == "play_iframe":
        play_iframe(url, params.get("referer"))
    elif action == "play_source":
        play_source(url, params.get("video_id"))
    xbmcplugin.endOfDirectory(HANDLE)


if __name__ == "__main__":
    run()
