from __future__ import absolute_import, unicode_literals
import re
import sys
import time
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
try:
    from urllib.parse import parse_qsl, quote, urlencode
except ImportError:
    from urlparse import parse_qsl
    from urllib import quote, urlencode
from resources.lib.extractor import VideoExtractor
from resources.lib.site import HDFilmCehennemiSite
from manituxui import DetailWindow, ManituxUI, format_time, get_continue_items, get_favorites, open_browser, play_and_track
ADDON_ID = bytes.fromhex('706c7567696e2e766964656f2e74657374').decode('utf-8')
I = ADDON_ID + bytes.fromhex('2e736b69705f6775695f756e74696c').decode('utf-8')
ADDON = xbmcaddon.Addon(id=ADDON_ID)
HANDLE = int(sys.argv[1])
BASE_URL = ADDON.getSetting(bytes.fromhex('626173655f75726c').decode('utf-8')) or bytes.fromhex('68747470733a2f2f7777772e686466696c6d636568656e6e656d692e6e6c').decode('utf-8')
UA = ADDON.getSetting(bytes.fromhex('757365725f6167656e74').decode('utf-8')) or bytes.fromhex('4d6f7a696c6c612f352e3020285831313b204c696e7578207838365f363429204170706c655765624b69742f3533372e333620284b48544d4c2c206c696b65204765636b6f29204368726f6d652f3132342e30205361666172692f3533372e3336').decode('utf-8')
site = HDFilmCehennemiSite(BASE_URL, UA)
extractor = VideoExtractor(UA)

class HDFilmCehennemiUI(ManituxUI):
    title = bytes.fromhex('484446696c6d436568656e6e656d69').decode('utf-8')
    favorite_owner = ADDON_ID

    def categories(llIl):
        categories = [{bytes.fromhex('7469746c65').decode('utf-8'): bytes.fromhex('417261').decode('utf-8'), bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('736561726368').decode('utf-8')}]
        for title, url in site.categories():
            categories.append({bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('75726c').decode('utf-8'): url})
        return categories

    def videos(llIl, category, page=1):
        if category.get(bytes.fromhex('616374696f6e').decode('utf-8')) == bytes.fromhex('736561726368').decode('utf-8'):
            query = xbmcgui.Dialog().input(bytes.fromhex('484446696c6d436568656e6e656d6920417261').decode('utf-8'))
            return [llIl._art_item(item) for item in site.search(query)] if query else []
        return [llIl._art_item(item) for item in site.get_page_items(category[bytes.fromhex('75726c').decode('utf-8')], page)]

    def _art_item(llIl, item):
        lI = dict(item)
        lI[bytes.fromhex('696d616765').decode('utf-8')] = art_url(lI.get(bytes.fromhex('696d616765').decode('utf-8'), bytes.fromhex('').decode('utf-8')), lI.get(bytes.fromhex('75726c').decode('utf-8')) or BASE_URL + bytes.fromhex('2f').decode('utf-8'))
        return lI

    def detail(llIl, video):
        page_url = video[bytes.fromhex('75726c').decode('utf-8')]
        page = site.get(page_url)
        llI = site.parse_detail(page, page_url)
        image = art_url(llI.get(bytes.fromhex('696d616765').decode('utf-8')) or video.get(bytes.fromhex('696d616765').decode('utf-8'), bytes.fromhex('').decode('utf-8')), page_url)
        plot = llI.get(bytes.fromhex('706c6f74').decode('utf-8')) or video.get(bytes.fromhex('706c6f74').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
        sources = []
        for source in llI.get(bytes.fromhex('736f7572636573').decode('utf-8'), []):
            sources.append({bytes.fromhex('6c6162656c').decode('utf-8'): source.get(bytes.fromhex('6c6162656c').decode('utf-8')) or bytes.fromhex('4f796e6174').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): source.get(bytes.fromhex('75726c').decode('utf-8')) if source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8')) else page_url, bytes.fromhex('766964656f5f6964').decode('utf-8'): source.get(bytes.fromhex('766964656f5f6964').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('69735f747261696c6572').decode('utf-8'): source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8'), False), bytes.fromhex('72656665726572').decode('utf-8'): page_url})
        return {bytes.fromhex('7469746c65').decode('utf-8'): llI.get(bytes.fromhex('7469746c65').decode('utf-8')) or video.get(bytes.fromhex('7469746c65').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('75726c').decode('utf-8'): page_url, bytes.fromhex('696d616765').decode('utf-8'): image, bytes.fromhex('6261636b64726f70').decode('utf-8'): llI.get(bytes.fromhex('6261636b64726f70').decode('utf-8')) or llI.get(bytes.fromhex('66616e617274').decode('utf-8')) or image, bytes.fromhex('706c6f74').decode('utf-8'): plot, bytes.fromhex('79656172').decode('utf-8'): llI.get(bytes.fromhex('79656172').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('636f756e747279').decode('utf-8'): llI.get(bytes.fromhex('636f756e747279').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('6475726174696f6e').decode('utf-8'): llI.get(bytes.fromhex('6475726174696f6e').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('726174696e67').decode('utf-8'): llI.get(bytes.fromhex('726174696e67').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('74616773').decode('utf-8'): llI.get(bytes.fromhex('74616773').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('6163746f7273').decode('utf-8'): llI.get(bytes.fromhex('6163746f7273').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('657069736f646573').decode('utf-8'): [llIl._art_episode(episode, image, page_url) for episode in llI.get(bytes.fromhex('657069736f646573').decode('utf-8'), [])], bytes.fromhex('736f7572636573').decode('utf-8'): sources}

    def _art_episode(llIl, episode, Ill, referer):
        lI = dict(episode)
        lI[bytes.fromhex('696d616765').decode('utf-8')] = art_url(lI.get(bytes.fromhex('696d616765').decode('utf-8')) or Ill, lI.get(bytes.fromhex('75726c').decode('utf-8')) or referer)
        return lI

    def play(llIl, source, video=None):
        if source.get(bytes.fromhex('69735f657069736f6465').decode('utf-8')):
            llIl._play_episode(source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
        elif source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8')):
            play_iframe_gui(source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), source.get(bytes.fromhex('72656665726572').decode('utf-8')))
        else:
            play_source_gui(source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), source.get(bytes.fromhex('766964656f5f6964').decode('utf-8'), bytes.fromhex('').decode('utf-8')), video, source)

    def resume(llIl, source, video, lIlI):
        play_source_gui(source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), source.get(bytes.fromhex('766964656f5f6964').decode('utf-8'), bytes.fromhex('').decode('utf-8')), video, source, lIlI)

    def _play_episode(llIl, IIl):
        page = site.get(IIl)
        llI = site.parse_detail(page, IIl)
        sources = llI.get(bytes.fromhex('736f7572636573').decode('utf-8'), [])
        if not sources:
            xbmcgui.Dialog().notification(bytes.fromhex('484446696c6d436568656e6e656d69').decode('utf-8'), bytes.fromhex('566964656f206b61796e61c49fc4b12062756c756e616d6164c4b1').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
            return
        source = sources[0]
        if len(sources) > 1:
            IIIl = [item.get(bytes.fromhex('6c6162656c').decode('utf-8')) or bytes.fromhex('4b61796e616b207b307d').decode('utf-8').format(lIl + 1) for lIl, item in enumerate(sources)]
            llII = xbmcgui.Dialog().select(bytes.fromhex('4b61796e616b20536563').decode('utf-8'), IIIl)
            if llII < 0:
                return
            source = sources[llII]
        if source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8')):
            play_iframe_gui(source.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), IIl)
        else:
            play_source_gui(IIl, source.get(bytes.fromhex('766964656f5f6964').decode('utf-8'), bytes.fromhex('').decode('utf-8')))

def build_url(query):
    return sys.argv[0] + bytes.fromhex('3f').decode('utf-8') + urlencode(query)

def art_url(url, referer=None):
    if not url or bytes.fromhex('7c').decode('utf-8') in url or (not url.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8')))):
        return url
    return url + bytes.fromhex('7c557365722d4167656e743d').decode('utf-8') + quote(UA) + bytes.fromhex('26526566657265723d').decode('utf-8') + quote(referer or BASE_URL + bytes.fromhex('2f').decode('utf-8'))

def add_directory(title, action, url=bytes.fromhex('').decode('utf-8'), image=bytes.fromhex('').decode('utf-8'), plot=bytes.fromhex('').decode('utf-8')):
    IIlI = xbmcgui.ListItem(label=title)
    image = art_url(image, url or BASE_URL + bytes.fromhex('2f').decode('utf-8'))
    IIlI.setArt({bytes.fromhex('7468756d62').decode('utf-8'): image, bytes.fromhex('69636f6e').decode('utf-8'): image, bytes.fromhex('706f73746572').decode('utf-8'): image, bytes.fromhex('66616e617274').decode('utf-8'): image})
    IIlI.setInfo(bytes.fromhex('766964656f').decode('utf-8'), {bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('706c6f74').decode('utf-8'): plot})
    xbmcplugin.addDirectoryItem(HANDLE, build_url({bytes.fromhex('616374696f6e').decode('utf-8'): action, bytes.fromhex('75726c').decode('utf-8'): url}), IIlI, True)

def add_video(title, action, url, image=bytes.fromhex('').decode('utf-8'), plot=bytes.fromhex('').decode('utf-8'), IlI=None):
    query = {bytes.fromhex('616374696f6e').decode('utf-8'): action, bytes.fromhex('75726c').decode('utf-8'): url}
    if IlI:
        query.update(IlI)
    IIlI = xbmcgui.ListItem(label=title)
    image = art_url(image, IlI.get(bytes.fromhex('72656665726572').decode('utf-8')) if IlI else url or BASE_URL + bytes.fromhex('2f').decode('utf-8'))
    IIlI.setArt({bytes.fromhex('7468756d62').decode('utf-8'): image, bytes.fromhex('69636f6e').decode('utf-8'): image, bytes.fromhex('706f73746572').decode('utf-8'): image, bytes.fromhex('66616e617274').decode('utf-8'): image})
    IIlI.setInfo(bytes.fromhex('766964656f').decode('utf-8'), {bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('706c6f74').decode('utf-8'): plot})
    IIlI.setProperty(bytes.fromhex('4973506c617961626c65').decode('utf-8'), bytes.fromhex('74727565').decode('utf-8'))
    xbmcplugin.addDirectoryItem(HANDLE, build_url(query), IIlI, False)

def main_menu():
    add_directory(bytes.fromhex('417261').decode('utf-8'), bytes.fromhex('736561726368').decode('utf-8'))
    for title, url in site.categories():
        add_directory(title, bytes.fromhex('6c697374').decode('utf-8'), url)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('766964656f73').decode('utf-8'))

def manitux_skin_categories():
    bytes.fromhex('52657475726e2063617465676f727920666f6c6465727320666f7220736b696e2e6d616e6974757820776974686f7574206f70656e696e67204d616e6974757855492e').decode('utf-8')
    for category in HDFilmCehennemiUI().categories():
        if category.get(bytes.fromhex('616374696f6e').decode('utf-8')) == bytes.fromhex('736561726368').decode('utf-8') or not category.get(bytes.fromhex('75726c').decode('utf-8')):
            continue
        IIlI = xbmcgui.ListItem(label=category.get(bytes.fromhex('7469746c65').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
        IIlI.setArt({bytes.fromhex('69636f6e').decode('utf-8'): ADDON.getAddonInfo(bytes.fromhex('69636f6e').decode('utf-8')), bytes.fromhex('7468756d62').decode('utf-8'): ADDON.getAddonInfo(bytes.fromhex('69636f6e').decode('utf-8'))})
        path = build_url({bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('6d616e697475785f736b696e5f6974656d73').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): category[bytes.fromhex('75726c').decode('utf-8')], bytes.fromhex('63617465676f7279').decode('utf-8'): category.get(bytes.fromhex('7469746c65').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('70616765').decode('utf-8'): bytes.fromhex('31').decode('utf-8')})
        xbmcplugin.addDirectoryItem(HANDLE, path, IIlI, True)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('766964656f73').decode('utf-8'))

def manitux_skin_items(url, page_number=1):
    bytes.fromhex('52657475726e20706f7374657220666f6c6465727320666f7220612073656c656374656420736b696e2e6d616e697475782063617465676f72792e').decode('utf-8')
    page_number = max(1, int(page_number))
    IIII = HDFilmCehennemiUI().videos({bytes.fromhex('75726c').decode('utf-8'): url}, page_number)
    if page_number > 1:
        add_manitux_page_card(url, 1, bytes.fromhex('c4b06c6b205361796661').decode('utf-8'))
    if page_number > 2:
        add_manitux_page_card(url, page_number - 1, bytes.fromhex('c3966e63656b69205361796661').decode('utf-8'))
    IlIl = (1 if page_number > 1 else 0) + (1 if page_number > 2 else 0)
    for lll, item in enumerate(IIII, IlIl):
        add_manitux_detail_card(item, lll)
    if IIII:
        add_manitux_page_card(url, page_number + 1, bytes.fromhex('536f6e72616b69205361796661').decode('utf-8'))
    xbmcplugin.setContent(HANDLE, bytes.fromhex('6d6f76696573').decode('utf-8'))

def manitux_skin_search(query):
    bytes.fromhex('52657475726e20736b696e2073656172636820726573756c747320776974686f757420706167696e6174696f6e2063617264732e').decode('utf-8')
    IIII = site.search(query) if query else []
    for lll, item in enumerate(IIII):
        add_manitux_detail_card(item, lll)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('6d6f76696573').decode('utf-8'))

def manitux_skin_favorites():
    bytes.fromhex('52657475726e207361766564204d616e697475785549206661766f726974657320617320736b696e20706f737465722063617264732e').decode('utf-8')
    for lll, item in enumerate(get_favorites(ADDON_ID)):
        add_manitux_detail_card(item, lll)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('6d6f76696573').decode('utf-8'))

def manitux_skin_continue():
    bytes.fromhex('52657475726e20756e66696e6973686564204d616e69747578554920706c61796261636b207265636f72647320617320736b696e20706f737465722063617264732e').decode('utf-8')
    for lll, item in enumerate(get_continue_items(ADDON_ID)):
        II = dict(item)
        II[bytes.fromhex('7469746c65').decode('utf-8')] = bytes.fromhex('7b7d2020e280a220207b7d').decode('utf-8').format(item.get(bytes.fromhex('7469746c65').decode('utf-8'), bytes.fromhex('566964656f').decode('utf-8')), format_time(item.get(bytes.fromhex('706f736974696f6e').decode('utf-8'))))
        add_manitux_detail_card(II, lll)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('6d6f76696573').decode('utf-8'))

def add_manitux_detail_card(item, lll):
    title = item.get(bytes.fromhex('7469746c65').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
    image = item.get(bytes.fromhex('696d616765').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
    plot = item.get(bytes.fromhex('706c6f74').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
    IIlI = xbmcgui.ListItem(label=title)
    IIlI.setArt({bytes.fromhex('7468756d62').decode('utf-8'): image, bytes.fromhex('69636f6e').decode('utf-8'): image, bytes.fromhex('706f73746572').decode('utf-8'): image, bytes.fromhex('66616e617274').decode('utf-8'): image})
    IIlI.setInfo(bytes.fromhex('766964656f').decode('utf-8'), {bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('706c6f74').decode('utf-8'): plot})
    IIlI.setProperty(bytes.fromhex('4973506c617961626c65').decode('utf-8'), bytes.fromhex('74727565').decode('utf-8'))
    path = build_url({bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('6d616e697475785f736b696e5f64657461696c').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): item.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8')), bytes.fromhex('7469746c65').decode('utf-8'): title, bytes.fromhex('696d616765').decode('utf-8'): image, bytes.fromhex('706c6f74').decode('utf-8'): plot, bytes.fromhex('6974656d5f696e646578').decode('utf-8'): str(lll)})
    xbmcplugin.addDirectoryItem(HANDLE, path, IIlI, False)

def add_manitux_page_card(url, page_number, l):
    IIlI = xbmcgui.ListItem(label=str(page_number))
    IIlI.setProperty(bytes.fromhex('6d616e697475785f706167655f63617264').decode('utf-8'), bytes.fromhex('74727565').decode('utf-8'))
    IIlI.setProperty(bytes.fromhex('6d616e697475785f706167655f63617074696f6e').decode('utf-8'), l)
    IIlI.setProperty(bytes.fromhex('4973506c617961626c65').decode('utf-8'), bytes.fromhex('74727565').decode('utf-8'))
    path = build_url({bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('6d616e697475785f736b696e5f70616765').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('70616765').decode('utf-8'): str(page_number)})
    xbmcplugin.addDirectoryItem(HANDLE, path, IIlI, False)

def set_skin_string(IlII, IIIIl):
    IIIIl = (IIIIl or bytes.fromhex('').decode('utf-8')).replace(bytes.fromhex('5c').decode('utf-8'), bytes.fromhex('5c5c').decode('utf-8')).replace(bytes.fromhex('2c').decode('utf-8'), bytes.fromhex('5c2c').decode('utf-8')).replace(bytes.fromhex('29').decode('utf-8'), bytes.fromhex('5c29').decode('utf-8'))
    xbmc.executebuiltin(bytes.fromhex('536b696e2e536574537472696e67287b307d2c7b317d29').decode('utf-8').format(IlII, IIIIl))

def manitux_skin_page(url, page_number):
    page_number = max(1, int(page_number))
    Il = build_url({bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('6d616e697475785f736b696e5f6974656d73').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('70616765').decode('utf-8'): str(page_number)})
    set_skin_string(bytes.fromhex('4d616e697475782e4c6f6164696e67').decode('utf-8'), bytes.fromhex('74727565').decode('utf-8'))
    set_skin_string(bytes.fromhex('4d616e697475782e43757272656e74506c7567696e43617465676f727950617468').decode('utf-8'), Il)
    set_skin_string(bytes.fromhex('4d616e697475782e43757272656e74506c7567696e43617465676f727950616765').decode('utf-8'), str(page_number))
    set_skin_string(bytes.fromhex('4d616e697475782e43757272656e74506c7567696e50726576696f757350616765').decode('utf-8'), str(max(1, page_number - 1)))
    set_skin_string(bytes.fromhex('4d616e697475782e43757272656e74506c7567696e4e65787450616765').decode('utf-8'), str(page_number + 1))
    xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
    xbmc.executebuiltin(bytes.fromhex('436f6e7461696e65722e52656672657368').decode('utf-8'))
    xbmc.sleep(150)
    xbmc.executebuiltin(bytes.fromhex('536574466f637573283330302c3029').decode('utf-8'))

def manitux_skin_detail(url, title, image, plot, lll=0):
    xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
    III = DetailWindow(bytes.fromhex('6d616e6974757875695f64657461696c2e786d6c').decode('utf-8'), xbmcaddon.Addon(id=bytes.fromhex('7363726970742e6d6f64756c652e6d616e697475787569').decode('utf-8')).getAddonInfo(bytes.fromhex('70617468').decode('utf-8')), bytes.fromhex('44656661756c74').decode('utf-8'), bytes.fromhex('3130383069').decode('utf-8'), adapter=HDFilmCehennemiUI(), video={bytes.fromhex('6661766f726974655f6f776e6572').decode('utf-8'): ADDON_ID, bytes.fromhex('7469746c65').decode('utf-8'): title or bytes.fromhex('').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): url or bytes.fromhex('').decode('utf-8'), bytes.fromhex('696d616765').decode('utf-8'): image or bytes.fromhex('').decode('utf-8'), bytes.fromhex('6261636b64726f70').decode('utf-8'): image or bytes.fromhex('').decode('utf-8'), bytes.fromhex('706c6f74').decode('utf-8'): plot or bytes.fromhex('').decode('utf-8')})
    III.doModal()
    del III
    ll = xbmc.getInfoLabel(bytes.fromhex('536b696e2e537472696e67284d616e697475782e43757272656e74506c7567696e43617465676f72795061746829').decode('utf-8'))
    if bytes.fromhex('616374696f6e3d6d616e697475785f736b696e5f6661766f7269746573').decode('utf-8') in ll or bytes.fromhex('616374696f6e3d6d616e697475785f736b696e5f636f6e74696e7565').decode('utf-8') in ll:
        xbmc.executebuiltin(bytes.fromhex('436f6e7461696e65722e52656672657368').decode('utf-8'))
    xbmc.sleep(100)
    xbmc.executebuiltin(bytes.fromhex('536574466f637573283330302c7b307d2c6162736f6c75746529').decode('utf-8').format(max(0, int(lll))))

def list_page(url, page_number=1):
    IIII = site.get_page_items(url, page_number)
    for item in IIII:
        add_directory(item[bytes.fromhex('7469746c65').decode('utf-8')], bytes.fromhex('64657461696c').decode('utf-8'), item[bytes.fromhex('75726c').decode('utf-8')], item[bytes.fromhex('696d616765').decode('utf-8')], item[bytes.fromhex('706c6f74').decode('utf-8')])
    if IIII:
        IIlI = xbmcgui.ListItem(label=bytes.fromhex('536f6e72616b69205361796661').decode('utf-8'))
        xbmcplugin.addDirectoryItem(HANDLE, build_url({bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('6c697374').decode('utf-8'), bytes.fromhex('75726c').decode('utf-8'): url, bytes.fromhex('70616765').decode('utf-8'): str(int(page_number) + 1)}), IIlI, True)
    xbmcplugin.setContent(HANDLE, bytes.fromhex('6d6f76696573').decode('utf-8'))

def search():
    query = xbmcgui.Dialog().input(bytes.fromhex('484446696c6d436568656e6e656d6920417261').decode('utf-8'))
    if query:
        for item in site.search(query):
            add_directory(item[bytes.fromhex('7469746c65').decode('utf-8')], bytes.fromhex('64657461696c').decode('utf-8'), item[bytes.fromhex('75726c').decode('utf-8')], item[bytes.fromhex('696d616765').decode('utf-8')], item.get(bytes.fromhex('706c6f74').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
        xbmcplugin.setContent(HANDLE, bytes.fromhex('6d6f76696573').decode('utf-8'))

def detail(url):
    page = site.get(url)
    llI = site.parse_detail(page, url)
    if llI[bytes.fromhex('736f7572636573').decode('utf-8')]:
        for source in llI[bytes.fromhex('736f7572636573').decode('utf-8')]:
            add_video(source[bytes.fromhex('6c6162656c').decode('utf-8')], bytes.fromhex('706c61795f696672616d65').decode('utf-8') if source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8')) else bytes.fromhex('706c61795f736f75726365').decode('utf-8'), source[bytes.fromhex('75726c').decode('utf-8')] if source.get(bytes.fromhex('69735f747261696c6572').decode('utf-8')) else url, llI[bytes.fromhex('696d616765').decode('utf-8')], llI[bytes.fromhex('706c6f74').decode('utf-8')], {bytes.fromhex('766964656f5f6964').decode('utf-8'): source.get(bytes.fromhex('766964656f5f6964').decode('utf-8'), bytes.fromhex('').decode('utf-8'))})
    if not is_episode_url(url):
        for episode in llI.get(bytes.fromhex('657069736f646573').decode('utf-8'), []):
            add_directory(episode[bytes.fromhex('7469746c65').decode('utf-8')], bytes.fromhex('64657461696c').decode('utf-8'), episode[bytes.fromhex('75726c').decode('utf-8')], llI[bytes.fromhex('696d616765').decode('utf-8')], llI[bytes.fromhex('706c6f74').decode('utf-8')])
    if not llI[bytes.fromhex('736f7572636573').decode('utf-8')] and is_episode_url(url):
        for episode in llI.get(bytes.fromhex('657069736f646573').decode('utf-8'), []):
            add_directory(episode[bytes.fromhex('7469746c65').decode('utf-8')], bytes.fromhex('64657461696c').decode('utf-8'), episode[bytes.fromhex('75726c').decode('utf-8')], llI[bytes.fromhex('696d616765').decode('utf-8')], llI[bytes.fromhex('706c6f74').decode('utf-8')])
    if not llI[bytes.fromhex('736f7572636573').decode('utf-8')] and (not llI.get(bytes.fromhex('657069736f646573').decode('utf-8'))):
        xbmcgui.Dialog().notification(bytes.fromhex('484446696c6d436568656e6e656d69').decode('utf-8'), bytes.fromhex('566964656f206b61796e61c49fc4b12062756c756e616d6164c4b1').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)

def is_episode_url(url):
    return bytes.fromhex('2f73657a6f6e2d').decode('utf-8') in (url or bytes.fromhex('').decode('utf-8')).lower() and bytes.fromhex('2f626f6c756d2d').decode('utf-8') in (url or bytes.fromhex('').decode('utf-8')).lower()

def youtube_plugin_url(url):
    IIIlI = bytes.fromhex('').decode('utf-8')
    for Illl in (bytes.fromhex('283f3a796f75747562655c2e636f6d2f656d6265642f7c796f75747562655c2e636f6d2f77617463685c3f763d7c796f7574755c2e62652f29285b412d5a612d7a302d395f2d5d7b362c7d29').decode('utf-8'), bytes.fromhex('5b3f265d763d285b412d5a612d7a302d395f2d5d7b362c7d29').decode('utf-8')):
        IIll = re.search(Illl, url or bytes.fromhex('').decode('utf-8'), re.I)
        if IIll:
            IIIlI = IIll.group(1)
            break
    return bytes.fromhex('706c7567696e3a2f2f706c7567696e2e766964656f2e796f75747562652f706c61792f3f766964656f5f69643d').decode('utf-8') + IIIlI if IIIlI else bytes.fromhex('').decode('utf-8')

def play_youtube(url):
    lIIl = youtube_plugin_url(url)
    if not lIIl:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    try:
        xbmcaddon.Addon(id=bytes.fromhex('706c7567696e2e766964656f2e796f7574756265').decode('utf-8'))
    except Exception:
        xbmcgui.Dialog().notification(bytes.fromhex('596f7554756265').decode('utf-8'), bytes.fromhex('706c7567696e2e766964656f2e796f757475626520676572656b6c69').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=lIIl))

def play_iframe(url, referer=None):
    if youtube_plugin_url(url):
        play_youtube(url)
        return
    llll, IIIII = extractor.resolve(url, referer)
    if not llll:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    IIlI = xbmcgui.ListItem(path=llll)
    if IIIII:
        IIlI.setSubtitles(IIIII)
    xbmcplugin.setResolvedUrl(HANDLE, True, IIlI)

def play_youtube_gui(url):
    lIIl = youtube_plugin_url(url)
    if not lIIl:
        return False
    try:
        xbmcaddon.Addon(id=bytes.fromhex('706c7567696e2e766964656f2e796f7574756265').decode('utf-8'))
    except Exception:
        xbmcgui.Dialog().notification(bytes.fromhex('596f7554756265').decode('utf-8'), bytes.fromhex('706c7567696e2e766964656f2e796f757475626520676572656b6c69').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
        return False
    xbmc.Player().play(lIIl)
    return True

def play_iframe_gui(url, referer=None, lIII=None, source=None, lIll=0):
    if youtube_plugin_url(url):
        play_youtube_gui(url)
        return
    llll, IIIII = extractor.resolve(url, referer)
    play_stream_gui(llll, IIIII, lIII, source, lIll)

def play_source_gui(page_url, IIIlI, lIII=None, source=None, lIll=0):
    try:
        lII = site.fetch_source_iframe(IIIlI, page_url)
    except Exception:
        page = site.get(page_url)
        lII = site.parse_detail(page, page_url).get(bytes.fromhex('696672616d65').decode('utf-8'))
    play_iframe_gui(lII, page_url, lIII, source, lIll)

def play_stream_gui(llll, IIIII=None, lIII=None, source=None, lIll=0):
    if not llll:
        xbmcgui.Dialog().notification(bytes.fromhex('484446696c6d436568656e6e656d69').decode('utf-8'), bytes.fromhex('4b61796e616b20c3a7c3b67ac3bc6c6d656469').decode('utf-8'), xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    IIlI = xbmcgui.ListItem(path=llll)
    if bytes.fromhex('2e6d337538').decode('utf-8') in (llll or bytes.fromhex('').decode('utf-8')).split(bytes.fromhex('7c').decode('utf-8'), 1)[0].lower():
        IIlI.setMimeType(bytes.fromhex('6170706c69636174696f6e2f766e642e6170706c652e6d70656775726c').decode('utf-8'))
        IIlI.setContentLookup(False)
    if IIIII:
        IIlI.setSubtitles(IIIII)
    if lIII:
        play_and_track(llll, IIlI, ADDON_ID, lIII, source or {}, lIll)
    else:
        xbmc.Player().play(llll, IIlI)

def play_source(page_url, IIIlI):
    try:
        lII = site.fetch_source_iframe(IIIlI, page_url)
    except Exception:
        page = site.get(page_url)
        lII = site.parse_detail(page, page_url).get(bytes.fromhex('696672616d65').decode('utf-8'))
    play_iframe(lII, page_url)

def run():
    IllI = dict(parse_qsl(sys.argv[2][1:]))
    action = IllI.get(bytes.fromhex('616374696f6e').decode('utf-8'))
    url = IllI.get(bytes.fromhex('75726c').decode('utf-8'), bytes.fromhex('').decode('utf-8'))
    page_number = int(IllI.get(bytes.fromhex('70616765').decode('utf-8'), bytes.fromhex('31').decode('utf-8')))
    if not action:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
        IIIll = xbmcgui.Window(10000)
        try:
            lllI = float(IIIll.getProperty(I) or bytes.fromhex('30').decode('utf-8'))
        except ValueError:
            lllI = 0
        if time.time() < lllI:
            return
        IIIll.clearProperty(I)
        xbmc.executebuiltin(bytes.fromhex('52756e506c7567696e287b307d29').decode('utf-8').format(build_url({bytes.fromhex('616374696f6e').decode('utf-8'): bytes.fromhex('677569').decode('utf-8')})))
        return
    elif action == bytes.fromhex('677569').decode('utf-8'):
        open_browser(HDFilmCehennemiUI())
        xbmcgui.Window(10000).setProperty(I, str(time.time() + 4))
        xbmc.executebuiltin(bytes.fromhex('416374697661746557696e646f7728486f6d6529').decode('utf-8'))
        return
    elif action == bytes.fromhex('636c6173736963').decode('utf-8'):
        main_menu()
    elif action == bytes.fromhex('6d616e697475785f736b696e5f63617465676f72696573').decode('utf-8'):
        manitux_skin_categories()
    elif action == bytes.fromhex('6d616e697475785f736b696e5f6974656d73').decode('utf-8'):
        manitux_skin_items(url, page_number)
    elif action == bytes.fromhex('6d616e697475785f736b696e5f736561726368').decode('utf-8'):
        manitux_skin_search(IllI.get(bytes.fromhex('7175657279').decode('utf-8'), bytes.fromhex('').decode('utf-8')))
    elif action == bytes.fromhex('6d616e697475785f736b696e5f6661766f7269746573').decode('utf-8'):
        manitux_skin_favorites()
    elif action == bytes.fromhex('6d616e697475785f736b696e5f636f6e74696e7565').decode('utf-8'):
        manitux_skin_continue()
    elif action == bytes.fromhex('6d616e697475785f736b696e5f70616765').decode('utf-8'):
        manitux_skin_page(url, page_number)
        return
    elif action == bytes.fromhex('6d616e697475785f736b696e5f64657461696c').decode('utf-8'):
        manitux_skin_detail(url, IllI.get(bytes.fromhex('7469746c65').decode('utf-8'), bytes.fromhex('').decode('utf-8')), IllI.get(bytes.fromhex('696d616765').decode('utf-8'), bytes.fromhex('').decode('utf-8')), IllI.get(bytes.fromhex('706c6f74').decode('utf-8'), bytes.fromhex('').decode('utf-8')), IllI.get(bytes.fromhex('6974656d5f696e646578').decode('utf-8'), bytes.fromhex('30').decode('utf-8')))
        return
    elif action == bytes.fromhex('6c697374').decode('utf-8'):
        list_page(url, page_number)
    elif action == bytes.fromhex('736561726368').decode('utf-8'):
        search()
    elif action == bytes.fromhex('64657461696c').decode('utf-8'):
        detail(url)
    elif action == bytes.fromhex('706c61795f696672616d65').decode('utf-8'):
        play_iframe(url, IllI.get(bytes.fromhex('72656665726572').decode('utf-8')))
    elif action == bytes.fromhex('706c61795f736f75726365').decode('utf-8'):
        play_source(url, IllI.get(bytes.fromhex('766964656f5f6964').decode('utf-8')))
    xbmcplugin.endOfDirectory(HANDLE)
if __name__ == bytes.fromhex('5f5f6d61696e5f5f').decode('utf-8'):
    run()
