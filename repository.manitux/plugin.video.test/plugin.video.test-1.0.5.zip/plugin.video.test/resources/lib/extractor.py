from __future__ import absolute_import, unicode_literals
import base64
import binascii
import json
import re
import string
import manituxhttp
try:
    from urllib.parse import quote, urlparse, urlunparse
except ImportError:
    from urllib import quote
    from urlparse import urlparse, urlunparse

class VideoExtractor(object):

    def __init__(lIIll, user_agent):
        lIIll.user_agent = user_agent
        lIIll.session = manituxhttp.Session()

    def headers(lIIll, referer=None):
        headers = {bytes.fromhex('557365722d4167656e74').decode('utf-8'): lIIll.user_agent, bytes.fromhex('416363657074').decode('utf-8'): bytes.fromhex('746578742f68746d6c2c6170706c69636174696f6e2f7868746d6c2b786d6c2c6170706c69636174696f6e2f786d6c3b713d302e392c2a2f2a3b713d302e38').decode('utf-8'), bytes.fromhex('436f6e74656e742d54797065').decode('utf-8'): bytes.fromhex('6170706c69636174696f6e2f6a736f6e').decode('utf-8'), bytes.fromhex('582d5265717565737465642d57697468').decode('utf-8'): bytes.fromhex('584d4c4874747052657175657374').decode('utf-8')}
        if referer:
            headers[bytes.fromhex('52656665726572').decode('utf-8')] = referer
        return headers

    def hdfilmcehennemi_extractor(lIIll, url, referer=None):
        url = lIIll.normalize_url(url)
        referer = referer or url
        page = lIIll.fetch(url, referer)
        IlIl = lIIll.origin(url)
        lIlIl = []
        source = lIIll._extract_obfuscated_video_link(page)
        llIlI = lIIll._unpack_first_eval(page)
        if llIlI:
            if not source:
                source = lIIll._extract_obfuscated_video_link(llIlI)
            if not source:
                source = lIIll._first(bytes.fromhex('736f75726365735c732a3a5c732a5c5b5c732a5c7b5c732a66696c655c732a3a5c732a5b275c225d285b5e275c225d2b29').decode('utf-8'), llIlI, re.S)
            if not source:
                lI = lIIll._first(bytes.fromhex('5b225c275d2861485230635b5e225c275d2b295b225c275d').decode('utf-8'), llIlI)
                if lI:
                    source = base64.b64decode(lI).decode(bytes.fromhex('7574662d38').decode('utf-8'), bytes.fromhex('7265706c616365').decode('utf-8'))
            lIlIl = lIIll._extract_subtitles(page + bytes.fromhex('0a').decode('utf-8') + llIlI, IlIl)
        else:
            source = lIIll._first(bytes.fromhex('22636f6e74656e7455726c225c732a3a5c732a22285b5e225d2b2922').decode('utf-8'), page)
            if not source:
                source = lIIll._first(bytes.fromhex('283f3a2266696c65227c66696c65295c732a3a5c732a5b225c275d285b5e225c275d2b29').decode('utf-8'), page)
            lIlIl = lIIll._extract_subtitles(page, IlIl)
        if not source:
            llIl = lIIll._first(bytes.fromhex('3c696672616d655b5e3e5d2b283f3a7372637c646174612d737263293d5b225c275d285b5e225c275d2b29').decode('utf-8'), page)
            if llIl and llIl != url:
                return lIIll.resolve(llIl.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')), url)
            return (None, lIlIl)
        source = source.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')).replace(bytes.fromhex('5c7530303236').decode('utf-8'), bytes.fromhex('26').decode('utf-8'))
        return (source + lIIll.kodi_headers(IlIl), lIlIl)

    def resolve(lIIll, url, referer=None):
        if not url:
            return (None, [])
        url = lIIll.normalize_url(url)
        if lIIll.is_hdfilm_url(url):
            return lIIll.hdfilmcehennemi_extractor(url, referer)
        if bytes.fromhex('7669646d6f6c79').decode('utf-8') in url or bytes.fromhex('666c6d706c61796572').decode('utf-8') in url:
            return lIIll.resolve_vidmoly(url)
        if bytes.fromhex('6f646e6f6b6c6173736e696b69').decode('utf-8') in url or bytes.fromhex('6f6b2e7275').decode('utf-8') in url:
            return lIIll.resolve_okru(url)
        return (url + lIIll.kodi_headers(referer), [])

    def resolve_hdfilm_embed(lIIll, url, referer=None):
        return lIIll.hdfilmcehennemi_extractor(url, referer)

    def resolve_vidmoly(lIIll, url):
        url = lIIll.normalize_url(url).replace(bytes.fromhex('2e746f70').decode('utf-8'), bytes.fromhex('2e746f').decode('utf-8'))
        page = lIIll.fetch(url, bytes.fromhex('68747470733a2f2f7669646d6f6c792e746f2f').decode('utf-8'))
        IlllI = lIIll._first(bytes.fromhex('77696e646f775c2e6c6f636174696f6e5c732a3d5c732a27285b5e275d2b2927').decode('utf-8'), page)
        if IlllI:
            page = lIIll.fetch(url.replace(bytes.fromhex('656d6265642d').decode('utf-8'), IlllI), url)
        source = lIIll._first(bytes.fromhex('285b5e275c225c735d2b5c2e6d3375385b5e275c225c735d2a29').decode('utf-8'), page)
        lIlll = re.findall(bytes.fromhex('66696c655c732a3a5c732a27285b5e275d2b2f7372745b5e275d2a2927').decode('utf-8'), page)
        return (source + lIIll.kodi_headers(bytes.fromhex('68747470733a2f2f7669646d6f6c792e746f2f').decode('utf-8')), lIlll)

    def resolve_okru(lIIll, url):
        url = lIIll.normalize_url(url)
        lllII = lIIll._first(bytes.fromhex('283f3a766964656f656d6265642f7c6d69643d29285c642b29').decode('utf-8'), url)
        if not lllII:
            return (url + lIIll.kodi_headers(bytes.fromhex('68747470733a2f2f6f6b2e72752f').decode('utf-8')), [])
        lIIII = lIIll.session.post(bytes.fromhex('68747470733a2f2f7777772e6f6b2e72752f646b').decode('utf-8'), data={bytes.fromhex('636d64').decode('utf-8'): bytes.fromhex('766964656f506c617965724d65746164617461').decode('utf-8'), bytes.fromhex('6d6964').decode('utf-8'): lllII}, headers=lIIll.headers(bytes.fromhex('68747470733a2f2f6f6b2e72752f').decode('utf-8')), timeout=25)
        lIIII.raise_for_status()
        data = lIIII.text
        source = lIIll._first(bytes.fromhex('283f3a756c7472617c717561647c66756c6c7c68647c73647c6c6f777c6c6f7765737429222c2275726c223a22282e2a3f2922').decode('utf-8'), data)
        return (source.replace(bytes.fromhex('5c7530303236').decode('utf-8'), bytes.fromhex('26').decode('utf-8')) + lIIll.kodi_headers(bytes.fromhex('68747470733a2f2f6f6b2e72752f').decode('utf-8')), [])

    def fetch(lIIll, url, referer=None):
        lIIII = lIIll.session.get(url, headers=lIIll.headers(referer), timeout=25, allow_redirects=True)
        lIIII.raise_for_status()
        return lIIII.text

    def normalize_url(lIIll, url):
        if url.startswith(bytes.fromhex('2f2f').decode('utf-8')):
            url = bytes.fromhex('68747470733a').decode('utf-8') + url
        elif url.startswith(bytes.fromhex('7777772e').decode('utf-8')):
            url = bytes.fromhex('68747470733a2f2f').decode('utf-8') + url
        elif not url.startswith((bytes.fromhex('687474703a2f2f').decode('utf-8'), bytes.fromhex('68747470733a2f2f').decode('utf-8'))):
            url = bytes.fromhex('68747470733a2f2f').decode('utf-8') + url
        IIllI = urlparse(url)
        return urlunparse(IIllI._replace(scheme=bytes.fromhex('6874747073').decode('utf-8')))

    def kodi_headers(lIIll, referer=None):
        III = [bytes.fromhex('557365722d4167656e743d').decode('utf-8') + quote(lIIll.user_agent)]
        if referer:
            III.append(bytes.fromhex('526566657265723d').decode('utf-8') + quote(referer))
        return bytes.fromhex('7c').decode('utf-8') + bytes.fromhex('26').decode('utf-8').join(III)

    def is_hdfilm_url(lIIll, url):
        lIlI = urlparse(url).netloc.lower()
        return bytes.fromhex('686466696c6d636568656e6e656d69').decode('utf-8') in lIlI or bytes.fromhex('64697a69636568656e6e656d69').decode('utf-8') in lIlI or bytes.fromhex('706c61796d6978').decode('utf-8') in lIlI or (bytes.fromhex('726170696472616d65').decode('utf-8') in lIlI)

    def origin(lIIll, url):
        IIllI = urlparse(url)
        return IIllI.scheme + bytes.fromhex('3a2f2f').decode('utf-8') + IIllI.netloc

    def _extract_subtitles(lIIll, page, origin):
        lIlll = []
        for lIllI in re.findall(bytes.fromhex('2266696c65225c732a3a5c732a22285b5e225d2b29225b5e7b7d5d2a226b696e64225c732a3a5c732a2263617074696f6e7322').decode('utf-8'), page, re.S):
            lIlll.append(lIIll._absolute_url(lIllI.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')), origin))
        for llIIl in re.findall(bytes.fromhex('747261636b735c732a3a5c732a285c5b2e2a3f5c5d295c732a2c').decode('utf-8'), page, re.S):
            for lIllI in re.findall(bytes.fromhex('2266696c65225c732a3a5c732a22285b5e225d2b2922').decode('utf-8'), llIIl):
                lIlll.append(lIIll._absolute_url(lIllI.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')), origin))
        for lIllI in re.findall(bytes.fromhex('747261636b5c732b7372633d5b275c225d285b5e275c225d2b29').decode('utf-8'), page, re.S | re.I):
            lIlll.append(lIIll._absolute_url(lIllI.replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')), origin))
        return list(dict.fromkeys(lIlll))

    def _absolute_url(lIIll, url, origin):
        if url.startswith(bytes.fromhex('2f2f').decode('utf-8')):
            return bytes.fromhex('68747470733a').decode('utf-8') + url
        if url.startswith(bytes.fromhex('2f').decode('utf-8')):
            return origin.rstrip(bytes.fromhex('2f').decode('utf-8')) + url
        return url

    def _unpack_first_eval(lIIll, page):
        IIIIl = re.search(bytes.fromhex('6576616c5c2866756e6374696f6e5c28702c612c632c6b2c652c645c292e2a3f5c7d5c28283f503c7061796c6f61643e5b275c225d2e2a3f5b275c225d295c732a2c5c732a283f503c626173653e5c642b295c732a2c5c732a283f503c636f756e743e5c642b295c732a2c5c732a283f503c73796d626f6c733e5b275c225d2e2a3f5b275c225d295c2e73706c69745c285b275c225d5c7c5b275c225d5c29').decode('utf-8'), page, re.S)
        if not IIIIl:
            return bytes.fromhex('').decode('utf-8')
        IlIll = lIIll._js_string(IIIIl.group(bytes.fromhex('7061796c6f6164').decode('utf-8')))
        ll = int(IIIIl.group(bytes.fromhex('62617365').decode('utf-8')))
        IIII = int(IIIIl.group(bytes.fromhex('636f756e74').decode('utf-8')))
        llIII = lIIll._js_string(IIIIl.group(bytes.fromhex('73796d626f6c73').decode('utf-8'))).split(bytes.fromhex('7c').decode('utf-8'))
        if IIII > len(llIII):
            llIII.extend([bytes.fromhex('').decode('utf-8')] * (IIII - len(llIII)))
        for lllI in range(IIII - 1, -1, -1):
            lllIl = lIIll._base_n(lllI, ll)
            if llIII[lllI]:
                IlIll = re.sub(bytes.fromhex('5c62').decode('utf-8') + re.escape(lllIl) + bytes.fromhex('5c62').decode('utf-8'), llIII[lllI], IlIll)
        return IlIll

    def _js_string(lIIll, llIll):
        IllIl = llIll[0]
        if llIll[-1] == IllIl:
            llIll = llIll[1:-1]
        return bytes(llIll, bytes.fromhex('7574662d38').decode('utf-8')).decode(bytes.fromhex('756e69636f64655f657363617065').decode('utf-8'))

    def _base_n(lIIll, IIlII, ll):
        I = string.digits + string.ascii_lowercase + string.ascii_uppercase
        if IIlII == 0:
            return bytes.fromhex('30').decode('utf-8')
        lIIIl = bytes.fromhex('').decode('utf-8')
        while IIlII:
            IIlII, Illll = divmod(IIlII, ll)
            lIIIl = I[Illll] + lIIIl
        return lIIIl

    def _decode_obfuscated_source(lIIll, page):
        IIIIl = re.search(bytes.fromhex('7661725c732b28735f5b412d5a612d7a302d395f5d2b295c732a3d5c732a2864635f5b412d5a612d7a302d395f5d2b295c28285c5b2e2a3f5c5d295c29').decode('utf-8'), page, re.S)
        if not IIIIl:
            return bytes.fromhex('').decode('utf-8')
        IlIIl = json.loads(IIIIl.group(3).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')))
        llIll = bytes.fromhex('').decode('utf-8').join(IlIIl)
        llIll = lIIll._rot13(llIll)[::-1]
        IIIl = base64.b64decode(llIll).decode(bytes.fromhex('6c6174696e2d31').decode('utf-8'))
        llI = []
        for llII, lII in enumerate(IIIl):
            lll = (ord(lII) - 399756995 % (llII + 5) + 256) % 256
            llI.append(chr(lll))
        return bytes.fromhex('').decode('utf-8').join(llI)

    @staticmethod
    def _rot13(llIll):
        IIlIl = []
        for lII in llIll:
            lll = ord(lII)
            if 65 <= lll <= 90:
                IIlIl.append(chr((lll - 65 + 13) % 26 + 65))
            elif 97 <= lll <= 122:
                IIlIl.append(chr((lll - 97 + 13) % 26 + 97))
            else:
                IIlIl.append(lII)
        return bytes.fromhex('').decode('utf-8').join(IIlIl)

    def _extract_obfuscated_video_link(lIIll, lIll):
        for IlI in lIIll._get_base64_candidates_from_html(lIll):
            source = lIIll._try_decrypt_candidate(IlI)
            if source:
                return source
        source = lIIll._decode_obfuscated_source(lIll)
        if source:
            return lIIll._get_url(source)
        return lIIll._direct_video_link(lIll)

    def _try_decrypt_candidate(lIIll, llIll):
        lIlII = (lambda llllI: lIIll._unmix(lIIll._rot13(lIIll._base64_decode_js(llllI[::-1]))), lambda llllI: lIIll._unmix(lIIll._base64_decode_js(lIIll._rot13(llllI))[::-1]), lambda llllI: lIIll._unmix(lIIll._rot13(lIIll._base64_decode_js(llllI))[::-1]), lambda llllI: lIIll._unmix(lIIll._base64_decode_js(lIIll._base64_decode_js(llllI[::-1]))), lambda llllI: lIIll._unmix(lIIll._base64_decode_js(lIIll._rot13(llllI)[::-1])), lIIll._decrypt_rot13_base64_reverse_unmix, lIIll._decrypt_reversed_double_base64_unmix, lIIll._decrypt_text_base64_rot13_reverse_unmix, lIIll._decrypt_rot13_reversed_base64_unmix)
        for IIlI in lIlII:
            try:
                IIIl = IIlI(llIll)
            except Exception:
                IIIl = None
            source = lIIll._get_url(IIIl)
            if source:
                return source
        return None

    def _decrypt_rot13_base64_reverse_unmix(lIIll, llIll):
        IIIl = lIIll._base64_decode_js(lIIll._rot13(llIll))
        if not IIIl:
            return None
        return lIIll._get_url(lIIll._unmix(IIIl[::-1]))

    def _decrypt_reversed_double_base64_unmix(lIIll, llIll):
        lIII = lIIll._base64_decode_js(llIll[::-1])
        if not lIII:
            return None
        lIIlI = lIIll._base64_decode_js(lIII)
        if not lIIlI:
            return None
        return lIIll._get_url(lIIll._unmix(lIIlI))

    def _decrypt_text_base64_rot13_reverse_unmix(lIIll, llIll):
        IIIl = lIIll._base64_decode_js(llIll)
        if not IIIl or lIIll._printable_ratio(IIIl) <= 0.75:
            return None
        return lIIll._get_url(lIIll._unmix(lIIll._rot13(IIIl)[::-1]))

    def _decrypt_rot13_reversed_base64_unmix(lIIll, llIll):
        IIIl = lIIll._base64_decode_js(lIIll._rot13(llIll)[::-1])
        if not IIIl or lIIll._printable_ratio(IIIl) <= 0.75:
            return None
        return lIIll._get_url(lIIll._unmix(IIIl))

    def _get_base64_candidates_from_html(lIIll, lIll):
        Ill = []
        lIIll._add_direct_array_values(lIll, Ill)
        lIIll._add_quoted_base64_values(lIll, Ill)
        llIlI = lIIll._unpack_first_eval(lIll)
        if llIlI:
            lIIll._add_direct_array_values(llIlI, Ill)
            lIIll._add_quoted_base64_values(llIlI, Ill)
        lIIll._add_packed_array_values(lIll, Ill)
        lIIIl = []
        for IlI in Ill:
            IlI = (IlI or bytes.fromhex('').decode('utf-8')).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')).strip()
            if lIIll._is_likely_encrypted_payload(IlI) and IlI not in lIIIl:
                lIIIl.append(IlI)
        return lIIIl

    def _add_direct_array_values(lIIll, lIll, Ill):
        II = re.compile(bytes.fromhex('5c625c772b5c732a5c285c732a285c5b5c732a283f3a5c225b5e5c225d2a5c227c275b5e275d2a27295c732a283f3a2c5c732a283f3a5c225b5e5c225d2a5c227c275b5e275d2a27295c732a292a5c5d295c732a5c29').decode('utf-8'), re.S)
        for IIIIl in II.finditer(lIll or bytes.fromhex('').decode('utf-8')):
            Il = IIIIl.group(1)
            IIllI = lIIll._parse_string_array(Il)
            if IIllI:
                Ill.append(IIllI)
            else:
                IlIIl = re.findall(bytes.fromhex('5b22275d285b5e22275d2b295b22275d').decode('utf-8'), Il)
                Ill.append(bytes.fromhex('').decode('utf-8').join(IlIIl))

    def _add_quoted_base64_values(lIIll, lIll, Ill):
        IlIlI = re.compile(bytes.fromhex('5b22275d283f503c76616c75653e283f3a3d7b302c327d295b412d5a612d7a302d392b2f5d7b38302c7d3d7b302c327d295b22275d').decode('utf-8'), re.S)
        for IIIIl in IlIlI.finditer(lIll or bytes.fromhex('').decode('utf-8')):
            Ill.append(IIIIl.group(bytes.fromhex('76616c7565').decode('utf-8')))

    def _add_packed_array_values(lIIll, lIll, Ill):
        Illl = re.compile(bytes.fromhex('6576616c5c2866756e6374696f6e5c28702c612c632c6b2c652c645c292e2a3f5c2e73706c69745c285b275c225d5c7c5b275c225d5c292c5c642b2c5c7b5c7d5c295c29').decode('utf-8'), re.S)
        for IllI in Illl.finditer(lIll or bytes.fromhex('').decode('utf-8')):
            IIl = IllI.group(0)
            IIll = re.search(bytes.fromhex('5b27225d285b5e27225d2a295b27225d5c2e73706c6974').decode('utf-8'), IIl, re.S)
            if not IIll:
                continue
            IlII = IIll.group(1).split(bytes.fromhex('7c').decode('utf-8'))
            llll = string.digits + string.ascii_lowercase + string.ascii_uppercase
            for l in re.finditer(bytes.fromhex('5c5b5c732a285b22275d2e2a3f5b22275d5c732a2c3f5c732a292b5c732a5c5d').decode('utf-8'), IIl, re.S):
                IlIIl = []
                for IlIII in re.finditer(bytes.fromhex('5b22275d283f503c76616c3e2e2a3f295b22275d').decode('utf-8'), l.group(0), re.S):
                    IIlll = re.sub(bytes.fromhex('5c772b').decode('utf-8'), lambda IIIII: lIIll._base62_lookup(IIIII.group(0), llll, IlII), IlIII.group(bytes.fromhex('76616c').decode('utf-8')))
                    IlIIl.append(IIlll)
                Ill.append(bytes.fromhex('').decode('utf-8').join(IlIIl))

    def _parse_string_array(lIIll, Il):
        IIIll = re.sub(bytes.fromhex('27285b5e275c5c5d2a283f3a5c5c2e5b5e275c5c5d2a292a2927').decode('utf-8'), lambda IIIII: json.dumps(IIIII.group(1)), Il)
        try:
            return bytes.fromhex('').decode('utf-8').join(json.loads(IIIll))
        except (TypeError, ValueError):
            return bytes.fromhex('').decode('utf-8')

    def _base62_lookup(lIIll, llIll, llll, IlII):
        lllI = 0
        IIIlI = 1
        for lII in reversed(llIll):
            lIl = llll.find(lII)
            if lIl == -1:
                return llIll
            lllI += lIl * IIIlI
            IIIlI *= 62
        if lllI < len(IlII) and IlII[lllI]:
            return IlII[lllI]
        return llIll

    def _base64_decode_js(lIIll, llIll):
        if not llIll:
            return bytes.fromhex('').decode('utf-8')
        try:
            if not isinstance(llIll, bytes):
                llIll = llIll.encode(bytes.fromhex('6c6174696e2d31').decode('utf-8'))
            llIll += b'=' * ((4 - len(llIll) % 4) % 4)
            return base64.b64decode(llIll).decode(bytes.fromhex('6c6174696e2d31').decode('utf-8'))
        except (TypeError, binascii.Error, UnicodeError):
            return bytes.fromhex('').decode('utf-8')

    def _is_likely_encrypted_payload(lIIll, llIll):
        if len(llIll) < 40:
            return False
        IIII = sum((1 for lII in llIll if lII.isalnum() or lII in bytes.fromhex('2b2f3d').decode('utf-8')))
        return float(IIII) / len(llIll) > 0.85

    def _unmix(lIIll, llIll):
        llI = []
        for llII, lII in enumerate(llIll):
            lll = (ord(lII) - 399756995 % (llII + 5) + 256) % 256
            llI.append(chr(lll))
        return bytes.fromhex('').decode('utf-8').join(llI)

    def _printable_ratio(lIIll, llIll):
        if not llIll:
            return 0
        IllII = sum((1 for lII in llIll if lII in bytes.fromhex('0d0a09').decode('utf-8') or bytes.fromhex('20').decode('utf-8') <= lII <= bytes.fromhex('7e').decode('utf-8')))
        return float(IllII) / len(llIll)

    def _get_url(lIIll, llIll):
        llIll = (llIll or bytes.fromhex('').decode('utf-8')).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8')).replace(bytes.fromhex('5c7530303236').decode('utf-8'), bytes.fromhex('26').decode('utf-8')).replace(bytes.fromhex('7530303236').decode('utf-8'), bytes.fromhex('26').decode('utf-8'))
        IIIIl = re.search(bytes.fromhex('68747470733f3a2f2f5b5e5c7322277c3c3e5d2b').decode('utf-8'), llIll)
        return IIIIl.group(0) if IIIIl else None

    def _direct_video_link(lIIll, lIll):
        llIlI = lIIll._unpack_first_eval(lIll)
        for source in (llIlI, lIll):
            IIIIl = re.search(bytes.fromhex('68747470733f3a5c5c3f2f5c5c3f2f5b5e22275c733c3e5d2b3f5c2e6d3375385b5e22275c733c3e5d2a').decode('utf-8'), source or bytes.fromhex('').decode('utf-8'), re.I)
            if IIIIl:
                return IIIIl.group(0).replace(bytes.fromhex('5c2f').decode('utf-8'), bytes.fromhex('2f').decode('utf-8'))
        return None

    @staticmethod
    def _first(IlIlI, text, lIIl=0):
        IIIIl = re.search(IlIlI, text or bytes.fromhex('').decode('utf-8'), lIIl | re.I)
        return IIIIl.group(1) if IIIIl else bytes.fromhex('').decode('utf-8')
