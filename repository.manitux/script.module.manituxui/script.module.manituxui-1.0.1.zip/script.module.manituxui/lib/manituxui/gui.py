# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import traceback

import xbmc
import xbmcaddon
import xbmcgui


ADDON_ID = "script.module.manituxui"
WINDOW_XML = "manituxui.xml"
DETAIL_XML = "manituxui_detail.xml"

CATEGORY_LIST_ID = 100
VIDEO_LIST_ID = 200
EPISODE_LIST_ID = 300
SOURCE_LIST_ID = 400


class UIError(Exception):
    pass


def addon_path():
    return xbmcaddon.Addon(id=ADDON_ID).getAddonInfo("path")


def _text(value, fallback=""):
    if value is None:
        return fallback
    try:
        return value if isinstance(value, str) else str(value)
    except Exception:
        return fallback


def _items(value):
    if value is None:
        return []
    if isinstance(value, (list, tuple)):
        return list(value)
    return list(value)


def _get(obj, key, fallback=""):
    if isinstance(obj, dict):
        return obj.get(key, fallback)
    return getattr(obj, key, fallback)


def _image(item):
    return _get(item, "image") or _get(item, "poster") or _get(item, "thumb") or _get(item, "icon") or ""


def _backdrop(item):
    return _get(item, "backdrop") or _get(item, "fanart") or _image(item)


def _title(item):
    return _get(item, "title") or _get(item, "label") or _get(item, "name") or "Video"


def _plot(item):
    return _get(item, "plot") or _get(item, "description") or _get(item, "overview") or ""


def _sources(item):
    return _get(item, "sources", None) or _get(item, "play_buttons", None) or _get(item, "players", None) or []


def _episodes(item):
    return _get(item, "episodes", None) or _get(item, "seasons", None) or []


def _metadata_line(item):
    parts = []
    for key in ("year", "country", "duration", "rating", "tags", "genres"):
        value = _text(_get(item, key, "")).strip()
        if not value:
            continue
        if key == "duration" and value.isdigit():
            value = value + " dk"
        if key == "rating":
            value = "IMDb " + value
        parts.append(value)
    return "  |  ".join(parts)


def _actors_line(item):
    actors = _get(item, "actors", "") or _get(item, "cast", "")
    if isinstance(actors, (list, tuple)):
        actors = ", ".join(_text(actor) for actor in actors if _text(actor))
    actors = _text(actors).strip()
    return "Oyuncular: " + actors if actors else ""


def _make_list_item(item):
    li = xbmcgui.ListItem(label=_text(_title(item), "Video"))
    image = _text(_image(item))
    fanart = _text(_backdrop(item))
    li.setArt({"thumb": image, "icon": image, "poster": image, "fanart": fanart})
    li.setInfo("video", {"title": _text(_title(item), "Video"), "plot": _text(_plot(item))})
    li.setProperty("plot", _text(_plot(item)))
    li.setProperty("poster", image)
    li.setProperty("backdrop", fanart)
    return li


def _make_page_item(label, page, direction):
    li = xbmcgui.ListItem(label=label)
    li.setProperty("is_page_button", "true")
    li.setProperty("page_direction", direction)
    li.setProperty("page_icon", "left_chevron.png" if direction == "previous" else "right_chevron.png")
    li.setProperty("plot", "Sayfa {0}".format(page + 1))
    return li


class ManituxUI(object):
    """Adapter base class for plugin-specific data providers."""

    title = "Manitux"

    def categories(self):
        return []

    def videos(self, category, page=1):
        return []

    def detail(self, video):
        return video

    def episode_detail(self, episode, video=None):
        return self.detail(episode)

    def play(self, source, video=None):
        raise UIError("Adapter play() is not implemented")


class VideoBrowserWindow(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        self.adapter = kwargs.pop("adapter", None)
        self.categories = []
        self.videos = []
        self.current_category = None
        self.current_page = 1
        self.loading = False
        self.initialized = False
        self.last_focus_id = CATEGORY_LIST_ID
        self.last_category_index = 0
        self.last_video_index = 0
        super(VideoBrowserWindow, self).__init__(*args, **kwargs)

    def onInit(self):
        if self.initialized:
            self._restore_position()
            return
        self.initialized = True
        if not self.adapter:
            raise UIError("ManituxUI adapter is required")
        self.setProperty("addon_title", _text(getattr(self.adapter, "title", "Manitux")))
        self._load_categories()

    def onAction(self, action):
        if action in (xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_PREVIOUS_MENU):
            self.close()

    def onClick(self, control_id):
        if self.loading:
            return
        self.last_focus_id = control_id
        if control_id == CATEGORY_LIST_ID:
            self._select_category()
        elif control_id == VIDEO_LIST_ID:
            self._open_selected_video()

    def _notify_error(self, message):
        xbmc.log("[manituxui] " + traceback.format_exc(), xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Manitux UI", message, xbmcgui.NOTIFICATION_ERROR, 4000)

    def _control(self, control_id):
        return self.getControl(control_id)

    def _set_loading(self, loading):
        self.loading = loading
        self.setProperty("loading", "true" if loading else "")

    def _restore_position(self):
        try:
            if self.categories:
                self._control(CATEGORY_LIST_ID).selectItem(self.last_category_index)
            if self.videos:
                self._control(VIDEO_LIST_ID).selectItem(self.last_video_index)
            self.setFocusId(self.last_focus_id)
        except Exception:
            xbmc.log("[manituxui] focus restore failed", xbmc.LOGDEBUG)

    def _load_categories(self):
        self._set_loading(True)
        try:
            xbmc.sleep(50)
            self.categories = _items(self.adapter.categories())
        except Exception:
            self.categories = []
            self._notify_error("Kategoriler yüklenemedi")
        finally:
            control = self._control(CATEGORY_LIST_ID)
            control.reset()
            for category in self.categories:
                title = _get(category, "title") or _get(category, "label") or _get(category, "name") or _text(category)
                control.addItem(xbmcgui.ListItem(label=_text(title, "Kategori")))
            if self.categories:
                control.selectItem(0)
                self.last_category_index = 0
                self.setProperty("empty_message", "Kategori seçin")
            else:
                self.setProperty("empty_message", "Kategori bulunamadı")
            self._set_loading(False)

    def _select_category(self):
        index = self._control(CATEGORY_LIST_ID).getSelectedPosition()
        if index < 0 or index >= len(self.categories):
            return
        self.last_category_index = index
        self.last_video_index = 0
        self.current_category = self.categories[index]
        self.current_page = 1
        self._load_videos()

    def _load_videos(self):
        self._set_loading(True)
        self.setProperty("empty_message", "")
        control = self._control(VIDEO_LIST_ID)
        control.reset()
        try:
            xbmc.sleep(50)
            self.videos = _items(self.adapter.videos(self.current_category, self.current_page))
        except Exception:
            self.videos = []
            self._notify_error("Videolar yüklenemedi")
        finally:
            if self.videos and self.current_page > 1:
                control.addItem(_make_page_item("Önceki Sayfa", self.current_page - 2, "previous"))
            for video in self.videos:
                control.addItem(_make_list_item(video))
            if self.videos:
                control.addItem(_make_page_item("Sonraki Sayfa", self.current_page, "next"))
            self.setProperty("empty_message", "" if self.videos else "Video bulunamadı")
            self._set_loading(False)

    def _focus_first_video(self):
        try:
            index = 1 if self.videos and self.current_page > 1 else 0
            self._control(VIDEO_LIST_ID).selectItem(index)
            self.setFocusId(VIDEO_LIST_ID)
            self.last_focus_id = VIDEO_LIST_ID
            self.last_video_index = index
        except Exception:
            xbmc.log("[manituxui] page focus failed", xbmc.LOGDEBUG)

    def _open_selected_video(self):
        index = self._control(VIDEO_LIST_ID).getSelectedPosition()
        if index < 0:
            return
        previous_offset = 1 if self.videos and self.current_page > 1 else 0
        if self.videos and self.current_page > 1 and index == 0:
            self.last_focus_id = VIDEO_LIST_ID
            self.last_video_index = 0
            self.current_page = max(1, self.current_page - 1)
            self._load_videos()
            self._focus_first_video()
            return
        if index == len(self.videos) + previous_offset and self.videos:
            self.last_focus_id = VIDEO_LIST_ID
            self.last_video_index = 0
            self.current_page += 1
            self._load_videos()
            self._focus_first_video()
            return
        video_index = index - previous_offset
        if video_index >= len(self.videos):
            return
        self.last_focus_id = VIDEO_LIST_ID
        self.last_video_index = index
        video = self.videos[video_index]
        detail_window = DetailWindow(
            DETAIL_XML,
            addon_path(),
            "Default",
            "1080i",
            adapter=self.adapter,
            video=video,
        )
        detail_window.doModal()
        del detail_window
        self._restore_position()


class DetailWindow(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        self.adapter = kwargs.pop("adapter", None)
        self.video = kwargs.pop("video", None)
        self.detail = kwargs.pop("detail", None) or self.video or {}
        self.play_context = self.detail
        self.episodes = []
        self.base_sources = []
        self.sources = []
        self.loading = False
        self.initialized = False
        self.last_focus_id = SOURCE_LIST_ID
        self.last_episode_index = 0
        self.last_source_index = 0
        super(DetailWindow, self).__init__(*args, **kwargs)

    def onInit(self):
        if self.initialized:
            self._restore_position()
            return
        self.initialized = True
        self._bind_detail()
        self._load_detail()

    def onAction(self, action):
        if action in (xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_PREVIOUS_MENU):
            self.close()

    def onClick(self, control_id):
        if self.loading:
            return
        self.last_focus_id = control_id
        if control_id == EPISODE_LIST_ID:
            self._select_episode()
        elif control_id == SOURCE_LIST_ID:
            self._play_selected_source()

    def _set_loading(self, loading):
        self.loading = loading
        self.setProperty("loading", "true" if loading else "")

    def _restore_position(self):
        try:
            if self.episodes:
                episode_index = min(self.last_episode_index, len(self.episodes) - 1)
                self.getControl(EPISODE_LIST_ID).selectItem(episode_index)
            if self.sources:
                source_index = min(self.last_source_index, len(self.sources) - 1)
                self.getControl(SOURCE_LIST_ID).selectItem(source_index)
            focus_id = self.last_focus_id
            if focus_id == EPISODE_LIST_ID and not self.episodes:
                focus_id = SOURCE_LIST_ID
            self.setFocusId(focus_id)
        except Exception:
            xbmc.log("[manituxui] detail focus restore failed", xbmc.LOGDEBUG)

    def _load_detail(self):
        self._set_loading(True)
        try:
            xbmc.sleep(50)
            self.detail = self.adapter.detail(self.video) or self.video or self.detail
        except Exception:
            xbmc.log("[manituxui] " + traceback.format_exc(), xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Manitux UI", "Ayrıntılar yüklenemedi", xbmcgui.NOTIFICATION_ERROR, 4000)
            self.detail = self.video or self.detail
        finally:
            self._bind_detail()
            self._set_loading(False)

    def _bind_detail(self):
        title = _text(_title(self.detail), "Video")
        plot = _text(_plot(self.detail))
        poster = _text(_image(self.detail))
        backdrop = _text(_backdrop(self.detail))
        self.setProperty("title", title)
        self.setProperty("plot", plot)
        self.setProperty("poster", poster)
        self.setProperty("backdrop", backdrop)
        self.setProperty("meta_line", _metadata_line(self.detail))
        self.setProperty("actors_line", _actors_line(self.detail))
        self.episodes = _items(_episodes(self.detail))
        self.setProperty("has_episodes", "true" if self.episodes else "")
        self._bind_episodes()
        self.play_context = self.detail
        self.base_sources = _items(_sources(self.detail))
        self.sources = list(self.base_sources)
        self._bind_sources()
        if self.episodes:
            try:
                self.setFocusId(EPISODE_LIST_ID)
                self.last_focus_id = EPISODE_LIST_ID
            except Exception:
                pass

    def _bind_episodes(self):
        control = self.getControl(EPISODE_LIST_ID)
        control.reset()
        for index, episode in enumerate(self.episodes, 1):
            label = _get(episode, "label") or _get(episode, "title") or "Bölüm {0}".format(index)
            control.addItem(xbmcgui.ListItem(label=_text(label)))

    def _bind_sources(self):
        control = self.getControl(SOURCE_LIST_ID)
        control.reset()
        for index, source in enumerate(self.sources, 1):
            label = _get(source, "label") or _get(source, "title") or _get(source, "quality") or "Oynat {0}".format(index)
            item = xbmcgui.ListItem(label=_text(label))
            item.setProperty("is_play", "true")
            control.addItem(item)
        if not self.sources:
            label = "Bölüm seçin" if self.episodes else "Kaynak bulunamadı"
            control.addItem(xbmcgui.ListItem(label=label))

    def _select_episode(self):
        index = self.getControl(EPISODE_LIST_ID).getSelectedPosition()
        if index < 0 or index >= len(self.episodes):
            return
        self.last_episode_index = index
        episode = self.episodes[index]
        self._set_loading(True)
        try:
            xbmc.sleep(50)
            detail = self.adapter.episode_detail(episode, self.detail) or episode
            self.play_context = detail
            episode_sources = _items(_sources(detail))
            first_episode_source = len(self.base_sources) if episode_sources else 0
            self.sources = list(self.base_sources) + episode_sources
        except Exception:
            self.sources = []
            first_episode_source = 0
            xbmc.log("[manituxui] " + traceback.format_exc(), xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Manitux UI", "Bölüm kaynakları yüklenemedi", xbmcgui.NOTIFICATION_ERROR, 4000)
        finally:
            self._bind_sources()
            self._set_loading(False)
            try:
                if self.sources:
                    self.getControl(SOURCE_LIST_ID).selectItem(first_episode_source)
                    self.last_source_index = first_episode_source
                self.setFocusId(SOURCE_LIST_ID)
                self.last_focus_id = SOURCE_LIST_ID
            except Exception:
                pass

    def _play_selected_source(self):
        index = self.getControl(SOURCE_LIST_ID).getSelectedPosition()
        if index < 0 or index >= len(self.sources):
            return
        self.last_source_index = index
        self.last_focus_id = SOURCE_LIST_ID
        try:
            self.adapter.play(self.sources[index], self.play_context)
        except Exception:
            xbmc.log("[manituxui] " + traceback.format_exc(), xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Manitux UI", "Oynatma başlatılamadı", xbmcgui.NOTIFICATION_ERROR, 4000)


DetailDialog = DetailWindow


def open_browser(adapter):
    window = VideoBrowserWindow(WINDOW_XML, addon_path(), "Default", "1080i", adapter=adapter)
    window.doModal()
    del window
