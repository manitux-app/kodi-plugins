# Manitux UI

`script.module.manituxui`, Manitux video eklentilerinin ortak kullanabilecegi
WindowXML tabanli bir arayuz saglar.

## Akis

- Sol panelde video kategorileri listelenir.
- Kategori seçilince sağ panelde poster grid'i yüklenir.
- Poster seçilince ayrıntı penceresi açılır.
- Ayrinti penceresinde poster, backdrop, aciklama ve oynatma kaynaklari gorunur.

## Adapter

Her eklenti kendi `site` sinifini ince bir adapter ile UI'a baglar:

```python
from manituxui import ManituxUI, open_browser


class MyUI(ManituxUI):
    title = "Eklenti Adi"

    def categories(self):
        return [{"title": title, "url": url} for title, url in site.categories()]

    def videos(self, category, page=1):
        items = site.get_page_items(category["url"], page)
        return [
            {
                "title": item["title"],
                "image": item.get("image", ""),
                "backdrop": item.get("fanart") or item.get("image", ""),
                "plot": item.get("plot", ""),
                "url": item["url"],
            }
            for item in items
        ]

    def detail(self, video):
        info = site.detail(video["url"])
        return {
            "title": info.get("title") or video["title"],
            "image": info.get("image") or video.get("image", ""),
            "backdrop": info.get("backdrop") or info.get("image") or video.get("image", ""),
            "plot": info.get("plot", ""),
            "year": info.get("year", ""),
            "country": info.get("country", ""),
            "duration": info.get("duration", ""),
            "rating": info.get("rating", ""),
            "tags": info.get("tags", ""),
            "actors": info.get("actors", ""),
            "episodes": info.get("episodes", []),
            "sources": info.get("sources", []),
        }

    def play(self, source, video=None):
        play_source(source["url"], source.get("referer"), source.get("label", ""))


open_browser(MyUI())
```

Adapter sozlesmesi esnektir: kategori, video ve kaynaklar dict veya attribute
tasiyan nesneler olabilir. Video gorselleri icin `image`, `poster`, `thumb` veya
`icon`; backdrop icin `backdrop` veya `fanart`; aciklama icin `plot`,
`description` veya `overview` okunur. Ayrinti metadata satiri icin `year`,
`country`, `duration`, `rating`, `tags`/`genres` ve `actors`/`cast` alanlari
gosterilir. Dizi bolumleri icin `episodes`; oynatma listesi icin `sources`,
`play_buttons` veya `players` kullanilabilir. `episodes` varsa bolumler solda,
kaynaklar sağda gösterilir; bölüm seçilince adapter'in `episode_detail()`
metodu veya varsayılan olarak `detail(episode)` ile bölüm kaynakları yüklenir.
