# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import json
import os
import time

import xbmc
import xbmcvfs


DATA_DIR = xbmcvfs.translatePath("special://profile/addon_data/script.module.manituxui")
DATA_PATH = os.path.join(DATA_DIR, "continue_watching.json")
MINIMUM_PROGRESS = 10.0
FINISHED_RATIO = 0.95
FINISHED_REMAINING = 60.0


def _load():
    try:
        with open(DATA_PATH, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, list) else []
    except (OSError, ValueError, TypeError):
        return []


def _save(items):
    if not os.path.isdir(DATA_DIR):
        os.makedirs(DATA_DIR)
    temporary_path = DATA_PATH + ".tmp"
    with open(temporary_path, "w", encoding="utf-8") as handle:
        json.dump(items, handle, ensure_ascii=False, indent=2, sort_keys=True)
    os.replace(temporary_path, DATA_PATH)


def _safe(value):
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, dict):
        return {str(key): _safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_safe(item) for item in value]
    return str(value)


def _key(owner, url):
    return str(owner or "") + "|" + str(url or "")


def get_continue_items(owner=None):
    items = sorted(_load(), key=lambda item: float(item.get("updated") or 0), reverse=True)
    if owner:
        items = [item for item in items if item.get("owner") == owner]
    return items


def get_progress(owner, url):
    item_key = _key(owner, url)
    matches = []
    for item in _load():
        context = item.get("context") or {}
        exact_match = _key(item.get("owner"), item.get("url")) == item_key
        parent_match = item.get("owner") == owner and context.get("parent_url") == url
        if exact_match or parent_match:
            matches.append(item)
    return max(matches, key=lambda item: float(item.get("updated") or 0)) if matches else None


def remove_progress(owner, url):
    item_key = _key(owner, url)
    items = [item for item in _load() if _key(item.get("owner"), item.get("url")) != item_key]
    _save(items)


def save_progress(owner, video, source, position, total):
    video = dict(video or {})
    url = video.get("url") or ""
    if not url:
        return
    position = max(0.0, float(position or 0))
    total = max(0.0, float(total or 0))
    finished = total > 0 and (position / total >= FINISHED_RATIO or total - position <= FINISHED_REMAINING)
    if position < MINIMUM_PROGRESS or finished:
        remove_progress(owner, url)
        return

    record = {
        "owner": str(owner or ""),
        "url": str(url),
        "title": str(video.get("title") or video.get("label") or "Video"),
        "image": str(video.get("image") or video.get("poster") or video.get("thumb") or ""),
        "backdrop": str(video.get("backdrop") or video.get("fanart") or video.get("image") or ""),
        "plot": str(video.get("plot") or video.get("description") or ""),
        "position": position,
        "total": total,
        "source": _safe(source or {}),
        "context": _safe(video),
        "updated": time.time(),
    }
    item_key = _key(owner, url)
    items = [item for item in _load() if _key(item.get("owner"), item.get("url")) != item_key]
    items.append(record)
    _save(items)


def play_and_track(stream, list_item, owner, video, source, resume_time=0):
    player = xbmc.Player()
    resume_time = max(0.0, float(resume_time or 0))
    if resume_time:
        list_item.setProperty("StartOffset", str(resume_time))
    player.play(stream, list_item)

    monitor = xbmc.Monitor()
    for _ in range(150):
        if monitor.abortRequested() or player.isPlayingVideo():
            break
        xbmc.sleep(100)
    if not player.isPlayingVideo():
        return

    if resume_time:
        xbmc.sleep(500)
        try:
            player.seekTime(resume_time)
        except Exception:
            pass

    position = resume_time
    total = 0.0
    while player.isPlayingVideo() and not monitor.abortRequested():
        try:
            position = player.getTime()
            total = player.getTotalTime()
        except Exception:
            pass
        if monitor.waitForAbort(0.5):
            break
    save_progress(owner, video, source, position, total)


def format_time(seconds):
    seconds = max(0, int(float(seconds or 0)))
    hours, remainder = divmod(seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    return "{:02d}:{:02d}:{:02d}".format(hours, minutes, seconds) if hours else "{:02d}:{:02d}".format(minutes, seconds)
