# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import json
import os

import xbmcvfs


FAVORITES_DIR = xbmcvfs.translatePath("special://profile/addon_data/script.module.manituxui")
FAVORITES_PATH = os.path.join(FAVORITES_DIR, "favorites.json")


def _load():
    try:
        with open(FAVORITES_PATH, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, list) else []
    except (OSError, ValueError, TypeError):
        return []


def _save(items):
    if not os.path.isdir(FAVORITES_DIR):
        os.makedirs(FAVORITES_DIR)
    temporary_path = FAVORITES_PATH + ".tmp"
    with open(temporary_path, "w", encoding="utf-8") as handle:
        json.dump(items, handle, ensure_ascii=False, indent=2, sort_keys=True)
    os.replace(temporary_path, FAVORITES_PATH)


def _key(item):
    owner = str(item.get("owner") or "")
    identity = str(item.get("url") or item.get("title") or "")
    return owner + "|" + identity


def get_favorites(owner=None):
    items = _load()
    if owner:
        items = [item for item in items if item.get("owner") == owner]
    return items


def is_favorite(item):
    item_key = _key(item)
    return bool(item_key.strip("|") and any(_key(saved) == item_key for saved in _load()))


def toggle_favorite(item):
    items = _load()
    item_key = _key(item)
    if not item_key.strip("|"):
        return False
    filtered = [saved for saved in items if _key(saved) != item_key]
    if len(filtered) != len(items):
        _save(filtered)
        return False
    filtered.append(item)
    _save(filtered)
    return True
