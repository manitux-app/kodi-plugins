# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import threading

try:
    import queue
except ImportError:
    import Queue as queue

import xbmc
import xbmcgui


CATEGORY_LOAD_TIMEOUT = 15


class CategoryLoadTimeout(RuntimeError):
    pass


def load_category(callback, timeout=CATEGORY_LOAD_TIMEOUT):
    results = queue.Queue(maxsize=1)

    def load():
        try:
            results.put((True, callback()))
        except Exception as exc:
            results.put((False, exc))

    worker = threading.Thread(target=load, name="ManituxCategoryLoader")
    worker.daemon = True
    worker.start()
    try:
        succeeded, value = results.get(timeout=timeout)
    except queue.Empty:
        raise CategoryLoadTimeout("Kategori yükleme zaman aşımı")
    if not succeeded:
        raise value
    return value


def reset_plugin_selection(message="Kategori yükleme zaman aşımına uğradı"):
    for name in (
        "Manitux.CurrentPluginId",
        "Manitux.CurrentPluginName",
        "Manitux.CurrentPluginIcon",
        "Manitux.CurrentPluginCategoryName",
        "Manitux.CurrentPluginCategoryPath",
        "Manitux.CurrentPluginCategoryPage",
        "Manitux.CurrentPluginPreviousPage",
        "Manitux.CurrentPluginNextPage",
        "Manitux.Loading",
    ):
        xbmc.executebuiltin("Skin.Reset({0})".format(name))
    xbmcgui.Dialog().notification("Manitux", message, xbmcgui.NOTIFICATION_ERROR, 4000)
